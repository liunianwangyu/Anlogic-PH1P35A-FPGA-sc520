"""Build the same freestanding RV32 integer ABI with pinned audio libraries."""
from pathlib import Path
import os,subprocess,argparse
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--assets-file',type=Path);parser.add_argument('--output-dir',type=Path)
parser.add_argument('--display-position-ms',type=int,choices=[250,400,600],help='Synthetic display-hold experiment; default uses cnn_model_config.h')
args=parser.parse_args()
if args.display_position_ms is not None and args.output_dir is None:parser.error('Display-hold experiments require a separate --output-dir')
fd=Path(os.environ.get('FD_HOME',str(next(p for p in root.parents if (p/'Application/FD').is_dir())/'Application/FD')))
tools=fd/'toolchain/gcc/riscv/ph1p35/bin'
out=args.output_dir or root/'build';out.mkdir(parents=True,exist_ok=True)
objects=out/'objects';objects.mkdir(exist_ok=True)
helix=root/'third_party/helix';fatfs=root/'third_party/fatfs/source'
flags=['-march=rv32im_zicsr','-mabi=ilp32','-Os','-g','-ffreestanding','-fno-builtin',
 '-ffunction-sections','-fdata-sections','-fstack-usage','-fno-strict-aliasing','-fwrapv',
 '-Wall','-Wextra','-Werror','-nostdlib',
 *[x for p in [root/'sc520_platform',root/'src',helix/'pub',helix/'real',fatfs] for x in ['-I',str(p)]]]
sources=sorted((root/'src').glob('*.c'))+sorted((root/'src').glob('*.S'))
if args.display_position_ms is not None:flags.append('-DCNN_DISPLAY_POSITION_MS='+str(args.display_position_ms)+'u')
if args.assets_file:sources=[p for p in sources if p.name!='voice_assets.c']+[args.assets_file.resolve()]
sources += [helix/'mp3dec.c',helix/'mp3tabs.c',*sorted((helix/'real').glob('*.c')),fatfs/'ff.c']
commands=[];objs=[]
for p in sources:
 obj=objects/(('_'.join(p.relative_to(root).parts) if p.is_relative_to(root) else p.name)+'.o');objs.append(str(obj))
 extra=['-Wno-unused-parameter','-Wno-sign-compare','-Wno-unused-but-set-variable',
        '-Wno-implicit-fallthrough','-Wno-misleading-indentation','-Wno-shift-negative-value'] if 'third_party' in p.parts else []
 commands.append([str(tools/'riscv64-unknown-elf-gcc.exe'),*flags,*extra,'-c',str(p),'-o',str(obj)])
commands += [
 [str(tools/'riscv64-unknown-elf-gcc.exe'),*flags,'-Wl,--undefined=mcu_cnn_add,--undefined=mcu_cnn_finish,--gc-sections,-Map='+str(out/'ae_firmware.map'),
  '-T',str(root/'linker.ld'),*objs,'-lgcc','-o',str(out/'ae_firmware.elf')],
 [str(tools/'riscv64-unknown-elf-objcopy.exe'),'-O','binary',str(out/'ae_firmware.elf'),str(out/'ae_firmware.bin')],
 [str(tools/'riscv64-unknown-elf-size.exe'),str(out/'ae_firmware.elf')]]
with (out/'build.log').open('w') as log:
 for cmd in commands:
  p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  print(p.stdout,end='');log.write(p.stdout)
  if p.returncode:raise SystemExit(p.returncode)
print('FD toolchain build PASS:',out/'ae_firmware.elf')
