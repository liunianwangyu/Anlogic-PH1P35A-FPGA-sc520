"""Refresh FD import descriptors and the matching exported HPF (no board I/O)."""
from pathlib import Path
import json, os, shutil, subprocess
from xml.sax.saxutils import escape
from zipfile import ZipFile

root = Path(__file__).resolve().parent
fd = Path(os.environ.get('FD_HOME', str(next(p for p in root.parents if (p/'Application/FD').is_dir())/'Application/FD')))
platform = root / 'sc520_platform'
app = root / 'sc520_ae'
platform.mkdir(exist_ok=True)
app.mkdir(exist_ok=True)
# The initial ASCT location had one extra level; keep the final project flat.
nested = platform / 'sc520_platform' / '.fd'
if nested.exists() and not (platform / '.fd').exists():
    shutil.move(str(nested), str(platform / '.fd'))
    (platform / 'sc520_platform').rmdir()

hpf = root.parent / 'td_project/camera_to_dsi_display.hpf'
shutil.copy2(hpf, platform / hpf.name)
with ZipFile(hpf) as archive:
    for name in ['soc_plat.c', 'soc_plat.h', 'soc_plat.tcl']:
        (platform/name).write_bytes(archive.read('HPFs/'+name))
env = os.environ.copy()
env.update(BSP_RESOURCE_PATH=(fd/'data/embeddedsw').as_posix(),
           IDE_ROOT_PATH=fd.as_posix(), IDE_TOOL_PATH=(fd/'tools').as_posix())
tool = fd / 'tools/asct/asct.exe'
subprocess.run([str(tool), '-target', 'ph1p35', '-func', 'create_mss_from_hpf',
               '-chip', 'ph1p35', '-hpf', str(platform/hpf.name), '-mssfile',
               str(platform/'system.mss'), '-os', 'standalone', '-proc', 'rpu'],
               env=env, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
for folder in [platform, app]:
    config = folder / '.fd/project.json'
    obj = json.loads(config.read_text())
    obj['location'] = folder.as_posix()
    if folder == platform:
        obj['hpfFile'] = (platform/hpf.name).as_posix()
    else:
        obj['bspLocation'] = platform.as_posix()
        obj['templateName'] = 'sc520_ae_freestanding'
    config.write_text(json.dumps(obj, indent=4) + '\n')
    nature = ('com.anlogic.sdk.bsp.platformProject' if folder == platform
              else 'com.anlogic.sdk.app.applicationProject')
    build = '<buildCommand><name>org.eclipse.cdt.managedbuilder.core.genmakebuilder</name><arguments/></buildCommand>'
    links = ''
    if folder == app:
        links = '''<linkedResources>
<link><name>src</name><type>2</type><locationURI>PARENT-1-PROJECT_LOC/src</locationURI></link>
<link><name>linker.ld</name><type>1</type><locationURI>PARENT-1-PROJECT_LOC/linker.ld</locationURI></link>
<link><name>build</name><type>2</type><locationURI>PARENT-1-PROJECT_LOC/build</locationURI></link>
</linkedResources>'''
    (folder/'.project').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<projectDescription><name>{folder.name}</name><comment>SC520CS v1.5 TD/FD split</comment>
<projects>{'<project>sc520_platform</project>' if folder == app else ''}</projects>
<buildSpec>{build}</buildSpec><natures><nature>org.eclipse.cdt.core.cnature</nature>
<nature>{nature}</nature><nature>org.eclipse.cdt.managedbuilder.core.managedBuildNature</nature></natures>
{links}</projectDescription>''')
    kind = 'elf' if folder == app else 'lib'
    make = escape((fd/'toolchain/build-tools/bin/make.exe').as_posix())
    (folder/'.cproject').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<?fileVersion 4.0.0?>
<cproject storage_type_id="org.eclipse.cdt.core.XmlProjectDescriptionStorage">
<storageModule moduleId="org.eclipse.cdt.core.settings"><cconfiguration id="{folder.name}.default">
<storageModule buildSystemId="org.eclipse.cdt.managedbuilder.core.configurationDataProvider" id="{folder.name}.default" moduleId="org.eclipse.cdt.core.settings" name="Default">
<externalSettings/><extensions><extension id="org.eclipse.cdt.core.GNU_ELF" point="org.eclipse.cdt.core.BinaryParser"/></extensions></storageModule>
<storageModule moduleId="cdtBuildSystem" version="4.0.0">
<configuration artifactExtension="elf" artifactName="ae_firmware" id="{folder.name}.default" name="Default" parent="com.anlogic.sdk.embedcdt.managedbuild.cross.riscv.config.{kind}.debug">
<folderInfo id="{folder.name}.default.root" name="/" resourcePath="">
<toolChain id="{folder.name}.toolchain" name="GNU RISC-V Embedded GCC" superClass="com.anlogic.sdk.embedcdt.managedbuild.cross.riscv.toolchain.{kind}.debug">
<targetPlatform id="{folder.name}.target" binaryParser="org.eclipse.cdt.core.GNU_ELF"/>
<builder id="{folder.name}.builder" superClass="com.anlogic.sdk.embedcdt.managedbuild.cross.riscv.builder" command="{make}" arguments="" buildPath="${{workspace_loc:/{folder.name}}}" managedBuildOn="false" keepEnvironmentInBuildfile="false" autoBuildTarget="all" enableAutoBuild="false" incrementalBuildTarget="all" cleanBuildTarget="clean"/>
</toolChain></folderInfo><sourceEntries><entry flags="VALUE_WORKSPACE_PATH|RESOLVED" kind="sourcePath" name="src"/></sourceEntries>
</configuration></storageModule></cconfiguration></storageModule>
<storageModule moduleId="cdtBuildSystem" version="4.0.0"><project id="{folder.name}.project" name="{folder.name}" projectType="com.anlogic.sdk.embedcdt.managedbuild.cross.riscv.target.{kind}"/></storageModule>
</cproject>''')
print('FD Platform/Application refreshed; only official MCU clock setup and minimal AE startup are linked.')
