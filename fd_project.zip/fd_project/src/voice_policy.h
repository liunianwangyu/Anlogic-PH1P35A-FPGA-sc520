#ifndef VOICE_POLICY_H
#define VOICE_POLICY_H
#include <stdint.h>
#define VOICE_CLASSES 3
typedef struct {
 uint32_t episode,absent_since,last_start,event_order;
 uint8_t active,hits,negatives,reserved,attempted,cooldown; /* hits: 3-bit entry history */
 uint16_t priority;
 uint32_t played_count;
} voice_class;
typedef struct {
 voice_class classes[VOICE_CLASSES];
 uint32_t last_seq,last_time,order;
 uint8_t have_seq,allowed,fresh,padding;
} voice_policy;
void voice_unknown(voice_policy *p,uint32_t cancel_pending);
void voice_rearm(voice_policy *p);
void voice_snapshot(voice_policy *p,uint32_t seq,uint32_t valid,uint32_t mask,uint32_t now);
void voice_tick(voice_policy *p,uint32_t now,uint32_t allowed);
int voice_select(voice_policy *p,uint32_t now,uint32_t ready_mask);
void voice_started(voice_policy *p,uint32_t cls,uint32_t now);
void voice_failed(voice_policy *p,uint32_t cls);
#endif
