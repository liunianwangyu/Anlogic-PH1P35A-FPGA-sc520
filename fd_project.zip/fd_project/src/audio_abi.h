/* Generated from tools/audio_abi.json. */
#ifndef AUDIO_ABI_H
#define AUDIO_ABI_H
#define AA_REGISTER_BASE 0x400u
#define AA_INTERFACE_ID 0x41550202u
#define AA_CAPABILITY 32u
#define AA_ID 0x00u
#define AA_STATUS 0x04u
#define AA_TIME_MS 0x08u
#define AA_EVENTS 0x0cu
#define AA_PCM_BASE 0x10u
#define AA_SAMPLE_COUNT 0x14u
#define AA_START_TOKEN 0x18u
#define AA_ACK_TOKEN 0x1cu
#define AA_STOP_TOKEN 0x20u
#define AA_FIFO_LEVEL 0x24u
#define AA_ERROR_CODE 0x28u
#define AA_FIRST_SAMPLE_MS 0x2cu
#define AA_SD_CONTROL 0x30u
#define AA_SD_BYTE 0x34u
#define AA_SD_STATUS 0x38u
#define AA_SD_READ_INDEX 0x3cu
#define AA_SD_SEQUENCE 0x40u
#define AA_SD_READ_BLOCK 0x44u
#define AA_SD_DATA 0x48u
#define AA_DDR_STATUS 0x50u
#define AA_DDR_MAX_WAIT 0x54u
#define AA_CACHE_ADDRESS 0x60u
#define AA_CACHE_DATA0 0x64u
#define AA_CACHE_DATA1 0x68u
#define AA_CACHE_DATA2 0x6cu
#define AA_CACHE_DATA3 0x70u
#define AA_CACHE_TOKEN 0x74u
#define AA_DONE_TOKEN 0x78u
#define AA_UNDERFLOWS 0x7cu
#endif
