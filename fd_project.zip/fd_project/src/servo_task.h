#ifndef SERVO_TASK_H
#define SERVO_TASK_H
#include "cnn_tracker.h"
#define SERVO_US_0 1000u
#define SERVO_US_180 2000u
#define SERVO_MIN_DEG 20u
#define SERVO_MAX_DEG 160u
enum { SERVO_IDLE,SERVO_TRACK,SERVO_WAIT,SERVO_SEARCH,SERVO_RELOCK,SERVO_HOLD };
typedef struct {uint32_t token,seq,generation,policy,fresh0;cnn_geometry box0;} track_observation;
uint32_t servo_get(uint32_t id);
uint32_t servo_status(void);
void servo_set(uint32_t id,uint32_t value);
void servo_restore(const uint32_t *saved);
void servo_forget(void);
void servo_step(void);
void servo_on_commit(const track_observation *o);
#endif
