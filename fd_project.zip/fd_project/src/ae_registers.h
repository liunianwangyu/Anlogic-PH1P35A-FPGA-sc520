#ifndef SC520_AE_REGISTERS_H
#define SC520_AE_REGISTERS_H
#include <stdint.h>
/* Official FD PH1P35 AHBDemo fabric window. AHB haddr omits address bit31. */
#define AE_BASE UINT32_C(0x80000000)
#define AE_INTERFACE_ID UINT32_C(0xAE150001)
#define AE_ID       0x00u
#define AE_STATUS   0x04u
#define AE_TOKEN    0x08u
#define AE_CURRENT  0x0cu
#define AE_STATS    0x10u
#define AE_CORE_HZ  0x14u
#define AE_CLAIM    0x18u
#define AE_RESULT   0x1cu
#define AE_COMMIT   0x20u
#define AE_EVENTS   0x24u
#define AE_CAPABILITIES 0x28u
#define AE_PENDING  (1u << 0)
#define AE_DONE     (1u << 1)
#define AE_MANUAL   (1u << 5)
#define AE_ERROR    (1u << 8)
#endif
