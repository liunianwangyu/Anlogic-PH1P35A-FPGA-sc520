#include "mcu_tasks.h"

/* Reuse 4608 image bytes: one 8-bit capture, packed previous/background
 * references, then motion evidence and flood queue. No extra frame RAM. */
#define W 64
#define H 36
#define N (W*H)
#define MB 288u
#define QC ((N-MB)/2)
#define AREA(s) ((s)&65535u)
#define SUPPORT(s) (((s)>>16)&1023u)
#define NEGATIVE 0x80000000u
#define PAIRED 0x40000000u
#define BASE 0x180u
#define READ(a) mcu_read(BASE+(a))
#define WRITE(a,v) mcu_write(BASE+(a),(v))
static union {
    uint8_t pixel[N];
    struct { uint8_t seed[MB];uint16_t queue[QC]; } flood;
} frame;
static uint8_t reference[2][N/2];
static uint8_t mask[MB],work[MB];
static uint32_t boxes[8],tracks[8];
static uint32_t sizes[8]; // area, boundary support, quantized appearance and flags
static uint8_t track_age[8],owner[8];
static struct {
    uint32_t phase,index,token,next_phase,previous_valid,scan_row,objects,camera;
    uint32_t raw_count,work_count,head,tail,area,support,x1,y1,x2,y2,reset_background;
    int32_t candidate,best_score,best_dx,best_dy,scan_sum,scan_score,bias,coarse_dx,coarse_dy;
    int32_t contrast;
    uint32_t tone_sum,low_sum,component_valid,hw_registration;
} motion;
uint32_t motion_last_count,motion_last_camera,motion_last_score;
static uint32_t bit(const uint8_t *a,uint32_t p) { return (a[p>>3]>>(p&7u))&1u; }
static void set(uint8_t *a,uint32_t p) { a[p>>3]|=(uint8_t)(1u<<(p&7u)); }
static void clear(uint8_t *a,uint32_t p) { a[p>>3]&=(uint8_t)~(1u<<(p&7u)); }
static int32_t absolute(int32_t x) { return x<0?-x:x; }
static int32_t minimum(int32_t a,int32_t b) { return a<b?a:b; }
static int32_t maximum(int32_t a,int32_t b) { return a>b?a:b; }
static uint8_t clip(int32_t v) { return (uint8_t)(v<0?0:(v>255?255:v)); }
static inline __attribute__((always_inline)) uint32_t packed(uint32_t kind,uint32_t p)
{ return ((reference[kind][p>>1]>>((p&1u)*4))&15u)*16u+8u; }
static void put(uint8_t *a,uint32_t p,uint8_t value)
{
    uint32_t shift=(p&1u)*4u;
    a[p>>1]=(uint8_t)((a[p>>1]&~(15u<<shift))|((uint32_t)(value>>4)<<shift));
}
static int32_t interpolate(uint32_t kind,int32_t x,int32_t y,int32_t dx,int32_t dy)
{
    int32_t xx=x*4+dx,yy=y*4+dy;
    xx=maximum(0,minimum(xx,(W-1)*4-1));yy=maximum(0,minimum(yy,(H-1)*4-1));
    int32_t ix=xx>>2,iy=yy>>2,fx=xx&3,fy=yy&3;
    uint32_t p=(uint32_t)(iy*W+ix);
    if(!(fx|fy))return (int32_t)packed(kind,p);
    if(!fy)return (int32_t)(packed(kind,p)*(4-fx)+packed(kind,p+1)*fx+2)>>2;
    if(!fx)return (int32_t)(packed(kind,p)*(4-fy)+packed(kind,p+W)*fy+2)>>2;
    return (int32_t)(packed(kind,p)*(4-fx)*(4-fy)+packed(kind,p+1)*fx*(4-fy)+
                    packed(kind,p+W)*(4-fx)*fy+packed(kind,p+W+1)*fx*fy+8)>>4;
}
static uint32_t candidate(int32_t dx,int32_t dy)
{
    if(!motion.scan_row) { motion.scan_sum=0;motion.scan_score=0; }
    int32_t y=4+(int32_t)((motion.scan_row/2)%7u)*4;
    int32_t start=4+(int32_t)(motion.scan_row&1u)*28;
    if(motion.scan_row<14) {
        for(int32_t x=start;x<start+28;x+=4) {
            int32_t d=frame.pixel[y*W+x]-interpolate(0,x,y,dx,dy);
            motion.scan_sum+=d>32?32:(d< -32?-32:d);
        }
        mcu_service_ae();
    } else {
        int32_t bias=motion.scan_sum/98;
        for(int32_t x=start;x<start+28;x+=4) {
            int32_t d=absolute(frame.pixel[y*W+x]-interpolate(0,x,y,dx,dy)-bias);
            motion.scan_score+=d>24?24:d;
        }
        mcu_service_ae();
    }
    if(++motion.scan_row<28)return 0;
    motion.scan_row=0;
    if(motion.scan_score<motion.best_score || (motion.scan_score==motion.best_score&&
       absolute(dx)+absolute(dy)<absolute(motion.best_dx)+absolute(motion.best_dy))) {
        motion.best_score=motion.scan_score;motion.best_dx=dx;motion.best_dy=dy;motion.bias=motion.scan_sum/98;
    }
    return 1;
}
static void empty(uint32_t camera)
{
    for(uint32_t i=0;i<MB;i++)mask[i]=0;
    for(uint32_t i=0;i<8;i++) { boxes[i]=0xfc0000u;sizes[i]=0;owner[i]=255; }
    motion.objects=0;motion.camera=camera;motion.index=0;motion.phase=7;
}
static void update_reference(uint32_t reset,uint32_t next)
{ motion.index=0;motion.reset_background=reset;motion.next_phase=next;motion.phase=10; }
static void registered(void)
{
    motion_last_score=(uint32_t)motion.best_score;
    if(motion.best_score>98*10) { empty(1);update_reference(1,7); }
    else {
        for(uint32_t i=0;i<MB;i++) { mask[i]=0;work[i]=0; }
        motion.phase=4;motion.index=0;motion.raw_count=0;
    }
}
/* Edge displacement, rather than gain/offset or edge polarity, establishes
 * movement. The region must also have enough independent boundary evidence. */
static uint32_t displaced_edge(int32_t x,int32_t y,int32_t old)
{
    int32_t center=frame.pixel[y*W+x];uint32_t votes=0;
    for(int32_t yy=-1;yy<=1;yy++) {
        for(int32_t xx=-1;xx<=1;xx++)if(xx||yy) {
            int32_t a=absolute(frame.pixel[(y+yy)*W+x+xx]-center);
            int32_t b=absolute(interpolate(0,x+xx,y+yy,motion.best_dx,motion.best_dy)-old);
            if((a>=32&&b<=8)||(a>=48&&b<=16))++votes;
        }
        mcu_service_ae();
    }
    return votes>=2;
}
static uint32_t bounds(uint32_t x1,uint32_t y1,uint32_t x2,uint32_t y2)
{ return (x1<<18)|(y1<<12)|(x2<<6)|y2; }
static uint32_t valid_box(uint32_t b) { return ((b>>18)&63u)<=((b>>6)&63u); }
static uint32_t join(uint32_t a,uint32_t b)
{
    return (a&0xff000000u)|bounds((uint32_t)minimum((a>>18)&63u,(b>>18)&63u),(uint32_t)minimum((a>>12)&63u,(b>>12)&63u),
                  (uint32_t)maximum((a>>6)&63u,(b>>6)&63u),(uint32_t)maximum(a&63u,b&63u));
}
static uint32_t qualified(uint32_t size)
{ return SUPPORT(size)>=3&&AREA(size)>=4&&SUPPORT(size)*12>=AREA(size); }
static void mark_component(uint32_t valid) { motion.head=0;motion.component_valid=valid;motion.phase=13; }
static void finish_component(void)
{
    if(motion.area<4) {
        mark_component(2);return;
    }
    uint32_t b=bounds(motion.x1,motion.y1,motion.x2,motion.y2)|((motion.tone_sum/motion.area)<<24),id=255;
    int32_t best=-100000;
    for(uint32_t i=0;i<8;i++)if(track_age[i]&&valid_box(tracks[i])) {
        uint32_t t=tracks[i];
        int32_t tx1=(int32_t)((t>>18)&63u)-motion.best_dx/4,ty1=(int32_t)((t>>12)&63u)-motion.best_dy/4;
        int32_t tx2=(int32_t)((t>>6)&63u)-motion.best_dx/4,ty2=(int32_t)(t&63u)-motion.best_dy/4;
        int32_t ix=minimum((int32_t)motion.x2,tx2+6)-maximum((int32_t)motion.x1,tx1-6)+1;
        int32_t iy=minimum((int32_t)motion.y2,ty2+6)-maximum((int32_t)motion.y1,ty1-6)+1;
        if(ix>0&&iy>0&&absolute((int32_t)(b>>24)-(int32_t)(t>>24))<=32) {
            int32_t overlap=maximum(0,minimum((int32_t)motion.x2,tx2)-maximum((int32_t)motion.x1,tx1)+1)*
                maximum(0,minimum((int32_t)motion.y2,ty2)-maximum((int32_t)motion.y1,ty1)+1);
            int32_t score=overlap*16-absolute((int32_t)(motion.x1+motion.x2)-tx1-tx2)-
                absolute((int32_t)(motion.y1+motion.y2)-ty1-ty2);
            if(score>best) { best=score;id=i; }
        }
    }
    uint32_t size=(motion.area+(motion.support<<16))|(motion.contrast<0?NEGATIVE:0)|
        ((motion.low_sum/motion.area/16u)<<26),good=qualified(size);
    // When the object was already in the initial reference, its old/new
    // silhouettes have opposite residual signs. Pair aligned nearby pieces
    // only if their inferred appearance agrees; do not join two new objects
    // just because their rectangles are close.
    for(uint32_t i=0;i<8;i++)if(sizes[i]&&owner[i]==id&&(good||qualified(sizes[i]))&&
       ((sizes[i]^size)&NEGATIVE)&&absolute((int32_t)(boxes[i]>>24)-(int32_t)(b>>24))<=24) {
        uint32_t a=boxes[i];
        int32_t ax1=(int32_t)((a>>18)&63u),ay1=(int32_t)((a>>12)&63u),ax2=(int32_t)((a>>6)&63u),ay2=(int32_t)(a&63u);
        int32_t ox=minimum(ax2,(int32_t)motion.x2)-maximum(ax1,(int32_t)motion.x1)+1;
        int32_t oy=minimum(ay2,(int32_t)motion.y2)-maximum(ay1,(int32_t)motion.y1)+1;
        int32_t gapx=maximum(ax1,(int32_t)motion.x1)-minimum(ax2,(int32_t)motion.x2)-1;
        int32_t gapy=maximum(ay1,(int32_t)motion.y1)-minimum(ay2,(int32_t)motion.y2)-1;
        uint32_t horizontal=gapx>=0&&gapx<=24&&oy*4>=minimum(ay2-ay1+1,(int32_t)(motion.y2-motion.y1+1))*3;
        uint32_t vertical=gapy>=0&&gapy<=24&&ox*4>=minimum(ax2-ax1+1,(int32_t)(motion.x2-motion.x1+1))*3;
        if(horizontal||vertical) {
            uint32_t combined=join(a,b),x1=(combined>>18)&63u,x2=(combined>>6)&63u;
            uint32_t y1=(combined>>12)&63u,y2=combined&63u;
            int32_t surrounding=(int32_t)(packed(0,(y1-1)*W+x1)+packed(0,(y2+1)*W+x2)+
                packed(0,y1*W+x2+1)+packed(0,y2*W+x1-1))/4;
            int32_t hi=(int32_t)(a>>24),lo=(int32_t)(((sizes[i]>>26)&15u)*16u+8u);
            uint32_t tone=(uint32_t)(absolute(surrounding-hi)<absolute(surrounding-lo)?lo:hi);
            // A wide unchanged interior can separate the two moving edges.
            // Require appearance continuity through that interior, rather
            // than unconditionally joining distant aligned rectangles.
            if((horizontal&&gapx>3)||(!horizontal&&gapy>3)) {
                uint32_t matches=0;
                for(int32_t sample=1;sample<=3;sample++) {
                    int32_t sx,sy;
                    if(horizontal) {
                        int32_t left=minimum(ax2,(int32_t)motion.x2),right=maximum(ax1,(int32_t)motion.x1);
                        sx=left+(right-left)*sample/4;
                        sy=(maximum(ay1,(int32_t)motion.y1)+minimum(ay2,(int32_t)motion.y2))/2;
                    } else {
                        int32_t top=minimum(ay2,(int32_t)motion.y2),bottom=maximum(ay1,(int32_t)motion.y1);
                        sy=top+(bottom-top)*sample/4;
                        sx=(maximum(ax1,(int32_t)motion.x1)+minimum(ax2,(int32_t)motion.x2))/2;
                    }
                    uint32_t p=(uint32_t)(sy*W+sx);
                    if(absolute((int32_t)packed(0,p)-(int32_t)tone)<=24||
                       absolute((int32_t)packed(1,p)-(int32_t)tone)<=24)++matches;
                }
                if(matches<3)continue;
            }
            uint32_t old=qualified(sizes[i]);
            boxes[i]=(combined&0xffffffu)|(tone<<24);
            sizes[i]=(sizes[i]+motion.area+(motion.support<<16))|PAIRED;
            motion.objects=(uint32_t)minimum((int32_t)(motion.objects-old+qualified(sizes[i])),99);
            mark_component(qualified(sizes[i]));return;
        }
    }
    if(id<8)for(uint32_t i=0;i<8;i++)if(sizes[i]&&owner[i]==id) {
        uint32_t old=qualified(sizes[i]);
        boxes[i]=join(boxes[i],b);sizes[i]+=motion.area+(motion.support<<16);
        motion.objects=(uint32_t)minimum((int32_t)(motion.objects-old+qualified(sizes[i])),99);
        mark_component(qualified(sizes[i]));return;
    }
    if(good&&motion.objects<99)++motion.objects;
    uint32_t slot=8,rank=3;
    for(uint32_t i=0;i<8;i++) {
        uint32_t r=sizes[i]?(qualified(sizes[i])?2u:1u):0u;
        if(!good&&r==2)continue;
        if(r<rank||(r==rank&&(slot==8||AREA(sizes[i])<AREA(sizes[slot])))) { slot=i;rank=r; }
    }
    if(slot<8&&(!sizes[slot]||(good&&!qualified(sizes[slot]))||motion.area>AREA(sizes[slot]))) {
        sizes[slot]=size;boxes[slot]=b;owner[slot]=(uint8_t)id;
    }
    mark_component(good);
}
static void enqueue(int32_t x,int32_t y)
{
    if(x<0||x>=W||y<0||y>=H)return;
    uint32_t p=(uint32_t)(y*W+x);
    if(!bit(work,p))return;
    clear(work,p);
    if(motion.tail>=QC) { motion.camera=1;return; }
    frame.flood.queue[motion.tail++]=(uint16_t)p;
}
static void publish_tracks(void)
{
    for(uint32_t i=0;i<8;i++)if(track_age[i])--track_age[i];
    if(motion.camera) { for(uint32_t i=0;i<8;i++)track_age[i]=0;return; }
    for(uint32_t i=0;i<8;i++)if(sizes[i]) {
        uint32_t id=owner[i],b=boxes[i];
        if(id>=8) {
            id=0;for(uint32_t j=1;j<8;j++)if(track_age[j]<track_age[id])id=j;
            if(track_age[id])continue;
        } else {
            uint32_t t=tracks[id],w=((t>>6)&63u)-((t>>18)&63u),h=(t&63u)-((t>>12)&63u);
            uint32_t x1=(b>>18)&63u,y1=(b>>12)&63u,x2=(b>>6)&63u,y2=b&63u;
            if(x2-x1<w) {
                if(x1>((t>>18)&63u))x2=(uint32_t)minimum((int32_t)(x1+w),W-4);
                else x1=(uint32_t)maximum(3,(int32_t)x2-(int32_t)w);
            }
            if(y2-y1<h) {
                if(y1>((t>>12)&63u))y2=(uint32_t)minimum((int32_t)(y1+h),H-4);
                else y1=(uint32_t)maximum(3,(int32_t)y2-(int32_t)h);
            }
            b=(b&0xff000000u)|bounds(x1,y1,x2,y2);
        }
        tracks[id]=b;track_age[id]=3;
    }
}
void mcu_motion_step(void)
{
    uint32_t status=READ(4);
    if(!(status&2u)) { motion.previous_valid=0;for(uint32_t i=0;i<8;i++)track_age[i]=0; }
    if(!(status&1u))return;
    uint32_t token=READ(8);
    if(!motion.phase||motion.token!=token) {
        motion.phase=1;motion.index=0;motion.token=token;
        motion.hw_registration=READ(12)>>31;WRITE(12,0);
    }
    if(!(status&2u)&&motion.phase!=7)empty(0);
    if(motion.phase==1) {
        for(uint32_t i=0;i<16&&motion.index<N;i++)frame.pixel[motion.index++]=(uint8_t)READ(16);
        if(motion.index==N) {
            if(motion.hw_registration) {
                WRITE(12,N);uint32_t result=READ(16);
                if(!(result>>31)) {
                    motion.previous_valid=0;
                    for(uint32_t i=0;i<8;i++)track_age[i]=0;
                }
                if(motion.previous_valid) {
                    motion.best_dx=(int32_t)(result<<26)>>26;
                    motion.best_dy=(int32_t)(result<<20)>>26;
                    motion.bias=(int32_t)(result<<13)>>25;
                    motion.best_score=(int32_t)((result>>19)&4095u);
                    registered();return;
                }
            }
            if(!motion.previous_valid) { empty(0);update_reference(1,7); }
            else {
                motion.phase=2;motion.candidate=0;motion.scan_row=0;motion.best_score=0x7fffffff;
                motion.best_dx=0;motion.best_dy=0;motion.bias=0;
            }
        }
    } else if(motion.phase==2) {
        int32_t c=motion.candidate;
        if(c==0) { if(!candidate(0,0))return;if(motion.best_score<=98*6) { registered();return; } }
        else if(!candidate(((c-1)%5-2)*4,((c-1)/5-2)*4))return;
        if(++motion.candidate==26) {
            motion.coarse_dx=motion.best_dx;motion.coarse_dy=motion.best_dy;motion.phase=3;motion.candidate=0;
        }
    } else if(motion.phase==3) {
        int32_t c=motion.candidate;
        if(!candidate(motion.coarse_dx+c%7-3,motion.coarse_dy+c/7-3))return;
        if(++motion.candidate==49)registered();
    } else if(motion.phase==4) {
        uint32_t end=motion.index+1;if(end>N)end=N;
        for(;motion.index<end;motion.index++) {
            int32_t x=(int32_t)(motion.index%W),y=(int32_t)(motion.index/W);
            if(x<3||x>=W-3||y<3||y>=H-3)continue;
            int32_t value=frame.pixel[motion.index];
            int32_t bg=interpolate(1,x,y,motion.best_dx,motion.best_dy)+motion.bias;
            if(absolute(value-bg)>24) { set(mask,motion.index);++motion.raw_count; }
            int32_t old=interpolate(0,x,y,motion.best_dx,motion.best_dy);
            if(absolute(value-old-motion.bias)>24&&displaced_edge(x,y,old))set(work,motion.index);
        }
        if(motion.index==N) {
            if(motion.raw_count>N/4) { empty(1);update_reference(1,7); }
            else if(!motion.raw_count) { empty(0);update_reference(0,7); }
            else update_reference(0,9);
        }
    } else if(motion.phase==10) {
        uint32_t end=motion.index+8;if(end>N)end=N;
        for(;motion.index<end;motion.index++) {
            uint32_t p=motion.index;int32_t x=(int32_t)(p%W),y=(int32_t)(p/W);
            uint8_t value=frame.pixel[p],bg=value;
            if(!motion.reset_background&&x>=3&&x<W-3&&y>=3&&y<H-3&&bit(mask,p))
                bg=clip(interpolate(1,x,y,motion.best_dx,motion.best_dy)+motion.bias);
            put(reference[0],p,value);
            put(frame.pixel,p,bg);
        }
        if(motion.index==N) { motion.phase=11;motion.index=0; }
    } else if(motion.phase==11) {
        uint32_t end=motion.index+128;if(end>N/2)end=N/2;
        for(;motion.index<end;motion.index++)reference[1][motion.index]=frame.pixel[motion.index];
        if(motion.index==N/2) { motion.phase=motion.next_phase;motion.index=0; }
    } else if(motion.phase==9) {
        uint32_t end=motion.index+4;if(end>N)end=N;
        for(;motion.index<end;motion.index++) {
            int32_t x=(int32_t)(motion.index%W),y=(int32_t)(motion.index/W);uint8_t hit=0;
            if(x>=2&&x<W-2&&y>=2&&y<H-2)
                for(int32_t yy=-1;yy<=1;yy++)for(int32_t xx=-1;xx<=1;xx++)
                    if(bit(mask,(uint32_t)((y+yy)*W+x+xx)))hit=1;
            frame.pixel[motion.index]=hit;
        }
        if(motion.index==N) { motion.phase=5;motion.index=0;motion.work_count=0; }
    } else if(motion.phase==5) {
        uint32_t end=motion.index+4;if(end>N)end=N;
        for(;motion.index<end;motion.index++) {
            int32_t x=(int32_t)(motion.index%W),y=(int32_t)(motion.index/W);uint32_t hit=1;
            if(x<3||x>=W-3||y<3||y>=H-3)hit=0;
            else for(int32_t yy=-1;yy<=1;yy++)for(int32_t xx=-1;xx<=1;xx++)
                if(!frame.pixel[(y+yy)*W+x+xx])hit=0;
            // Closing must not bridge a visible static post or a strong
            // background edge. Reference 0 now holds this frame's luminance.
            if(hit&&!bit(mask,motion.index)) {
                int32_t value=(int32_t)packed(0,motion.index);
                if(absolute(value-(int32_t)packed(0,motion.index-1))>=32||
                   absolute(value-(int32_t)packed(0,motion.index+1))>=32||
                   absolute(value-(int32_t)packed(0,motion.index-W))>=32||
                   absolute(value-(int32_t)packed(0,motion.index+W))>=32)hit=0;
            }
            if(hit) { set(mask,motion.index);++motion.work_count; }else clear(mask,motion.index);
        }
        if(motion.index==N) {
            if(motion.work_count>=QC)empty(1);
            else { motion.phase=8;motion.index=0;motion.objects=0;motion.camera=0;motion.head=0;motion.tail=0;
                for(uint32_t i=0;i<8;i++) { boxes[i]=0xfc0000u;sizes[i]=0;owner[i]=255; } }
        }
    } else if(motion.phase==8) {
        uint32_t end=motion.index+64;if(end>MB)end=MB;
        for(;motion.index<end;motion.index++) { frame.flood.seed[motion.index]=work[motion.index];work[motion.index]=mask[motion.index]; }
        if(motion.index==MB) { motion.phase=6;motion.index=0; }
    } else if(motion.phase==6) {
        for(uint32_t slice=0;slice<4;slice++) {
            if(motion.head<motion.tail) {
                uint32_t p=frame.flood.queue[motion.head++],x=p%W,y=p/W;
                ++motion.area;motion.support+=bit(frame.flood.seed,p);
                int32_t now=(int32_t)packed(0,p),bg=(int32_t)packed(1,p);
                motion.contrast+=now-bg;motion.tone_sum+=(uint32_t)maximum(now,bg);
                motion.low_sum+=(uint32_t)minimum(now,bg);
                if(x<motion.x1)motion.x1=x;
                if(x>motion.x2)motion.x2=x;
                if(y<motion.y1)motion.y1=y;
                if(y>motion.y2)motion.y2=y;
                for(int32_t yy=-1;yy<=1;yy++)for(int32_t xx=-1;xx<=1;xx++)
                    if(xx||yy)enqueue((int32_t)x+xx,(int32_t)y+yy);
                if(motion.head==motion.tail) { finish_component();if(motion.phase!=6)break; }
            } else {
                if(motion.index==N) {
                    motion.phase=12;motion.index=0;
                    for(uint32_t i=0;i<8;i++) { work[i*4]=W;work[i*4+1]=H;work[i*4+2]=0;work[i*4+3]=0; }
                    break;
                }
                uint32_t p=motion.index++;
                if(bit(work,p)) {
                    motion.head=0;motion.tail=0;motion.area=0;motion.support=0;
                    motion.contrast=0;motion.tone_sum=0;motion.low_sum=0;
                    motion.x1=W;motion.y1=H;motion.x2=0;motion.y2=0;
                    enqueue((int32_t)(p%W),(int32_t)(p/W));
                }
            }
        }
        if(motion.camera)empty(1);
    } else if(motion.phase==13) {
        uint32_t end=motion.head+16;if(end>motion.tail)end=motion.tail;
        for(;motion.head<end;motion.head++) {
            uint32_t p=frame.flood.queue[motion.head];
            if(motion.component_valid==1)set(frame.flood.seed,p);
            else clear(frame.flood.seed,p);
            if(motion.component_valid==2)clear(mask,p);
        }
        if(motion.head==motion.tail)motion.phase=6;
    } else if(motion.phase==12) {
        // A visible fragment can borrow motion support from another fragment
        // of its established track; stopped tracks publish neither count nor mask.
        uint32_t end=motion.index+8;if(end>N)end=N;
        for(;motion.index<end;motion.index++) {
            uint32_t x=motion.index%W,y=motion.index/W;
            uint32_t valid=bit(frame.flood.seed,motion.index),keep=0,reject=0;
            for(uint32_t i=0;i<8;i++)if(sizes[i]) {
                uint32_t b=boxes[i];
                if(x>=((b>>18)&63u)&&x<=((b>>6)&63u)&&y>=((b>>12)&63u)&&y<=(b&63u)) {
                    if(qualified(sizes[i])&&!(sizes[i]&PAIRED)) { keep=1;valid=1; }
                    else if(qualified(sizes[i])&&absolute((int32_t)packed(0,motion.index)-(int32_t)(b>>24))<=24) {
                        keep=1;valid=1;
                        set(mask,motion.index);
                        if(x<work[i*4])work[i*4]=(uint8_t)x;
                        if(y<work[i*4+1])work[i*4+1]=(uint8_t)y;
                        if(x>work[i*4+2])work[i*4+2]=(uint8_t)x;
                        if(y>work[i*4+3])work[i*4+3]=(uint8_t)y;
                    } else reject=1;
                }
            }
            if((reject&&!keep)||!valid)clear(mask,motion.index);
        }
        if(motion.index==N) {
            for(uint32_t i=0;i<8;i++) {
                if(qualified(sizes[i])&&(sizes[i]&PAIRED)) {
                    if(work[i*4]<=work[i*4+2])boxes[i]=(boxes[i]&0xff000000u)|
                        bounds(work[i*4],work[i*4+1],work[i*4+2],work[i*4+3]);
                    else { sizes[i]=0;if(motion.objects)--motion.objects; }
                }
                if(!qualified(sizes[i])) { sizes[i]=0;boxes[i]=0xfc0000u; }
            }
            motion.phase=14;motion.index=0;
        }
    } else if(motion.phase==14) {
        // Absorb photometric-only changes and stopped foreground after the
        // geometric decision. Otherwise a lit static region can permanently
        // contaminate segmentation when a real target later enters it.
        uint32_t end=motion.index+64;if(end>N)end=N;
        for(;motion.index<end;motion.index+=2) {
            uint32_t p=motion.index,now=reference[0][p>>1],bg=reference[1][p>>1];
            if(!bit(mask,p))bg=(bg&240u)|(now&15u);
            if(!bit(mask,p+1))bg=(bg&15u)|(now&240u);
            reference[1][p>>1]=(uint8_t)bg;
        }
        if(motion.index==N) { motion.phase=7;motion.index=0; }
    } else if(motion.phase==7) {
        if(motion.hw_registration)motion.index=MB; // rectangles-only MOT2 extension
        for(uint32_t i=0;i<8&&motion.index<MB;i++)WRITE(20,mask[motion.index++]);
        if(motion.index==MB) {
            for(uint32_t i=0;i<8;i++)WRITE(24,boxes[i]&0xffffffu);
            // Reuse the existing result transaction for both decimal displays.
            // Low byte remains the original count/camera ABI; no extra MMIO.
            uint32_t bcd=((motion.objects/10u)<<4)|(motion.objects%10u);
            WRITE(28,motion.objects|(motion.camera<<7)|(bcd<<8));WRITE(32,motion.token);
            publish_tracks();motion_last_count=motion.objects;motion_last_camera=motion.camera;
            motion.previous_valid=(status&2u)!=0;motion.phase=0;
        }
    }
}
