#ifndef SC520_AE_CALCULATE_H
#define SC520_AE_CALCULATE_H
#include <stdint.h>
typedef struct {
    uint16_t exposure;
    uint8_t gain, mean, clip_ratio, near_ratio;
} ae_input;
typedef struct {
    uint16_t exposure;
    uint8_t gain, update;
} ae_result;
ae_result ae_calculate(ae_input input);
#endif
