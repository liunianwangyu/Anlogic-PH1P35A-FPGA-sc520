#ifndef VOICE_ASSETS_H
#define VOICE_ASSETS_H
#include <stdint.h>
typedef struct {
 const char *path,*name;
 uint32_t configured,bytes,crc32,max_samples,priority;
} voice_asset;
extern const voice_asset voice_assets[3];
#endif
