#ifndef CNN_MODEL_CONFIG_H
#define CNN_MODEL_CONFIG_H
/* dataset1027_gray20_empty3: score is the signed objectness byte + 128.
 * Weak positions may extend a display cache but never vote for identity. */
#define CNN_MODEL_OBJ_THRESHOLD 131u
#define CNN_MODEL_WEAK_THRESHOLD 126u
#define CNN_MODEL_CLASS_MARGIN 4
/* 100 MHz cycle counter. These are bounded display evidence budgets. */
#ifndef CNN_DISPLAY_POSITION_MS
#define CNN_DISPLAY_POSITION_MS 400u
#endif
#define CNN_DISPLAY_CLASS_MS 600u
#define CNN_DISPLAY_RESET_MS 1000u
#define CNN_DISPLAY_SWITCH_HITS 3u
#define CNN_DISPLAY_SWITCH_MARGIN 8u
#endif
