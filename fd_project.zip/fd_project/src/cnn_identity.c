#include "cnn_model_config.h"
#include "cnn_identity.h"
#include "mcu_tasks.h"
#define MS 100000u
#define LOST (CNN_DISPLAY_POSITION_MS*MS)
#define WEAK (CNN_DISPLAY_CLASS_MS*MS)
#define RESET (CNN_DISPLAY_RESET_MS*MS)
#define ACTION (120u*MS)
typedef struct { cnn_geometry box; uint32_t score; uint8_t vote,used,root,pad; } candidate;
typedef struct {
    cnn_geometry raw,q2;
    uint32_t seen,strong;
    uint16_t votes;
    uint8_t count,label,suspect,streak,last_vote,live,fresh,score;
    uint8_t visible,pad[3];
} identity;
typedef struct {
    identity committed[2],working[2];
    uint32_t token,generation,policy,now,old_generation,old_policy,last_time;
    uint32_t accepted_token,accepted_seq,have,accepted,phase,cursor,best_cost;
    int8_t match[2],best[2];
    uint8_t ambiguous,display,actions,duplicate;
    /* One owner per class, encoded as cache slot + 1. Accept is the only
     * promotion point, including arbitration and challenge counters. */
    uint8_t owner[2],saved_owner[2],challenge[2],saved_challenge[2];
    uint8_t saved_display;
} workspace;
_Static_assert(sizeof(candidate)==sizeof(mcu_box),"reuse existing candidate DLM");
#define POOL ((candidate *)cnn_data.top)
#define CACHE (cnn_data.words)
static workspace state __attribute__((section(".audio_state.cnn_identity")));
_Static_assert(sizeof(workspace)<=1024,"CNN identity workspace budget");

static int32_t abs32(int32_t n) {return n<0?-n:n;}
static int32_t sb(uint32_t n) {return (int32_t)(n&255u)-((n&128u)?256:0);}
static int32_t clamp(int32_t n,int32_t top) {return n<0?0:(n>top?top:n);}
static void geometry(cnn_geometry *d,const cnn_geometry *s)
{d->cx=s->cx;d->cy=s->cy;d->hw=s->hw;d->hh=s->hh;}
/* Aligned word copies avoid audio_libc's byte checkpoints and main-stack
 * reentrancy. Records consist entirely of initialized 32-bit words. */
static void copy_tracks(identity *d,const identity *s)
{
    volatile uint32_t *out=(volatile uint32_t *)d;
    const uint32_t *in=(const uint32_t *)s;
    for(uint32_t i=0;i<sizeof(identity)*2/4;i++)out[i]=in[i];
}
static void clear_track(identity *t)
{volatile uint32_t *p=(volatile uint32_t *)t;for(uint32_t i=0;i<sizeof(*t)/4;i++)p[i]=0;}
static void clear_slot(uint32_t i)
{
    clear_track(&state.working[i]);
    for(uint32_t c=0;c<2;c++)if(state.owner[c]==i+1u){state.owner[c]=0;state.challenge[c]=0;}
}
static uint32_t same_object(const cnn_geometry *a,const cnn_geometry *b)
{
    int32_t l=a->cx-a->hw>b->cx-b->hw?a->cx-a->hw:b->cx-b->hw;
    int32_t r=a->cx+a->hw<b->cx+b->hw?a->cx+a->hw:b->cx+b->hw;
    int32_t t=a->cy-a->hh>b->cy-b->hh?a->cy-a->hh:b->cy-b->hh;
    int32_t u=a->cy+a->hh<b->cy+b->hh?a->cy+a->hh:b->cy+b->hh;
    if(r<=l||u<=t)return 0;
    uint32_t inter=(uint32_t)(r-l)*(uint32_t)(u-t);
    uint32_t aa=(uint32_t)(a->hw*a->hh)*4u,bb=(uint32_t)(b->hw*b->hh)*4u;
    uint32_t small=aa<bb?aa:bb;
    return inter*3u>=aa+bb || inter*5u>=small*4u;
}
static uint32_t cost(const identity *t,const candidate *c)
{
    if(!c->score||c->root!=(uint32_t)(c-POOL)||state.now-t->seen>LOST)return 2000000u;
    int32_t dx=abs32(t->raw.cx-c->box.cx),dy=abs32(t->raw.cy-c->box.cy);
    if(dx>(t->raw.hw>32?t->raw.hw:32)||dy>(t->raw.hh>24?t->raw.hh:24)||
       c->box.hw*2<t->raw.hw||c->box.hw>t->raw.hw*2||
       c->box.hh*2<t->raw.hh||c->box.hh>t->raw.hh*2)return 2000000u;
    return (uint32_t)(dx+dy+abs32(t->raw.hw-c->box.hw)+abs32(t->raw.hh-c->box.hh));
}
void cnn_identity_begin(uint32_t now,uint32_t token,uint32_t generation,uint32_t policy)
{
    state.now=now;state.token=token;state.generation=generation;state.policy=policy;
    state.phase=0;state.cursor=0;state.display=state.actions=state.ambiguous=0;
    state.duplicate=state.have&&generation==state.old_generation&&token==state.accepted_token;
    copy_tracks(state.working,state.committed);
    uint32_t reset=!state.have||generation!=state.old_generation||
        ((policy^state.old_policy)&(24u|8192u))||now-state.last_time>=RESET;
    for(uint32_t c=0;c<2;c++) {
        state.owner[c]=reset?0:state.saved_owner[c];
        state.challenge[c]=reset?0:state.saved_challenge[c];
    }
    for(uint32_t i=0;i<2;i++) {
        identity *t=&state.working[i];
        if(reset||(t->live&&now-t->strong>=RESET))clear_slot(i);
        /* Do not expire position before consuming this complete observation.
         * An already expired class needs two fresh compatible recovery votes. */
        if(t->live&&t->label&&now-t->strong>=WEAK){t->suspect=1;t->visible=0;}
        t->fresh=0;state.match[i]=state.best[i]=-1;
    }
    for(uint32_t i=0;i<8;i++){POOL[i].score=0;POOL[i].used=0;POOL[i].root=(uint8_t)i;}
    CACHE[0]=policy;CACHE[7]=CACHE[8]=0;CACHE[9]=0;CACHE[10]=4;
    for(uint32_t i=0;i<2;i++) {
        CACHE[1+i*3]=state.working[i].live;
        CACHE[2+i*3]=(uint32_t)state.working[i].raw.cx;CACHE[3+i*3]=(uint32_t)state.working[i].raw.cy;
    }
}
void __attribute__((optimize("O2"))) cnn_identity_add(uint32_t cell,uint32_t w0,uint32_t w1)
{
    uint32_t score=(w0+128u)&255u,w=w0>>24,h=w1&255u;
    if(score<CNN_MODEL_WEAK_THRESHOLD||!w||w>127u||!h||h>127u)return;
    int32_t c0=sb(w1>>8),c1=sb(w1>>16);
    uint32_t cls=c1>c0;
    if((state.policy&8192u)&&cls)return;
    /* Four spatial alternatives per class prevent a dense class from filling
     * the entire pool. Collapse adjacent equal-class cells before admission.
     * Near established objects retain priority over distant higher scores. */
    int32_t x=(int32_t)(cell%20u)*64+32+(sb(w0>>8)>>1);
    int32_t y=(int32_t)(cell/20u)*60+30+(sb(w0>>16)>>1);
    cnn_geometry b={x,y,(int32_t)w*4,(int32_t)h*4};
    uint32_t slot=cls*4u,rank=score,minimum=0xffffffffu,second=0xffffffffu;
    if((CACHE[1]&&(uint32_t)(x-(int32_t)CACHE[2]+32)<=64u&&(uint32_t)(y-(int32_t)CACHE[3]+24)<=48u)||
       (CACHE[4]&&(uint32_t)(x-(int32_t)CACHE[5]+32)<=64u&&(uint32_t)(y-(int32_t)CACHE[6]+24)<=48u))rank+=256u;
    if(rank<=CACHE[7+cls])return;
    for(uint32_t i=cls*4u;i<cls*4u+4u;i++) {
        candidate *p=&POOL[i];
        if(p->score<minimum){second=minimum;minimum=p->score;slot=i;}
        else if(p->score<second)second=p->score;
        if(!p->score||abs32(b.cx-p->box.cx)>32||abs32(b.cy-p->box.cy)>24)continue;
        int32_t gx=b.hw<p->box.hw?b.hw:p->box.hw,gy=b.hh<p->box.hh?b.hh:p->box.hh;
        if(abs32(b.cx-p->box.cx)<=gx&&abs32(b.cy-p->box.cy)<=gy&&
           b.hw*2>=p->box.hw&&p->box.hw*2>=b.hw&&b.hh*2>=p->box.hh&&p->box.hh*2>=b.hh) {
            if(rank>p->score){geometry(&p->box,&b);p->score=rank;p->vote=score>=CNN_MODEL_OBJ_THRESHOLD&&abs32(c0-c1)>=CNN_MODEL_CLASS_MARGIN?cls+1u:0;}
            return;
        }
    }
    if(rank<=POOL[slot].score)return;
    candidate *p=&POOL[slot];geometry(&p->box,&b);p->score=rank;
    p->vote=score>=CNN_MODEL_OBJ_THRESHOLD&&abs32(c0-c1)>=CNN_MODEL_CLASS_MARGIN?cls+1u:0;
    CACHE[7+cls]=rank<second?rank:second;
}
static uint32_t root(uint32_t i)
{while(POOL[i].root!=i)i=POOL[i].root;return i;}
static uint32_t votes(const identity *t,uint32_t label,uint32_t n)
{uint32_t total=0,h=t->votes;for(uint32_t i=0;i<n;i++){total+=(h&3u)==label;h>>=2;}return total;}
static void update(uint32_t i)
{
    identity *t=&state.working[i];int32_t idx=state.match[i];uint32_t vote=0;
    if(idx>=0) {
        candidate *c=&POOL[idx];vote=c->vote;
        if(!t->live) {
            clear_track(t);t->live=1;
            t->q2=(cnn_geometry){c->box.cx*4,c->box.cy*4,c->box.hw*4,c->box.hh*4};
            t->strong=state.now;
        } else if(!t->label||vote==t->label) {
            uint32_t fast=abs32(c->box.cx-t->raw.cx)>24||abs32(c->box.cy-t->raw.cy)>18;
            t->q2.cx=fast?c->box.cx*4:t->q2.cx+(c->box.cx*4-t->q2.cx)/2;
            t->q2.cy=fast?c->box.cy*4:t->q2.cy+(c->box.cy*4-t->q2.cy)/2;
            t->q2.hw+=(c->box.hw*4-t->q2.hw)/4;t->q2.hh+=(c->box.hh*4-t->q2.hh)/4;
        }
        geometry(&t->raw,&c->box);t->seen=state.now;t->score=(uint8_t)c->score;
        if(vote&&(!t->label||vote==t->label))t->strong=state.now;
    }
    if(!t->live)return;
    if(idx<0&&state.now-t->seen>=LOST){clear_slot(i);return;}
    if(state.now-t->strong>=WEAK){t->suspect=1;t->visible=0;}
    t->votes=(uint16_t)(((uint32_t)t->votes<<2|vote)&1023u);
    if(t->count<5)t->count++;
    t->streak=vote&&vote==t->last_vote?(t->streak<5?t->streak+1u:5u):(vote?1u:0u);
    t->last_vote=(uint8_t)vote;
    if(t->label&&vote&&vote!=t->label&&t->streak>=2)t->suspect=1;
    if(t->count==5) {
        if(!t->label) {if(votes(t,1,5)>=4)t->label=1;else if(votes(t,2,5)>=4)t->label=2;t->visible=!!t->label;}
        else if(vote&&vote!=t->label&&t->streak>=3&&votes(t,vote,5)>=4){
            for(uint32_t c=0;c<2;c++)if(state.owner[c]==i+1u){state.owner[c]=0;state.challenge[c]=0;}
            t->label=(uint8_t)vote;t->suspect=0;t->visible=1;t->strong=state.now;
        }
        else if(t->suspect&&vote==t->label&&votes(t,t->label,3)>=2){t->suspect=0;t->visible=1;}
    }
    t->fresh=vote&&vote==t->label&&!t->suspect;
}
uint32_t __attribute__((optimize("O2"))) cnn_identity_step(void)
{
    /* Re-reading an accepted full token may republish its last complete
     * display, but cannot add a vote, move a box, renew a timer or act. */
    if(state.duplicate){
        state.display=state.saved_display;state.actions=0;
        for(uint32_t i=0;i<2;i++)if(!state.working[i].live||state.now-state.working[i].seen>=LOST||
            state.now-state.working[i].strong>=WEAK)state.display&=~(1u<<i);
        return 1;
    }
    if(state.phase==0 && state.cursor<8) {
        for(uint32_t n=0;n<4;n++,state.cursor++) {
            candidate *c=&POOL[state.cursor];cnn_geometry *b=&c->box;
            if(!c->score)continue;
            int32_t l=clamp(b->cx-b->hw,1279),r=clamp(b->cx+b->hw,1279);
            int32_t t=clamp(b->cy-b->hh,719),u=clamp(b->cy+b->hh,719);
            *b=(cnn_geometry){(l+r)/2,(t+u)/2,(r-l)/2,(u-t)/2};
            if(!b->hw||!b->hh)c->score=0;
        }
        return 0;
    }
    if(state.phase==0) {
        /* 28 relations in four cooperative slices. Union makes a nested
         * whole/part conflict consume exactly one spatial observation. */
        for(uint32_t n=0;n<8&&state.cursor<36;n++,state.cursor++) {
            uint32_t k=state.cursor-8,a=0;while(k>=7u-a){k-=7u-a;a++;}
            uint32_t b=a+1u+k;
            if(POOL[a].score&&POOL[b].score&&same_object(&POOL[a].box,&POOL[b].box)) {
                uint32_t ra=root(a),rb=root(b);if(ra!=rb)POOL[rb].root=(uint8_t)ra;
            }
        }
        if(state.cursor==36){state.phase=1;state.cursor=0;}
        return 0;
    }
    if(state.phase==1) {
        /* Two groups per slice; all members vote once, conflicting strong
         * classes yield unknown rather than score-weighted invented support. */
        for(uint32_t n=0;n<2;n++) {
        uint32_t i=state.cursor++;
        if(POOL[i].score&&root(i)==i) {
            uint32_t mask=0,best=i;
            for(uint32_t j=0;j<8;j++)if(POOL[j].score&&root(j)==i) {
                mask|=POOL[j].vote?1u<<(POOL[j].vote-1u):0;
                if(POOL[j].box.hw*POOL[j].box.hh>POOL[best].box.hw*POOL[best].box.hh)best=j;
            }
            geometry(&POOL[i].box,&POOL[best].box);
            POOL[i].vote=mask==1?1:(mask==2?2:0);
        }
        }
        if(state.cursor==8){
            /* Two same-class histories must not starve the other display
             * class. Reclaim the non-owner for a separated strong candidate.
             * A compatible opposite vote stays on its existing cache. */
            identity *a=&state.working[0],*b=&state.working[1];
            uint32_t la=a->label?a->label:a->last_vote,lb=b->label?b->label:b->last_vote;
            if(a->live&&b->live&&la&&la==lb)for(uint32_t j=0;j<8;j++) {
                candidate *c=&POOL[j];
                if(c->score&&root(j)==j&&c->vote&&c->vote!=la&&cost(a,c)>=2000000u&&cost(b,c)>=2000000u) {
                    uint32_t keep=state.owner[la-1u]?state.owner[la-1u]-1u:(a->label?0u:1u);
                    clear_slot(1u-keep);break;
                }
            }
            state.phase=2;state.cursor=0;state.best_cost=0xffffffffu;
        }
        return 0;
    }
    if(state.phase==2) {
        for(uint32_t n=0;n<8;n++) {
            uint32_t k=state.cursor++,i=k/8u,j=k%8u;
            CACHE[k]=state.working[i].live?cost(&state.working[i],&POOL[j]):2000000u;
        }
        if(state.cursor==16){state.phase=3;state.cursor=0;}
        return 0;
    }
    if(state.phase==3) {
        /* Joint spatial assignment, including an unmatched option. A missing
         * live track costs more than any legal match. No shared observation. */
        uint32_t cursor=state.cursor,best_cost=state.best_cost;
        uint32_t live0=state.working[0].live,live1=state.working[1].live,ambiguous=state.ambiguous;
        int32_t best0=state.best[0],best1=state.best[1];
        for(uint32_t n=0;n<8&&cursor<81;n++,cursor++) {
            int32_t a=(int32_t)(cursor/9u)-1,b=(int32_t)(cursor%9u)-1;
            if(a>=0&&a==b)continue;
            uint32_t ca=live0?(a<0?100000u:CACHE[(uint32_t)a]):(a<0?0:2000000u);
            uint32_t cb=live1?(b<0?100000u:CACHE[8u+(uint32_t)b]):(b<0?0:2000000u);
            if(ca+cb<best_cost){best_cost=ca+cb;best0=a;best1=b;ambiguous=0;}
            /* Equal legal assignments keep fixed raster/slot order. A tie
             * never converts an otherwise usable display into absence. */
        }
        state.cursor=cursor;state.best_cost=best_cost;state.best[0]=(int8_t)best0;state.best[1]=(int8_t)best1;state.ambiguous=(uint8_t)ambiguous;
        if(cursor==81){state.phase=4;state.cursor=0;
            for(uint32_t i=0;i<2;i++){state.match[i]=state.best[i];if(state.best[i]>=0)POOL[(uint32_t)state.best[i]].used=1;}}

        return 0;
    }
    if(state.phase==4) {
        uint32_t i=state.cursor++;identity *t=&state.working[i];
        if(t->live&&state.match[i]<0&&state.now-t->seen>=LOST)clear_slot(i);
        if(!t->live) {
            int32_t best=-1;uint32_t rank=0;
            identity *other=&state.working[1u-i];
            uint32_t other_label=other->label?other->label:other->last_vote;
            for(uint32_t j=0;j<8;j++)if(POOL[j].score&&root(j)==j&&!POOL[j].used&&POOL[j].vote&&
                (best<0||POOL[j].score+((other_label&&POOL[j].vote!=other_label)?512u:0u)>rank)) {
                best=(int32_t)j;rank=POOL[j].score+((other_label&&POOL[j].vote!=other_label)?512u:0u);
            }
            if(best>=0){state.match[i]=(int8_t)best;POOL[best].used=1;}
        }
        update(i);if(state.cursor==2)state.phase=5;
        return 0;
    }
    if(state.phase==5) {
        state.display=state.actions=0;
        for(uint32_t i=0;i<2;i++) {
            identity *t=&state.working[i];
            if(t->live&&t->label&&t->visible&&state.now-t->seen<LOST&&state.now-t->strong<WEAK)
                state.display|=1u<<i;
        }
        if(state.display==3) {
            identity *a=&state.working[0],*b=&state.working[1];
            if(same_object(&a->raw,&b->raw)) {
                uint32_t keep=state.owner[a->label-1u]==1?0:(state.owner[b->label-1u]==2?1:0);
                state.display=1u<<keep;
            } else if(a->label==b->label) {
                uint32_t c=a->label-1u,old=state.owner[c],winner;
                if(old&&state.display&(1u<<(old-1u))) {
                    winner=old-1u;uint32_t other=1u-winner;
                    identity *inc=&state.working[winner],*alt=&state.working[other];
                    uint32_t better=alt->fresh&&(!inc->fresh||
                        (uint32_t)alt->score>=(uint32_t)inc->score+CNN_DISPLAY_SWITCH_MARGIN);
                    state.challenge[c]=better?state.challenge[c]+1u:0u;
                    if(state.challenge[c]>=CNN_DISPLAY_SWITCH_HITS){winner=other;state.challenge[c]=0;}
                } else {winner=b->score>a->score?1u:0u;state.challenge[c]=0;}
                state.display=1u<<winner;
            }
        }
        for(uint32_t c=0;c<2;c++) {
            uint32_t owner=0;
            for(uint32_t i=0;i<2;i++)if((state.display&(1u<<i))&&state.working[i].label==c+1u)owner=i+1u;
            if(!owner||state.display!=3u) {
                uint32_t both=state.working[0].label==c+1u&&state.working[1].label==c+1u&&
                    state.working[0].visible&&state.working[1].visible;
                if(!both)state.challenge[c]=0;
            }
            state.owner[c]=(uint8_t)owner;
        }
        for(uint32_t i=0;i<2;i++)if((state.display&(1u<<i))&&state.working[i].fresh)
            state.actions|=1u<<(state.working[i].label-1u);
        if(state.duplicate)state.actions=0;
        state.phase=6;
    }
    return 1;
}
uint32_t cnn_identity_box(uint32_t cls,cnn_geometry *b)
{
    for(uint32_t i=0;i<2;i++)if((state.display&(1u<<i))&&state.working[i].label==cls+1u) {
        cnn_geometry *p=&state.working[i].q2;*b=(cnn_geometry){p->cx/4,p->cy/4,p->hw/4,p->hh/4};
        if((state.policy&(8192u|8u))==(8192u|8u))b->cx=1279-b->cx;
        return 1;
    }
    return 0;
}
uint32_t cnn_identity_pack(uint32_t *words)
{
    for(uint32_t i=0;i<16;i++)words[i]=0;
    uint32_t n=0;
    for(uint32_t cls=0;cls<2;cls++) {
        cnn_geometry b;if(!cnn_identity_box(cls,&b))continue;
        uint32_t score=128;
        for(uint32_t i=0;i<2;i++)if(state.working[i].label==cls+1u&&state.display&(1u<<i))score=state.working[i].score;
        words[n*2]=(uint32_t)clamp(b.cx+b.hw,1279)<<21|(uint32_t)clamp(b.cy+b.hh,719)<<10;
        words[n*2+1]=score<<24|cls<<22|(uint32_t)clamp(b.cx-b.hw,1279)<<11|(uint32_t)clamp(b.cy-b.hh,719);n++;
    }
    return n;
}
uint32_t cnn_identity_pending_actions(void){return state.actions;}
uint32_t cnn_identity_generation(void){return state.generation;}
void cnn_identity_accept(uint32_t seq)
{
    if(state.duplicate||(state.have&&state.generation==state.old_generation&&seq==state.accepted_seq))return;
    copy_tracks(state.committed,state.working);state.have=1;state.accepted=state.actions;
    for(uint32_t c=0;c<2;c++){state.saved_owner[c]=state.owner[c];state.saved_challenge[c]=state.challenge[c];}
    state.saved_display=state.display;
    state.accepted_token=state.token;state.accepted_seq=seq;state.old_generation=state.generation;
    state.old_policy=state.policy;state.last_time=state.now;
}
uint32_t cnn_identity_actions(uint32_t now)
{return state.have&&now-state.last_time<ACTION?state.accepted:0;}

