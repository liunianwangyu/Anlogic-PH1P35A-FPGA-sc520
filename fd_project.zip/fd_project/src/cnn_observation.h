#ifndef CNN_OBSERVATION_H
#define CNN_OBSERVATION_H
/* Atomic read through the existing CSI CDC, valid only with bit31 set.
 * No new counter/RAM: all fields derive from existing post state.
 * A pending COMMIT cannot span 4096 new completed jobs; sequence-byte reuse
 * after a long outage remains subject to the 1 s policy freshness guard. */
#define CO_REGISTER 0x17cu
#define CO_VALID 0x80000000u
#define CO_ENABLED 0x40000000u
#define CO_ACCEPTED 0x20000000u
#define CO_CAPTURE_CURRENT 0x10000000u
#define CO_GENERATION(s) (((s)>>20)&255u)
#define CO_TOKEN(s) (((s)>>8)&4095u)
#define CO_SEQUENCE(s) ((s)&255u)
#endif
