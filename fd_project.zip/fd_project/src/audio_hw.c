#include "audio_runtime.h"
#include "mcu_tasks.h"
#include "voice_assets.h"
#include "cnn_observation.h"
#include "cnn_identity.h"
AUDIO_STATE audio_diagnostics audio_diag;
AUDIO_STATE uint32_t audio_in_worker;
extern unsigned char __audio_stack_bottom[],__audio_stack_top[],__audio_arena_start[],__audio_arena_end[];
static uint32_t cycles(void) {uint32_t n;__asm__ volatile("rdcycle %0":"=r"(n));return n;}
uint32_t audio_read(uint32_t off) {return mcu_read(AUDIO_BASE+off);}
void audio_write(uint32_t off,uint32_t value) {mcu_write(AUDIO_BASE+off,value);}
void audio_yield(void)
{
 uint32_t elapsed=cycles()-audio_diag.slice_start;
 if(elapsed>audio_diag.max_prepare_slice)audio_diag.max_prepare_slice=elapsed;
 uint32_t sp;__asm__ volatile("mv %0,sp":"=r"(sp));
 uint32_t used=(uint32_t)__audio_stack_top-sp;
 if(used>audio_diag.max_stack_used)audio_diag.max_stack_used=used;
 audio_in_worker=0;
 audio_context_switch(&audio_diag.worker,&audio_diag.caller);
 audio_in_worker=1;
 audio_diag.slice_start=cycles();
}
void audio_checkpoint(void)
{
 if(audio_in_worker&&cycles()-audio_diag.slice_start>=10000u)audio_yield();
}
void *audio_alloc(size_t n)
{
 n=(n+15u)&~15u;
 uint32_t size=(uint32_t)(__audio_arena_end-__audio_arena_start);
 if(n>size-audio_diag.arena_used)return 0;
 void *p=__audio_arena_start+audio_diag.arena_used;audio_diag.arena_used+=n;
 if(audio_diag.arena_used>audio_diag.arena_high)audio_diag.arena_high=audio_diag.arena_used;
 return p;
}
void audio_free(void *p) {(void)p;} /* fixed arena reset only between files */
void audio_memory_fault(uint32_t address,uint32_t cause)
{
 audio_diag.fault_address=address;audio_diag.fault_cause=cause;
 audio_diag.fault=1;audio_diag.ready_mask=0;audio_diag.preparing=0;audio_in_worker=0;
 audio_context_switch(&audio_diag.worker,&audio_diag.caller);
 for(;;){} /* faulted worker is never resumed */
}
uint32_t audio_crc32(uint32_t crc,const void *data,uint32_t count)
{
 const uint8_t *p=data;
 while(count--) {crc^=*p++;for(uint32_t i=0;i<8;i++)crc=(crc>>1)^((crc&1u)?0xedb88320u:0u);audio_checkpoint();}
 return crc;
}
int audio_pcm_write(uint32_t addr,const int16_t *samples,uint32_t count)
{
 if(count>8||!count||addr<1600000u||addr>=5794304u||(addr&7u))return 0;
 uint32_t data[4]={0,0,0,0};
 for(uint32_t i=0;i<count;i++)data[i/2]|=(uint32_t)(uint16_t)samples[i]<<((i&1u)*16);
 audio_write(AA_CACHE_ADDRESS,addr);
 for(uint32_t i=0;i<4;i++)audio_write(AA_CACHE_DATA0+i*4,data[i]);
 uint32_t token=++audio_diag.pcm_write_token;if(!token)token=++audio_diag.pcm_write_token;
 audio_write(AA_CACHE_TOKEN,token);
 uint32_t start=audio_read(AA_TIME_MS);
 while(audio_read(AA_STATUS)&16u) {if(audio_read(AA_TIME_MS)-start>100u)return 0;audio_yield();}
 return audio_read(AA_CACHE_TOKEN)==token&&audio_read(AA_ERROR_CODE)==0;
}
void audio_worker(void)
{
 audio_diag.card_state=1; /* waiting for DDR calibration */
 uint32_t start=audio_read(AA_TIME_MS);
 while(!(audio_read(AA_DDR_STATUS)&1u)) {
  if(audio_read(AA_TIME_MS)-start>=1000u) {audio_diag.fault=3;audio_diag.prepare_done=1;for(;;)audio_yield();}
  audio_yield();
 }
 volatile uint32_t *probe=(volatile uint32_t *)0x8100ffe0u;
 for(uint32_t i=0;i<8;i++) {probe[i]=0x12340000u+i;audio_checkpoint();}
 ((volatile uint8_t *)probe)[1]=0xab;((volatile uint16_t *)probe)[1]=0xcdef;
 for(uint32_t i=0;i<8;i++) {
  uint32_t expected=i?0x12340000u+i:0xcdefab00u;
  if(probe[i]!=expected) {audio_diag.fault=4;audio_diag.prepare_done=1;for(;;)audio_yield();}
  audio_checkpoint();
 }
 audio_diag.memory_tested=1;
 audio_prepare_assets();audio_diag.prepare_done=1;
 for(;;)audio_yield();
}
void audio_note_commit(uint32_t token,uint32_t mask)
{
 if(!(mcu_capabilities()&AUDIO_CAP))return;
 if(!audio_diag.abi_ok)return;
 audio_diag.commit_token=token;audio_diag.commit_mask=mask;
 audio_diag.commit_pending=1;
}
void audio_step(uint32_t capabilities)
{
 if(!(capabilities&AUDIO_CAP))return;
 if(!audio_diag.abi_ok) {
  if(audio_read(AA_ID)!=AUDIO_ABI) {audio_diag.fault=2;return;}
  audio_diag.abi_ok=1;audio_diag.start_class=3;
  audio_diag.control_ms=0xffffffffu;
  for(uint32_t c=0;c<3;c++)audio_diag.policy.classes[c].priority=(uint16_t)voice_assets[c].priority;
  audio_diag.worker.sp=(uint32_t)__audio_stack_top;audio_diag.worker.ra=(uint32_t)audio_worker;
  for(uint32_t *p=(uint32_t *)__audio_stack_bottom;p<(uint32_t *)__audio_stack_top;p++) {
   *p=0xa5a5a5a5u;
   if(((uintptr_t)p&63u)==0)mcu_service_ae();
  }
 }
 uint32_t now=audio_read(AA_TIME_MS);
 if(now!=audio_diag.control_ms||audio_diag.commit_pending||audio_diag.start_inflight) {
 audio_diag.control_ms=now;
 uint32_t observation=mcu_read(CO_REGISTER);
 audio_diag.observation_status=observation;
 uint32_t observation_valid=!!(observation&CO_VALID);
 /* Zero from a stopped CSI bridge is unavailable, not detector OFF. Age
  * still advances; no new request is issued without an acknowledged read. */
 uint32_t enabled=observation_valid?!!(observation&CO_ENABLED):audio_diag.policy.allowed;
 uint32_t generation=CO_GENERATION(observation);
 if(observation_valid&&generation!=audio_diag.observation_generation) {
  audio_diag.observation_generation=generation;voice_rearm(&audio_diag.policy);
  /* A short OFF/ON can occur between polls. Retire ownership of any old
   * START without interrupting its clip: its late ACK/failure must not mark
   * a class attempted in the new session. The existing out-of-range class
   * sentinel is ignored by voice_started/voice_failed; no extra state. */
  audio_diag.start_class=VOICE_CLASSES;
 }
 if(!enabled)audio_diag.start_class=VOICE_CLASSES;
 voice_tick(&audio_diag.policy,now,enabled);
 if(audio_diag.commit_pending&&observation_valid) {
  uint32_t seq=CO_SEQUENCE(observation);
  if((observation&CO_ACCEPTED)&&(!audio_diag.policy.have_seq||seq!=audio_diag.observed_seq)) {
   audio_diag.observed_seq=seq;
   if(CO_TOKEN(observation)==(audio_diag.commit_token&4095u))
    voice_snapshot(&audio_diag.policy,seq,enabled&&!!(observation&CO_CAPTURE_CURRENT),audio_diag.commit_mask,now);
   else voice_unknown(&audio_diag.policy,0);
   audio_diag.commit_pending=0;
  } else {
   /* A rejected/expired COMMIT did not publish a new observation. Drop the
    * attempt without counting it or erasing a still-fresh accepted hit. */
   audio_diag.commit_pending=0;
  }
 }
 uint32_t status=audio_read(AA_STATUS);
 if(audio_diag.start_inflight) {
  if(audio_read(AA_ACK_TOKEN)==audio_diag.start_token) {
   voice_started(&audio_diag.policy,audio_diag.start_class,audio_read(AA_FIRST_SAMPLE_MS));
   audio_diag.start_inflight=0;audio_diag.playing=1;
  } else if(!(status&2u)||now-audio_diag.start_sent_ms>100u) {
   voice_failed(&audio_diag.policy,audio_diag.start_class);
   audio_write(AA_STOP_TOKEN,audio_diag.start_token);audio_diag.start_inflight=0;
  }
 }
 if(!(status&2u))audio_diag.playing=0;
 if(observation_valid&&!audio_diag.start_inflight&&!audio_diag.playing&&(status&1u)) {
  uint32_t action_mask=cnn_identity_actions(cycles());
  if(!(observation&CO_CAPTURE_CURRENT)||!enabled)action_mask=0;
  for(uint32_t c=0;c<VOICE_CLASSES;c++)if(!(action_mask&(1u<<c)))
   audio_diag.policy.classes[c].reserved=0;
  int cls=voice_select(&audio_diag.policy,now,audio_diag.ready_mask&action_mask);
  if(cls>=0) {
   audio_diag.start_class=(uint32_t)cls;
   audio_write(AA_PCM_BASE,audio_diag.app_base[cls]);audio_write(AA_SAMPLE_COUNT,audio_diag.sample_count[cls]);
   if(!++audio_diag.start_token)++audio_diag.start_token;
   audio_diag.start_sent_ms=now;audio_diag.start_inflight=1;
   audio_write(AA_START_TOKEN,audio_diag.start_token);
  }
 }
 }
 if(!audio_diag.prepare_done&&!audio_diag.fault&&mcu_background_allowed()) {
  audio_diag.slice_start=cycles();audio_in_worker=1;
  audio_context_switch(&audio_diag.caller,&audio_diag.worker);
  audio_in_worker=0;
 }
}
