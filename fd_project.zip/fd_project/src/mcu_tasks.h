#ifndef SC520_MCU_TASKS_H
#define SC520_MCU_TASKS_H
#include <stdint.h>

#define MCU_CAP_CNN 1u
#define MCU_CAP_AWB 2u
#define MCU_CAP_HIST 4u
#define MCU_CAP_UI 8u
#define MCU_CAP_MOTION 16u
void mcu_motion_step(void);
void mcu_ui_step(void);
#define HIST_BASE 0x40u
void mcu_histogram_step(void);
#define CNN_BASE 0x100u
#define AWB_BASE 0x200u

/* All arithmetic stays integer and matches the existing RTL layouts. */
typedef struct {
    uint32_t x1, y1, x2, y2, score, cls;
} mcu_box;
typedef struct {
    mcu_box top[8];
    uint32_t count;
    uint32_t words[16];
    uint8_t order[8];
} mcu_cnn_data;
extern mcu_cnn_data cnn_data;
void mcu_cnn_reset(void);
void mcu_cnn_add(uint32_t cell, uint32_t w0, uint32_t w1);
uint32_t mcu_cnn_finish(void);
uint32_t mcu_awb_gain(uint32_t green, uint32_t channel, uint32_t previous,
                      uint32_t limits, uint32_t smooth_shift);

/* Read on a real board through DLM/JTAG to obtain actual cycle measurements.
 * Co-simulation records its separate instruction/bus timing assumptions. */
typedef struct {
    uint32_t max_ae_poll_gap, max_cnn_cycles, max_awb_cycles;
    uint32_t cnn_jobs, awb_jobs, abandoned_jobs;
} mcu_performance;
extern volatile mcu_performance mcu_perf;
uint32_t mcu_read(uint32_t off);
void mcu_write(uint32_t off, uint32_t value);
void mcu_tasks_step(uint32_t capabilities);
void mcu_service_ae(void);
void mcu_poll(void);
uint32_t mcu_capabilities(void);
uint32_t mcu_background_allowed(void);
#endif
