#include "mcu_tasks.h"

/* One cooperative slice per bin. All division runs on the existing hard
 * MCU; AE is serviced between slices. Input/output counts share FPGA RAM,
 * but only INPUT counts drive the CDF, avoiding output-to-input feedback. */
static struct {
    uint16_t bins[256];
    uint16_t output_bins[256];
    uint32_t phase, index, token, total, peak, output_peak, cdf, minimum, denominator;
} hist;

void mcu_histogram_step(void)
{
    uint32_t status = mcu_read(HIST_BASE + 4);
    /* The shared CSI bridge deliberately returns zero when its clock stops.
     * That is not proof the frozen job ended. Keep progress until a verified
     * new token arrives; restarting this token would retransmit a partial LUT
     * and eventually raise an AHB store fault at the 256-word boundary. */
    if (!(status & 1u)) return;
    uint32_t token = mcu_read(HIST_BASE + 8);
    if (!hist.phase || token != hist.token) {
        if (mcu_read(HIST_BASE) != 0x48495332u) return;
        if (mcu_read(HIST_BASE + 8) != token) return;
        hist.phase = 1; hist.index = 0; hist.token = token;
        hist.total = 0; hist.peak = 0; hist.output_peak = 0; hist.cdf = 0; hist.minimum = 0;
    }
    if (hist.phase == 1) {
        mcu_write(HIST_BASE + 12, hist.index);
        uint32_t count = mcu_read(HIST_BASE + 16);
        hist.bins[hist.index++] = (uint16_t)count;
        hist.total += count;
        if (count > hist.peak) hist.peak = count;
        if (!hist.minimum && count) hist.minimum = count;
        if (hist.index == 256) {
            hist.denominator = hist.total - hist.minimum;
            hist.phase = 2; hist.index = 0;
        }
        return;
    }
    if (hist.phase == 2) {
        mcu_write(HIST_BASE + 12, 256u + hist.index);
        uint32_t count = mcu_read(HIST_BASE + 16);
        hist.output_bins[hist.index++] = (uint16_t)count;
        if (count > hist.output_peak) hist.output_peak = count;
        if (hist.index == 256) { hist.phase = 3; hist.index = 0; }
        return;
    }
    /* A timed-out write may have reached CSI before its ACK was lost. Advance
     * only from the existing hardware write counter, so either outcome is
     * safe to retry. Never reset/reupload an already accepted table prefix. */
    uint32_t written = mcu_read(HIST_BASE + 20);
    if (!(written & 0x80000000u)) return; /* no acknowledged CSI response */
    written &= 511u;
    if (written == hist.index + 1u && hist.index < 256u) {
        hist.cdf += hist.bins[hist.index++];
    }
    if (written != hist.index) return; /* includes an unavailable zero reply */
    if (hist.index == 256u) {
        /* Retain this completed job even if COMMIT's acknowledgement is lost.
         * A new verified token starts the next snapshot. */
        mcu_write(HIST_BASE + 24, hist.token);
        return;
    }
    uint32_t count = hist.bins[hist.index];
    uint32_t next_cdf = hist.cdf + count;
    /* CDF-min normalization. Empty or constant frames retain identity.
     * Max products fit uint32 (57,600 * 255), with nearest rounding. */
    uint32_t mapped = hist.index;
    if (hist.denominator) {
        uint32_t cdf = next_cdf > hist.minimum ? next_cdf - hist.minimum : 0;
        mapped = (cdf * 255u + hist.denominator / 2u) / hist.denominator;
    }
    uint32_t height = hist.peak ? (count * 112u + hist.peak / 2u) / hist.peak : 0;
    uint32_t output_height = hist.output_peak ?
        (hist.output_bins[hist.index] * 112u + hist.output_peak / 2u) / hist.output_peak : 0;
    mcu_write(HIST_BASE + 20, mapped | (height << 8) | (output_height << 15));
}
