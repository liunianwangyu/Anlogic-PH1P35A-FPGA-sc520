#ifndef CNN_IDENTITY_H
#define CNN_IDENTITY_H
#include "cnn_tracker.h"
/* Fixed-capacity physical-object evidence. Only accept promotes history.
 * The existing numerical/display ABI is retained, with 0..2 confirmed boxes. */
void cnn_identity_begin(uint32_t now,uint32_t token,uint32_t generation,uint32_t policy);
void cnn_identity_add(uint32_t cell,uint32_t w0,uint32_t w1);
uint32_t cnn_identity_step(void);
uint32_t cnn_identity_pack(uint32_t *words);
uint32_t cnn_identity_box(uint32_t cls,cnn_geometry *box);
uint32_t cnn_identity_actions(uint32_t now);
uint32_t cnn_identity_pending_actions(void);
uint32_t cnn_identity_generation(void);
void cnn_identity_accept(uint32_t seq);
#endif
