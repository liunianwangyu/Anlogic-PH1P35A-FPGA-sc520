#include "servo_task.h"
#include "mcu_tasks.h"
extern uint32_t ui_config[4];
#define TRACK 8192u
#define SEARCH 65536u
#define ORIENTATION (TRACK|24u)
#define INTERVAL 10000000u /* fresh TRACK updates remain at most 10 Hz */
#define SEARCH_INTERVAL 4000000u /* 40 ms = two PWM frames */
#define DWELL 80000000u
#define LOST 80000000u
#define STALL 100000000u
#define ACTION_AGE 40000000u
#define SETTLE 60000000u
#define RELOCK_TIME 150000000u
#define SEARCH_TIME 2000000000u /* 20 s bounded 2-axis round */
static struct {
    track_observation observation;
    uint32_t initialized,last_move,last_commit,last_seen,search_start,settle_start,relock_start;
    uint32_t token,seq,generation,policy;
    uint16_t angle[2],anchor[2],goal[2];
    uint8_t reverse[2],state,pending,have,locked,search_enabled,index,drain,confirm,settling,speed;
    int8_t direction[2],track_step[2];
} servo __attribute__((section(".audio_state.servo")));
static uint32_t cycles(void){uint32_t n;__asm__ volatile("rdcycle %0":"=r"(n));return n;}
static void init(void)
{
    if(servo.initialized)return;
    servo.angle[0]=servo.angle[1]=90;servo.initialized=1;servo.direction[0]=servo.direction[1]=1;
    servo.last_move=cycles();
}
static uint16_t clamp(int32_t n)
{return n<20?20:(n>160?160:(uint16_t)n);}
static void send(void)
{
    uint32_t pan=SERVO_US_0+((SERVO_US_180-SERVO_US_0)*(180u-servo.angle[0])+90u)/180u;
    uint32_t tilt=SERVO_US_0+((SERVO_US_180-SERVO_US_0)*(180u-servo.angle[1])+90u)/180u;
    mcu_write(0xbcu,pan|(tilt<<16));
}
void servo_forget(void)
{
    init();servo.have=servo.pending=servo.locked=0;servo.state=SERVO_IDLE;
    servo.last_move=cycles();servo.direction[0]=servo.direction[1]=1;
    servo.track_step[0]=servo.track_step[1]=0;
}
uint32_t servo_status(void){init();return servo.state;}
uint32_t servo_get(uint32_t id)
{init();return id<2?servo.angle[id]:(id<4?servo.reverse[id-2]:0);}
void servo_set(uint32_t id,uint32_t value)
{
    init();if(id>=4||(ui_config[0]&TRACK))return;
    if(id<2){servo.angle[id]=clamp((int32_t)(value>160?160:value));send();}
    else servo.reverse[id-2]=(uint8_t)!!value;
    servo_forget();
}
void servo_restore(const uint32_t *saved)
{for(uint32_t i=0;i<4;i++)servo_set(i,saved[i]);}
/* ACK owns this immutable copy. No identity working state is read by step. */
void servo_on_commit(const track_observation *o)
{servo.observation=*o;servo.pending=1;}
static void wait_target(void)
{
    servo.state=SERVO_WAIT;servo.track_step[0]=servo.track_step[1]=0;
    servo.anchor[0]=servo.angle[0];servo.anchor[1]=servo.angle[1];
}
/* Seven raster waypoints in flash, no RAM array or large stack frame.
 * Pan scans +/-24 degrees on three tilt rows (0,+16,-16), then returns.
 * Last real compensated command chooses the first direction on each axis. */
static uint16_t search_coord(uint32_t point,uint32_t axis)
{
    static const int8_t offset[7][2]={{24,0},{-24,0},{-24,16},{24,16},{24,-16},{-24,-16},{0,0}};
    return clamp((int32_t)servo.anchor[axis]+offset[point][axis]*servo.direction[axis]);
}
static void next_point(void)
{
    uint32_t i=servo.index;
    servo.settling=0;servo.speed=1;
    for(;i<7;i++) {
        uint16_t pan=search_coord(i,0),tilt=search_coord(i,1);
        uint32_t duplicate=0;
        for(uint32_t j=0;j<i&&i<6;j++)
            duplicate|=pan==search_coord(j,0)&&tilt==search_coord(j,1);
        if(duplicate)continue;
        servo.index=(uint8_t)i;servo.goal[0]=pan;servo.goal[1]=tilt;
        servo.state=SERVO_SEARCH;return;
    }
    servo.state=SERVO_HOLD;
}
static void start_search(uint32_t now)
{
    servo.index=0;servo.search_start=now;next_point();
}
static void track(uint32_t now)
{
    const cnn_geometry *b=&servo.observation.box0;
    int32_t x1=b->cx-b->hw,x2=b->cx+b->hw,y1=b->cy-b->hh,y2=b->cy+b->hh;
    if(x1<0)x1=0;
    if(x2>1279)x2=1279;
    if(y1<0)y1=0;
    if(y2>719)y2=719;
    int32_t x=(x1+x2)/2,y=(y1+y2)/2;
    if(servo.policy&16u)y=(1438-y1-y2)/2;
    uint32_t changed=0;
    for(uint32_t i=0;i<2;i++) {
        int32_t e=i?y-360:x-640,dead=i?36:64;
        if(servo.policy&(i?16u:8u))e=-e;
        int32_t distance=e<0?-e:e;
        /* Pixel error bands share the existing dead-zone normalization.
         * No division/PID state: pan 1..4, tilt 1..3 menu degrees/100 ms.
         * Accelerate by at most one degree/update; braking is immediate.
         * Starting or reversing always begins with a one-degree command. */
        int32_t magnitude=distance<=dead?0:(distance<=dead*3?1:
            (distance<=dead*5?2:(i||distance<=dead*7?3:4)));
        int32_t sign=e<0?-1:1;
        if(i==1)sign=-sign;
        if(servo.reverse[i])sign=-sign;
        int32_t previous=servo.track_step[i],old_speed=previous<0?-previous:previous;
        if(!previous||(previous<0)!=(sign<0))old_speed=0;
        if(magnitude>old_speed+1)magnitude=old_speed+1;
        int32_t step=sign*magnitude;
        uint16_t next=clamp((int32_t)servo.angle[i]+step);
        servo.track_step[i]=(int8_t)((int32_t)next-servo.angle[i]);
        if(next!=servo.angle[i]) {
            changed=1;
            servo.direction[i]=next>servo.angle[i]?1:-1;
            servo.angle[i]=next;
        }
    }
    if(changed){servo.last_move=now;send();}
}
void servo_step(void)
{
    init();uint32_t now=cycles(),policy=ui_config[0]&ORIENTATION;
    uint32_t enabled=!!(ui_config[0]&SEARCH),fresh=0,event=0;
    if(!(policy&TRACK)){servo_forget();servo.policy=policy;servo.search_enabled=enabled;return;}
    if(policy!=servo.policy){uint8_t pending=servo.pending;servo_forget();servo.pending=pending;servo.policy=policy;}
    if(!enabled&&(servo.state==SERVO_SEARCH||servo.state==SERVO_RELOCK))servo.state=SERVO_HOLD;
    if(enabled&&!servo.search_enabled&&servo.locked&&servo.state==SERVO_HOLD)wait_target();
    servo.search_enabled=enabled;
    if(servo.pending) {
        const track_observation *o=&servo.observation;servo.pending=0;
        if(o->policy==policy&&(!servo.have||(o->token!=servo.token&&o->seq!=servo.seq))) {
            if(servo.have&&o->generation!=servo.generation){servo.locked=0;servo.state=SERVO_IDLE;}
            servo.have=1;servo.token=o->token;servo.seq=o->seq;
            servo.generation=o->generation;servo.last_commit=now;fresh=o->fresh0;event=1;
            if(fresh){servo.last_seen=now;servo.locked=1;}
            else if(servo.state==SERVO_TRACK)wait_target();
        }
    }
    /* All fault and exit gates precede automatic PWM. Unsigned subtraction
     * remains correct across rdcycle wrap; the longest interval is 20 s. */
    if((servo.state==SERVO_SEARCH||servo.state==SERVO_RELOCK)&&
       (now-servo.last_commit>=STALL||now-servo.search_start>=SEARCH_TIME)) {
        servo.state=SERVO_HOLD;return;
    }
    if(servo.state==SERVO_RELOCK) {
        if(now-servo.relock_start>=RELOCK_TIME){servo.index++;next_point();return;}
        if(now-servo.last_move<SETTLE)return;
        if(event) {
            if(!servo.drain)servo.drain=1;
            else if(!fresh)servo.confirm=0;
            else if(++servo.confirm>=2){servo.state=SERVO_TRACK;return;}
        }
        return;
    }
    if(fresh) {
        if(servo.state==SERVO_SEARCH) {
            servo.state=SERVO_RELOCK;servo.relock_start=now;servo.drain=servo.confirm=0;return;
        }
        servo.state=SERVO_TRACK;
        if(now-servo.last_move>=INTERVAL)track(now);
        return;
    }
    if(servo.state==SERVO_TRACK&&now-servo.last_seen>=ACTION_AGE)wait_target();
    if(servo.state==SERVO_WAIT&&enabled&&servo.locked&&now-servo.last_seen>=LOST) {
        if(now-servo.last_commit>=STALL){servo.state=SERVO_HOLD;return;}
        start_search(now);
    }
    if(servo.state!=SERVO_SEARCH)return;
    if(servo.angle[0]!=servo.goal[0]||servo.angle[1]!=servo.goal[1]) {
        if(now-servo.last_move>=SEARCH_INTERVAL) {
            for(uint32_t axis=0;axis<2;axis++) {
                int32_t delta=(int32_t)servo.goal[axis]-servo.angle[axis];
                uint32_t distance=(uint32_t)(delta<0?-delta:delta);
                uint32_t step=axis?1u:(distance<=4?1u:servo.speed);
                if(step>distance)step=distance;
                servo.angle[axis]=(uint16_t)((int32_t)servo.angle[axis]+(delta<0?-(int32_t)step:(int32_t)step));
            }
            servo.speed=2;servo.last_move=now;send();
        }
        return;
    }
    if(!servo.settling){servo.settling=1;servo.settle_start=now;}
    else if(now-servo.settle_start>=DWELL){servo.index++;next_point();}
}
