#include "ae_calculate.h"
#include "ae_registers.h"
#include "mcu_tasks.h"
#include "audio_runtime.h"
static inline void barrier(void) { __asm__ volatile("fence iorw,iorw" ::: "memory"); }
uint32_t mcu_read(uint32_t off) { uint32_t v = *(volatile uint32_t *)(AE_BASE + off); barrier(); return v; }
void mcu_write(uint32_t off, uint32_t value) { barrier(); *(volatile uint32_t *)(AE_BASE + off) = value; barrier(); }
#define read_reg mcu_read
#define write_reg mcu_write
static uint32_t capabilities;
uint32_t mcu_capabilities(void) {return capabilities;}
static uint32_t last_ae_cycle;
void mcu_service_ae(void)
{
        uint32_t now;
        __asm__ volatile("rdcycle %0" : "=r"(now));
        uint32_t gap = now - last_ae_cycle;
        if (last_ae_cycle && gap > mcu_perf.max_ae_poll_gap) mcu_perf.max_ae_poll_gap = gap;
        last_ae_cycle = now;
        uint32_t status = read_reg(AE_STATUS);
        if (!(status & AE_PENDING) || (status & (AE_DONE | AE_MANUAL | AE_ERROR))) return;
        uint32_t token = read_reg(AE_TOKEN);
        write_reg(AE_CLAIM, token);
        uint32_t current = read_reg(AE_CURRENT), stats = read_reg(AE_STATS);
        ae_input in = {(uint16_t)(current & 0x7ffu), (uint8_t)(current >> 11),
                       (uint8_t)stats, (uint8_t)(stats >> 8), (uint8_t)(stats >> 16)};
        ae_result out = ae_calculate(in);
        // Mode/timeout cancellation drains the mailbox before a new snapshot.
        // Recheck identity and live state before atomic commit; hardware rechecks it.
        status = read_reg(AE_STATUS);
        if (!(status & AE_PENDING) || (status & (AE_DONE | AE_MANUAL | AE_ERROR)) ||
            read_reg(AE_TOKEN) != token) return;
        write_reg(AE_RESULT, out.exposure | ((uint32_t)out.gain << 11) | ((uint32_t)out.update << 19));
        write_reg(AE_COMMIT, token);
}

void mcu_poll(void)
{
    mcu_service_ae();
    if (capabilities) mcu_tasks_step(capabilities);
    mcu_service_ae();
    // The PCM player is autonomous. Even control polling must yield the MCU
    // while CNN/AWB have an outstanding deadline, not just MP3 decode work.
    if ((capabilities & AUDIO_CAP) && mcu_background_allowed()) audio_step(capabilities);
}

int main(void)
{
    if (read_reg(AE_ID) != AE_INTERFACE_ID) for (;;) { /* mismatched bit: hold */ }
    capabilities = read_reg(AE_CAPABILITIES);
    for (;;) mcu_poll();
}
