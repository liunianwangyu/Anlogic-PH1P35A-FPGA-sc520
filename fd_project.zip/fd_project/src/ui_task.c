#include "mcu_tasks.h"
#include "servo_task.h"
#include "ui_font_map.h"

#define UI_BASE 0x80u
#define UI_READ(a) mcu_read(UI_BASE+(a))
#define UI_WRITE(a,v) mcu_write(UI_BASE+(a),(v))
#define AE_AUTO 1u
#define WB_AUTO 2u
#define CENTER 4u
#define MIRROR 8u
#define FLIP 16u
#define HIST_SHOW 32u
#define HIST_EQ 64u
#define SATURATION 128u
#define CNN_ENABLE 256u
#define MOTION_ENABLE 512u
#define TRACK_ENABLE 8192u
#define SPOT_ENABLE 32768u
#define SEARCH_ENABLE 65536u
#define LAT_DIAG 16384u // UI-only bit; does not select or stop an analysis mode.
#define MODE ((ui_config[0]>>10)&7u)
#define CUSTOM_RGB (1u<<22) // word 2 bit 22; shared preview/commit/rollback
#define COLS 80u
#define CELLS 3600u
#define TEXT_PERSISTENT 2u // cell bit 9; reuse spare text-RAM width, no new buffer
// Physical bit indices; reset handling below deliberately still uses KEY4.
enum { KEY_CANCEL=0, KEY_CONFIRM=1, KEY_DOWN=2, KEY_UP=3 };

enum { ROOT, IMAGE, EXPOSURE, HISTOGRAM, EFFECTS, THRESHOLDS, REGION, RGB, BOUNDS, ANALYSIS, SERVO, LATENCY };
enum { NO_ITEM, BOOL_AE, BOOL_WB, METER, EXP_VALUE, GAIN_VALUE, BOOL_HIST, BOOL_EQ,
       BOOL_SAT, BOOL_MIRROR, BOOL_FLIP, EFFECT_MODE, BINARY_VALUE, EDGE_VALUE,
       TARGET_COLOR, SENSITIVITY, FILL_COLOR, RGB_LOWER, RGB_UPPER, BOOL_CNN, BOOL_MOTION, BOOL_TRACK, BOOL_LAT, SERVO_PAN, SERVO_TILT, SERVO_PAN_REV, SERVO_TILT_REV, BOOL_SEARCH, BOOL_SPOT };

// Exposed symbols allow the firmware simulator to inspect real navigation.
uint32_t ui_config[4]={0u,0x00820082u,0x8010a0ffu,0x050087c7u};
uint32_t ui_page,ui_depth,ui_cursor[12],ui_open,ui_edit,ui_edit_value;
static uint32_t ui_stack[5],ui_channel,ui_edit_config[4],ui_edit_ae_ag,ui_edit_changed;
static uint16_t ui_cells[CELLS];
static uint32_t ui_initialized,ui_dirty=1,ui_upload,ui_upload_index;
static uint32_t ui_sample=255,ui_stable,ui_changed_cycle,ui_last_poll,ui_repeat_cycle;
static uint32_t ui_key_armed,ui_last_keys,ui_seen_switches;
static uint32_t ui_reset_armed;
static uint32_t ui_clear_pending;
static uint32_t ui_ae_ag,ui_refresh_cycle,ui_manual_pending;
static uint32_t ui_hide_sample,ui_hide_changed_cycle,ui_hide_active;

static void refresh_ae_ag(void)
{
    uint32_t actual=UI_READ(0x30u)&0x7ffffu;
    // Preserve the latest manual pair while the camera I2C update is pending.
    if(!ui_manual_pending||actual==(ui_config[3]&0x7ffffu)) {
        ui_ae_ag=actual;ui_manual_pending=0;
    }
}

static uint32_t cycle(void) { uint32_t v;__asm__ volatile("rdcycle %0":"=r"(v));return v; }
/* A job can arrive after render() begins. Reuse the existing bounded vision
 * slices at the already frequent text/clear checkpoints, and finish urgent
 * mailboxes before resuming drawing. The mask excludes UI, histogram, motion
 * and audio, so this cannot recursively enter the renderer or MP3 worker. */
static void ui_checkpoint(void)
{
    uint32_t urgent=mcu_capabilities()&(MCU_CAP_CNN|MCU_CAP_AWB);
    mcu_service_ae();
    if(urgent)do { mcu_tasks_step(urgent); }while(!mcu_background_allowed());
}
static uint32_t item_count(uint32_t page)
{
    static const uint8_t counts[]={3,4,4,2,5,2,4,3,2,4,7,2};
    return counts[page];
}
static uint32_t item_id(uint32_t page,uint32_t i)
{
    static const uint8_t exposure_ids[]={BOOL_AE,METER,EXP_VALUE,GAIN_VALUE};
    static const uint8_t effect_ids[]={BOOL_MIRROR,BOOL_FLIP,EFFECT_MODE,NO_ITEM,NO_ITEM};
    static const uint8_t region_ids[]={NO_ITEM,TARGET_COLOR,SENSITIVITY,FILL_COLOR};
    switch(page) {
    case IMAGE:return i==1?BOOL_WB:(i==3?BOOL_SAT:NO_ITEM);
    case EXPOSURE:return exposure_ids[i];
    case HISTOGRAM:return i?BOOL_EQ:BOOL_HIST;
    case EFFECTS:return effect_ids[i];
    case THRESHOLDS:return i?EDGE_VALUE:BINARY_VALUE;
    case REGION:return region_ids[i];
    case BOUNDS:return i?RGB_UPPER:RGB_LOWER;
    case SERVO:return i==0?BOOL_TRACK:(i<5?SERVO_PAN+i-1:(i==5?BOOL_SEARCH:BOOL_SPOT));
    case LATENCY:return i?NO_ITEM:BOOL_LAT;
    case ANALYSIS:return i<2?(i?BOOL_MOTION:BOOL_CNN):NO_ITEM;
    default:return NO_ITEM;
    }
}
static uint32_t item_enabled(uint32_t page,uint32_t i)
{
    if(page==SERVO&&i>=1&&i<=4&&(ui_config[0]&TRACK_ENABLE))return 0;
    if(page==EXPOSURE&&i>=2&&(ui_config[0]&AE_AUTO))return 0;
    if(page==EFFECTS&&i==4&&MODE!=5&&MODE!=6)return 0;
    return 1;
}
static uint32_t bool_mask(uint32_t id)
{
    switch(id) {
    case BOOL_AE:return AE_AUTO;case BOOL_WB:return WB_AUTO;
    case BOOL_HIST:return HIST_SHOW;case BOOL_EQ:return HIST_EQ;
    case BOOL_SAT:return SATURATION;case BOOL_MIRROR:return MIRROR;
    case BOOL_FLIP:return FLIP;case BOOL_CNN:return CNN_ENABLE;case BOOL_MOTION:return MOTION_ENABLE;case BOOL_TRACK:return TRACK_ENABLE;
    case BOOL_LAT:return LAT_DIAG;case BOOL_SEARCH:return SEARCH_ENABLE;case BOOL_SPOT:return SPOT_ENABLE;
    default:return 0;
    }
}
static uint32_t rgb_bound(uint32_t upper)
{
    uint32_t byte=(2u-ui_channel)*2u+(upper?0u:1u);
    return byte<4?(ui_config[1]>>(byte*8u))&255u:(ui_config[2]>>((byte-4u)*8u))&255u;
}
static uint32_t get_value(uint32_t id)
{
    if(id>=SERVO_PAN&&id<=SERVO_TILT_REV)return servo_get(id-SERVO_PAN);
    uint32_t mask=bool_mask(id);
    if(mask)return !!(ui_config[0]&mask);
    switch(id) {
    case METER:return !!(ui_config[0]&CENTER);
    case EXP_VALUE:return ui_ae_ag&2047u;
    case GAIN_VALUE:return (ui_ae_ag>>11)&255u;
    case EFFECT_MODE:return MODE;
    case BINARY_VALUE:return ui_config[2]>>24;
    case EDGE_VALUE:return (ui_config[3]>>20)&2047u;
    case TARGET_COLOR:return (ui_config[2]>>18)&3u;
    case SENSITIVITY:return (ui_config[2]>>20)&3u;
    case FILL_COLOR:return (ui_config[2]>>16)&3u;
    case RGB_LOWER:return rgb_bound(0);
    case RGB_UPPER:return rgb_bound(1);
    default:return 0;
    }
}
static void commit_config(void)
{
    for(uint32_t i=0;i<4;i++)UI_WRITE(0x10u+i*4u,ui_config[i]);
    UI_WRITE(0x20u,1);
}
static void load_preset(void)
{
    uint32_t sensitivity=(ui_config[2]>>20)&3u,target=(ui_config[2]>>18)&3u;
    uint32_t lo=sensitivity==0?128u:(sensitivity==2?192u:160u);
    uint32_t hi=sensitivity==0?160u:(sensitivity==2?100u:130u);
    uint8_t limits[6]={0,(uint8_t)hi,0,(uint8_t)hi,0,(uint8_t)hi};
    limits[target*2]=lo;limits[target*2+1]=255;
    ui_config[1]=((uint32_t)limits[2]<<24)|((uint32_t)limits[3]<<16)|((uint32_t)limits[4]<<8)|limits[5];
    ui_config[2]=(ui_config[2]&0xffff0000u)|((uint32_t)limits[0]<<8)|limits[1];
    ui_config[2]&=~CUSTOM_RGB;
}
static void apply_value(uint32_t id,uint32_t v)
{
    if(id>=SERVO_PAN&&id<=SERVO_TILT_REV){servo_set(id-SERVO_PAN,v);ui_dirty=1;return;}
    if(id==BOOL_TRACK||id==BOOL_CNN||id==BOOL_MOTION||id==BOOL_MIRROR||id==BOOL_FLIP)servo_forget();
    uint32_t mask=bool_mask(id);
    if(mask) {
        // Publish all three analysis bits in the same existing config transaction.
        if(v&&(id==BOOL_CNN||id==BOOL_MOTION||id==BOOL_TRACK))ui_config[0]&=~(CNN_ENABLE|MOTION_ENABLE|TRACK_ENABLE);
        ui_config[0]=(ui_config[0]&~mask)|(v?mask:0u);
        if(id==BOOL_AE&&v)ui_manual_pending=0;
    }
    else switch(id) {
    case METER:ui_config[0]=(ui_config[0]&~CENTER)|(v?CENTER:0u);break;
    case EFFECT_MODE:ui_config[0]=(ui_config[0]&~(7u<<10))|(v<<10);break;
    case BINARY_VALUE:ui_config[2]=(ui_config[2]&0xffffffu)|(v<<24);break;
    case EDGE_VALUE:ui_config[3]=(ui_config[3]&~(2047u<<20))|(v<<20);break;
    case TARGET_COLOR:ui_config[2]=(ui_config[2]&~(3u<<18))|(v<<18);load_preset();break;
    case SENSITIVITY:ui_config[2]=(ui_config[2]&~(3u<<20))|(v<<20);load_preset();break;
    case FILL_COLOR:ui_config[2]=(ui_config[2]&~(3u<<16))|(v<<16);break;
    case EXP_VALUE:case GAIN_VALUE: {
        uint32_t ae=id==EXP_VALUE?v:(ui_ae_ag&2047u);
        uint32_t ag=id==GAIN_VALUE?v:((ui_ae_ag>>11)&255u);
        ui_config[3]=(ui_config[3]&0xfff00000u)|((ui_config[3]^(1u<<19))&(1u<<19))|ae|(ag<<11);
        ui_ae_ag=ae|(ag<<11);ui_manual_pending=1;
        break;
    }
    case RGB_LOWER:case RGB_UPPER: {
        ui_config[2]|=CUSTOM_RGB;
        uint32_t byte=(2u-ui_channel)*2u+(id==RGB_UPPER?0u:1u);
        uint32_t word=byte<4?1u:2u,shift=(byte%4u)*8u;
        ui_config[word]=(ui_config[word]&~(255u<<shift))|(v<<shift);
        break;
    }
    default:break;
    }
    commit_config();ui_dirty=1;
}
static uint32_t numeric(uint32_t id)
{
    return id==SERVO_PAN||id==SERVO_TILT||id==EXP_VALUE||id==GAIN_VALUE||id==BINARY_VALUE||id==EDGE_VALUE||id==RGB_LOWER||id==RGB_UPPER;
}
static uint32_t maximum(uint32_t id)
{
    if(id==SERVO_PAN||id==SERVO_TILT)return SERVO_MAX_DEG;
    if((id>=SERVO_PAN_REV&&id<=SERVO_TILT_REV))return 1;
    if(bool_mask(id)||id==METER)return 1;
    switch(id) {
    case EXP_VALUE:return 1991;case GAIN_VALUE:return 208;
    case EFFECT_MODE:return 6;case EDGE_VALUE:return 2047;
    case TARGET_COLOR:case SENSITIVITY:return 2;case FILL_COLOR:return 3;
    case RGB_LOWER:return rgb_bound(1)>=8?rgb_bound(1)-8:0;
    default:return 255;
    }
}
static uint32_t minimum(uint32_t id)
{
    if(id==SERVO_PAN||id==SERVO_TILT)return SERVO_MIN_DEG;
    if(id==EXP_VALUE)return 4;
    if(id==GAIN_VALUE)return 16;
    if(id==RGB_UPPER)return rgb_bound(0)<=247?rgb_bound(0)+8:255;
    return 0;
}
static void adjust(uint32_t increase)
{
    uint32_t lo=minimum(ui_edit),hi=maximum(ui_edit),step=1,old=ui_edit_value;
    if(ui_edit==EXP_VALUE)step=16;
    if(ui_edit==GAIN_VALUE)step=4;
    if(ui_edit==EDGE_VALUE||ui_edit==RGB_LOWER||ui_edit==RGB_UPPER)step=8;
    if(!numeric(ui_edit))ui_edit_value=increase?(ui_edit_value==hi?lo:ui_edit_value+1):(ui_edit_value==lo?hi:ui_edit_value-1);
    else if(increase)ui_edit_value=ui_edit_value+step>hi?hi:ui_edit_value+step;
    else ui_edit_value=ui_edit_value<lo+step?lo:ui_edit_value-step;
    if(ui_edit_value!=old) { apply_value(ui_edit,ui_edit_value);ui_edit_changed=1; }
    ui_dirty=1;
}
static void finish_edit(uint32_t cancel)
{
    if(cancel&&ui_edit_changed&&(ui_edit>=SERVO_PAN&&ui_edit<=SERVO_TILT_REV))servo_restore(ui_edit_config);
    if(cancel&&ui_edit_changed&&(ui_edit<SERVO_PAN||ui_edit>SERVO_TILT_REV)) {
        // Snapshot all words: color presets and analysis selection also change
        // fields other than the selected leaf. Never rewind a command toggle.
        uint32_t toggle=ui_config[3]&(1u<<19);
        for(uint32_t i=0;i<4;i++)ui_config[i]=ui_edit_config[i];
        ui_config[3]=(ui_config[3]&~(1u<<19))|toggle;
        if(ui_edit==EXP_VALUE||ui_edit==GAIN_VALUE||
           (ui_edit==BOOL_AE&&!(ui_config[0]&AE_AUTO))) {
            // AUTO preview and outstanding I2C writes may have changed the
            // sensor. Restore the actual saved pair with a fresh load edge.
            ui_ae_ag=ui_edit_ae_ag;ui_manual_pending=1;
            ui_config[3]=(ui_config[3]&0xfff00000u)|(toggle^(1u<<19))|ui_ae_ag;
        } else if(ui_edit==BOOL_AE)ui_manual_pending=0;
        commit_config();
    }
    ui_edit=0;ui_dirty=1;
}
static void push(uint32_t page)
{
    if(ui_depth<4) { ui_stack[++ui_depth]=page;ui_page=page; }
    ui_dirty=1;
}
static void key_event(uint32_t k)
{
    if(!ui_open)return;
    if(ui_edit) {
        if(k>=KEY_DOWN)adjust(k==KEY_UP);
        else finish_edit(k==KEY_CANCEL);
        ui_dirty=1;return;
    }
    if(k>=KEY_DOWN) {
        uint32_t count=item_count(ui_page),next=ui_cursor[ui_page];
        do { next=k==KEY_DOWN?(next+1)%count:(next==0?count-1:next-1);
            if(next==ui_cursor[ui_page]&&!item_enabled(ui_page,next))return; }
        while(!item_enabled(ui_page,next));
        ui_cursor[ui_page]=next;
    } else if(k==KEY_CANCEL) {
        if(ui_depth)ui_page=ui_stack[--ui_depth];
    } else {
        uint32_t i=ui_cursor[ui_page];
        if(!item_enabled(ui_page,i))return;
        uint32_t id=item_id(ui_page,i);
        if(id) {
            refresh_ae_ag();ui_edit=id;
            ui_edit_value=get_value(id);ui_edit_ae_ag=ui_ae_ag;ui_edit_changed=0;
            for(uint32_t j=0;j<4;j++)ui_edit_config[j]=(id>=SERVO_PAN&&id<=SERVO_TILT_REV)?servo_get(j):ui_config[j];
        } else switch(ui_page) {
        case ROOT:push(i==0?IMAGE:(i==1?EFFECTS:ANALYSIS));break;
        case IMAGE:push(i==0?EXPOSURE:HISTOGRAM);break;
        case EFFECTS:push(i==3?THRESHOLDS:REGION);break;
        case REGION:push(RGB);break;
        case RGB:ui_channel=i;push(BOUNDS);break;
        case ANALYSIS:push(i==2?SERVO:LATENCY);break;
        case LATENCY:ui_clear_pending=1;break;
        default:break;
        }
    }
    ui_dirty=1;
}

static uint8_t codepoint(uint32_t cp)
{
    if(cp>=32&&cp<=95)return (uint8_t)(cp-31);
    // The generated codepoint table is sorted: bounded binary lookup keeps
    // a fully Chinese menu refresh short without additional state or memory.
    uint32_t lo=0,hi=UI_CHINESE_COUNT;
    while(lo<hi) {
        uint32_t mid=(lo+hi)>>1,value=ui_chinese_codepoints[mid];
        if(cp==value)return (uint8_t)(65+mid);
        if(cp<value)hi=mid;else lo=mid+1;
    }
    return (uint8_t)('?' -31);
}
static uint32_t put(uint32_t x,uint32_t y,const char *s,uint32_t selected)
{
    uint32_t n=0;
    while(*s&&x<COLS&&y<45) {
        uint32_t cp=(uint8_t)*s++;
        if(cp>=0xe0&&*s) { cp=(cp&15u)<<12;cp|=((uint8_t)*s++&63u)<<6;if(*s)cp|=(uint8_t)*s++&63u; }
        else if(cp>=0xc0&&*s) { cp=(cp&31u)<<6;cp|=(uint8_t)*s++&63u; }
        ui_cells[y*COLS+x++]=codepoint(cp)|((selected&3u)<<8);
        if((++n&7u)==0)ui_checkpoint();
    }
    ui_checkpoint();
    return x;
}
static uint32_t number(uint32_t x,uint32_t y,uint32_t v,uint32_t selected)
{
    char out[11];uint32_t n=0;
    do { out[n++]=(char)('0'+v%10u);v/=10u; }while(v&&n<10);
    while(n) { char one[2]={out[--n],0};x=put(x,y,one,selected); }
    return x;
}
static const char *effect_name(uint32_t v)
{
    static const char *const names[]={"原图","灰度","二值化","边缘检测","卡通化","区域填充","掩膜"};
    return names[v<7?v:0];
}
static const char *page_title(uint32_t page)
{
    static const char *const names[]={"功能菜单","图像参数调节","曝光控制","直方图","图像效果变换","界限值调整","区域填充与掩膜修改","颜色范围","通道范围","智能分析","目标追踪","延迟可视化"};
    return names[page];
}
static const char *item_label(uint32_t page,uint32_t i)
{
    static const char *const root[]={"图像参数调节","图像效果变换","智能分析"};
    static const char *const image[]={"曝光控制","自动白平衡","直方图","饱和度增强"};
    static const char *const exposure[]={"曝光控制","测光模式","手动曝光","手动增益"};
    static const char *const hist[]={"直方图展示","直方图均衡"};
    static const char *const effects[]={"左右镜像","上下翻转","图像效果","界限值调整","区域填充与掩膜修改"};
    static const char *const thresholds[]={"二值化阈值","边缘检测阈值"};
    static const char *const region[]={"颜色范围","目标颜色","敏感度","填充颜色"};
    static const char *const rgb[]={"红","绿","蓝"};
    static const char *const bounds[]={"下限","上限"};
    static const char *const analysis[]={"目标检测识别","运动物体检测","目标追踪","延迟可视化"};
    static const char *const servo[]={"追踪开关","水平角度","俯仰角度","水平反向","俯仰反向","自动寻找","目标聚光"};
    switch(page) {
    case SERVO:return servo[i];
    case LATENCY:return i?"清除统计":"显示开关";
    case ROOT:return root[i];case IMAGE:return image[i];case EXPOSURE:return exposure[i];
    case HISTOGRAM:return hist[i];case EFFECTS:return effects[i];case THRESHOLDS:return thresholds[i];
    case REGION:return region[i];case RGB:return rgb[i];case BOUNDS:return bounds[i];
    default:return analysis[i];
    }
}
static void value_text(uint32_t x,uint32_t y,uint32_t id,uint32_t v,uint32_t selected)
{
    static const char *const targets[]={"红","绿","蓝"};
    static const char *const sensitivities[]={"宽松","适中","严格"};
    static const char *const fills[]={"绿","蓝","黄","白"};
    if(id==SERVO_PAN_REV||id==SERVO_TILT_REV)put(x,y,v?"开启":"关闭",selected);
    else if(id==BOOL_AE||id==BOOL_WB)put(x,y,v?"自动":"手动",selected);
    else if(bool_mask(id))put(x,y,v?"开启":"关闭",selected);
    else if(id==METER)put(x,y,v?"中心":"平均",selected);
    else if(id==EFFECT_MODE)put(x,y,effect_name(v),selected);
    else if(id==TARGET_COLOR)put(x,y,targets[v%3],selected);
    else if(id==SENSITIVITY)put(x,y,sensitivities[v%3],selected);
    else if(id==FILL_COLOR)put(x,y,fills[v%4],selected);
    else number(x,y,v,selected);
}
static void panel(uint32_t page,uint32_t slot,uint32_t active)
{
    static const char *const channels[]={"红","绿","蓝"};
    uint32_t xs[]={1,16,44},ys[]={18,20,22},widths[]={14,26,34};
    uint32_t x=xs[slot],y=page==SERVO?18u:ys[slot],w=widths[slot],count=item_count(page);
    for(uint32_t row=0;row<count*2+3;row++) {
        for(uint32_t col=0;col<w;col++)ui_cells[(y+row)*COLS+x+col]=codepoint(' ');
        ui_checkpoint();
    }
    put(x,y,page_title(page),0);
    if(page==BOUNDS)put(x+9,y,channels[ui_channel],0);
    for(uint32_t i=0;i<count;i++) {
        uint32_t yy=y+2+i*2,selected=active&&ui_cursor[page]==i;
        uint32_t end=put(x,yy,item_label(page,i),selected);
        uint32_t id=item_id(page,i);
        if(id) {
            end=put(end+1,yy,":",selected);
            value_text(end+1,yy,id,(selected&&ui_edit==id)?ui_edit_value:get_value(id),selected);
        } else if(page==RGB) {
            uint32_t saved=ui_channel;ui_channel=i;
            end=number(end+2,yy,rgb_bound(0),selected);end=put(end,yy,"-",selected);
            number(end,yy,rgb_bound(1),selected);ui_channel=saved;
        }
        if(!item_enabled(page,i))put(x,yy+1,(page==ANALYSIS)?"待开发":"当前不可用",0);
    }
}
static void summary(void)
{
    const char *parts[14];uint32_t n=0;
    if(!(ui_config[0]&AE_AUTO))parts[n++]="曝光:手动";
    if(!(ui_config[0]&WB_AUTO))parts[n++]="白平衡:手动";
    if(ui_config[0]&CENTER)parts[n++]="测光:中心";
    if(ui_config[0]&MIRROR)parts[n++]="左右镜像";
    if(ui_config[0]&FLIP)parts[n++]="上下翻转";
    if(ui_config[0]&HIST_SHOW)parts[n++]="直方图展示";
    if(ui_config[0]&HIST_EQ)parts[n++]="直方图均衡";
    if(ui_config[0]&SATURATION)parts[n++]="饱和度增强";
    if(ui_config[0]&CNN_ENABLE)parts[n++]="目标检测";
    if(ui_config[0]&MOTION_ENABLE)parts[n++]="运动物体检测";
    if(ui_config[0]&TRACK_ENABLE) {
        parts[n++]="目标追踪";
        if(ui_config[0]&SEARCH_ENABLE)parts[n++]="自动寻找";
        if(ui_config[0]&SPOT_ENABLE)parts[n++]="目标聚光";
    }
    if(ui_seen_switches&4u)parts[n++]="原图对比";
    else if(MODE&&!(ui_config[0]&TRACK_ENABLE))parts[n++]=effect_name(MODE);
    uint32_t row=0,lengths[4]={0},rows[14],positions[14];
    for(uint32_t i=0;i<n;i++) {
        uint32_t length=0;
        for(const uint8_t *s=(const uint8_t *)parts[i];*s;s++)if((*s&192u)!=128u)++length;
        uint32_t gap=lengths[row]?2u:0u;
        if(lengths[row]+gap+length>34u) { ++row;gap=0; }
        rows[i]=row;positions[i]=lengths[row]+gap;lengths[row]+=gap+length;
    }
    for(uint32_t i=0;i<n;i++)put(79u-lengths[rows[i]]+positions[i],43u-row+rows[i],parts[i],0);

}
/* Read-only, held handshake snapshot. Average and decimal formatting reuse
 * RV32M and the existing text bank, with zero new persistent pixel arrays. */
static void latency_panel(void)
{
    if(ui_open||!(ui_config[0]&LAT_DIAG)||mcu_read(0x1bcu)!=0x4c415431u)return;
    uint32_t status=mcu_read(0x1a4u);
    if(status&1u)return;
    uint32_t sum=mcu_read(0x1a8u),counts=mcu_read(0x1acu);
    uint32_t lo_bad=mcu_read(0x1b0u),hi_last=mcu_read(0x1b4u);
    if(status!=mcu_read(0x1a4u))return;
    uint32_t n=counts&65535u,x=0;
    x=put(0,17,"视频延迟 五秒 最小/平均/最大:",TEXT_PERSISTENT);
    if(n&&(hi_last&(1u<<29))&&!(hi_last&(1u<<28))) {
        x=number(x,17,lo_bad>>16,TEXT_PERSISTENT);x=put(x,17,"/",TEXT_PERSISTENT);
        x=number(x,17,(sum+n/2u)/n,TEXT_PERSISTENT);x=put(x,17,"/",TEXT_PERSISTENT);
        x=number(x,17,hi_last&1023u,TEXT_PERSISTENT);put(x,17," 毫秒",TEXT_PERSISTENT);
    } else put(x,17,"---/---/---",TEXT_PERSISTENT);
    x=put(0,18,"有效:",TEXT_PERSISTENT);x=number(x,18,n,TEXT_PERSISTENT);
    x=put(x,18," 保持:",TEXT_PERSISTENT);x=number(x,18,counts>>16,TEXT_PERSISTENT);
    x=put(x,18," 异常:",TEXT_PERSISTENT);x=number(x,18,lo_bad&65535u,TEXT_PERSISTENT);
    uint32_t reason=(hi_last>>20)&255u;
    const char *code=reason&1u?"超时":reason&2u?"编号":reason&4u?"写入":
        reason&8u?"地址":reason&16u?"队列":reason&32u?"过期":"正常";
    x=put(x,18," ",TEXT_PERSISTENT);x=put(x,18,code,TEXT_PERSISTENT);
    if(hi_last&(1u<<28))put(x,18," 溢出",TEXT_PERSISTENT);
    mcu_write(0x1a4u,1); // next frame's snapshot; never wait inside a UI slice
}
static void render(void)
{
    for(uint32_t i=0;i<CELLS;i++) { ui_cells[i]=0;if((i&63u)==0)ui_checkpoint(); }
    summary();latency_panel();
    if(ui_open) {
        uint32_t start=ui_depth>2?ui_depth-2:0;
        for(uint32_t d=start;d<=ui_depth;d++)panel(ui_stack[d],d-start,d==ui_depth);
        if(ui_edit) {
            put(44,35,"修改:",1);value_text(48,35,ui_edit,ui_edit_value,1);
            if(numeric(ui_edit)) {
                uint32_t lo=minimum(ui_edit),hi=maximum(ui_edit);
                uint32_t filled=hi>lo?(ui_edit_value-lo)*24u/(hi-lo):0;
                put(44,37,"[",1);
                for(uint32_t i=0;i<24;i++)put(45+i,37,i<filled?"#":"-",1);
                put(69,37,"]",1);
            }
        }
        put(1,34,"按键4上 按键3下 按键2确认 按键1取消",0);
    }
    ui_upload=1;ui_upload_index=0;ui_dirty=0;
    UI_WRITE(0x24u,0);
}
static void inputs(uint32_t now)
{
    uint32_t sample=UI_READ(4)&255u;
    // Reset requires key release in the all-SW-OFF context. SW2 is masked
    // below for menu independence, so check all raw synchronized switches.
    uint32_t raw_switches=sample>>4,raw_keys=sample&15u;
    if(raw_switches||(raw_keys&&(raw_keys&(raw_keys-1u))))ui_reset_armed=0;
    // A loose SW2 contact must never control pixels directly. Keep its
    // 50 ms stability timer separate, so key activity cannot restart it.
    uint32_t hide=(sample>>5)&1u;
    if(hide!=ui_hide_sample) { ui_hide_sample=hide;ui_hide_changed_cycle=now; }
    if(hide!=ui_hide_active&&now-ui_hide_changed_cycle>=5000000u) {
        ui_hide_active=hide;UI_WRITE(0x34u,hide);
    }
    // SW2 has its own timer; contact bounce must not starve SW1 or keys.
    sample&=~(1u<<5);
    if(sample!=ui_sample) { ui_sample=sample;ui_changed_cycle=now; }
    if(now-ui_changed_cycle<2000000u)return;
    if(ui_stable!=sample) {
        uint32_t switches=(sample>>4)&15u,keys=sample&15u;
        if(switches!=ui_seen_switches) {
            if((switches&1u)&&!(ui_seen_switches&1u)) { ui_open=1;ui_page=ROOT;ui_depth=0;ui_stack[0]=ROOT;ui_edit=0; }
            if(!(switches&1u)) { if(ui_edit)finish_edit(1);ui_open=0; }
            ui_seen_switches=switches;ui_key_armed=0;ui_dirty=1;
        }
        if(!keys)ui_key_armed=1;
        if(ui_key_armed&&keys&&!(keys&(keys-1u))) {
            uint32_t k=0;while((keys>>k)!=1u)++k;
            if(k==3&&ui_reset_armed&&!raw_switches&&!switches&&!ui_hide_active) {
                // Hardware holds this request until the official sequencer
                // resets every consumer, including this MCU and UI CSR.
                ui_reset_armed=0;UI_WRITE(0x38u,0x52535431u);
            } else key_event(k);
            ui_key_armed=0;ui_repeat_cycle=now+35000000u;
        }
        ui_stable=sample;ui_last_keys=keys;
    }
    if(!ui_last_keys)ui_key_armed=1;
    if(!ui_last_keys&&!raw_keys&&!raw_switches&&!(ui_stable>>4)&&!ui_hide_active)
        ui_reset_armed=1;
    if(ui_edit&&(ui_last_keys==(1u<<KEY_DOWN)||ui_last_keys==(1u<<KEY_UP))&&(int32_t)(now-ui_repeat_cycle)>=0) {
        adjust(ui_last_keys==(1u<<KEY_UP));ui_repeat_cycle=now+8000000u;
    }
}
void mcu_ui_step(void)
{
    if(!ui_initialized) {
        if(UI_READ(0)!=0x55493138u)return;
        ui_initialized=1;ui_stack[0]=ROOT;UI_WRITE(0x34u,0);commit_config();
    }
    // Queue clear while the snapshot mailbox is busy; never lose a key press.
    if(ui_clear_pending&&mcu_read(0x1bcu)==0x4c415431u&&!(mcu_read(0x1a4u)&1u)) {
        mcu_write(0x1a4u,3);ui_clear_pending=0;
    }
    uint32_t now=cycle();
    if(now-ui_last_poll>=100000u) { ui_last_poll=now;inputs(now); }
    if((ui_open||(ui_config[0]&(LAT_DIAG|TRACK_ENABLE)))&&!ui_edit&&now-ui_refresh_cycle>=(ui_open?20000000u:50000000u)) {
        ui_refresh_cycle=now;refresh_ae_ag();ui_dirty=1;
    }
    // Keys and configuration above remain responsive. Text banks can wait
    // a few milliseconds; their MMIO stream must not consume CNN/AWB's
    // hardware watchdog window, even when a previous upload is in progress.
    if(!mcu_background_allowed())return;
    if(ui_upload) {
        if(ui_upload_index<CELLS) {
            // Eight bounded writes per cooperative slice; AE runs between
            // slices. Text upload never stalls camera or HDMI processing.
            for(uint32_t i=0;i<8&&ui_upload_index<CELLS;i++)UI_WRITE(0x28u,ui_cells[ui_upload_index++]);
        } else if(!(UI_READ(8)&1u)) { UI_WRITE(0x2cu,1);ui_upload=0; }
    } else {
        uint32_t status=UI_READ(8);
        if(!(status&2u))ui_dirty=1;
        // Input/configuration handling above stays live; defer the full text
        // render until frozen CNN/AWB jobs have met their hardware deadlines.
        if(ui_dirty&&!(status&1u))render();
    }
}
