#ifndef AUDIO_RUNTIME_H
#define AUDIO_RUNTIME_H
#include <stdint.h>
#include <stddef.h>
#include "voice_policy.h"
#include "audio_abi.h"
#define AUDIO_STATE __attribute__((section(".audio_state")))
#define AUDIO_WORK __attribute__((section(".audio_work")))
#define AUDIO_BASE AA_REGISTER_BASE
#define AUDIO_ABI AA_INTERFACE_ID
#define AUDIO_CAP AA_CAPABILITY
typedef struct {uint32_t sp,ra,s[12];} audio_context;
typedef struct {
 voice_policy policy;
 uint32_t abi_ok,fault,ready_mask,invalid_mask,preparing,prepare_done;
 uint32_t max_prepare_slice,arena_used,arena_high,max_stack_used;
 uint32_t sd_timeout_count,decode_error_count,prepare_started_ms,prepare_finished_ms;
 uint32_t sample_count[3],pcm_crc32[3],app_base[3],prepare_ms[3],asset_error[3];
 uint32_t commit_pending,commit_token,observation_status,commit_mask,observed_seq;
 uint32_t start_token,start_class,start_inflight,start_sent_ms,playing;
 uint32_t slice_start,read_count,read_bytes,pcm_write_token;
 audio_context caller,worker;
 uint32_t card_state,mount_failures,memory_tested;
 uint32_t observation_generation;
 uint32_t fault_address,fault_cause;
 uint32_t control_ms;
} audio_diagnostics;
extern AUDIO_STATE audio_diagnostics audio_diag;
void audio_context_switch(audio_context *old,audio_context *next);
void audio_worker(void);
void audio_step(uint32_t capabilities);
void audio_checkpoint(void);
void audio_yield(void);
void audio_note_commit(uint32_t token,uint32_t mask);
void *audio_alloc(size_t size);
void audio_free(void *ptr);
uint32_t audio_crc32(uint32_t crc,const void *data,uint32_t count);
int audio_pcm_write(uint32_t app_addr,const int16_t *samples,uint32_t count);
uint32_t audio_read(uint32_t off);
void audio_write(uint32_t off,uint32_t value);
void audio_prepare_assets(void);
int audio_sd_initialize(void);
int audio_sd_read(uint32_t lba,uint8_t *data);
void audio_memory_fault(uint32_t address,uint32_t cause) __attribute__((noreturn));
#endif
