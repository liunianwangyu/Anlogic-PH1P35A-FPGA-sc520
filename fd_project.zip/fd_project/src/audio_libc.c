/* Freestanding decoder/FatFs primitives, with cooperative bounds. */
#include "audio_runtime.h"
void *memset(void *d,int c,size_t n)
{unsigned char *p=d;while(n--) {*p++=(unsigned char)c;audio_checkpoint();}return d;}
void *memcpy(void *d,const void *s,size_t n)
{unsigned char *p=d;const unsigned char *q=s;while(n--) {*p++=*q++;audio_checkpoint();}return d;}
void *memmove(void *d,const void *s,size_t n)
{unsigned char *p=d;const unsigned char *q=s;if((uintptr_t)p<(uintptr_t)q)return memcpy(d,s,n);
 p+=n;q+=n;while(n--) {*--p=*--q;audio_checkpoint();}return d;}
int memcmp(const void *a,const void *b,size_t n)
{const unsigned char *p=a,*q=b;while(n--) {int v=*p++-*q++;if(v)return v;audio_checkpoint();}return 0;}
size_t strlen(const char *s) {size_t n=0;while(s[n]) {n++;audio_checkpoint();}return n;}
char *strchr(const char *s,int c) {do {if(*s==(char)c)return (char*)s;audio_checkpoint();}while(*s++);return 0;}
