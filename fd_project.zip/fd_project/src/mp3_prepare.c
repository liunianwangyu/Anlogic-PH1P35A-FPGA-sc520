#include "audio_runtime.h"
#include "voice_assets.h"
#include "ff.h"
#include "mp3dec.h"
#include <string.h>
static AUDIO_STATE FATFS filesystem;
static AUDIO_STATE FIL file;
static AUDIO_WORK unsigned char input_buffer[4096];
static AUDIO_WORK short pcm_buffer[2304];
static int read_bytes(void *p,UINT n,UINT *actual)
{
 audio_checkpoint();return f_read(&file,p,n,actual)==FR_OK;
}
static uint32_t prepare_one(uint32_t cls,uint32_t app_base)
{
 const voice_asset *a=&voice_assets[cls];
 if(f_open(&file,a->path,FA_READ)!=FR_OK)return 1;
 uint32_t err=0,crc=0xffffffffu,total=0;
 UINT got;
 if(f_size(&file)!=a->bytes) {err=2;goto close;}
 /* Complete file checksum, then rewind. No partial cache is ever published. */
 while(!f_eof(&file)) {
  if(!read_bytes(input_buffer,512,&got)||!got) {err=3;goto close;}
  crc=audio_crc32(crc,input_buffer,got);audio_checkpoint();
 }
 if((crc^0xffffffffu)!=a->crc32) {err=4;goto close;}
 if(f_lseek(&file,0)!=FR_OK||!read_bytes(input_buffer,10,&got)||got!=10) {err=5;goto close;}
 uint32_t offset=0;
 if(input_buffer[0]=='I'&&input_buffer[1]=='D'&&input_buffer[2]=='3') {
  uint32_t allowed=input_buffer[3]==4?0xf0u:(input_buffer[3]==3?0xe0u:0xc0u);
  if(input_buffer[3]<2||input_buffer[3]>4||(input_buffer[5]&~allowed)) {err=6;goto close;}
  for(uint32_t i=6;i<10;i++)if(input_buffer[i]&128u) {err=6;goto close;}
  offset=10u+((uint32_t)input_buffer[6]<<21)+((uint32_t)input_buffer[7]<<14)+
              ((uint32_t)input_buffer[8]<<7)+input_buffer[9];
  if(input_buffer[5]&16u)offset+=10u;
  if(offset>65536u||offset>=a->bytes) {err=6;goto close;}
 }
 if(f_lseek(&file,offset)!=FR_OK) {err=5;goto close;}
 audio_diag.arena_used=0;
 HMP3Decoder decoder=MP3InitDecoder();
 if(!decoder) {err=7;goto close;}
 int buffered=0;unsigned char *cursor=input_buffer;
 uint32_t pcm_crc=0xffffffffu,bitrate=0;
 while(1) {
  if(buffered<1024&&!f_eof(&file)) {
   memmove(input_buffer,cursor,(size_t)buffered);cursor=input_buffer;
   if(!read_bytes(input_buffer+buffered,(UINT)(sizeof(input_buffer)-buffered),&got)) {err=3;break;}
   buffered+=(int)got;
  }
  if(!buffered)break;
  if(buffered==128&&f_eof(&file)&&cursor[0]=='T'&&cursor[1]=='A'&&cursor[2]=='G')break;
  if(buffered<4) {err=8;break;}
  /* Strict supported subset: MPEG1 Layer III, 48k mono, CBR64/96. */
  uint32_t h=((uint32_t)cursor[0]<<24)|((uint32_t)cursor[1]<<16)|((uint32_t)cursor[2]<<8)|cursor[3];
  uint32_t bi=(h>>12)&15u;
  if((h&0xfffe0cc0u)!=0xfffa04c0u||(bi!=5u&&bi!=7u)) {err=9;break;}
  if(bitrate&&bi!=bitrate) {err=9;break;}bitrate=bi;
  int frame_bytes=(bi==5u?192:288)+(int)((h>>9)&1u);
  if(buffered<frame_bytes) {err=8;break;}
  int left=frame_bytes;unsigned char *frame=cursor;
  int status=MP3Decode(decoder,&frame,&left,pcm_buffer,0);
  if(status!=ERR_MP3_NONE||left!=0) {err=10;break;}
  MP3FrameInfo info;MP3GetLastFrameInfo(decoder,&info);
  if(info.samprate!=48000||info.nChans!=1||info.outputSamps!=1152||info.layer!=3||info.version!=0) {err=9;break;}
  if(total+(uint32_t)info.outputSamps>a->max_samples||total+(uint32_t)info.outputSamps>480000u) {err=11;break;}
  /* Five ms ramp uses integer multiplies on the MCU, no fabric DSPs. Tail
   * fade is applied when remaining file bytes prove this is the last frame. */
  uint32_t last_frame=f_eof(&file)&&(buffered==frame_bytes||buffered==frame_bytes+128);
  for(uint32_t i=0;i<1152;i++) {
   int32_t sample=pcm_buffer[i];
   if(total+i<240u)sample=sample*(int32_t)(total+i)/240;
   if(last_frame&&i>=912u)sample=sample*(int32_t)(1151u-i)/240;
   pcm_buffer[i]=(int16_t)sample;audio_checkpoint();
  }
  pcm_crc=audio_crc32(pcm_crc,pcm_buffer,2304);
  for(uint32_t i=0;i<1152;i+=8) {
   if(!audio_pcm_write(app_base+total+i,pcm_buffer+i,8)) {err=12;break;}
   audio_checkpoint();
  }
  if(err)break;
  total+=1152u;cursor+=frame_bytes;buffered-=frame_bytes;audio_checkpoint();
 }
 MP3FreeDecoder(decoder);
 if(!err&&total) {
  audio_diag.sample_count[cls]=total;audio_diag.app_base[cls]=app_base;
  audio_diag.pcm_crc32[cls]=pcm_crc^0xffffffffu;audio_diag.ready_mask|=1u<<cls;
 } else if(!err)err=8;
close:
 (void)f_close(&file);return err;
}
void audio_prepare_assets(void)
{
 audio_diag.preparing=1;audio_diag.prepare_started_ms=audio_read(AA_TIME_MS);
 audio_diag.card_state=2;
 while(f_mount(&filesystem,"0:",1)!=FR_OK||filesystem.fs_type!=FS_FAT32) {
  audio_diag.card_state=3;audio_diag.mount_failures++;
  uint32_t start=audio_read(AA_TIME_MS);
  while(audio_read(AA_TIME_MS)-start<1000u)audio_yield();
 }
 audio_diag.card_state=4;
 for(uint32_t c=0;c<3;c++) {
  if(!voice_assets[c].configured)continue;
  uint32_t start=audio_read(AA_TIME_MS);
  /* One fixed 960000-byte slot per class, aligned 128-bit and disjoint. */
  uint32_t err=prepare_one(c,1600000u+c*480000u);
  audio_diag.prepare_ms[c]=audio_read(AA_TIME_MS)-start;audio_diag.asset_error[c]=err;
  if(err) {audio_diag.invalid_mask|=1u<<c;audio_diag.decode_error_count++;}
 }
 audio_diag.prepare_finished_ms=audio_read(AA_TIME_MS);audio_diag.preparing=0;audio_diag.card_state=5;
}
