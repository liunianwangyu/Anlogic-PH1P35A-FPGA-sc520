#include "voice_policy.h"
void voice_unknown(voice_policy *p,uint32_t cancel_pending)
{
 p->fresh=0;
 for(uint32_t i=0;i<VOICE_CLASSES;i++) {
  voice_class *c=&p->classes[i];c->hits=0;c->negatives=0;
  if(cancel_pending)c->reserved=0;
 }
}
void voice_rearm(voice_policy *p)
{
 /* A real detector restart is a new session, unlike an unavailable result.
  * Reuse the existing MCU state; retain priorities and diagnostic totals. */
 p->have_seq=0;p->fresh=0;
 for(uint32_t i=0;i<VOICE_CLASSES;i++) {
  voice_class *c=&p->classes[i];
  c->active=0;c->hits=0;c->negatives=0;c->reserved=0;
  c->attempted=0;c->cooldown=0;
 }
}
void voice_tick(voice_policy *p,uint32_t now,uint32_t allowed)
{
 p->allowed=(uint8_t)!!allowed;
 for(uint32_t i=0;i<VOICE_CLASSES;i++)
  if(p->classes[i].cooldown&&now-p->classes[i].last_start>=5000u)p->classes[i].cooldown=0;
 if(!allowed)voice_rearm(p);
 else if(p->have_seq&&now-p->last_time>1000u)voice_unknown(p,0);
}
void voice_snapshot(voice_policy *p,uint32_t seq,uint32_t valid,uint32_t mask,uint32_t now)
{
 if(p->have_seq&&seq==p->last_seq)return;
 uint32_t gap=p->have_seq?now-p->last_time:0;
 p->last_seq=seq;p->last_time=now;p->have_seq=1;
 if(!valid||!p->allowed||gap>1000u) {voice_unknown(p,0);return;}
 p->fresh=1;
 uint32_t order=0;
 for(uint32_t i=0;i<VOICE_CLASSES;i++) {
  voice_class *c=&p->classes[i];
  /* An unfinished detector can miss one accepted frame or briefly select
   * another class. Confirm with two hits in three valid observations, not
   * two consecutive hits. Reuse the existing byte as a 3-bit history so the
   * public structure, SRAM use and diagnostic offsets remain unchanged. */
  if(!c->active)c->hits=(uint8_t)((((uint32_t)c->hits<<1)|((mask>>i)&1u))&7u);
  if(mask&(1u<<i)) {
   c->negatives=0;
   if(!c->active&&(c->hits==3u||c->hits>=5u)) {
    c->active=1;c->episode++;c->reserved=0;c->attempted=0;c->hits=0;
   }
  } else {
   if(c->active) {
    if(!c->negatives)c->absent_since=now;
    if(c->negatives<255)c->negatives++;
    if(c->negatives>=3&&now-c->absent_since>=5000u) {
     c->active=0;c->reserved=0;c->negatives=0;
    }
   }
  }
  if((mask&(1u<<i))&&c->active&&!c->attempted&&!c->reserved) {
   if(!order)order=++p->order;
   c->reserved=1;c->event_order=order;
  }
 }
}
int voice_select(voice_policy *p,uint32_t now,uint32_t ready_mask)
{
 voice_tick(p,now,p->allowed);
 if(!p->allowed||!p->fresh)return -1;
 int best=-1;
 for(uint32_t i=0;i<VOICE_CLASSES;i++) {
  voice_class *c=&p->classes[i];
  if(c->active&&c->reserved&&!c->attempted&&!c->cooldown&&(ready_mask&(1u<<i))) {
   if(best<0||(int32_t)(c->event_order-p->classes[best].event_order)<0||
      (c->event_order==p->classes[best].event_order&&c->priority<p->classes[best].priority))best=(int)i;
  }
 }
 return best;
}
void voice_started(voice_policy *p,uint32_t cls,uint32_t now)
{
 if(cls>=VOICE_CLASSES)return;
 voice_class *c=&p->classes[cls];c->last_start=now;c->cooldown=1;c->attempted=1;c->reserved=0;c->played_count++;
}
void voice_failed(voice_policy *p,uint32_t cls)
{
 if(cls>=VOICE_CLASSES)return;
 p->classes[cls].attempted=1;p->classes[cls].reserved=0;
}
