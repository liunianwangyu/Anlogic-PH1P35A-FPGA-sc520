#include "ae_calculate.h"
/* Match sc520_ae_control, including strict comparisons and floor shifts.
 * SC520GainTbl uses 32 fine codes per gain doubling. A 16-code increase
 * can jump from below the 192 near-highlight threshold past 240 (clipped),
 * then the next decrease undoes it. Limit fast gain changes to 6 codes:
 * the largest upward ratio is 38/32 = 1.1875, leaving noise margin inside
 * the existing 192..239 hold band instead of skipping over it.
 * No sensor access, floating point, division or persistent software state. */
ae_result ae_calculate(ae_input in)
{
    ae_result out = {in.exposure, in.gain, 0};
    const uint8_t clipped = in.clip_ratio >= 16;
    // Ratio hysteresis: hold highlights down to 12/256; only reduce at
    // 16/256 clipped. Sampling noise near 16 must not restart brightening.
    const uint8_t dark = in.mean < 112 && !clipped && in.near_ratio < 12;
    const uint8_t bright = in.mean > 128 || clipped;
    const uint8_t fast = in.mean < 64 || in.mean > 160 || in.clip_ratio >= 32;
    uint16_t step = in.exposure >> (fast ? 2 : 4);
    const uint16_t gain_step = fast ? 6 : 4;
    if (step == 0) step = 1;
    if (dark) {
        if (in.exposure < 1991) {
            uint16_t sum = in.exposure + step;
            out.exposure = sum > 1991 ? 1991 : sum;
            out.update = 1;
        } else if (in.gain < 208) {
            uint16_t sum = in.gain + gain_step;
            out.gain = (uint8_t)(sum > 208 ? 208 : sum);
            out.update = 1;
        }
    } else if (bright) {
        if (in.gain > 16) {
            out.gain = (uint8_t)(in.gain <= 16 + gain_step ? 16 : in.gain - gain_step);
            out.update = 1;
        } else if (in.exposure > 4) {
            out.exposure = in.exposure <= 4 + step ? 4 : in.exposure - step;
            out.update = 1;
        }
    }
    return out;
}
