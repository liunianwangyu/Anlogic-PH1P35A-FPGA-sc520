#include "audio_runtime.h"
#include "ff.h"
#include "diskio.h"
static AUDIO_STATE uint32_t sd_ready;
static int transfer(uint8_t out,uint8_t *in)
{
 audio_checkpoint();
 uint32_t seq=audio_read(AA_SD_SEQUENCE),start=audio_read(AA_TIME_MS);
 audio_write(AA_SD_BYTE,out);
 while(audio_read(AA_SD_SEQUENCE)==seq) {
  if(audio_read(AA_TIME_MS)-start>10u) {audio_diag.sd_timeout_count++;return 0;}
  audio_checkpoint();
 }
 *in=(uint8_t)audio_read(AA_SD_BYTE);return 1;
}
static int byte(uint8_t b) {uint8_t v=255;return transfer(b,&v)?v:-1;}
static int command(uint8_t cmd,uint32_t arg)
{
 audio_checkpoint();
 if(byte(0xff)<0||byte(0x40u|cmd)<0)return -1;
 for(int i=3;i>=0;i--)if(byte((uint8_t)(arg>>(i*8)))<0)return -1;
 if(byte(cmd==0?0x95:(cmd==8?0x87:0x01))<0)return -1;
 for(uint32_t i=0;i<9;i++) {int v=byte(0xff);if(v<0||!(v&128))return v;}
 return -1;
}
static void deselect(uint32_t fast) {audio_write(AA_SD_CONTROL,1u|(fast?2u:0u));(void)byte(0xff);}
int audio_sd_initialize(void)
{
 uint32_t start=audio_read(AA_TIME_MS);sd_ready=0;
 audio_write(AA_SD_CONTROL,1);
 while(audio_read(AA_TIME_MS)-start<2u)audio_yield();
 for(uint32_t i=0;i<10;i++)if(byte(0xff)<0)return 0;
 audio_write(AA_SD_CONTROL,0);
 if(command(0,0)!=1||command(8,0x1aa)!=1) {deselect(0);return 0;}
 uint32_t r7=0;
 for(uint32_t i=0;i<4;i++) {int b=byte(0xff);if(b<0) {deselect(0);return 0;}r7=(r7<<8)|(uint8_t)b;}
 if(r7!=0x1aa) {deselect(0);return 0;}
 start=audio_read(AA_TIME_MS);
 for(;;) {
  int r=command(55,0);
  if(r<0||r>1) {deselect(0);return 0;}
  r=command(41,0x40000000u);
  if(r==0)break;
  if(r!=1||audio_read(AA_TIME_MS)-start>=1000u) {audio_diag.sd_timeout_count++;deselect(0);return 0;}
  audio_yield();
 }
 if(command(58,0)!=0) {deselect(0);return 0;}
 uint32_t ocr=0;
 for(uint32_t i=0;i<4;i++) {int b=byte(0xff);if(b<0) {deselect(0);return 0;}ocr=(ocr<<8)|(uint8_t)b;}
 if((ocr&0xc0000000u)!=0xc0000000u||!(ocr&0x00ff8000u)) {deselect(0);return 0;}
 deselect(1);sd_ready=1;return 1;
}
int audio_sd_read(uint32_t lba,uint8_t *data)
{
 audio_checkpoint();
 if(!sd_ready)return 0;
 audio_write(AA_SD_CONTROL,2);
 if(command(17,lba)!=0) {deselect(1);return 0;}
 uint32_t start=audio_read(AA_TIME_MS);
 int v;
 do {
  v=byte(0xff);
  if(v<0||audio_read(AA_TIME_MS)-start>=250u) {audio_diag.sd_timeout_count++;deselect(1);return 0;}
  audio_checkpoint();
 }while(v==255);
 if(v!=0xfe) {deselect(1);return 0;}
 uint32_t seq=audio_read(AA_SD_SEQUENCE);audio_write(AA_SD_READ_BLOCK,1);
 while(audio_read(AA_SD_SEQUENCE)==seq) {
  if(audio_read(AA_TIME_MS)-start>=300u) {audio_diag.sd_timeout_count++;return 0;}
  audio_yield();
 }
 if(audio_read(AA_SD_STATUS)&2u) {deselect(1);return 0;}
 audio_write(AA_SD_READ_INDEX,0);
 for(uint32_t i=0;i<128;i++) {
  uint32_t w=audio_read(AA_SD_DATA);
  for(uint32_t j=0;j<4;j++)data[i*4+j]=(uint8_t)(w>>(j*8));
  audio_checkpoint();
 }
 deselect(1);audio_diag.read_count++;audio_diag.read_bytes+=512;return 1;
}
DSTATUS disk_status(BYTE pdrv) {return pdrv||!sd_ready?STA_NOINIT:0;}
DSTATUS disk_initialize(BYTE pdrv) {return pdrv||!audio_sd_initialize()?STA_NOINIT:0;}
DRESULT disk_read(BYTE pdrv,BYTE *buff,LBA_t sector,UINT count)
{
 if(pdrv||!count||!sd_ready)return RES_PARERR;
 while(count--) {if(!audio_sd_read((uint32_t)sector++,buff))return RES_ERROR;buff+=512;audio_checkpoint();}
 return RES_OK;
}
DRESULT disk_ioctl(BYTE pdrv,BYTE cmd,void *buff)
{
 (void)buff;return pdrv||!sd_ready?RES_NOTRDY:(cmd==CTRL_SYNC?RES_OK:RES_PARERR);
}
