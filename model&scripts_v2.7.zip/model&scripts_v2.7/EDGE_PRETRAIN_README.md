# SC520 v2.6 edge-density training package

This package prepares a fourth CNN input channel derived from the board's
existing Gaussian and robust Sobel edge path. The packaged root model and
programming files remain the known-good v2.4-8 baseline until a reviewed
candidate is installed. A complete untouched copy is retained in
`baseline_v2.4-8/`.

## Input definition

- RGB input: 1280x720, converted to the existing 160x90 8x8 box means.
- CH3: 90x160 edge density in 0..127.
- Edge source: augmented RGB, then the board-aligned Gaussian, 3x3
  median-Sobel, fixed threshold 80, and 8x8 hit density.
- Training order: photometric/grayscale augmentation first, edge density last.
- The first-layer CH3 weights are initialized to zero when fine-tuning starts.

The machine-readable interface is `configs/cnn_contract.edge.json`.

## Dataset

Use the existing frozen dataset and split:

```text
D:\Works\QianSai\Versions\datasets\dataset1027
```

No edge images, edge labels, or replacement split are required.

| Split | Groups | Images | Purpose |
| --- | --- | ---: | --- |
| train | S02/S03/S04 | 2727 | weight updates only |
| val | S05 | 395 | model and threshold selection |
| test | S01 | 1848 | locked final evaluation |

Do not train on validation or test images.

## Commands

Run the observation-only pretraining first:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File "D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.6\scripts\train_edge.ps1" `
  -Mode pretrain
```

The default observation output is:

```text
D:\Works\QianSai\Versions\runs\edge_test0
```

This run uses five epochs, QAT off, and does not export a deployment bundle.
It is only for checking learning behavior and validation metrics.

After reviewing `edge_test0`, run the formal candidate:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File "D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.6\scripts\train_edge.ps1" `
  -Mode formal
```

The formal command writes the candidate model package into this v2.6 directory.
Its metrics and validation evidence must be reviewed before replacing any
known-good programming files.

## Rollback

The original package remains at:

```text
D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8
```

A second full copy is retained at:

```text
D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.6\baseline_v2.4-8
```

Do not modify either baseline directory during edge experiments.
