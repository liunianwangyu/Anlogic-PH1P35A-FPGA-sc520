# SC520 v2.6 edge-density formal training review

Status: formal model candidate produced. The fourth channel is effective on
the S05 validation set. The locked S01 test has not been run, and the current
BIT/BIN files are still the old non-edge runtime.

## Training

- Initialization: `edge_test0/weights/best_training.pt`
- Edge initialization zeroed: no
- First-layer CH3 weights remained from edge pretraining
- Regular fine-tuning: 10 epochs, learning rate 2e-5
- Best regular epoch: 9, validation AP50 0.768965
- QAT: 30 epochs, learning rate 1e-4
- Best QAT epoch: 25, integer validation AP50 0.788377
- Calibration samples: 256
- Training time: approximately 2 h 36 min

## Validation comparison at threshold 131

Both models were evaluated on the same S05 validation split, with 395 images
and 180 empty scenes.

| Display metric | Old v2.4-8 | Edge v2.6 | Delta |
| --- | ---: | ---: | ---: |
| AP50 | 0.706282 | **0.750237** | **+4.40 pp** |
| Precision | 0.879310 | 0.871383 | -0.79 pp |
| Recall | 0.747801 | **0.794721** | **+4.69 pp** |
| F1 | 0.808241 | **0.831288** | **+2.30 pp** |
| Empty-image false boxes | 7 / 180 | 10 / 180 | +3 |
| Class 0 AP50 | 0.781298 | **0.823437** | **+4.21 pp** |
| Class 1 AP50 | 0.631267 | **0.677037** | **+4.58 pp** |

At threshold 128, the edge model reaches display AP50 0.805166 and F1
0.820937, but has 26 false boxes on empty images. Threshold 131 is the better
operating point for F1 and empty-scene control.

## Threshold scan

The validation scan selected threshold 131 using detection F1, then empty
false boxes as the tie-breaker.

| Threshold | Display AP50 | Precision | Recall | F1 | Empty FP |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 128 | 0.8052 | 0.7740 | 0.8739 | 0.8209 | 26 |
| 129 | 0.7693 | 0.7995 | 0.8301 | 0.8194 | 18 |
| 130 | 0.7696 | 0.8518 | 0.8225 | 0.8330 | 15 |
| 131 | 0.7502 | 0.8714 | 0.7947 | 0.8313 | 10 |
| 132 | 0.7030 | 0.8757 | 0.7442 | 0.8073 | 7 |

Threshold 130 has a slightly higher F1, but threshold 131 preserves the
existing firmware threshold and reduces empty-scene false boxes by another
five. The current threshold-selection script chose 131.

## Artifact checks

- `weights/cnn_weights.dat` equals `deploy/cnn_weights.dat`.
- `quant/quant_params.entries.json` equals the deploy copy.
- Bundle contract uses `R,G,B,EDGE_DENSITY`.
- Float, ONNX, model checkpoint and deploy manifest were generated.
- No integer saturation was observed in the four CNN layers.

## Deployment boundary

Do not burn the current package yet. The RTL edge-density sideband and
`cnn_capture` CH3 writer have not been integrated, and the files under `burn/`
are still the old v2.4-8 BIT/BIN. The model can be installed for simulation and
verified against an edge-capable bitstream only.

Recommended next steps:

1. Implement the C4 sideband and mirror alignment in RTL.
2. Perform Python-to-RTL bit-exact comparison for all 14,400 input words.
3. Regenerate the pair of edge-capable BIT and MCU BIN.
4. Run the full regression suite and board acceptance.
5. Evaluate the locked S01 set after the implementation is frozen.
