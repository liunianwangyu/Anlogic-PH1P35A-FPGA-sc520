# SC520 v2.6-6 边缘密度模型硬件版本

日期：2026-10-30  
状态：RTL、固件、综合布线、时序和仿真验证通过；尚未进行实板验收。

## 1. 模型与输入契约

- 模型：`dataset1027_edge80_v1`
- 输入：`R,G,B,EDGE_DENSITY`
- 输入形状：`1x4x90x160`
- 输出形状：`1x8x12x20`
- 边缘阈值：`80`
- 推荐目标检测门限：`131`
- 权重 SHA256：`a38f922a23233a34ddac00dc3dc83258f558ab091933e8fe54789e5559444ece`
- 量化参数 SHA256：`04901ab30e7223fbdc6732cb9e4fffedc802774efb7055b7ede254e1260283a7`
- 契约几何 SHA256：`88ae3dce7f0896eb45cc5df951876e9498a02026394cb19cf027a51c74135714`

第四通道由板端 Gaussian、鲁棒中值 Sobel、阈值 80 和 8x8 命中密度生成；每块累计 32 个样本，第四通道值为 `min(命中数*4,127)`。

## 2. 本版 RTL 改动

1. `edge_detect_96.v` 输出与显示像素同拍的固定阈值边缘命中。
2. `isp_top.v` 将两路边缘命中沿普通显示和跟踪显示路径旁带传输。
3. 镜像模式保存并反序两路边缘命中，保持与四像素视频拍严格对齐。
4. `cnn_capture.v` 把 8x8 边缘密度写入输入字最高字节，字格式为 `{EDGE_DENSITY,B,G,R}`。
5. `cnn_subsystem.v` 与顶层添加完整 `I_edge_hits`/`O_mon_edge` 连线。
6. 屏幕版本号更新为 `VER:2.6-6`。

## 3. 验证结果

| 项目 | 结果 |
|---|---|
| CNN 存储契约 | PASS，1024 权重、36 qparams、18432 字特征空间 |
| 边缘采集专项 | PASS，14400 字，CH3 密度和 RGB 对齐 |
| 镜像边缘旁带 | PASS，320 拍行反转、321 拍旁带对齐、边缘位换序 |
| CNN 四层端到端 | PASS，6880 字逐字一致，测试输入 CH3 非零 |
| MCU 固件 | PASS，text 87400 B / data 664 B / bss 24328 B |
| TD 综合、布局、布线 | PASS |
| 最终建立时序 | WNS +0.077 ns，TNS 0 ns |
| 最终保持时序 | WNS +0.020 ns，TNS 0 ns |
| Slice | 19059 / 21216，89.83% |
| ERAM20K | 89 / 108，82.41% |
| DSP | 24 / 40，60.00% |
| 迁移路径重绑定 | PASS，模拟换目录后自动修正 td/.al、ROM 和 FD 路径 |

完整日志和最终时序报告位于本目录的 `verification/`。

## 4. 可烧录文件

`burn/` 中的 BIT、压缩 BIT、MCU BIN 必须作为同一套使用：

- `camera_to_dsi_display_v2.6-6.bit`
- `camera_to_dsi_display_compress_v2.6-6.bit`
- `mcu_firmware_v2.6-6.bin`
- `mcu_firmware_v2.6-6.elf`
- `mcu_firmware_v2.6-6.map`
- `camera_to_dsi_display_v2.6-6.hpf`

不要把这些文件与 v2.6-5、v2.4-8 或旧边缘测试版本的 BIT/BIN/权重混用。

## 5. 迁移到其他电脑或目录

复制整个工程到任意路径后，先运行：

```powershell
python tools\prepare_project.py
```

该命令会把以下内容重绑定到当前工程目录：

- TD 的 `.al` 工程根路径
- UI 字体和 Logo 初始化文件路径
- 四路 CNN 权重 ERAM 初始化路径
- FD Platform/Application 的本地路径
- FD 编译器与 Make 的工程描述路径

FD/TD 会自动探测常见安装位置，也可显式设置：

```powershell
$env:FD_HOME = "C:\Anlogic\FD"
$env:TD_HOME = "C:\Anlogic\TD"
python tools\prepare_project.py
```

迁移后推荐按顺序执行：

```powershell
python fd_project\build.py
python verification\run_build.py
python verification\export_hpf.py
python fd_project\prepare_projects.py
python tools\run_edge_regression.py
```

## 6. 同步模型/GUI 打包目录

将本版本的 BIT/BIN、修复后的四通道部署校验脚本以及 GUI 路径重绑定步骤同步到模型包：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File ".\release\v2.6-6\apply_model_package_update.ps1"
```

脚本默认目标是同级目录中的：

```text
D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.6
```

如模型包位置不同，可显式传入 `-PackageRoot`。脚本会先备份被修改的部署脚本和清单，再更新 `burn\`。

## 7. 回退

旧工程 `lab_integrated_sc520_720p_v2.6-5` 未被修改。旧模型 BIT/BIN 仍可从原位置或模型包内 `burn_v2.4-8_LEGACY` 取得。回退时 BIT、BIN 和权重必须一起更换。

## 8. 尚未完成

- 实板摄像头、镜像、跟踪和显示验收
- S01 锁定测试集评估
- 新模型与旧模型的同板视觉对比

在完成实板验收前，建议保留 v2.6-5 作为现场回退版本。
