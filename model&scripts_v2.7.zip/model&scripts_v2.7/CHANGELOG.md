# Changelog

## v2.6 edge-density

- Added board-aligned 8x8 edge density as CNN input CH3.
- Retrained the existing four-channel detector with edge pretraining and QAT.
- Added `density` and legacy-compatible `zero` training modes to the GUI.
- Added edge threshold and Python interpreter controls to the GUI.
- Added model-side edge mode and edge threshold detection to the deployment page.
- Added target input-channel compatibility checks before installation.
- Added portable root launcher, package checker, deployment guide and hash list.
- Preserved the complete v2.4-8 package under `baseline_v2.4-8/`.

## v2.4-8 legacy package

See `baseline_v2.4-8/CHANGELOG.md`.
