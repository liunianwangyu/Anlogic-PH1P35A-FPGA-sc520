# X-AnyLabeling / CNN 部署包

这个目录是训练产物的部署子包，不依赖训练项目。

## 安装到工程

```bat
python "<Versions>\scripts\deploy_model_bundle.py" --bundle "<本目录>" --project "<工程本体目录>" --dry-run
python "<Versions>\scripts\deploy_model_bundle.py" --bundle "<本目录>" --project "<工程本体目录>"
```

安装后在目标工程生成硬件初始化文件并检查。v2.3+ 工程使用：

```bat
cd /d "<工程本体目录>"
python tools\cnn_contract.py --generate
python tools\cnn_contract.py --check
```

旧 v1.7 工程使用：

```bat
cd /d "<Versions>"
.\scripts\cnn_contract.ps1 -GenW ; -GenQrom ; -GenVh ; -Check
.\scripts\cnn_flow.ps1 -Check -Mode external
.\scripts\cnn_regress.ps1
cd /d "<工程本体目录>"
.\build.ps1
```

`model.onnx` 是 float/QAT 参考模型；板上精确部署以 `cnn_weights.dat` + `quant_params.entries.json` 为准。
