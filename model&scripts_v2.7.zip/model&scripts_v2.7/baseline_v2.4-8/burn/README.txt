SC520 model deployment artifacts

FPGA BIT:
  camera_to_dsi_display.bit
  camera_to_dsi_display_compress.bit
MCU BIN:
  mcu_firmware_v2.4-8_thr131.bin
MCU Flash Offset: 0x00E00000
MCU execution address: 0x20E00000

Objectness threshold: 131
The BIT and BIN were generated from the same deployed model and threshold.
Physical-board programming and acceptance were not performed by the packaging tool.
