#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
_project_root.py -- Python 侧的"工程本体目录"解析（train_cnn.py / env_check.py 共用）

背景：脚本已从工程本体搬到 Versions\scripts\，工程根不能再按 __file__ 的父目录算。
解析顺序（与 scripts\resolve_project_root.ps1 保持一致）：
  1) 参数 explicit / 环境变量 QIANSAI_PROJECT
  2) 同目录或上一级的 project_root.txt（一行绝对路径；换版本改这里，最稳）
  3) 兜底：在 scripts 的上一级找 lab_integrated_sc520_720p_v* 里版本号最高的那个
     （自身含 td_project，或只含一个同名子目录且该子目录含 td_project）
"""
import os
import re
from pathlib import Path


def _is_root(p):
    try:
        return (p / 'td_project').is_dir() and (p / 'user_source').is_dir()
    except Exception:
        return False


def _normalize(p):
    try:
        p = Path(p)
    except Exception:
        return None
    if not p.is_dir():
        return None
    if _is_root(p):
        return p
    for c in sorted(p.glob('*')):
        if c.is_dir() and _is_root(c):
            return c
    return None


def _ver_key(name):
    m = re.search(r'v(\d+)\.(\d+)', name)
    return int(m.group(1)) * 1000 + int(m.group(2)) if m else -1


def resolve_project_root(explicit=None):
    here = Path(__file__).resolve().parent
    for c in (explicit, os.environ.get('QIANSAI_PROJECT')):
        r = _normalize(c) if c else None
        if r:
            return r
    for pin in (here / 'project_root.txt', here.parent / 'project_root.txt'):
        try:
            v = pin.read_text(encoding='utf-8-sig').strip()
        except Exception:
            continue
        if v:
            r = _normalize(v)
            if r:
                return r
    base = here.parent
    cands = [d for d in base.glob('lab_integrated_sc520_720p_v*') if d.is_dir()]
    for d in sorted(cands, key=lambda q: _ver_key(q.name), reverse=True):
        if _is_root(d):
            return d
        for c in sorted(d.glob('*')):
            if c.is_dir() and _is_root(c):
                return c
    raise SystemExit('找不到工程根：请在 scripts\\project_root.txt 写一行工程本体绝对路径，或设环境变量 QIANSAI_PROJECT')