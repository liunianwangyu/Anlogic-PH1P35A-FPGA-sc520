param(
    [Parameter(Mandatory=$true)][string]$ProjectRoot,
    [string]$BackupDir = '',
    [string]$TdBin = ''
)

$ErrorActionPreference = 'Stop'
try {
    $root = (Resolve-Path -LiteralPath $ProjectRoot).Path
} catch {
    throw ('Project directory does not exist: ' + $ProjectRoot)
}
$sourceRoot = Join-Path $root 'user_source'
if (-not (Test-Path -LiteralPath $sourceRoot)) {
    throw ('Project is missing user_source: ' + $root)
}

$initExts = @('.dat', '.dath', '.hex', '.mif')
$initFiles = @(Get-ChildItem -LiteralPath $sourceRoot -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $initExts -contains $_.Extension.ToLowerInvariant() })

$byName = @{}
$ambiguous = @{}
foreach ($f in $initFiles) {
    $name = $f.Name.ToLowerInvariant()
    if ($byName.ContainsKey($name)) {
        $ambiguous[$name] = $true
    } else {
        $byName[$name] = $f.FullName
    }
}

$sourceFiles = @(Get-ChildItem -LiteralPath $sourceRoot -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.v', '.sv', '.vh' })
# Match only absolute initialization paths inside double quotes. Resolve each
# basename against user_source so copied projects do not retain old drive roots.
$pattern = '"([A-Za-z]:[\\/][^"\r\n]+?\.(?:dat|dath|hex|mif))"'
$changes = New-Object System.Collections.Generic.List[string]
$unresolved = New-Object System.Collections.Generic.List[string]
$changedFiles = 0

foreach ($sf in $sourceFiles) {
    $text = [System.IO.File]::ReadAllText($sf.FullName, [System.Text.Encoding]::UTF8)
    $updated = $text
    foreach ($m in [regex]::Matches($text, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
        $oldPath = $m.Groups[1].Value
        $name = [System.IO.Path]::GetFileName($oldPath.Replace('/', '\')).ToLowerInvariant()
        if ($ambiguous.ContainsKey($name)) {
            $unresolved.Add(('{0}: ambiguous init basename {1}' -f $sf.FullName, $name))
            continue
        }
        if (-not $byName.ContainsKey($name)) {
            $unresolved.Add(('{0}: missing init basename {1}' -f $sf.FullName, $name))
            continue
        }
        $newPath = ([string]$byName[$name]).Replace('\', '/')
        if ($oldPath -ne $newPath) {
            $updated = $updated.Replace($oldPath, $newPath)
            $changes.Add(('{0}: {1} -> {2}' -f $sf.FullName, $oldPath, $newPath))
        }
    }
    if ($updated -ne $text) {
        if ($BackupDir) {
            $rel = $sf.FullName.Substring($root.Length).TrimStart([char[]]@('\', '/'))
            $dst = Join-Path $BackupDir $rel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
            Copy-Item -LiteralPath $sf.FullName -Destination $dst -Force
        }
        [System.IO.File]::WriteAllText($sf.FullName, $updated, (New-Object System.Text.UTF8Encoding($false)))
        $changedFiles++
    }
}

if ($unresolved.Count -gt 0) {
    $unresolved | ForEach-Object { Write-Host ('  !! ' + $_) }
    throw ('Unable to resolve {0} initialization path(s) before synthesis' -f $unresolved.Count)
}

if ($changedFiles -eq 0) {
    Write-Host '  init paths: all already point to the current project'
} else {
    Write-Host ('  init paths: repaired {0} source file(s), {1} path(s)' -f $changedFiles, $changes.Count)
    $changes | Select-Object -First 20 | ForEach-Object { Write-Host ('    ' + $_) }
    if ($changes.Count -gt 20) {
        Write-Host ('    ... and {0} more' -f ($changes.Count - 20))
    }
}
Write-Host 'PASS INIT_PATH_REPAIR'

# ModelSim run files under cnn_flow also reference the vendor ph1p simulation
# primitives by absolute path. Map those basenames to the TD installation
# actually selected for this deployment.
if ($TdBin -and (Test-Path -LiteralPath $TdBin)) {
    $tdRoot = Split-Path -Parent (Split-Path -Parent (Resolve-Path -LiteralPath $TdBin).Path)
    $simRoot = Join-Path $tdRoot 'sim_release\ph1p'
    if (-not (Test-Path -LiteralPath $simRoot)) {
        throw ('Selected TD has no sim_release\ph1p directory: ' + $tdRoot)
    }
    $simByName = @{}
    Get-ChildItem -LiteralPath $simRoot -File -Filter '*.v' | ForEach-Object {
        $simByName[$_.Name.ToLowerInvariant()] = $_.FullName
    }
    $flowDir = Join-Path $root 'verification\cnn_flow'
    $pathPattern = '"([A-Za-z]:[\\/][^"\r\n]+?\.(?:v|sv))"'
    $doChanges = 0
    foreach ($df in @(Get-ChildItem -LiteralPath $flowDir -File -Filter '*.do' -ErrorAction SilentlyContinue)) {
        $text = [System.IO.File]::ReadAllText($df.FullName, [System.Text.Encoding]::UTF8)
        $updated = $text
        $missing = @()
        foreach ($m in [regex]::Matches($text, $pathPattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            $oldPath = $m.Groups[1].Value
            $name = [System.IO.Path]::GetFileName($oldPath.Replace('/', '\')).ToLowerInvariant()
            if ($simByName.ContainsKey($name)) {
                $newPath = ([string]$simByName[$name]).Replace('\', '/')
                if ($oldPath -ne $newPath) {
                    $updated = $updated.Replace($oldPath, $newPath)
                    $doChanges++
                }
            } elseif ($name -like 'ph1p_*') {
                $missing += $name
            }
        }
        if ($missing.Count -gt 0) {
            throw ('TD simulation library file missing from ' + $simRoot + ': ' + ($missing -join ', '))
        }
        if ($updated -ne $text) {
            if ($BackupDir) {
                $rel = $df.FullName.Substring($root.Length).TrimStart([char[]]@('\', '/'))
                $dst = Join-Path $BackupDir $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
                Copy-Item -LiteralPath $df.FullName -Destination $dst -Force
            }
            [System.IO.File]::WriteAllText($df.FullName, $updated, (New-Object System.Text.UTF8Encoding($false)))
        }
    }
    if ($doChanges -eq 0) {
        Write-Host '  ModelSim paths: all refer to the selected TD installation'
    } else {
        Write-Host ('  ModelSim paths: repaired {0} vendor path(s)' -f $doChanges)
    }
}
Write-Host 'PASS SIM_PATH_REPAIR'
