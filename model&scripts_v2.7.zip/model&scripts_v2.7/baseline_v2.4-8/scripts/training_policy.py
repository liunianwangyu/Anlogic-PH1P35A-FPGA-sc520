"""Reproducible split/calibration and strict native-label audit; never trains."""
from pathlib import Path
import hashlib
import json
import random
from collections import defaultdict


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def group(item):
    name = Path(item[2]).stem
    return name.split('_')[0] if '_' in name else '__all__'


def fixed_split(items, val_ratio, test_ratio, seed):
    if not (0 < val_ratio < 1 and 0 < test_ratio < 1 and val_ratio+test_ratio < 1):
        raise ValueError('val/test ratios must be positive and sum to less than 1')
    groups = defaultdict(list)
    for it in items:
        groups[group(it)].append(it)
    keys = sorted(groups)
    if len(keys) < 3:
        raise ValueError('Need at least three independent scenes for train/val/test; no per-image fallback')
    random.Random(seed).shuffle(keys)
    nv = max(1, round(len(keys)*val_ratio)); nt = max(1, round(len(keys)*test_ratio))
    if nv+nt >= len(keys):
        raise ValueError('Split leaves no training scenes; provide more scenes or smaller ratios')
    return {name: [it for k in ks for it in groups[k]] for name, ks in
            [('val', keys[:nv]), ('test', keys[nv:nv+nt]), ('train', keys[nv+nt:])]}


def save_fixed_split(parts, path):
    seen = {}; rows = {}
    for name, items in parts.items():
        rows[name] = []
        for ip, lp, original in items:
            ih = digest(ip)
            if ih in seen and seen[ih] != name:
                raise ValueError('Exact duplicate image crosses splits: '+ip)
            seen[ih] = name
            rows[name].append(dict(image=Path(ip).name, original=original, group=group((ip,lp,original)),
                                   image_sha256=ih, label_sha256=digest(lp)))
    Path(path).write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')


def load_fixed_split(items, path):
    rows = json.loads(Path(path).read_text(encoding='utf-8'))
    index = {Path(it[0]).name: it for it in items}
    if len(index) != len(items):
        raise ValueError('Duplicate image basenames')
    result = {}; groups = {}; names = set(); hashes = {}
    for part in ['train', 'val', 'test']:
        result[part] = []
        for row in rows[part]:
            it = index[row['image']]
            if row['image'] in names:
                raise ValueError('Sample appears twice in split manifest')
            names.add(row['image'])
            ih = digest(it[0])
            if ih != row['image_sha256'] or digest(it[1]) != row['label_sha256']:
                raise ValueError('Dataset content changed: '+it[0])
            key = group(it)
            if row['group'] != key or row['original'] != it[2]:
                raise ValueError('Dataset provenance changed: '+it[0])
            if key in groups and groups[key] != part:
                raise ValueError('Scene crosses splits: '+key)
            if ih in hashes and hashes[ih] != part:
                raise ValueError('Duplicate image crosses splits')
            groups[key] = part; hashes[ih] = part
            result[part].append(it)
        if not result[part]:
            raise ValueError('Empty split: '+part)
    if names != set(index):
        raise ValueError('Dataset inventory changed; freeze a new explicit split')
    return result


def stratified_calibration(items, count, seed):
    bins = defaultdict(list)
    for it in items:
        from PIL import Image
        with Image.open(it[0]) as image:
            image = image.convert('RGB'); image.thumbnail((16,9))
            brightness = int(sum(sum(px) for px in image.getdata())/(image.width*image.height*3))//64
        boxes = json.loads(Path(it[1]).read_text(encoding='utf-8-sig')).get('boxes', [])
        classes = tuple(sorted({int(b['cls']) for b in boxes}))
        sizes = tuple(sorted({int(max(b['w'], b['h']) >= 32) for b in boxes}))
        bins[(group(it), classes, sizes, brightness)].append(it)
    rng = random.Random(seed)
    for values in bins.values():
        rng.shuffle(values)
    chosen = []
    while len(chosen) < count and bins:
        for k in sorted(list(bins)):
            chosen.append(bins[k].pop())
            if not bins[k]: del bins[k]
            if len(chosen) >= count: break
    return chosen


def validate_boxes(boxes, num_class, gw=20, gh=12):
    occupied = set()
    for b in boxes:
        gx, gy, cls = int(b['gx']), int(b['gy']), int(b['cls'])
        if not (0 <= gx < gw and 0 <= gy < gh and 0 <= cls < num_class):
            raise ValueError('Invalid grid/class: '+str(b))
        if (gx, gy) in occupied:
            raise ValueError('Multiple targets in one head cell; retain and re-label/isolate sample')
        occupied.add((gx, gy))
        if any(not -128 <= float(b[k]) <= 127 for k in ['dx', 'dy']) or any(not 1 <= float(b[k]) <= 127 for k in ['w', 'h']):
            raise ValueError('Box exceeds signed INT8 head representation: '+str(b))
        if not (0 <= b['x1'] < b['x2'] <= 1279 and 0 <= b['y1'] < b['y2'] <= 719):
            raise ValueError('Degenerate/out-of-image box: '+str(b))
