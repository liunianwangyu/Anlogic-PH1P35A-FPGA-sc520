﻿<#
  resolve_project_root.ps1  --  解析"当前要操作的工程本体"目录

  背景：脚本已经从工程本体搬到 Versions\scripts\（版本文件夹只留项目主体 + 比特流），
        所以工程根不能再按 $PSScriptRoot 的父目录算。

  解析顺序（先命中先用）：
    1) 参数 -Explicit
    2) 环境变量 QIANSAI_PROJECT
    3) 本文件同目录的 project_root.txt（一行绝对路径；换版本就改这里，最稳）
    4) 兜底：在 scripts 的上一级找 lab_integrated_sc520_720p_v* 里版本号最高的那个
       （自身含 td_project，或只含一个同名子目录且子目录含 td_project）

  只向管道输出一行：工程本体的绝对路径（找不到则不输出）。
#>
param([string]$Explicit)

function Test-ProjectRoot([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $p 'td_project')) -and
            (Test-Path -LiteralPath (Join-Path $p 'user_source')))
}

function Normalize-ProjectRoot([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    if (-not (Test-Path -LiteralPath $p)) { return $null }
    $rp = (Resolve-Path -LiteralPath $p).Path
    if (Test-ProjectRoot $rp) { return $rp }
    foreach ($c in @(Get-ChildItem -LiteralPath $rp -Directory -ErrorAction SilentlyContinue)) {
        if (Test-ProjectRoot $c.FullName) { return $c.FullName }
    }
    return $null
}

function Get-VerKey([string]$name) {
    if ($name -match 'v(\d+)\.(\d+)') { return ([int]$Matches[1] * 1000 + [int]$Matches[2]) }
    return -1
}

$cand = New-Object System.Collections.Generic.List[string]
if ($Explicit) { $cand.Add($Explicit) }
if ($env:QIANSAI_PROJECT) { $cand.Add($env:QIANSAI_PROJECT) }
$pin = Join-Path $PSScriptRoot 'project_root.txt'
if (Test-Path -LiteralPath $pin) {
    $v = Get-Content -LiteralPath $pin -Raw -ErrorAction SilentlyContinue
    if ($v) { $cand.Add($v.Trim()) }
}
foreach ($c in $cand) {
    $r = Normalize-ProjectRoot $c
    if ($r) { Write-Output $r; return }
}

$base = Split-Path -Parent $PSScriptRoot
$best = $null; $bestKey = -2; $bestT = [datetime]'1970-01-01'
foreach ($d in @(Get-ChildItem -LiteralPath $base -Directory -Filter 'lab_integrated_sc520_720p_v*' -ErrorAction SilentlyContinue)) {
    $r = Normalize-ProjectRoot $d.FullName
    if (-not $r) { continue }
    $k = Get-VerKey $d.Name
    if (($k -gt $bestKey) -or (($k -eq $bestKey) -and ($d.LastWriteTime -gt $bestT))) {
        $bestKey = $k; $bestT = $d.LastWriteTime; $best = $r
    }
}
if ($best) { Write-Output $best }