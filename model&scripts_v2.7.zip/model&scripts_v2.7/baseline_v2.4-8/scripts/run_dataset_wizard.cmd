@echo off
rem ============================================================
rem  Launcher for the step-by-step CNN dataset wizard.
rem  WinForms needs STA, so force -STA and bypass execution policy.
rem ============================================================
setlocal
set PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe
if not exist "%PS%" set PS=powershell.exe
"%PS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0dataset_wizard.ps1" %*
endlocal
