﻿CNN 数据集与模型训练向导使用说明
=================================

启动
----
双击本目录下的：
    run_dataset_wizard.cmd

新向导按四步推进，每一步底部都有“上一步 / 下一步 / 取消”：

1. 路径与预处理
2. 导入标签
3. 训练与导出
4. 部署到工程

仅部署模型
----------
队友只需要安装权重、验收或烧录时，不必填写数据集根：

1. 打开向导。
2. 勾选第 1 步的“仅部署模型”，或直接点击底部的“直接部署”。
3. 在第 4 步选择完整模型版本目录和目标工程本体。
4. 选择安装、验收或编译 bit。

仅部署模式会跳过数据集、标签映射和训练输出目录检查，只保留部署所需的模型包与工程检查。

第 2 步只保留 X-AnyLabeling 原生 JSON（2b）
------------------------------------------------
以后统一使用这条路线：

- 在 X-AnyLabeling 中直接打开 <数据集根>\images。
- 画矩形，标签名使用 starve、genshin 等明确名称。
- 有目标图片保存同名 JSON（例如 S01_starve_0001.json）。
- 空场景也必须保存 shapes=[] 的同名 JSON，导入后作为负样本。
- 点“扫描标签并生成映射”，GUI 会读取 JSON 中实际出现的标签名。
- 在映射表格中确认每个标签对应的类别号，例如 starve=0、genshin=1。
- 映射会保存到配置，下次打开自动复用。
- 点“导入 X-AnyLabeling JSON”即可，不需要手输命令或 ClassMap 字符串。
- 未知标签不会自动映射到 class 0，必须在 GUI 映射表中确认。

路径含义
--------
工程本体目录：
    必须包含 td_project\ 和 user_source\。
    不要选 Versions 根目录，也不要选 scripts\。

数据集根目录（训练流程）：
    必须包含非空的 images\。
    不是 images 本身，也不是 runs 输出目录。

原始图片目录：
    只给“运行预处理”使用，只扫描第一层图片。
    如果 images\ 已有原生 JSON，不要重复预处理，否则旧标注可能错位。

CNN 契约文件：
    默认是：
    <工程本体>\user_source\hdl_source\cnn\cnn_contract.json

训练输出父目录：
    只选版本目录的上一级，例如：
    <数据集根>\runs
    每次训练自动新建 <标签>_vN_<时间>。
    不要选 model\、weights\、deploy\ 或某个版本目录。

模型版本目录：
    选一次训练的完整版本目录，或选 runs 父目录自动取最新。
    分享给队友时发送整个版本目录，不要只发 model\ 或 deploy\。

部署状态：
    第 4 步默认勾选“自动跟随最新训练模型”，并同时扫描当前训练输出目录、
    Versions\runs 和模型包目录。选择目录、切换自动跟随或修改目标门限后，
    状态栏会立即刷新权重时间、BIT/BIN 时间/门限及是否需要重编。
    GUI 的“开始部署”只调用 deploy_cnn.ps1，不再维护第二套部署入口。

训练产物
--------
每次训练会导出：

- weights\cnn_weights.dat
- quant\quant_params.entries.json
- model\model.pt
- model\model.onnx（勾选时）
- deploy\deploy_manifest.json 及其部署文件
- model_card.json、meta.json、VERSION、exp\ 等

部署
----
三种动作：

- 只安装权重：安装并生成 RTL 侧文件，跳过 ModelSim。
- 安装 + 验收：增加 ModelSim 逐层逐字对拍。
- 安装 + 验收 + 编译 bit：再跑 TD P&R，在版本目录的 burn\ 生成比特流。

部署前会校验模型包和目标工程 contract 几何。几何不匹配时必须停止，
不要用 --force 绕过。

自测
----
命令行运行：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -STA ^
      -File ".\dataset_wizard.ps1" -SelfTest

自测覆盖 GUI 标签扫描与映射、2b 导入、正样本/空场景计数和 dataset.yaml 生成。
