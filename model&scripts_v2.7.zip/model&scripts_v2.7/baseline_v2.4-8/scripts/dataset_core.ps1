﻿<#
  dataset_core.ps1 -- 数据集预处理核心（无 GUI，可独立测试/被 GUI 调用）

  职责：
    1. Invoke-Preprocess   扫描输入图片 -> 等比缩放+居中裁剪到 1280x720 -> 统一编号 -> id_map.csv + 报告
    2. Encode-HeadLabel    按 cnn_contract.json 的公式把框编码成 head 目标（可校验）

  当前 X-AnyLabeling 2b 导入流程由 import_xanylabeling.ps1 实现。
  旧单页工具使用的兼容函数已拆分到 dataset_core_legacy.ps1，不属于新向导依赖。

  依赖：.NET System.Drawing（本机已确认可用）
#>
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

# ============================ 1. 预处理 ============================
function Invoke-Preprocess {
    param(
        [Parameter(Mandatory=$true)][string]$InDir,
        [Parameter(Mandatory=$true)][string]$OutRoot,
        [string]$Exts = '.jpg,.jpeg,.png,.bmp',
        [int]$W = 1280, [int]$H = 720,
        [int]$JpegQuality = 95,
        [switch]$KeepAspectNoCrop     # 不加就做等比缩放+居中裁剪
    )
    if (-not (Test-Path -LiteralPath $InDir)) { throw ('输入目录不存在: ' + $InDir) }
    $imgDir = Join-Path $OutRoot 'images'
    $repDir = Join-Path $OutRoot 'report'
    New-Item -ItemType Directory -Force -Path $imgDir,$repDir | Out-Null

    $extList = $Exts.Split(',') | ForEach-Object { $_.Trim().ToLower() }
    $files = Get-ChildItem -LiteralPath $InDir -File |
             Where-Object { $extList -contains $_.Extension.ToLower() } |
             Sort-Object Name
    if ($files.Count -eq 0) { throw ('输入目录里没有图片: ' + $InDir) }

    $enc = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
           Where-Object { $_.MimeType -eq 'image/jpeg' }
    $ep  = New-Object System.Drawing.Imaging.EncoderParameters 1
    $ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter ([System.Drawing.Imaging.Encoder]::Quality), ([int64]$JpegQuality)

    $map = New-Object System.Collections.Generic.List[object]
    $rep = New-Object System.Collections.Generic.List[object]
    $n = 0
    foreach ($f in $files) {
        $n++
        $id = '{0:d4}' -f $n
        $src = [System.Drawing.Image]::FromFile($f.FullName)
        try {
            $sw = $src.Width; $sh = $src.Height
            # 等比缩放到"覆盖"1280x720，再居中裁剪
            $scale = [Math]::Max($W / [double]$sw, $H / [double]$sh)
            $rw = [int][Math]::Round($sw * $scale); $rh = [int][Math]::Round($sh * $scale)
            $offX = [int][Math]::Floor(($rw - $W) / 2.0)
            $offY = [int][Math]::Floor(($rh - $H) / 2.0)

            $dst = New-Object System.Drawing.Bitmap $W, $H
            $g = [System.Drawing.Graphics]::FromImage($dst)
            $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
            $g.DrawImage($src, (New-Object System.Drawing.Rectangle (-$offX), (-$offY), $rw, $rh))
            $g.Dispose()

            $outImg = Join-Path $imgDir ($id + '.jpg')
            $dst.Save($outImg, $enc, $ep)
            # 顺便算一下均值亮度（过暗/过曝告警用）
            $mean = Get-MeanLuma $dst
            $dst.Dispose()

            $map.Add([pscustomobject]@{ new_id=$id; new_file=($id + '.jpg'); src_file=$f.Name;
                                        src_w=$sw; src_h=$sh; scale=[Math]::Round($scale,6);
                                        off_x=$offX; off_y=$offY })
            $rep.Add([pscustomobject]@{ new_id=$id; src_file=$f.Name; src_size=("$sw x $sh");
                                        scaled=("$rw x $rh"); crop_off=("$offX,$offY");
                                        mean_luma=$mean; warn=$(if ($mean -lt 40) {'过暗'} elseif ($mean -gt 220) {'过曝'} else {''}) })
        } finally { $src.Dispose() }
    }

    $mapCsv = Join-Path $OutRoot 'id_map.csv'
    $map | Export-Csv -LiteralPath $mapCsv -NoTypeInformation -Encoding UTF8
    $repCsv = Join-Path $repDir 'preprocess_report.csv'
    $rep | Export-Csv -LiteralPath $repCsv -NoTypeInformation -Encoding UTF8
    Write-Host ('预处理完成: ' + $n + ' 张 -> ' + $imgDir)
    Write-Host ('  id_map : ' + $mapCsv)
    Write-Host ('  报告   : ' + $repCsv)
    $warn = @($rep | Where-Object { $_.warn -ne '' })
    if ($warn.Count -gt 0) { Write-Host ('  !! 亮度告警 ' + $warn.Count + ' 张（过暗/过曝）') -ForegroundColor Yellow }
    return [pscustomobject]@{ Count=$n; MapCsv=$mapCsv; ReportCsv=$repCsv; WarnCount=$warn.Count }
}

function Get-MeanLuma([System.Drawing.Bitmap]$bmp) {
    # 缩小到 32x18 再取平均，够用且极快
    $tw = 32; $th = 18
    $tmp = New-Object System.Drawing.Bitmap $tw, $th
    $g = [System.Drawing.Graphics]::FromImage($tmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.DrawImage($bmp, 0, 0, $tw, $th)
    $g.Dispose()
    $s = 0L
    for ($y=0; $y -lt $th; $y++) { for ($x=0; $x -lt $tw; $x++) {
        $c = $tmp.GetPixel($x,$y)
        $s += [int](0.299*$c.R + 0.587*$c.G + 0.114*$c.B)
    } }
    $tmp.Dispose()
    return [int][Math]::Round($s / [double]($tw*$th))
}

# ============================ 2. head 目标编码 ============================
function Encode-HeadLabel {
    param([int]$x1,[int]$y1,[int]$x2,[int]$y2,[int]$GW=20,[int]$GH=12,
          [int]$CellW=64,[int]$CellH=60)
    $cx = ($x1+$x2)/2.0; $cy = ($y1+$y2)/2.0
    $gx = [Math]::Min($GW-1, [int][Math]::Floor($cx/$CellW))
    $gy = [Math]::Min($GH-1, [int][Math]::Floor($cy/$CellH))
    $dx = [int][Math]::Round(($cx - ($gx*$CellW + $CellW/2)) * 2)
    $dy = [int][Math]::Round(($cy - ($gy*$CellH + $CellH/2)) * 2)
    # 单位是 8 个原图像素（w/h 8 位无符号）
    $w  = [int][Math]::Round(($x2-$x1) / 8.0)
    $h  = [int][Math]::Round(($y2-$y1) / 8.0)
    return [pscustomobject]@{ gx=$gx; gy=$gy; dx=$dx; dy=$dy; w=$w; h=$h }
}

