#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
deploy_model_bundle.py -- 把训练产出的 deploy/ 包安装到指定工程

训练和部署解耦：
  * 训练侧只负责生成 model.pt / model.onnx / deploy/*；
  * 本脚本只依赖标准库，不导入 torch，也不依赖训练环境；
  * 安装前校验 contract 几何哈希，防止把权重装到不兼容的 RTL 版本。

用法：
  python scripts\deploy_model_bundle.py --bundle <run目录或deploy目录> --project <工程本体> --dry-run
  python scripts\deploy_model_bundle.py --bundle <...> --project <...>
"""

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def contract_geometry(c):
    ignore = {'version', 'frozen', 'purpose', 'device', 'status',
              'placeholder_weights', 'quant_params'}
    geo = {k: v for k, v in c.items() if k not in ignore}
    qp = c.get('quant_params', {}) or {}
    geo['quant_params'] = {k: v for k, v in qp.items() if k != 'entries'}
    return geo


def contract_geometry_sha256(c):
    raw = json.dumps(contract_geometry(c), sort_keys=True,
                     ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def read_text_raw(path):
    with open(path, 'rb') as f:
        return f.read().decode('utf-8')


def write_text_raw(path, text):
    tmp = Path(str(path) + '.tmp')
    with open(tmp, 'wb') as f:
        f.write(text.encode('utf-8'))
    os.replace(tmp, path)


def resolve_bundle(path):
    p = Path(path).expanduser().resolve()
    if (p / 'deploy_manifest.json').exists():
        return p
    if (p / 'deploy' / 'deploy_manifest.json').exists():
        return p / 'deploy'
    raise SystemExit('找不到 deploy_manifest.json：%s' % p)


def parse_args():
    ap = argparse.ArgumentParser(description='安装 X-AnyLabeling/CNN 训练部署包')
    ap.add_argument('--bundle', required=True,
                    help='训练输出目录，或其中的 deploy 子目录')
    ap.add_argument('--project', required=True,
                    help='工程本体目录（含 user_source/hdl_source/cnn）')
    ap.add_argument('--dry-run', action='store_true', help='只检查并打印计划，不写文件')
    ap.add_argument('--no-backup', action='store_true', help='经使用者确认后直接原位安装，不建立备份目录')
    ap.add_argument('--force', action='store_true',
                    help='跳过 contract 几何哈希检查（不推荐）')
    return ap.parse_args()


def main():
    args = parse_args()
    bundle = resolve_bundle(args.bundle)
    manifest = json.loads((bundle / 'deploy_manifest.json').read_text(encoding='utf-8'))

    project = Path(args.project).expanduser().resolve()
    contract_path = project / 'user_source' / 'hdl_source' / 'cnn' / 'cnn_contract.json'
    if not contract_path.exists():
        raise SystemExit('目标工程缺少 cnn_contract.json：%s' % contract_path)

    weights_src = bundle / manifest.get('weights_file', 'cnn_weights.dat')
    qparams_src = bundle / manifest.get('qparams_file', 'quant_params.entries.json')
    for p in (weights_src, qparams_src):
        if not p.exists():
            raise SystemExit('部署包缺少文件：%s' % p)

    for key, p in (('weights_sha256', weights_src),
                   ('qparams_sha256', qparams_src),
                   ('contract_file_sha256',
                    bundle / manifest.get('contract_file', 'cnn_contract.bundle.json'))):
        expected = manifest.get(key)
        if expected and p.exists() and sha256_file(p) != expected:
            raise SystemExit('部署包文件哈希不匹配：%s' % p)

    weights = [t for t in read_text_raw(weights_src).split() if t]
    target_contract = json.loads(contract_path.read_text(encoding="utf-8"))
    expected = 4*target_contract["weight_layout"]["words_per_instance"]
    if len(weights) != expected:
        raise SystemExit('cnn_weights.dat 行数 %d != %d，拒绝安装' % (len(weights),expected))
    entries = json.loads(qparams_src.read_text(encoding='utf-8'))
    if len(entries) != 36:
        raise SystemExit('quant_params.entries.json 条数 %d != 36，拒绝安装' % len(entries))

    target_contract = json.loads(contract_path.read_text(encoding='utf-8'))
    target_geo = contract_geometry_sha256(target_contract)
    bundle_geo = manifest.get('contract_geometry_sha256')
    if bundle_geo and target_geo != bundle_geo and not args.force:
        raise SystemExit(
            'contract 几何不匹配，拒绝安装：\n'
            '  bundle: %s\n  target: %s\n'
            '如果确认兼容，可加 --force。' % (bundle_geo, target_geo))

    print('bundle :', bundle)
    print('project:', project)
    print('weights:', len(weights), '行', sha256_file(weights_src))
    print('qparams:', len(entries), '条', sha256_file(qparams_src))
    print('contract geometry:', target_geo,
          '(MATCH)' if target_geo == bundle_geo else '(FORCED)')

    if args.dry_run:
        print('\n[dry-run] 未写入任何文件。')
        return 0

    stamp = time.strftime('%Y%m%d_%H%M%S')
    backup = project / 'backups' / ('model_bundle_' + stamp)
    if not args.no_backup:backup.mkdir(parents=True, exist_ok=True)
    wdst = contract_path.parent / 'cnn_weights.dat'
    if wdst.exists() and not args.no_backup:
        shutil.copy2(wdst, backup / 'cnn_weights.dat')
    if not args.no_backup:
        shutil.copy2(contract_path, backup / 'cnn_contract.json')
        print('backup :', backup)

    # 直接按 bundle 的字节写入，保留原始换行/编码，避免和 bundle 哈希不一致。
    tmp = Path(str(wdst) + '.tmp')
    shutil.copyfile(weights_src, tmp)
    os.replace(tmp, wdst)
    print('weights:', wdst)

    txt = read_text_raw(contract_path)
    nl = '\r\n' if '\r\n' in txt else '\n'
    i0 = txt.find('"entries"')
    if i0 < 0:
        raise SystemExit('cnn_contract.json 里找不到 "entries"')
    i1 = txt.find(']', i0)
    if i1 < 0:
        raise SystemExit('"entries" 数组没有闭合')
    body = '[' + nl + (',' + nl).join(
        '      { "oc": %d, "shift": %d, "bias": %d }'
        % (e['oc'], e['shift'], e['bias']) for e in entries
    ) + nl + '    ]'
    txt = txt[:i0] + '"entries": ' + body + txt[i1 + 1:]
    for old in ('"status": "临时占位，不是训练结果"',
                '"status": "selfcheck (P3-d: 可预测权重端到端自检；用 -Restore 还原)"'):
        if old in txt:
            txt = txt.replace(old, '"status": "trained: %s"' % manifest.get('model_name', 'bundle'))
    write_text_raw(contract_path, txt)
    print('contract:', contract_path)

    check = json.loads(contract_path.read_text(encoding='utf-8'))
    if len(check['quant_params']['entries']) != 36:
        raise SystemExit('契约回读异常：entries 条数不对')
    print('verify : OK')
    print()
    versions_root = Path(__file__).resolve().parent.parent
    project_contract_tool = project / 'tools' / 'cnn_contract.py'
    print('下一步：')
    if project_contract_tool.exists():
        print('  cd /d "%s"' % project)
        print(r'  python tools\cnn_contract.py --generate')
        print(r'  python tools\cnn_contract.py --check')
        print('  (v2.3+ 使用四路 cnn_weight_*.dath，不使用 cnn_wrom.v)')
    else:
        print('  cd /d "%s"' % versions_root)
        print(r'  .\scripts\cnn_contract.ps1 -GenW ; -GenQrom ; -GenVh ; -Check')
        print(r'  .\scripts\cnn_flow.ps1 -Check -Mode external')
        print(r'  .\scripts\cnn_regress.ps1')
        print('  cd /d "%s"' % project)
        print(r'  .\build.ps1')
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    raise SystemExit(main())
