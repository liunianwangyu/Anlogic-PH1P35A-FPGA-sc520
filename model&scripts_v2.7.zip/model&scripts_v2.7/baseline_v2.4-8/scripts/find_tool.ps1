﻿<#
  find_tool.ps1 -- 工具路径解析（不绑定某一台机器）

  查找顺序：
    1) 环境变量（如 VSIM_EXE / TD_BIN）
    2) PATH（Get-Command）
    3) 常见安装路径（本脚本内置的候选）
  找不到返回 $null —— 调用方要自己判断并给出提示。

  用法：
    . (Join-Path $PSScriptRoot 'find_tool.ps1')
    $vsim = Find-Tool -Name 'vsim.exe' -EnvVar 'VSIM_EXE' -Candidates @('D:\...\vsim.exe')
#>
function Find-Tool {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [string]$EnvVar,
        [string[]]$Candidates = @()
    )
    if ($EnvVar) {
        $v = [Environment]::GetEnvironmentVariable($EnvVar)
        if ($v -and (Test-Path -LiteralPath $v)) { return (Resolve-Path -LiteralPath $v).Path }
    }
    $c = Get-Command $Name -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    foreach ($p in $Candidates) {
        if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
    }
    return $null
}