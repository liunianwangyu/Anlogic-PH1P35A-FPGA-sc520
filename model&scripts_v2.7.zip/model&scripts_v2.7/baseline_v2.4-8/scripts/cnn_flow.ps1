﻿<#
  cnn_flow.ps1 -- P2-C1：PC(外部参考) 与 RTL 的逐层对拍
      .\scripts\cnn_flow.ps1 -Gen     # 生成 RTL 侧打包权重/输入帧，并用"独立规格实现"算出 4 层参考输出
      .\scripts\cnn_flow.ps1 -Check   # 读取 RTL 转储与参考，逐层逐字比对

  设计要点（为什么这样才有效）：
    * 权重先生成"逻辑张量" w[L][oc][ic][tap]，再分别落成两种形式：
        - verification/cnn_flow/w_rtl.hex  : 按 RTL 打包布局（实例/地址/字节=IC），供 DUT 预装
        - 脚本内部的逻辑张量               : 供**独立参考**做朴素卷积
      这样"打包布局 + 引擎寻址"才真的在受测范围内。
    * 参考实现只依赖 cnn_contract.json 的**规格**（几何、逐 OC 的 shift/bias、边界规则），
      不复用任何 RTL 结构。将来在 PC 上用 python 实现同一套即可无缝替换。
    * 数据取小权重(±3) + 中等输入，避免全饱和，保证有区分度。
#>
param([switch]$Gen, [switch]$Check, [string]$Mode = 'full')
$ErrorActionPreference = 'Stop'
$root = & (Join-Path $PSScriptRoot 'resolve_project_root.ps1'); if (-not $root -or -not (Test-Path -LiteralPath $root)) { throw 'PROJECT ROOT NOT FOUND - edit scripts\project_root.txt (or see scripts\resolve_project_root.ps1)' }
$dir  = Join-Path $root 'verification\cnn_flow'
$jsonPath = Join-Path $root 'user_source\hdl_source\cnn\cnn_contract.json'
$c = [System.IO.File]::ReadAllText($jsonPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
New-Item -ItemType Directory -Force -Path $dir | Out-Null

$NL = [char]10
function Rnd([int]$max) { $script:seed = ([int64]$script:seed * 1103515245 + 12345) -band 0x7FFFFFFF; return [int](($script:seed -shr 8) % $max) }

function Sat8([int]$v, [int]$r6) {
  if ($r6 -ne 0) { if ($v -lt 0) { return 0 } elseif ($v -gt 127) { return 127 } else { return $v } }
  else           { if ($v -lt -128) { return -128 } elseif ($v -gt 127) { return 127 } else { return $v } }
}
function Sh([int]$v, [int]$s) { return [int][math]::Floor($v / [math]::Pow(2, $s)) }
function ToByte([int]$v) { return (($v % 256) + 256) % 256 }

# 逐 OC 量化参数：index = q_base + oc
function QShift([int]$L, [int]$oc) { $i = $c.layers[$L].q_base + $oc; return [int]$c.quant_params.entries[$i].shift }
function QBias ([int]$L, [int]$oc) { $i = $c.layers[$L].q_base + $oc; return [int]$c.quant_params.entries[$i].bias }

$NLyr = $c.num_layers

if ($Gen) {
  $script:seed = 20261015
  # ---- 1) 逻辑权重 w[L][oc][ic][tap] ----
  $TAPS = @(9, 9, 9, 1)
  $W = [System.Collections.Generic.List[object]]::new()
  for ($L = 0; $L -lt $NLyr; $L++) {
    $oc_n = [int]$c.layers[$L].out_ch; $ic_n = [int]$c.layers[$L].in_ch; $tap_n = $TAPS[$L]
    $wl = [int[,,]]::new($oc_n, $ic_n, $tap_n)
    for ($o = 0; $o -lt $oc_n; $o++) { for ($i = 0; $i -lt $ic_n; $i++) { for ($t = 0; $t -lt $tap_n; $t++) {
        $wl.SetValue((Rnd 7) - 3, $o, $i, $t)
    } } }
    [void]$W.Add($wl)
  }
  # ---- 1b) 退化模式（定位用）----
  if ($Mode -eq 'zero') {
    for ($L = 0; $L -lt $NLyr; $L++) {
      $oc_n = [int]$c.layers[$L].out_ch; $ic_n = [int]$c.layers[$L].in_ch
      for ($o = 0; $o -lt $oc_n; $o++) { for ($i = 0; $i -lt $ic_n; $i++) { for ($t2 = 0; $t2 -lt $TAPS[$L]; $t2++) {
          $W[$L].SetValue(0, $o, $i, $t2)
      } } }
    }
    Write-Host '  [Mode=zero] 所有权重置 0：每层输出应为"每 OC 一个常数 = sat(bias>>shift)"'
  }
  if ($Mode -eq 'one') {
    for ($L = 0; $L -lt $NLyr; $L++) {
      $oc_n = [int]$c.layers[$L].out_ch; $ic_n = [int]$c.layers[$L].in_ch
      for ($o = 0; $o -lt $oc_n; $o++) { for ($i = 0; $i -lt $ic_n; $i++) { for ($t2 = 0; $t2 -lt $TAPS[$L]; $t2++) {
          $W[$L].SetValue(0, $o, $i, $t2)
      } } }
    }
    # 只留 L0 的 OC0/IC0/中心抽头 = 1
    $W[0].SetValue(1, 0, 0, 4)
    Write-Host '  [Mode=one] 只留 L1 的 OC0<-IC0 中心抽头 = 1'
  }
  # ---- 2) RTL 打包：4 个实例 x 128 字，byte k = IC(cg*4+k)，实例 m = OC 车道 m ----
  $pack = [int[]]::new(512)
  for ($L = 0; $L -lt $NLyr; $L++) {
    $ly = $c.layers[$L]
    $oc_n = [int]$ly.out_ch; $ic_n = [int]$ly.in_ch; $tap_n = $TAPS[$L]
    $ng = [int]($ic_n / 4); $nocg = [int]($oc_n / 4); $wbase = [int]$ly.w_base
    for ($cog = 0; $cog -lt $nocg; $cog++) {
      for ($m = 0; $m -lt 4; $m++) {
        for ($ct = 0; $ct -lt $tap_n; $ct++) {
          for ($cg = 0; $cg -lt $ng; $cg++) {
            $a = ($wbase + $cog * $tap_n * $ng + $ct * $ng + $cg) % 128
            $wd = 0
            for ($k = 0; $k -lt 4; $k++) {
              $occ = $cog * 4 + $m; $icc = $cg * 4 + $k
              $v = 0
              if ($icc -lt $ic_n) { $v = [int]$W[$L].GetValue($occ, $icc, $ct) }
              $wd = $wd -bor ((ToByte $v) -shl (8 * $k))
            }
            $pack[$m * 128 + $a] = $wd
          }
        }
      }
    }
  }
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($v in $pack) { $out.Add(('{0:x8}' -f $v)) }
  [System.IO.File]::WriteAllText((Join-Path $dir 'w_rtl.hex'), (($out -join $NL) + $NL))

  # ---- 2b) 打包自检：按"RTL 的读法"反解 w_rtl.hex，与逻辑张量 $W 比对 ----
  $nbad = 0
  for ($L = 0; $L -lt $NLyr; $L++) {
    $ly = $c.layers[$L]
    $oc_n = [int]$ly.out_ch; $ic_n = [int]$ly.in_ch; $tap_n = $TAPS[$L]
    $ng = [int]($ic_n / 4); $nocg = [int]($oc_n / 4); $wbase = [int]$ly.w_base
    for ($cog = 0; $cog -lt $nocg; $cog++) {
      for ($ct = 0; $ct -lt $tap_n; $ct++) {
        for ($cg = 0; $cg -lt $ng; $cg++) {
          $a = ($wbase + $cog * $tap_n * $ng + $ct * $ng + $cg) % 128
          for ($m = 0; $m -lt 4; $m++) {
            $wd = $pack[$m * 128 + $a]
            for ($k = 0; $k -lt 4; $k++) {
              $occ = $cog * 4 + $m; $icc = $cg * 4 + $k
              if ($icc -lt $ic_n) {
                $gotb = [int](($wd -shr (8 * $k)) -band 0xFF); if ($gotb -ge 128) { $gotb -= 256 }
                $expb = [int]$W[$L].GetValue($occ, $icc, $ct)
                if ($gotb -ne $expb) {
                  $nbad++
                  if ($nbad -le 5) { Write-Host ("  PACK MISMATCH L{0} oc{1} ic{2} t{3}: rtl={4} ref={5}" -f $L, $occ, $icc, $ct, $gotb, $expb) }
                }
              }
            }
          }
        }
      }
    }
  }
  if ($nbad -eq 0) { Write-Host '  打包自检: 反解结果与逻辑张量一致（512 字 / 144 个权重）' }
  else { Write-Host ("  打包自检: {0} 处不一致  <-- 打包公式或反解公式有 bug" -f $nbad) }
  # ---- 3) 输入帧（4 通道 int8，居中域）----
  $inw = [int]$c.input_frame.w; $inh = [int]$c.input_frame.h
  $frame = [int[]]::new($inw * $inh)
  for ($y = 0; $y -lt $inh; $y++) {
    for ($x = 0; $x -lt $inw; $x++) {
      $r0 = (($x*3 + $y*5) % 255) - 128
      $g0 = (($x   + $y*2) % 255) - 128
      $b0 = (($x -bxor $y) % 255) - 128
      $r0 = $r0 + (Rnd 9) - 4; $g0 = $g0 + (Rnd 9) - 4; $b0 = $b0 + (Rnd 9) - 4
      if ($r0 -gt 127) { $r0 = 127 }; if ($r0 -lt -128) { $r0 = -128 }
      if ($g0 -gt 127) { $g0 = 127 }; if ($g0 -lt -128) { $g0 = -128 }
      if ($b0 -gt 127) { $b0 = 127 }; if ($b0 -lt -128) { $b0 = -128 }
      # 字 = {8'h00, B, G, R}：byte0=R byte1=G byte2=B byte3=0
      $frame[$y*$inw + $x] = ((ToByte $b0) -shl 16) -bor ((ToByte $g0) -shl 8) -bor (ToByte $r0)
    }
  }
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($v in $frame) { $out.Add(('{0:x8}' -f $v)) }
  [System.IO.File]::WriteAllText((Join-Path $dir 'in_frame.hex'), (($out -join $NL) + $NL))

  # ---- 4) 独立参考实现（朴素卷积，只用契约规格）----
  #   当前层的输入 fm[] 用"上一层的打包输出"表示：word = y*row_step + x*n_g + cg，byte k = 通道 cg*4+k
  $prevFm = $frame; $prevRowStep = $inw; $prevNg = 1; $prevW = $inw; $prevH = $inh; $prevCh = 4
  for ($L = 0; $L -lt $NLyr; $L++) {
    $ly = $c.layers[$L]
    $ow = [int]$ly.out_w; $oh = [int]$ly.out_h; $oc_n = [int]$ly.out_ch; $ic_n = [int]$ly.in_ch
    $stride = [int]$ly.stride; $tap_n = $TAPS[$L]; $border = [int]$ly.border
    $ng = [int]($ic_n / 4); $nocg = [int]($oc_n / 4); $r6 = [int]$ly.relu6
    $iw = [int]$ly.in_w; $ih = [int]$ly.in_h
    $nWords = $ow * $nocg * $oh
    $fm = [int[]]::new($nWords)
    for ($oy = 0; $oy -lt $oh; $oy++) {
      for ($ox = 0; $ox -lt $ow; $ox++) {
        for ($cog = 0; $cog -lt $nocg; $cog++) {
          $wd = 0
          for ($k = 0; $k -lt 4; $k++) {
            $occ = $cog * 4 + $k
            $acc = QBias $L $occ
            for ($t = 0; $t -lt $tap_n; $t++) {
              if ($tap_n -eq 9) { $dy = [int][math]::Floor($t / 3); $dx = $t % 3 } else { $dy = 0; $dx = 0 }
              $ir = $stride * $oy + $dy - $border
              $ic2 = $stride * $ox + $dx - $border
              if (($ir -ge 0) -and ($ir -lt $ih) -and ($ic2 -ge 0) -and ($ic2 -lt $iw)) {
                for ($cg = 0; $cg -lt $ng; $cg++) {
                  $word = $prevFm[$ir * $prevRowStep + $ic2 * $ng + $cg - ($ng - $prevNg)*0 ]
                  # 上一层的 ng：同一层的输入就是上层的输出，其 n_g = prevNg
                  $word = $prevFm[$ir * $prevRowStep + $ic2 * $prevNg + $cg]
                  for ($kk = 0; $kk -lt 4; $kk++) {
                    $icc = $cg * 4 + $kk
                    if ($icc -lt $ic_n) {
                      $xv = [int](($word -shr (8 * $kk)) -band 0xFF); if ($xv -ge 128) { $xv -= 256 }
                      $wv = [int]$W[$L].GetValue($occ, $icc, $t)
                      $acc += $xv * $wv
                    }
                  }
                }
              }
            }
            $q = Sat8 (Sh $acc (QShift $L $occ)) $r6
            $wd = $wd -bor ((ToByte $q) -shl (8 * $k))
          }
          $fm[($oy * $ow + $ox) * $nocg + $cog] = $wd
        }
      }
    }
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($v in $fm) { $out.Add(('{0:x8}' -f $v)) }
    [System.IO.File]::WriteAllText((Join-Path $dir ("ref_{1}_L{0}.hex" -f $L, $Mode)), (($out -join $NL) + $NL))
    $prevFm = $fm; $prevRowStep = $ow * $nocg; $prevNg = $nocg; $prevW = $ow; $prevH = $oh; $prevCh = $oc_n
    Write-Host ("  ref_L{0}: {1}x{2}x{3}  {4} words" -f $L, $ow, $oh, $oc_n, $nWords)
  }
  Write-Host 'PC 侧参考生成完成'
}

if ($Check) {
  $bad = 0
  for ($L = 0; $L -lt $NLyr; $L++) {
    # external: 参考由训练侧（PC/PyTorch 定点）给出，文件名为 exp_L*.hex
    $rp = if ($Mode -eq 'external') { Join-Path $dir ("exp_L{0}.hex" -f $L) } else { Join-Path $dir ("ref_{1}_L{0}.hex" -f $L, $Mode) }; $tp = Join-Path $dir ("rtl_L{0}.hex" -f $L)
    if (-not (Test-Path -LiteralPath $tp)) { Write-Host ("  L{0}: 缺 RTL 转储 {1}" -f $L, $tp); $bad++; continue }
    $a = [System.IO.File]::ReadAllLines($rp); $b = [System.IO.File]::ReadAllLines($tp)
    $n = [Math]::Min($a.Count, $b.Count); $m = 0
    for ($i = 0; $i -lt $n; $i++) {
      if ($a[$i].Trim() -ne $b[$i].Trim()) {
        $m++
        if ($m -le 3) { Write-Host ("  L{0} word[{1}]: ref={2} rtl={3}" -f $L, $i, $a[$i].Trim(), $b[$i].Trim()) }
      }
    }
    if (($m -eq 0) -and ($a.Count -eq $b.Count)) { Write-Host ("  L{0}: OK  {1} words 与参考一致" -f $L, $n) }
    else { Write-Host ("  L{0}: FAIL  {1}/{2} 不一致" -f $L, $m, $n); $bad++ }
  }
  if ($bad -eq 0) { Write-Host 'PASS CNN_FLOW: 4 层逐字与 PC 参考一致'; exit 0 }
  Write-Host ("FAIL CNN_FLOW: {0} 层不一致" -f $bad); exit 1
}
