"""Tensor/fixture checks only. No dataset training or optimizer steps."""
import io
import hashlib
import json
import tempfile
from pathlib import Path
import numpy as np
import torch
import train_cnn as tc
from training_policy import fixed_split, validate_boxes, save_fixed_split, load_fixed_split
from evaluate_detection import decode_head, detection_metrics


def main():
    torch.set_num_threads(2)
    torch.manual_seed(52024)
    checks = []
    y = torch.zeros(2,8,12,20,requires_grad=True)
    o = torch.zeros(2,12,20); h = o.clone(); b = torch.zeros(2,4,12,20)
    cl = torch.zeros(2,3,12,20)
    o[0,2,3]=h[0,2,3]=1; cl[0,0,2,3]=1
    loss, obj, box, cls = tc.compute_loss(y,o,b,cl,h,3)
    assert abs(obj-1.5*np.log(2))<1e-6 and box==0
    loss.backward(); assert torch.isfinite(y.grad).all() and y.grad[0,7,2,3]>0
    checks.append('hard mining mixed positive/empty batch; finite gradients; unused class negative')
    bright = np.full((3,8,8),127,dtype=np.float32)
    for _ in range(4):
        a=tc.augment_rgb(bright);assert np.equal(a,np.rint(a)).all() and a.min()>=-128 and a.max()<=127
    checks.append('photometric output integer and clipped')
    gray_src=np.array([[[64]],[[96]],[[32]]],dtype=np.float32)-128
    gray=tc.board_grayscale_rgb(gray_src)
    expected=(np.uint16(64)>>2)+(np.uint16(96)>>1)+(np.uint16(32)>>2)-128
    assert np.array_equal(gray,np.repeat(np.array([[[expected]]],dtype=np.float32),3,axis=0))
    forced=tc.augment_rgb(gray_src,grayscale_prob=1.0)
    assert np.equal(forced,np.rint(forced)).all() and forced.min()>=-128 and forced.max()<=127
    checks.append('board grayscale formula and mandatory grayscale augmentation')
    invalid=[dict(gx=0,gy=0,cls=0,dx=0,dy=0,w=255,h=1,x1=0,y1=0,x2=8,y2=8)]
    try:validate_boxes(invalid,3)
    except ValueError:pass
    else:raise AssertionError('signed size audit')
    invalid[0]['w']=1
    try:validate_boxes(invalid*2,3)
    except ValueError:pass
    else:raise AssertionError('cell collision audit')
    try:fixed_split([('a','b','S01_a'),('c','d','S02_a')],.2,.2,1)
    except ValueError:pass
    else:raise AssertionError('scene fallback must be forbidden')
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp);items=[]
        for i in range(6):
            ip=p/f'S{i:02}_a.jpg';lp=ip.with_suffix('.json')
            ip.write_bytes(bytes([i]));lp.write_text('{}')
            items.append((str(ip),str(lp),ip.name))
        parts=fixed_split(items,.2,.2,1);manifest=p/'splits.json'
        save_fixed_split(parts,manifest);assert load_fixed_split(items,manifest)==parts
        Path(items[0][0]).write_bytes(b'changed')
        try:load_fixed_split(items,manifest)
        except ValueError:pass
        else:raise AssertionError('content drift must fail')
    checks.append('invalid sizes/cell collisions; strict scene split; hash drift rejected')
    pred=dict(cls=0,score=200,box=[0,0,10,10])
    gt=dict(cls=0,box=[0,0,10,10])
    m=detection_metrics([dict(pred=[pred,pred],gt=[gt])])
    assert (m['tp'],m['fp'],m['fn'])==(1,1,0) and m['map50']==1
    wrong={**pred,'cls':1};m=detection_metrics([dict(pred=[wrong],gt=[gt])])
    assert (m['tp'],m['fp'],m['fn'])==(0,1,1)
    h8=np.full((8,12,20),-128,dtype=np.int32);h8[3:5]=0
    h8[:,0,0]=[0,0,0,1,1,10,10,-128]
    h8[:,0,1]=[0,0,0,1,1,10,10,-128]
    out,_=decode_head(h8);assert [d['cell'] for d in out]==[0,1]
    checks.append('IoU/class one-to-one matching; duplicate FP; scan ties')
    c=tc.load_contract()
    net=tc.build_net(c)
    x=torch.randint(-128,128,(3,4,90,160),dtype=torch.int32).float();x[:,3]=0
    q=tc.quantize(net,x,c,io.StringIO())
    for layer in q[:-1]:
        eff=layer['acc_scale']*2.**layer['shift'];assert np.all(eff==eff[0])
    eff=q[-1]['acc_scale']*2.**q[-1]['shift']
    assert np.all(eff[1:5]==1) and np.all(eff[5:]==eff[5])
    a=tc.int_forward(q,x[0].numpy().astype(np.int32),c['layers'],c)
    fast=tc.integer_forward_fast(q,x[0].numpy(),c['layers'])
    assert all(np.array_equal(s,t) for s,t in zip(a,fast))
    checks.append('power-of-two effective scales; exact native box units; fast/scalar integer oracle')
    result=dict(status='PASS',checks=checks,dataset_training_run=False,optimizer_steps=0,
                source_sha256={n:hashlib.sha256((Path(__file__).parent/n).read_bytes()).hexdigest()
                for n in ['train_cnn.py','training_policy.py','evaluate_detection.py',
                          'evaluate_cnn_threshold.py','import_xanylabeling.ps1','test_training_tools.py']})
    dest=Path(__file__).parent.parent/'training_tools_checks.json'
    dest.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
