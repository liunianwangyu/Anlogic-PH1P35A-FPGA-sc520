﻿<#
  build_firmware.ps1 -- 编译 FD 固件 + 与 v1.6 发布包逐字节比对

  为什么需要：build.py 是 python（本机没装 python），这里用 PowerShell 等价实现，
  并且**自动与 release_v1.6 里的 ae_firmware_v1.6.bin 做逐字节比对** ——
  因为 8 个固件源文件的 SHA256 与 v1.6 发布时**完全一致**，
  所以用同一套工具链重编，产物应当**逐字节相同**。这是"FD 工具链装对了"的硬判据。

  用法：
      .\scripts\build_firmware.ps1                          # 自动找 FD_HOME
      .\scripts\build_firmware.ps1 -FdHome 'D:\TOOLs\Anlogic\FD_Release_2026.2'
      .\scripts\build_firmware.ps1 -CheckOnly               # 只比对，不编译

  查找顺序： -FdHome 参数 -> $env:FD_HOME -> 常见安装路径
#>
param(
    [string]$FdHome = '',
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
$root = & (Join-Path $PSScriptRoot 'resolve_project_root.ps1'); if (-not $root -or -not (Test-Path -LiteralPath $root)) { throw 'PROJECT ROOT NOT FOUND - edit scripts\project_root.txt (or see scripts\resolve_project_root.ps1)' }
$fdproj = Join-Path $root 'fd_project'
$out    = Join-Path $fdproj 'build'
$ref    = Join-Path $root 'release_v1.6\ae_firmware_v1.6.bin'

# ---------- 定位 FD_HOME ----------
if (-not $FdHome) { $FdHome = $env:FD_HOME }
if (-not $FdHome) {
    foreach ($c in @(
        'D:\TOOLs\Anlogic\FD_Release_2026.2',
        'D:\TOOLs\Anlogic\FD',
        'D:\TOOLs\FD',
        'C:\Anlogic\FD',
        'G:\FPGAcontest\Application\FD'
    )) { if (Test-Path -LiteralPath $c) { $FdHome = $c; break } }
}
if (-not $FdHome) { throw '找不到 FD_HOME。请用 -FdHome 指定 FD 安装根目录（或用环境变量 FD_HOME）' }
if (-not (Test-Path -LiteralPath $FdHome)) { throw ('FD_HOME 不存在: ' + $FdHome) }
Write-Host ('FD_HOME = ' + $FdHome)

$gccDir = Join-Path $FdHome 'toolchain\gcc\riscv\ph1p35\bin'
$gcc    = Join-Path $gccDir 'riscv64-unknown-elf-gcc.exe'
$objcpy = Join-Path $gccDir 'riscv64-unknown-elf-objcopy.exe'
$size   = Join-Path $gccDir 'riscv64-unknown-elf-size.exe'
foreach ($t in @($gcc, $objcpy, $size)) {
    if (-not (Test-Path -LiteralPath $t)) { throw ('工具链里找不到: ' + $t) }
}
Write-Host '工具链三个可执行文件都在 ✅'

# ---------- 逐字节比对（可单独使用）----------
function Compare-Bin([string]$a, [string]$b) {
    if (-not (Test-Path -LiteralPath $a)) { throw ('缺文件: ' + $a) }
    if (-not (Test-Path -LiteralPath $b)) { throw ('缺文件: ' + $b) }
    $ba = [System.IO.File]::ReadAllBytes($a)
    $bb = [System.IO.File]::ReadAllBytes($b)
    $shaA = (Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash
    $shaB = (Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash
    Write-Host ('  新编  : ' + $ba.Length + ' 字节  ' + $shaA)
    Write-Host ('  发布包: ' + $bb.Length + ' 字节  ' + $shaB)
    if ($ba.Length -ne $bb.Length) { Write-Host '  -> FAIL 长度不同' -ForegroundColor Red; return $false }
    for ($i = 0; $i -lt $ba.Length; $i++) {
        if ($ba[$i] -ne $bb[$i]) {
            Write-Host ('  -> FAIL 首个不同字节在 offset ' + $i + '：新=' + $ba[$i] + ' 参考=' + $bb[$i]) -ForegroundColor Red
            return $false
        }
    }
    Write-Host '  -> PASS 逐字节完全一致（工具链与 v1.6 发布时一致）' -ForegroundColor Green
    return $true
}

if ($CheckOnly) {
    Write-Host ''
    Write-Host '=== 只比对 ==='
    $newBin = Join-Path $out 'ae_firmware.bin'
    if (Compare-Bin $newBin $ref) { exit 0 } else { exit 1 }
}

# ---------- 编译（逐字对应 build.py）----------
New-Item -ItemType Directory -Force -Path $out | Out-Null
$flags = @('-march=rv32im_zicsr','-mabi=ilp32','-Os','-g','-ffreestanding','-fno-builtin',
           '-ffunction-sections','-fdata-sections','-Wall','-Wextra','-Werror','-nostdlib')
$srcs  = @('startup.S','platform_startup.S','main.c','ae_calculate.c') |
         ForEach-Object { Join-Path (Join-Path $fdproj 'src') $_ }
$elf   = Join-Path $out 'ae_firmware.elf'
$map   = Join-Path $out 'ae_firmware.map'
$bin   = Join-Path $out 'ae_firmware.bin'
$log   = Join-Path $out 'build_pwsh.log'

$argv = @($flags) + @('-I', (Join-Path $fdproj 'sc520_platform'),
                     ('-Wl,--gc-sections,-Map=' + $map),
                     '-T', (Join-Path $fdproj 'linker.ld')) + $srcs + @('-o', $elf)

Write-Host ''
Write-Host '=== 编译 ==='
$results = New-Object System.Collections.Generic.List[string]
Push-Location $fdproj
try {
    $o1 = (& $gcc @argv 2>&1 | Out-String); $c1 = $LASTEXITCODE
    $results.Add('gcc exit=' + $c1); if ($o1.Trim()) { $results.Add($o1) }
    if ($c1 -ne 0) { Write-Host $o1; Set-Content -LiteralPath $log -Value ($results -join [Environment]::NewLine) -Encoding UTF8; throw 'gcc 编译失败' }

    $o2 = (& $objcpy '-O' 'binary' $elf $bin 2>&1 | Out-String); $c2 = $LASTEXITCODE
    $results.Add('objcopy exit=' + $c2); if ($o2.Trim()) { $results.Add($o2) }
    if ($c2 -ne 0) { throw 'objcopy 失败' }

    $o3 = (& $size $elf 2>&1 | Out-String); $c3 = $LASTEXITCODE
    $results.Add('size exit=' + $c3); if ($o3.Trim()) { $results.Add($o3) }
} finally { Pop-Location }
Set-Content -LiteralPath $log -Value ($results -join [Environment]::NewLine) -Encoding UTF8
Write-Host ('编译产物: ' + $bin)
if ($o3.Trim()) { Write-Host $o3.Trim() }

# ---------- 验证 ----------
Write-Host ''
Write-Host '=== 与 v1.6 发布包逐字节比对 ==='
if (Compare-Bin $bin $ref) { Write-Host 'PASS FD_FIRMWARE: 可复现，工具链正确'; exit 0 }
Write-Host 'FAIL FD_FIRMWARE: 产物与发布包不一致 -> 记录差异（FD 版本可能与队友当时不同）'
exit 1