﻿<#
  cnn_regress.ps1 -- CNN 回归总入口（固定清单，可重复执行）

  用法：
      .\scripts\cnn_regress.ps1                 # 跑全部 14 项
      .\scripts\cnn_regress.ps1 -Only cnn_flow  # 只跑某一项（逗号分隔可多选）

  判据（每项必须同时满足）：
      * 出现以 PASS 开头的行
      * 不出现以 FAIL 开头的行
      * 退出码为 0

  产物： verification\cnn_regress_last.txt （完整日志）

  说明：
      cnn_contract = cnn_contract.ps1 -Check  +  verification/cnn_contract 的 TB
      cnn_flow     = cnn_flow.ps1 -Gen        +  TB 转储 rtl_L*.hex  +  cnn_flow.ps1 -Check

  注意（本机环境踩坑）：
      * 必须用 & 直接调用 vsim / powershell 子进程；Start-Process 生成的进程拿不到
        本工作区的写权限，会以 "couldn't open transcript: permission denied" 退出。
      * 每个 TB 目录下残留的旧 transcript 同样会让 vsim 启动失败，故每次运行前清理。
#>
param([string]$Only = '', [string]$LogPath = '')
$ErrorActionPreference = 'Stop'

$root = & (Join-Path $PSScriptRoot 'resolve_project_root.ps1'); if (-not $root -or -not (Test-Path -LiteralPath $root)) { throw 'PROJECT ROOT NOT FOUND - edit scripts\project_root.txt (or see scripts\resolve_project_root.ps1)' }
. (Join-Path $PSScriptRoot 'find_tool.ps1')
$vsim  = Find-Tool -Name 'vsim.exe' -EnvVar 'VSIM_EXE' -Candidates @('D:\TOOLs\modelsim_win64_10.6d_se\modelsim_win64_10.6d_se\win64\vsim.exe','C:\modeltech64_10.6d\win64\vsim.exe','C:\intelFPGA_pro\24.1\modelsim_ase\win32aloem\vsim.exe','C:\intelFPGA\24.1\modelsim_ase\win32aloem\vsim.exe')
$psExe = (Get-Command powershell.exe -ErrorAction Stop).Source
if (-not $vsim -or -not (Test-Path -LiteralPath $vsim)) { throw '找不到 vsim.exe：请设置环境变量 VSIM_EXE，或把 vsim.exe 所在目录加入 PATH。' }
if (-not $LogPath) { $LogPath = Join-Path $root 'verification\cnn_regress_last.txt' }

$log = New-Object System.Collections.Generic.List[string]
function Log([string]$s) { $log.Add($s); Write-Host $s }

# 直接调用外部程序并捕获全部输出（不用 Start-Process）
function InvokeExe([string]$exe, [string[]]$argv, [string]$wd) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    Push-Location $wd
    try {
        $txt  = (& $exe @argv 2>&1 | Out-String)
        $code = $LASTEXITCODE
        if ($null -eq $code) { $code = 0 }
    } finally {
        Pop-Location
        $ErrorActionPreference = $old
    }
    return @{ Code = [int]$code; Text = $txt }
}

function InvokeSim([string]$name, [string]$reldir) {
    $d = Join-Path $root $reldir
    if (-not (Test-Path -LiteralPath (Join-Path $d 'run.do'))) {
        return @{ Code = 127; Text = ('缺 run.do: ' + $d) }
    }
    foreach ($stale in @('transcript', 'vsim.wlf')) {
        Remove-Item -LiteralPath (Join-Path $d $stale) -Force -ErrorAction SilentlyContinue
    }
    return (InvokeExe $vsim @('-c', '-do', 'run.do') $d)
}

function InvokePS([string]$script, [string[]]$argList) {
    return (InvokeExe $psExe (@('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $script) + $argList) $root)
}

function Verdict([string]$text, [int]$code) {
    $hasPass = ($text -match '(?m)^\s*#?\s*PASS\s')
    $hasFail = ($text -match '(?m)^\s*#?\s*FAIL\s')
    return ($hasPass -and (-not $hasFail) -and ($code -eq 0))
}

function Suite([string]$name, [scriptblock]$body) {
    Log ('=== ' + $name + ' ===')
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $r  = & $body
    $sw.Stop()
    $ok  = [bool]$r.OK
    $txt = [string]$r.Text
    foreach ($ln in ($txt -split "`r?`n")) {
        if ($ln -match '^\s*#?\s*(PASS|FAIL)') { Log ('    | ' + $ln.Trim()) }
    }
    $mark = 'FAIL'; if ($ok) { $mark = 'PASS' }
    Log ('  ' + $mark + '  ' + $name + '   (' + [int]$sw.Elapsed.TotalSeconds + ' s)  ' + $r.Note)
    return [pscustomobject]@{ Name = $name; OK = $ok; Note = $r.Note; Sec = [int]$sw.Elapsed.TotalSeconds }
}

$want = @()
if ($Only) { $want = @(($Only -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
function Need([string]$n) { return (($want.Count -eq 0) -or ($want -contains $n)) }

$ccPath  = Join-Path $PSScriptRoot 'cnn_contract.ps1'
$cfPath  = Join-Path $PSScriptRoot 'cnn_flow.ps1'
$results = New-Object System.Collections.Generic.List[object]

Log ('# CNN 回归  root=' + $root)
Log ('# 时间 ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))

if (Need 'cnn_contract') {
    [void]$results.Add((Suite 'cnn_contract' {
        $a = InvokePS $ccPath @('-Check')
        $b = InvokeSim 'cnn_contract' 'verification\cnn_contract'
        $ok = (Verdict $a.Text $a.Code) -and (Verdict $b.Text $b.Code)
        return @{ OK = $ok; Text = ($a.Text + "`n" + $b.Text); Note = ('ps1 -Check code=' + $a.Code + ' / tb code=' + $b.Code) }
    }))
}

if (Need 'cnn_flow') {
    [void]$results.Add((Suite 'cnn_flow' {
        $g = InvokePS $cfPath @('-Gen', '-Mode', 'full')
        $s = InvokeSim 'cnn_flow' 'verification\cnn_flow'
        $c = InvokePS $cfPath @('-Check', '-Mode', 'full')
        # -Gen 只负责生成数据，没有 PASS 标记：只校验退出码 + 无 FAIL
        $okGen = ($g.Code -eq 0) -and (-not ($g.Text -match '(?m)^\s*#?\s*FAIL\s'))
        $ok = $okGen -and (Verdict $s.Text $s.Code) -and (Verdict $c.Text $c.Code)
        return @{ OK = $ok; Text = ($s.Text + "`n" + $c.Text); Note = ('gen=' + $g.Code + ' tb=' + $s.Code + ' check=' + $c.Code) }
    }))
}

$simSuites = @(
    @('cnn_capture',     'verification\cnn_capture'),
    @('cnn_fmap_buf',    'verification\cnn_fmap_buf'),
    @('cnn_layer_engine','verification\cnn_layer_engine'),
    @('cnn_linebuf',     'verification\cnn_linebuf'),
    @('cnn_mem_top',     'verification\cnn_mem_top'),
    @('cnn_pe',          'verification\cnn_pe'),
    @('cnn_post',        'verification\cnn_post'),
    @('cnn_subsystem',   'verification\cnn_subsystem'),
    @('cnn_top',         'verification\cnn_top'),
    @('cnn_window_addr', 'verification\cnn_window_addr'),
    @('cnn_result_cdc',  'verification\cnn_result_cdc'),
    @('meter_osd',       'verification\meter_osd'),
    @('isp_mon',         'verification\isp_mon'),
    @('awb_ddr',         'verification\awb_whitepaper\tb_awb_ddr')
)
foreach ($s in $simSuites) {
    $nm = $s[0]; $rd = $s[1]
    if (-not (Need $nm)) { continue }
    [void]$results.Add((Suite $nm {
        $r = InvokeSim $nm $rd
        return @{ OK = (Verdict $r.Text $r.Code); Text = $r.Text; Note = ('vsim code=' + $r.Code) }
    }))
}

$pass = @($results | Where-Object { $_.OK }).Count
$tot  = $results.Count
Log ''
Log ('== 汇总: ' + $pass + '/' + $tot + ' PASS ==')
foreach ($r in $results) {
    $m = 'FAIL'; if ($r.OK) { $m = 'PASS' }
    Log (('   {0,-18} {1}  {2}s' -f $r.Name, $m, $r.Sec))
}

Set-Content -LiteralPath $LogPath -Value ($log -join [Environment]::NewLine) -Encoding UTF8
Write-Host ('log -> ' + $LogPath)

if ($pass -eq $tot) { Write-Host ('PASS CNN_REGRESS: ' + $tot + '/' + $tot); exit 0 }
Write-Host ('FAIL CNN_REGRESS: ' + $pass + '/' + $tot); exit 1
