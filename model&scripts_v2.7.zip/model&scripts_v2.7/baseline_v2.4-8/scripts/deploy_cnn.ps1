﻿<#
  deploy_cnn.ps1 -- 训练产物 -> 可烧录权重：一条命令闭环

  做的事（顺序固定，任何一步失败就停）：
    1) 把 <版本目录>\weights\cnn_weights.dat 装进 RTL 侧
       并把 <版本目录>\quant\quant_params.entries.json 的 36 条 qparam 合并进 cnn_contract.json
    2) 修复工程内初始化文件绝对路径；若有 tools\cnn_contract.py（v2.3+），
       用它生成四路 .dath/存储参数并检查；否则回退到 v1.7 的 cnn_wrom 流程
    3) 训练侧按 verification\cnn_flow 的输入帧算整数参考 exp_L*.hex
    4) ModelSim 跑 RTL -> rtl_L*.hex，逐层逐字对拍（验收②，6880 字必须 0 mismatch）
    5) 把要烧/要下发的东西收进 <版本目录>\burn\ 并写一份 README.txt

  可选：
    -Pnr     额外跑 TD 的 syn+phy（约 10~20 分钟），把新比特流也放进 burn\

  用法：
    .\deploy_cnn.ps1 -Out "D:\...\runs\bear_v3_f1select"
    .\deploy_cnn.ps1 -Out "...\bear_v3_f1select" -Pnr
    .\deploy_cnn.ps1 -Out "...\<版本目录>" -Pnr -BurnDir "D:\out\burn" -ProjectRoot "D:\...\<工程本体>"
#>
param(
    [Parameter(Mandatory=$true)][string]$Out,
    [string]$ProjectRoot = '',
    [switch]$Pnr,
    [switch]$UseExistingBit,     # 复用刚编好的比特流（要求它比 cnn_weights.dat 新）
    [switch]$NoVerify,
    [string]$BurnDir = '',       # 留空 = <版本目录>\burn
    [string]$Python = '',        # 留空 = PYTHON_EXE / PATH / 常见安装位置
    [string]$Vsim = '',          # 留空 = VSIM_EXE / PATH / 常见安装位置
    [string]$Td = '',            # 留空 = TD_BIN / PATH / 常见安装位置
    [int]$Threshold = 131        # 同步到目标工程的CNN目标门限
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'find_tool.ps1')
$root = & (Join-Path $PSScriptRoot 'resolve_project_root.ps1') -Explicit $ProjectRoot
if (-not $root -or -not (Test-Path -LiteralPath $root)) { throw '找不到工程根（用 -ProjectRoot 或 project_root.txt 指定）' }
$env:QIANSAI_PROJECT = $root
if (-not (Test-Path -LiteralPath $Out)) { throw ('版本目录不存在: ' + $Out) }
$Out = (Resolve-Path -LiteralPath $Out).Path

$bundleManifest = Join-Path $Out 'deploy\deploy_manifest.json'
$oldWeights = Join-Path $Out 'weights\cnn_weights.dat'
$oldQuant = Join-Path $Out 'quant\quant_params.entries.json'
$hasBundle = Test-Path -LiteralPath $bundleManifest
$hasOldLayout = (Test-Path -LiteralPath $oldWeights) -and (Test-Path -LiteralPath $oldQuant)
if (-not $hasBundle -and -not $hasOldLayout) {
    if (Test-Path -LiteralPath (Join-Path $Out 'cnn_weights.dat')) {
        throw ('Out 指向 weights 子目录: ' + $Out + '；请选择模型包根目录或版本目录。')
    }
    if (Test-Path -LiteralPath (Join-Path $Out 'model.pt')) {
        throw ('Out 指向 model 子目录: ' + $Out + '；请选择模型包根目录或版本目录。')
    }
    throw ('Out 不是有效版本目录: ' + $Out + '；需要 deploy\deploy_manifest.json 或 weights\cnn_weights.dat + quant\quant_params.entries.json。')
}

$py = if ($Python) { $Python } else {
    Find-Tool -Name 'python.exe' -EnvVar 'PYTHON_EXE' -Candidates @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
        'C:\Python312\python.exe')
}
if (-not $py) { throw '找不到 python.exe' }
$vsim = if ($Vsim) { $Vsim } else {
    Find-Tool -Name 'vsim.exe' -EnvVar 'VSIM_EXE' -Candidates @('D:\TOOLs\modelsim_win64_10.6d_se\modelsim_win64_10.6d_se\win64\vsim.exe','C:\modeltech64_10.6d\win64\vsim.exe','C:\intelFPGA_pro\24.1\modelsim_ase\win32aloem\vsim.exe','C:\intelFPGA\24.1\modelsim_ase\win32aloem\vsim.exe')
}
$td = if ($Td) { $Td } else {
    Find-Tool -Name 'td_commands_prompt.exe' -EnvVar 'TD_BIN' -Candidates @('D:\TOOLs\Anlogic\TD_6.2.1_Engineer_6.2.168.116\bin\td_commands_prompt.exe','C:\Anlogic\TD\bin\td_commands_prompt.exe','D:\Anlogic\TD\bin\td_commands_prompt.exe')
}
$thresholdScript = Join-Path $PSScriptRoot 'configure_threshold.py'
if (Test-Path -LiteralPath $thresholdScript) {
    Write-Host ('=== [0/5] 同步CNN门限 = ' + $Threshold + ' ===')
    $r = & $py $thresholdScript --project $root --threshold $Threshold
    if ($LASTEXITCODE -ne 0) { throw '目标工程CNN门限同步失败' }
}

function Get-ChildEncoding([string]$Exe) {
    # train_cnn.py 自己把 stdout 设为 UTF-8；PowerShell / TD / ModelSim 使用
    # Windows 控制台代码页。按子进程类型解码，避免中文日志和 PASS 判据被破坏。
    $name = [System.IO.Path]::GetFileName($Exe).ToLowerInvariant()
    if ($name -like 'python*') { return [System.Text.Encoding]::UTF8 }
    try {
        $cp = [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage
        return [System.Text.Encoding]::GetEncoding($cp)
    } catch {
        return [System.Text.Encoding]::Default
    }
}

function Run([string]$exe, [string[]]$argv, [string]$wd) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = (($argv | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"','\"') + '"' } else { $_ } }) -join ' ')
    $psi.WorkingDirectory = $wd
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $enc = Get-ChildEncoding $exe
    try { $psi.StandardOutputEncoding = $enc; $psi.StandardErrorEncoding = $enc } catch { }
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()
    $txt = $p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()
    [void]$p.WaitForExit()
    if ($txt) { $txt -split "`r?`n" | Where-Object { $_.Trim() } | ForEach-Object { Write-Host ('  ' + $_) } }
    return @{ Code = $p.ExitCode; Text = $txt }
}

$cnn = Join-Path $root 'user_source\hdl_source\cnn'
$flowDir = Join-Path $root 'verification\cnn_flow'
$burn = if ($BurnDir) { [System.IO.Path]::GetFullPath($BurnDir) } else { Join-Path $Out 'burn' }

Write-Host '=== [1/5] 安装权重 + 合并 qparam ==='
$deployBundle = Join-Path $Out 'deploy'
if ($hasBundle) {
    Write-Host '  使用 model bundle（含契约几何/文件哈希校验）'
    $r = Run $py @('-u', (Join-Path $PSScriptRoot 'deploy_model_bundle.py'),
                   '--bundle', $deployBundle, '--project', $root) $root
} else {
    Write-Host '  使用兼容布局 weights\ + quant\'
    $r = Run $py @('-u', (Join-Path $PSScriptRoot 'train_cnn.py'),
                   '--install', '--out', $Out) $root
}
if ($r.Code -ne 0) { throw '安装失败' }

Write-Host '=== [2/5] 修复初始化路径 + 生成目标工程硬件文件 ==='
$pathRepair = Join-Path $PSScriptRoot 'repair_init_paths.ps1'
$pathBackup = Join-Path $root ('backups\init_paths_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
$r = Run 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File', $pathRepair,
                           '-ProjectRoot', $root, '-BackupDir', $pathBackup, '-TdBin', $td) $root
if ($r.Code -ne 0 -or $r.Text -notmatch 'PASS SIM_PATH_REPAIR') {
    throw '工程初始化文件路径修复失败'
}

$projectContractTool = Join-Path $root 'tools\cnn_contract.py'
if (Test-Path -LiteralPath $projectContractTool) {
    Write-Host '  检测到 v2.3+ 存储工具: tools\cnn_contract.py'
    $r = Run $py @('-u', $projectContractTool, '--generate') $root
    if ($r.Code -ne 0) { throw '目标工程 cnn_contract.py --generate 失败' }
    $r = Run $py @('-u', $projectContractTool, '--check') $root
    if ($r.Code -ne 0 -or $r.Text -notmatch 'PASS CNN CONTRACT') {
        throw '目标工程 v2.3+ 存储契约检查失败'
    }
} else {
    Write-Host '  未检测到 tools\cnn_contract.py，使用 v1.7 cnn_wrom 流程'
    $r = Run 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File', (Join-Path $PSScriptRoot 'cnn_contract.ps1'), '-GenW','-GenQrom','-GenVh','-Check') $root
    if ($r.Code -ne 0 -or $r.Text -notmatch 'PASS CNN_CONTRACT') { throw '契约自检失败' }
}

if (-not $NoVerify) {
    Write-Host '=== [3/5] 训练侧整数参考 exp_L*.hex ==='
    # 必须先把新权重同步成 RTL 侧预装的 w_rtl.hex，再算 exp —— 否则 exp 用旧权重、
    # RTL 用新权重，逐字对拍必然全错（本脚本第一次端到端跑就踩到了）。
    Copy-Item -LiteralPath (Join-Path $cnn 'cnn_weights.dat') -Destination (Join-Path $flowDir 'w_rtl.hex') -Force
    $r = Run $py @('-u', (Join-Path $PSScriptRoot 'flow_check_standalone.py'),
                   '--contract', (Join-Path $cnn 'cnn_contract.json'),
                   '--flow-dir', $flowDir) $root
    if ($r.Code -ne 0) { throw 'flow-check 失败' }

    Write-Host '=== [4/5] ModelSim 跑 RTL 并逐层逐字对拍（验收②）==='
    if (-not $vsim -or -not (Test-Path -LiteralPath $vsim)) { throw '找不到 vsim.exe：请设置环境变量 VSIM_EXE，或把 vsim.exe 加入 PATH。' }
    foreach ($st in @('transcript','vsim.wlf')) { Remove-Item -LiteralPath (Join-Path $flowDir $st) -Force -ErrorAction SilentlyContinue }
    $r = Run $vsim @('-c','-do','run.do') $flowDir
    if ($r.Text -notmatch 'PASS CNN_FLOW_TB') { throw 'RTL 仿真没有 PASS' }
    $r = Run 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File', (Join-Path $PSScriptRoot 'cnn_flow.ps1'), '-Check','-Mode','external') $root
    if ($r.Text -notmatch 'PASS CNN_FLOW') { throw '验收②失败（逐层不一致）' }
    Write-Host '  验收② 通过：4 层 6880 字逐字一致'
} else {
    Write-Host '=== [3/5][4/5] 已跳过逐层对拍（-NoVerify）==='
}

Write-Host '=== [5/5] 收集可烧录产物 ==='
New-Item -ItemType Directory -Force -Path $burn | Out-Null
Copy-Item -LiteralPath (Join-Path $cnn 'cnn_weights.dat') -Destination (Join-Path $burn 'cnn_weights.dat') -Force
Copy-Item -LiteralPath (Join-Path $Out 'quant\quant_params.entries.json') -Destination (Join-Path $burn 'quant_params.entries.json') -Force
$bitFiles = @()
$phy = Join-Path $root 'td_project\camera_to_dsi_display_Runs\phy_1'
if ($UseExistingBit -and -not $Pnr) {
    $dat = Get-Item -LiteralPath (Join-Path $cnn 'cnn_weights.dat')
    $bit0 = Join-Path $phy 'camera_to_dsi_display.bit'
    if (-not (Test-Path -LiteralPath $bit0)) { throw ('没有现成比特流: ' + $bit0) }
    $bit = Get-Item -LiteralPath $bit0
    if ($bit.LastWriteTime -lt $dat.LastWriteTime) {
        throw ('现有比特流比 cnn_weights.dat 旧（' + $bit.LastWriteTime + ' < ' + $dat.LastWriteTime + '），必须加 -Pnr 重编')
    }
    Write-Host ('=== [BIT] 复用现有比特流（' + $bit.LastWriteTime + '，比权重新）===')
    foreach ($n in @('camera_to_dsi_display.bit','camera_to_dsi_display_compress.bit')) {
        $src = Join-Path $phy $n
        if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $burn $n) -Force; $bitFiles += $n }
    }
}
if ($Pnr) {
    if (-not $td -or -not (Test-Path -LiteralPath $td)) { throw '找不到 td_commands_prompt.exe：请设置环境变量 TD_BIN（指向该 exe），或把 TD 的 bin 目录加入 PATH。' }
    Write-Host '=== [P&R] TD syn+phy（约 10~20 分钟）==='
    $r = Run $td @('rebuild.tcl') (Join-Path $root 'td_project')
    if ($r.Text -notmatch 'REBUILD_FLOW_RETURNED') { throw 'P&R 没有正常返回' }
    foreach ($n in @('camera_to_dsi_display.bit','camera_to_dsi_display_compress.bit')) {
        $src = Join-Path $phy $n
        if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $burn $n) -Force; $bitFiles += $n }
    }
}
$lines = @()
$lines += ('检测模块可烧录产物  ' + (Get-Date).ToString('s'))
$lines += ('来源版本目录: ' + $Out)
$lines += ''
$lines += '【怎么用】'
$lines += '  1) 比特流：用 TD Programmer 烧 camera_to_dsi_display.bit（_compress 为压缩版，二选一）'
$lines += '  2) 板上开关检测：长按 KEY4 >= 1.5 秒（任何开关上下文都有效）'
$lines += '      开 -> 画框 + 屏幕底部出现 "F.. W.. E. N." 诊断行'
$lines += '      关 -> 不画框、诊断行消失、LED[3] 与 LED[1:0] 熄灭'
$lines += '  3) 若改用 MCU 下发权重：cnn_weights.dat（512 行）+ quant_params.entries.json（36 条）'
$lines += '      qparam 条目顺序 = oc = q_base + lane，与 cnn_contract.json 一致'
$lines += ''
$lines += '【注意】'
$lines += '  换权重后必须重新 P&R 才能让比特流里生效（权重是 ROM 初值，不是运行时可改的 RAM）'
$lines += '  本目录的 bit 与 cnn_weights.dat 是同一次生成的；不要拿旧 bit 配新 dat'
[System.IO.File]::WriteAllLines((Join-Path $burn 'README.txt'), $lines)
$deployStatus = [ordered]@{
    format = 'qiansai_cnn_deployment_status_v1'
    completed_at = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    deployed_threshold_u8 = $Threshold
    source_version = $Out
    target_project = $root
    verify_mode = $(if ($NoVerify) { 'skipped' } else { 'modelsim_pass' })
    bit_files = @($bitFiles)
    bit_generated = [bool]$Pnr
    mcu_bin_generated = $false
    physical_board_tested = $false
}
$deployStatus |
    ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $burn 'deployment_status.json') -Encoding UTF8
Write-Host ''
Write-Host ('完成。产物目录: ' + $burn)
Get-ChildItem -LiteralPath $burn | ForEach-Object { Write-Host ('  ' + $_.Name + '  (' + $_.Length + ' B)') }
