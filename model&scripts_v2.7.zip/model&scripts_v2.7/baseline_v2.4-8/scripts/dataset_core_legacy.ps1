<#
  dataset_core_legacy.ps1 -- 旧单页工具的标签兼容层

  仅由 dataset_tool.ps1 加载，提供：
    1. Import-LabelFile      读取 YOLO txt 或旧内部 JSON
    2. Export-InternalLabels 按 id_map 把原始标注映射到预处理后的编号

  新四步向导不使用本文件。
#>

function Import-LabelFile {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$ImgW = 1280, [int]$ImgH = 720
    )
    $txt = $Path + '.txt'
    $js  = $Path + '.json'
    $boxes = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $txt) {
        foreach ($line in [System.IO.File]::ReadAllLines($txt)) {
            $s = $line.Trim(); if ($s -eq '') { continue }
            $p = $s -split '\s+'
            if ($p.Count -lt 5) { continue }
            $cls=[int]$p[0]; $cx=[double]$p[1]*$ImgW; $cy=[double]$p[2]*$ImgH
            $bw=[double]$p[3]*$ImgW; $bh=[double]$p[4]*$ImgH
            $boxes.Add([pscustomobject]@{ cls=$cls;
                x1=[int][Math]::Round($cx-$bw/2); y1=[int][Math]::Round($cy-$bh/2);
                x2=[int][Math]::Round($cx+$bw/2); y2=[int][Math]::Round($cy+$bh/2); src='yolo_txt' })
        }
        return $boxes
    }
    if (Test-Path -LiteralPath $js) {
        foreach ($b in ((Get-Content -LiteralPath $js -Raw -Encoding UTF8 | ConvertFrom-Json).boxes)) {
            $boxes.Add([pscustomobject]@{ cls=[int]$b.cls; x1=[int]$b.x1; y1=[int]$b.y1;
                x2=[int]$b.x2; y2=[int]$b.y2; src='json' })
        }
        return $boxes
    }
    return $null
}

function Export-InternalLabels {
    param(
        [Parameter(Mandatory=$true)][string]$LabelDir,
        [Parameter(Mandatory=$true)][string]$OutRoot,
        [int]$ImgW = 1280, [int]$ImgH = 720,
        [int]$NumClass = 1
    )
    $mapCsv = Join-Path $OutRoot 'id_map.csv'
    if (-not (Test-Path -LiteralPath $mapCsv)) { throw ('缺 id_map.csv，先跑 Invoke-Preprocess: ' + $mapCsv) }
    $map = Import-Csv -LiteralPath $mapCsv
    $labDir = Join-Path $OutRoot 'labels'
    $repDir = Join-Path $OutRoot 'report'
    New-Item -ItemType Directory -Force -Path $labDir,$repDir | Out-Null

    $rows = New-Object System.Collections.Generic.List[object]
    $miss = @(); $oob = @(); $small = @(); $badcls = @()
    foreach ($m in $map) {
        $base = Join-Path $LabelDir ([System.IO.Path]::GetFileNameWithoutExtension($m.src_file))
        $boxes = Import-LabelFile -Path $base -ImgW $m.src_w -ImgH $m.src_h
        if ($null -eq $boxes) { $miss += $m.src_file; continue }
        if ($boxes.Count -eq 0) { $miss += $m.src_file; continue }

        $out = New-Object System.Collections.Generic.List[object]
        foreach ($b in $boxes) {
            $sc = [double]$m.scale; $ox = [int]$m.off_x; $oy = [int]$m.off_y
            $nx1 = [int][Math]::Round($b.x1 * $sc) - $ox
            $ny1 = [int][Math]::Round($b.y1 * $sc) - $oy
            $nx2 = [int][Math]::Round($b.x2 * $sc) - $ox
            $ny2 = [int][Math]::Round($b.y2 * $sc) - $oy
            $clip = $false
            if ($nx1 -lt 0 -or $ny1 -lt 0 -or $nx2 -gt ($ImgW-1) -or $ny2 -gt ($ImgH-1)) { $clip = $true }
            $nx1 = [Math]::Max(0,$nx1); $ny1 = [Math]::Max(0,$ny1)
            $nx2 = [Math]::Min($ImgW-1,$nx2); $ny2 = [Math]::Min($ImgH-1,$ny2)
            if ($clip) { $oob += $m.src_file }
            if ($b.cls -ge $NumClass) { $badcls += $m.src_file }
            $hd = Encode-HeadLabel -x1 $nx1 -y1 $ny1 -x2 $nx2 -y2 $ny2
            $share = (($ny2-$ny1+1) / [double]$ImgH)
            if ($share -lt 0.30) { $small += $m.src_file }
            $out.Add([pscustomobject]@{ cls=[int]$b.cls; x1=$nx1; y1=$ny1; x2=$nx2; y2=$ny2;
                                        cx=(($nx1+$nx2)/2); cy=(($ny1+$ny2)/2);
                                        gx=$hd.gx; gy=$hd.gy; dx=$hd.dx; dy=$hd.dy; w=$hd.w; h=$hd.h;
                                        clipped=$clip; height_share=[Math]::Round($share,3) })
        }
        $rec = [pscustomobject]@{ image=($m.new_id + '.jpg'); src_file=$m.src_file; boxes=$out.ToArray() }
        [System.IO.File]::WriteAllText((Join-Path $labDir ($m.new_id + '.json')),
            ($rec | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
        $rows.Add([pscustomobject]@{ new_id=$m.new_id; src_file=$m.src_file; nbox=$out.Count })
    }
    $repPath = Join-Path $repDir 'label_report.txt'
    $lines = @()
    $lines += ('标注对齐报告  ' + (Get-Date).ToString('s'))
    $lines += ('图片总数: ' + $map.Count + '   有标注: ' + $rows.Count + '   缺标注: ' + $miss.Count)
    $lines += ('目标被裁剪(越界) : ' + $oob.Count + ' 张  -> ' + (($oob | Select-Object -First 20) -join ', '))
    $lines += ('类别号非法(<0 或 >= ' + $NumClass + ') : ' + $badcls.Count + ' 张 -> ' + (($badcls | Select-Object -First 20) -join ', '))
    $lines += ('目标占屏高 < 0.30 : ' + $small.Count + ' 张 -> ' + (($small | Select-Object -First 20) -join ', '))
    $lines += ('缺标注 : ' + $miss.Count + ' 张 -> ' + (($miss | Select-Object -First 20) -join ', '))
    [System.IO.File]::WriteAllLines($repPath, $lines)
    Write-Host ('已写 labels\ (' + $rows.Count + ' 个文件)')
    $lines | ForEach-Object { Write-Host ('  ' + $_) }
    return [pscustomobject]@{ Labeled=$rows.Count; Missing=$miss.Count; OOB=$oob.Count;
                              BadCls=$badcls.Count; TooSmall=$small.Count; Report=$repPath }
}
