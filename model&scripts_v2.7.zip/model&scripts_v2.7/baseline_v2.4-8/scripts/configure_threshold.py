#!/usr/bin/env python3
"""Set the SC520 objectness threshold consistently in the target project."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def replace_once(path: Path, pattern: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"Expected one threshold match in {path}, found {count}")
    path.write_text(updated, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--threshold", type=int, default=131)
    args = parser.parse_args()
    threshold = args.threshold
    retain = max(0, threshold - 2)
    project = args.project.resolve()

    contract_path = project / "user_source/hdl_source/cnn/cnn_contract.json"
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    contract["post"]["obj_thresh"] = threshold
    contract_path.write_text(
        json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    replace_once(
        project / "user_source/hdl_source/cnn/cnn_config.vh",
        r"(`define\s+CNN_OBJ_THRESH\s+)8'd\d+",
        rf"\g<1>8'd{threshold}",
    )
    replace_once(
        project / "fd_project/src/mcu_tasks.c",
        r"if\s*\(score\s*<\s*\d+u",
        f"if (score < {threshold}u",
    )
    replace_once(
        project / "fd_project/src/cnn_tracker.c",
        r"#define ACQUIRE_SCORE \d+u",
        f"#define ACQUIRE_SCORE {threshold}u",
    )
    replace_once(
        project / "fd_project/src/cnn_tracker.c",
        r"#define RETAIN_SCORE \d+u",
        f"#define RETAIN_SCORE {retain}u",
    )
    print(json.dumps({
        "threshold": threshold,
        "retain_threshold": retain,
        "contract": str(contract_path),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
