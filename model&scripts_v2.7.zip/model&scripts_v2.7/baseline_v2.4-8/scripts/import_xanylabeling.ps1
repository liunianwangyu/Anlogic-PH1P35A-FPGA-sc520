﻿<#
  import_xanylabeling.ps1 -- 把 X-AnyLabeling 的原生 json 直接转成训练用的内部标注

  适用场景：
    在 X-AnyLabeling 中直接标注 <数据集根>\images 里的图片，并在同目录保存
    同名原生 JSON（shapes[] + points[][]）。本脚本按 ClassMap 把标签名映射为
    类别号，直接生成 <数据集根>\labels\<同名>.json。

  用法：
    .\scripts\import_xanylabeling.ps1 -ImgDir "<数据集根>\images" -NumClass 2 -ClassMap "starve=0,genshin=1" -KeepEmpty
#>
param(
    [Parameter(Mandatory=$true)][string]$ImgDir,
    [string]$OutDir,
    [int]$NumClass = 1,
    [string]$ClassMap = "",
    [switch]$KeepEmpty          # 0 个 shapes 的空场景也写成 labels\*.json（boxes=[]）
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'dataset_core.ps1')

$ImgDir = (Resolve-Path -LiteralPath $ImgDir).Path
$root   = Split-Path -Parent $ImgDir
if (-not $OutDir) { $OutDir = Join-Path $root 'labels' }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# ---- 类名 -> 索引 ----
$lmap = @{}
foreach ($p in ($ClassMap -split ',')) {
    if ($p.Trim() -eq '') { continue }
    $kv = $p.Split('=')
    if ($kv.Count -eq 2) { $lmap[$kv[0].Trim()] = [int]$kv[1] }
}
$lmapAuto = ($lmap.Count -eq 0)

# ---- id_map（拿 src_file，可选）----
$srcmap = @{}
$mp = Join-Path $root 'id_map.csv'
if (Test-Path -LiteralPath $mp) {
    foreach ($r in (Import-Csv -LiteralPath $mp)) { $srcmap[$r.new_id] = $r.src_file }
}

$imgs  = @(Get-ChildItem -LiteralPath $ImgDir -File | Where-Object { $_.Extension -in '.jpg','.jpeg','.png','.bmp' } | Sort-Object Name)
$jmap  = @{}
Get-ChildItem -LiteralPath $ImgDir -File -Filter '*.json' | ForEach-Object { $jmap[$_.BaseName] = $_.FullName }

Add-Type -AssemblyName System.Drawing
$nImg = 0; $nBox = 0
$noLab = @(); $skipType = @(); $degen = @(); $clamped = @(); $badSize = @(); $multi = @(); $emptyKept = @()
$labelCount = @{}

foreach ($im in $imgs) {
    $jp = $jmap[$im.BaseName]
    if (-not $jp) { $noLab += $im.Name; continue }

    $j = Get-Content -LiteralPath $jp -Raw -Encoding UTF8 | ConvertFrom-Json
    $imw = [int]$j.imageWidth; $imh = [int]$j.imageHeight
    if ($imw -le 0 -or $imh -le 0) {
        $probe = [System.Drawing.Image]::FromFile($im.FullName); $imw = $probe.Width; $imh = $probe.Height; $probe.Dispose()
    }
    $act = [System.Drawing.Image]::FromFile($im.FullName)
    $aw = $act.Width; $ah = $act.Height; $act.Dispose()
    if ($imw -ne $aw -or $imh -ne $ah) {
        # 标注坐标系和图片不一致 -> 不猜，直接跳过并报出来
        $badSize += ('{0}  json={1}x{2}  图片={3}x{4}' -f $im.Name, $imw, $imh, $aw, $ah)
        throw ('Coordinate metadata mismatch: ' + $im.Name)
    }
    if ($aw -ne 1280 -or $ah -ne 720) { throw ('Expected native 1280x720 image: ' + $im.Name) }

    $out = New-Object System.Collections.Generic.List[object]
    $occupied = @{}
    foreach ($s in @($j.shapes)) {
        $st = [string]$s.shape_type
        if ($st -ne 'rectangle') { throw ('Unsupported shape type: ' + $im.Name + ':' + $st) }
        $pts = @($s.points)
        if ($pts.Count -lt 2) { throw ('Invalid rectangle points: ' + $im.Name) }

        $xs = @($pts | ForEach-Object { [double]$_[0] })
        $ys = @($pts | ForEach-Object { [double]$_[1] })
        $x1 = [int][Math]::Round(($xs | Measure-Object -Minimum).Minimum)
        $x2 = [int][Math]::Round(($xs | Measure-Object -Maximum).Maximum)
        $y1 = [int][Math]::Round(($ys | Measure-Object -Minimum).Minimum)
        $y2 = [int][Math]::Round(($ys | Measure-Object -Maximum).Maximum)

        $clip = $false
        if ($x1 -lt 0 -or $y1 -lt 0 -or $x2 -gt ($aw-1) -or $y2 -gt ($ah-1)) { throw ('Out-of-image box; correct annotation: ' + $im.Name) }
        $x1 = [Math]::Max(0, $x1); $y1 = [Math]::Max(0, $y1)
        $x2 = [Math]::Min($aw-1, $x2); $y2 = [Math]::Min($ah-1, $y2)
        if ($x2 -le $x1 -or $y2 -le $y1) { throw ('Degenerate box: ' + $im.Name) }

        $lab = [string]$s.label
        if ($lmapAuto) { $cls = 0 } else { $cls = if ($lmap.ContainsKey($lab)) { $lmap[$lab] } else { -1 } }
        if ($cls -lt 0 -or $cls -ge $NumClass) { throw ('Unknown label: ' + $im.Name + ':' + $lab) }
        if (-not $labelCount.ContainsKey($lab)) { $labelCount[$lab] = 0 }
        $labelCount[$lab]++

        $hd = Encode-HeadLabel -x1 $x1 -y1 $y1 -x2 $x2 -y2 $y2
        if ($hd.w -lt 1 -or $hd.w -gt 127 -or $hd.h -lt 1 -or $hd.h -gt 127 -or
            $hd.dx -lt -128 -or $hd.dx -gt 127 -or $hd.dy -lt -128 -or $hd.dy -gt 127) {
            throw ('Box exceeds signed INT8 contract; isolate and report: ' + $im.Name)
        }
        $cell = '{0},{1}' -f $hd.gx,$hd.gy
        if ($occupied.ContainsKey($cell)) { throw ('Multiple objects in one head cell: ' + $im.Name + ':' + $cell) }
        $occupied[$cell] = $true
        $out.Add([pscustomobject]@{
            cls = $cls; x1 = $x1; y1 = $y1; x2 = $x2; y2 = $y2
            cx = (($x1+$x2)/2); cy = (($y1+$y2)/2)
            gx = $hd.gx; gy = $hd.gy; dx = $hd.dx; dy = $hd.dy; w = $hd.w; h = $hd.h
            clipped = $clip; height_share = [Math]::Round((($y2-$y1+1)/[double]$ah), 3)
        })
    }
    if ($out.Count -eq 0) {
        if ($KeepEmpty) {
            $rec = [pscustomobject]@{
                image    = $im.Name
                src_file = $srcmap[$im.BaseName]
                boxes    = @()
            }
            [System.IO.File]::WriteAllText((Join-Path $OutDir ($im.BaseName + '.json')),
                ($rec | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
            $nImg++
            $emptyKept += $im.Name
        } else {
            $noLab += $im.Name
        }
        continue
    }
    if ($out.Count -gt 1) { $multi += ('{0}({1})' -f $im.Name, $out.Count) }

    $rec = [pscustomobject]@{
        image    = $im.Name
        src_file = $srcmap[$im.BaseName]
        boxes    = $out.ToArray()
    }
    [System.IO.File]::WriteAllText((Join-Path $OutDir ($im.BaseName + '.json')),
        ($rec | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
    $nImg++; $nBox += $out.Count
}

$repDir = Join-Path $root 'report'
New-Item -ItemType Directory -Force -Path $repDir | Out-Null
$rep = Join-Path $repDir 'import_xanylabeling.txt'
$lines = @()
$lines += ('X-AnyLabeling 导入报告  ' + (Get-Date).ToString('s'))
$lines += ('图片 {0} 张 -> 已转 {1} 张 / {2} 个框' -f $imgs.Count, $nImg, $nBox)
$lines += ('空场景保留为负样本: {0} 张 -> {1}' -f $emptyKept.Count, (($emptyKept | Select-Object -First 20) -join ', '))
$lines += ('标签分布: ' + (($labelCount.GetEnumerator() | ForEach-Object { $_.Key + '=' + $_.Value }) -join ', '))
$lines += ('没有 json（未标注）: {0} 张 -> {1}' -f $noLab.Count, ($noLab -join ', '))
$lines += ('坐标系不一致（跳过）: {0} -> {1}' -f $badSize.Count, ($badSize -join ' | '))
$lines += ('非矩形/点数不足/标签非法（跳过）: {0} -> {1}' -f $skipType.Count, (($skipType | Select-Object -First 30) -join ' | '))
$lines += ('退化框（宽或高<=0，跳过）: {0} -> {1}' -f $degen.Count, (($degen | Select-Object -First 30) -join ', '))
$lines += ('越界被裁剪: {0} -> {1}' -f $clamped.Count, (($clamped | Select-Object -First 30) -join ', '))
$lines += ('一张图多个框: {0} -> {1}' -f $multi.Count, (($multi | Select-Object -First 30) -join ', '))
[System.IO.File]::WriteAllLines($rep, $lines)
$lines | ForEach-Object { Write-Host ('  ' + $_) }
Write-Host ('  标注目录: ' + $OutDir)
