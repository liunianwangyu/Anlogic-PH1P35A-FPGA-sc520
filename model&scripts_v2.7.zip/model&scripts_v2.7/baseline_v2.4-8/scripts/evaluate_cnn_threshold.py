"""Scan thresholds on frozen validation scenes using actual detection matching."""
import argparse, json
from pathlib import Path
import torch
import train_cnn as tc
from training_policy import load_fixed_split, digest
from evaluate_detection import decode_head, detection_metrics

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',required=True); ap.add_argument('--data',required=True)
    ap.add_argument('--min-threshold',type=int,default=128)
    ap.add_argument('--max-threshold',type=int,default=160)
    ap.add_argument('--grayscale',action='store_true',help='Scan board-converted grayscale input')
    ap.add_argument('--output',help='Output JSON; defaults to run/threshold_validation.json')
    a=ap.parse_args()
    if not 0<=a.min_threshold<=a.max_threshold<=255: raise ValueError('threshold range')
    run=Path(a.run)
    ck=torch.load(run/'model/model.pt',map_location='cpu',weights_only=False)
    c=ck['contract']; nc=int(c['post']['num_class'])
    items=load_fixed_split(tc.collect_dataset(Path(a.data),nc),run/'split_manifest.json')['val']
    words=[int(s,16) for s in (run/'weights/cnn_weights.dat').read_text().split()]
    layers=tc.layers_from_contract(c,tc.unpack_weights(words,c['layers']))
    heads=[]
    for ip,lp,_ in items:
        y=tc.integer_forward_fast(
            layers,tc.load_frame(ip,force_grayscale=a.grayscale),c['layers'])[-1]
        gt=[dict(cls=int(b['cls']),box=[b['x1'],b['y1'],b['x2'],b['y2']]) for b in tc.load_targets(lp,nc)[-1]]
        heads.append((y,gt))
    rows=[]
    for th in range(a.min_threshold,a.max_threshold+1):
        rec=[]; shown=[]
        for y,gt in heads:
            pred,disp=decode_head(y,th,num_classes=nc)
            rec.append(dict(pred=pred,gt=gt)); shown.append(dict(pred=disp,gt=gt))
        class_ids=tuple(range(nc))
        rows.append(dict(threshold_u8=th,
                         numerical=detection_metrics(rec,class_ids=class_ids),
                         display=detection_metrics(shown,class_ids=class_ids)))
    best=max(rows,key=lambda d:(d['numerical']['f1'],-d['numerical']['empty_false_boxes'],-d['threshold_u8']))
    out=dict(split='val',metric='class-aware IoU>=0.5 one-to-one F1',best=best,rows=rows,firmware_automatically_modified=False,
             weights_sha256=digest(run/'weights/cnn_weights.dat'),split_sha256=digest(run/'split_manifest.json'),
             grayscale=bool(a.grayscale))
    output=Path(a.output) if a.output else run/'threshold_validation.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(best,indent=2))
if __name__=='__main__': main()
