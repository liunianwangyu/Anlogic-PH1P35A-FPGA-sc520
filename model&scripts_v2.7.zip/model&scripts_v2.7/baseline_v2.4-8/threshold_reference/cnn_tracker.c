#include "cnn_tracker.h"

/* 100 MHz MCU. Unsigned elapsed arithmetic also handles rdcycle rollover.
 * Keep acquisition at the current validated threshold. Two consistent strong
 * observations are needed; weak observations can only extend an existing track.
 * Parameters are engineering defaults, not a measured accuracy calibration. */
#define TICKS_MS 100000u
#define ACQUIRE_SCORE 131u
#define RETAIN_SCORE 129u
#define CLASS_MARGIN 2
#define LOST_TICKS (120u*TICKS_MS)
#define WEAK_TICKS (200u*TICKS_MS)

typedef struct {
    cnn_geometry raw,filtered,pending;
    uint32_t last_match,last_strong,pending_time;
    uint8_t valid,pending_valid,history;
} track;
typedef struct { cnn_geometry box; uint32_t rank,score,strong; } candidate;
typedef struct {
    int16_t cx,cy,hw,hh;
    uint32_t fresh_w0,fresh_w1,fresh_cell,near_w0,near_w1,near_cell;
} hot_track;
_Static_assert(sizeof(hot_track)*2==64,"reuse only the existing 16 result words");
/* DLM already reserves its full stack budget. Reuse the unused portion of
 * the existing private audio SRAM, as the servo history already does. Startup
 * zeroes this section; the linker checks it stays below the audio stack. */
#define HISTORY __attribute__((section(".audio_state.cnn_tracker")))
static track tracks[2] HISTORY;
static uint32_t context_generation HISTORY,context_orientation HISTORY;
static uint32_t last_job HISTORY,have_context HISTORY;

static int32_t signed_byte(uint32_t x)
{ return (int32_t)(x&255u)-((x&128u)?256:0); }
static int32_t absolute(int32_t x) { return x<0?-x:x; }
static int32_t half_floor(int32_t x) { return x>=0?x/2:-((-x+1)/2); }
static void copy_geometry(volatile cnn_geometry *d,const cnn_geometry *s)
{
    /* Do not lower to libc memcpy: it checkpoints after every byte for the
     * MP3 worker. These aligned MMIO SRAM records need four word accesses. */
    d->cx=s->cx;d->cy=s->cy;d->hw=s->hw;d->hh=s->hh;
}

/* Geometric gating is relative to object size, with a small-object floor.
 * A 2x scale envelope tolerates movement but rejects tiny local parts and
 * implausible size jumps. No float, division, allocation, or global matching. */
static uint32_t compatible(const cnn_geometry *a,const cnn_geometry *b)
{
    int32_t gx=a->hw>32?a->hw:32,gy=a->hh>24?a->hh:24;
    return absolute(a->cx-b->cx)<=gx && absolute(a->cy-b->cy)<=gy &&
        b->hw*2>=a->hw && b->hw<=a->hw*2 &&
        b->hh*2>=a->hh && b->hh<=a->hh*2;
}

void cnn_tracker_begin(uint32_t now,uint32_t generation,uint32_t orientation,uint32_t *scratch)
{
    hot_track *hot=(hot_track *)scratch;
    uint32_t reset=!have_context || generation!=context_generation ||
        orientation!=context_orientation || now-last_job>=500u*TICKS_MS;
    for(uint32_t c=0;c<2;c++) {
        hot[c].fresh_w0=hot[c].near_w0=0;
        if(reset) {tracks[c].valid=0;tracks[c].pending_valid=0;tracks[c].history=0;}
        if(tracks[c].valid && (now-tracks[c].last_match>=LOST_TICKS ||
           now-tracks[c].last_strong>=WEAK_TICKS))tracks[c].valid=0;
        hot[c].cx=(int16_t)tracks[c].raw.cx;hot[c].cy=(int16_t)tracks[c].raw.cy;
        hot[c].hw=tracks[c].valid?(int16_t)tracks[c].raw.hw:0;
        hot[c].hh=(int16_t)tracks[c].raw.hh;
    }
    context_generation=generation;context_orientation=orientation;
    have_context=1;last_job=now;
}

static cnn_geometry decode(uint32_t cell,uint32_t w0,uint32_t w1)
{
    return (cnn_geometry){(int32_t)(cell%20u)*64+32+half_floor(signed_byte(w0>>8)),
        (int32_t)(cell/20u)*60+30+half_floor(signed_byte(w0>>16)),(int32_t)(w0>>24)*4,(int32_t)(w1&255u)*4};
}
static uint32_t priority(uint32_t cell,uint32_t w0)
{ return (((w0+128u)&255u)<<8)|(255u-cell); }
static void __attribute__((noinline)) consider_near(hot_track *t,uint32_t cell,uint32_t w0,uint32_t w1)
{
    int32_t hw=(int32_t)(w0>>24)*4,hh=(int32_t)(w1&255u)*4;
    if(hw*2<t->hw || hw>t->hw*2 || hh*2<t->hh || hh>t->hh*2)return;
    int32_t x=(int32_t)(cell%20u)*64+32+half_floor(signed_byte(w0>>8));
    int32_t y=(int32_t)(cell/20u)*60+30+half_floor(signed_byte(w0>>16));
    int32_t dx=absolute(x-t->cx),dy=absolute(y-t->cy);
    if(dx>(t->hw>32?t->hw:32) || dy>(t->hh>24?t->hh:24))return;
    /* Continuity outweighs a modest score advantage. Store rank above the
     * eight-bit cell index, reusing a word instead of adding hot-state RAM. */
    uint32_t rank=((w0+128u)&255u)*64u+32768u-(uint32_t)(dx+dy)*24u;
    if(!t->near_w0 || rank>(t->near_cell>>8)) {
        t->near_w0=w0;t->near_w1=w1;t->near_cell=(rank<<8)|cell;
    }
}
void cnn_tracker_add(uint32_t cell,uint32_t w0,uint32_t w1,uint32_t *scratch)
{
    uint32_t w=w0>>24,h=w1&255u,score=(w0+128u)&255u;
    if(score<RETAIN_SCORE || w<1 || w>127 || h<1 || h>127)return;
    int32_t c0=signed_byte(w1>>8),c1=signed_byte(w1>>16);
    uint32_t cls=c0>=c1?0u:1u;
    hot_track *t=&((hot_track *)scratch)[cls];
    if(!t->hw) {
        if(score>=ACQUIRE_SCORE && absolute(c0-c1)>=CLASS_MARGIN &&
           (!t->fresh_w0 || priority(cell,w0)>priority(t->fresh_cell,t->fresh_w0))) {
            t->fresh_w0=w0;t->fresh_w1=w1;t->fresh_cell=cell;
        }
        return;
    }
    if(t->hw) {
        /* Most cells are far from a track. Reject them before constructing
         * geometry; offsets can shift a grid centre by at most 64 pixels. */
        if(absolute((int32_t)(cell%20u)*64+32-t->cx)>t->hw+64 ||
           absolute((int32_t)(cell/20u)*60+30-t->cy)>t->hh+64)return;
        consider_near(t,cell,w0,w1);
    }
}

static void smooth(track *t,const cnn_geometry *b)
{
    /* Q2 history avoids integer deadband. Fast motion bypasses the centre
     * low-pass while width/height remain filtered. */
    uint32_t fast=absolute(b->cx-t->raw.cx)>24 || absolute(b->cy-t->raw.cy)>18;
    t->filtered.cx=fast?b->cx*4:t->filtered.cx+(b->cx*4-t->filtered.cx)/2;
    t->filtered.cy=fast?b->cy*4:t->filtered.cy+(b->cy*4-t->filtered.cy)/2;
    t->filtered.hw+=(b->hw*4-t->filtered.hw)/4;
    t->filtered.hh+=(b->hh*4-t->filtered.hh)/4;
    copy_geometry(&t->raw,b);
}

static uint32_t conflicts(uint32_t cls,const candidate *n,uint32_t w1,uint32_t now)
{
    track *other=&tracks[cls^1u];
    if(!other->valid || now-other->last_match>=LOST_TICKS || now-other->last_strong>=WEAK_TICKS)return 0;
    const cnn_geometry *a=&other->raw,*b=&n->box;
    int32_t x1=a->cx-a->hw>b->cx-b->hw?a->cx-a->hw:b->cx-b->hw;
    int32_t x2=a->cx+a->hw<b->cx+b->hw?a->cx+a->hw:b->cx+b->hw;
    int32_t y1=a->cy-a->hh>b->cy-b->hh?a->cy-a->hh:b->cy-b->hh;
    int32_t y2=a->cy+a->hh<b->cy+b->hh?a->cy+a->hh:b->cy+b->hh;
    if(x2<=x1 || y2<=y1)return 0;
    uint32_t inter=(uint32_t)(x2-x1)*(uint32_t)(y2-y1);
    uint32_t aa=(uint32_t)(a->hw*a->hh)*4u,bb=(uint32_t)(b->hw*b->hh)*4u;
    /* Block a duplicate identity on essentially the same box. A small nested
     * part is rejected only with weak class separation; strong overlapping
     * detections remain possible for two real nearby objects. */
    return (inter*4u>=aa*3u && inter*4u>=bb*3u) ||
        (bb*4u<=aa && inter*4u>=bb*3u && absolute(signed_byte(w1>>8)-signed_byte(w1>>16))<8);
}

void cnn_tracker_finish(uint32_t now,uint32_t *scratch,uint32_t cls)
{
    hot_track *hot=(hot_track *)scratch;
    if(cls<2) {
        hot_track *s=&hot[cls];
        candidate matched={decode(s->near_cell&255u,s->near_w0,s->near_w1),s->near_w0,0,
            ((s->near_w0+128u)&255u)>=ACQUIRE_SCORE && absolute(signed_byte(s->near_w1>>8)-signed_byte(s->near_w1>>16))>=CLASS_MARGIN};
        candidate novel={decode(s->fresh_cell,s->fresh_w0,s->fresh_w1),s->fresh_w0,0,1};
        track *t=&tracks[cls];candidate *m=&matched,*n=&novel;
        if(t->valid && m->rank) {
            smooth(t,&m->box);t->last_match=now;
            if(m->strong)t->last_strong=now;
            t->pending_valid=0;t->history=0;
            return;
        }
        if(t->valid && (now-t->last_match>=LOST_TICKS || now-t->last_strong>=WEAK_TICKS))t->valid=0;
        /* A live target cannot be replaced by a far one-frame high score. */
        if(t->valid)return;
        t->history=(uint8_t)((t->history<<1)&7u);
        if(!n->rank) {
            if(now-t->pending_time>=LOST_TICKS)t->pending_valid=0;
            return;
        }
        if(conflicts(cls,n,s->fresh_w1,now)) {t->pending_valid=0;t->history=0;return;}
        if(!t->pending_valid || now-t->pending_time>=LOST_TICKS ||
           !compatible(&t->pending,&n->box))t->history=0;
        copy_geometry(&t->pending,&n->box);t->pending_valid=1;t->pending_time=now;t->history|=1u;
        if((t->history&2u)||(t->history&4u)) {
            copy_geometry(&t->raw,&n->box);t->filtered=(cnn_geometry){n->box.cx*4,n->box.cy*4,n->box.hw*4,n->box.hh*4};
            t->valid=1;t->last_match=t->last_strong=now;
            t->pending_valid=0;t->history=0;
        }
    }
}

uint32_t cnn_tracker_box(uint32_t cls,cnn_geometry *box)
{
    if(cls>=2 || !tracks[cls].valid)return 0;
    cnn_geometry *b=&tracks[cls].filtered;
    *box=(cnn_geometry){b->cx/4,b->cy/4,b->hw/4,b->hh/4};
    return 1;
}
