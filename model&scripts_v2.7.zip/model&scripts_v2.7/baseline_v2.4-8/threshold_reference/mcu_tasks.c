#include "mcu_tasks.h"
#include "servo_task.h"
#include "audio_runtime.h"
#include "cnn_tracker.h"

mcu_cnn_data cnn_data;
volatile mcu_performance mcu_perf;

/* Independent display winners do not consume the numerical top-8 budget.
 * A strict improvement preserves raster-scan order when scores tie. */
static struct { uint32_t rank, w0, w1; } cnn_display[2];

static uint32_t cycle(void)
{
    uint32_t value;
    __asm__ volatile("rdcycle %0" : "=r"(value));
    return value;
}

void mcu_cnn_reset(void)
{
    cnn_data.count = 0;
    cnn_display[0].rank = cnn_display[1].rank = 0;
    for (uint32_t i = 0; i < 16; ++i) cnn_data.words[i] = 0;
}

static int32_t byte_signed(uint32_t value)
{
    return (int32_t)(value & 255u) - ((value & 128u) ? 256 : 0);
}

static int32_t half_floor(int32_t value)
{
    /* Verilog >>>1 rounds negative odd values down, unlike C division. */
    return value >= 0 ? value / 2 : -((-value + 1) / 2);
}

static uint32_t saturate(int32_t value, int32_t high)
{
    return value < 0 ? 0u : (value > high ? (uint32_t)high : (uint32_t)value);
}

void mcu_cnn_add(uint32_t cell, uint32_t w0, uint32_t w1)
{
    /* INT8 head sizes are legal only in [1,127]. Never reinterpret a
     * negative regression output as a large unsigned rectangle. */
    uint32_t width = w0 >> 24, height = w1 & 255u;
    uint32_t score = (w0 + 128u) & 255u; /* objectness, not class logit */
    if (score < 131u || !width || width > 127u || !height || height > 127u) return;
    int32_t c0 = byte_signed(w1 >> 8), c1 = byte_signed(w1 >> 16);
    uint32_t cls = c0 >= c1 ? 0u : 1u; /* third physical channel is reserved */
    /* A single unsigned comparison covers validity, score and scan-order ties.
     * Every valid rank is nonzero, including score 0 in the final cell. */
    uint32_t rank = (score << 8) | (255u - cell);
    if (cls < 2 && rank > cnn_display[cls].rank) {
        cnn_display[cls].rank = rank; cnn_display[cls].w0 = w0;
        cnn_display[cls].w1 = w1;
    }
    uint32_t pos = 0;
    /* Strict > in the RTL insertion priority preserves scan order on ties. */
    while (pos < cnn_data.count && score <= cnn_data.top[cnn_data.order[pos]].score) ++pos;
    if (pos == 8) return;
    uint32_t n = cnn_data.count;
    uint32_t slot = n < 8 ? n : cnn_data.order[7];
    if (n < 8) cnn_data.count = ++n;
    /* Move eight one-byte handles instead of wide candidate structures.
     * Decode coordinates only for the final eight, outside the scan loop. */
    for (uint32_t i = n - 1; i > pos; --i) cnn_data.order[i] = cnn_data.order[i-1];
    cnn_data.order[pos] = (uint8_t)slot;
    mcu_box *b = &cnn_data.top[slot];
    b->x1 = w0; b->y1 = w1; b->x2 = cell;
    b->cls = cls; b->score = score;
}

uint32_t mcu_cnn_finish(void)
{
    /* The same 64 bytes are display scratch during head scanning. */
    for(uint32_t i=0;i<16;i++)cnn_data.words[i]=0;
    uint32_t suppressed = 0, count = 0;
    for (uint32_t i = 0; i < cnn_data.count; ++i) {
        mcu_box *b = &cnn_data.top[i];
        uint32_t w0 = b->x1, w1 = b->y1, cell = b->x2;
        int32_t cx = (int32_t)(cell % 20u) * 64 + 32 + half_floor(byte_signed(w0 >> 8));
        int32_t cy = (int32_t)(cell / 20u) * 60 + 30 + half_floor(byte_signed(w0 >> 16));
        int32_t hw = (int32_t)(w0 >> 24) * 4, hh = (int32_t)(w1 & 255u) * 4;
        b->x1 = saturate(cx - hw, 1279); b->x2 = saturate(cx + hw, 1279);
        b->y1 = saturate(cy - hh, 719); b->y2 = saturate(cy + hh, 719);
    }
    for (uint32_t i = 0; i < cnn_data.count; ++i) {
        if (suppressed & (1u << i)) continue;
        const mcu_box *a = &cnn_data.top[cnn_data.order[i]];
        uint32_t ai = (a->x2 - a->x1 + 1u) * (a->y2 - a->y1 + 1u);
        for (uint32_t j = i + 1; j < cnn_data.count; ++j) {
            const mcu_box *b = &cnn_data.top[cnn_data.order[j]];
            if ((suppressed & (1u << j)) || a->cls != b->cls) continue;
            int32_t iw = (int32_t)(a->x2 < b->x2 ? a->x2 : b->x2) -
                         (int32_t)(a->x1 > b->x1 ? a->x1 : b->x1) + 1;
            int32_t ih = (int32_t)(a->y2 < b->y2 ? a->y2 : b->y2) -
                         (int32_t)(a->y1 > b->y1 ? a->y1 : b->y1) + 1;
            uint32_t inter = (iw < 0 || ih < 0) ? 0u : (uint32_t)iw * (uint32_t)ih;
            uint32_t aj = (b->x2 - b->x1 + 1u) * (b->y2 - b->y1 + 1u);
            if (2u * inter > ai + aj - inter) suppressed |= 1u << j;
        }
        cnn_data.words[count*2] = (a->x2 << 21) | (a->y2 << 10);
        cnn_data.words[count*2+1] = (a->score << 24) | (a->cls << 22) | (a->x1 << 11) | a->y1;
        ++count;
    }
    return count;
}

uint32_t mcu_awb_gain(uint32_t green, uint32_t channel, uint32_t previous,
                      uint32_t limits, uint32_t smooth_shift)
{
    /* Exact 36/24 restoring division of (sum_g << 12), without a runtime
     * 64-bit division helper in this freestanding firmware. The RTL clamps
     * any nonzero quotient bits above bit15 directly to GAIN_MAX. */
    uint32_t remainder = 0, quotient = 0, overflow = 0;
    for (int32_t bit = 35; bit >= 0; --bit) {
        uint32_t incoming = bit >= 12 ? ((green >> (uint32_t)(bit - 12)) & 1u) : 0u;
        remainder = (remainder << 1) | incoming;
        uint32_t take = remainder >= channel;
        if (take) remainder -= channel;
        if (bit >= 16) overflow |= take;
        else quotient = (quotient << 1) | take;
    }
    uint32_t low = limits & 65535u, high = limits >> 16;
    uint32_t target = overflow || quotient > high ? high : (quotient < low ? low : quotient);
    int32_t delta = (int32_t)target - (int32_t)previous;
    int32_t step = smooth_shift >= 17 ? (delta < 0 ? -1 : 0) : (delta >> smooth_shift);
    return (uint32_t)((int32_t)previous + step) & 65535u;
}

static struct {
    uint32_t active, token, index, start_cycle;
} cnn_task;

static uint32_t cnn_label_bcd(uint32_t value)
{
    uint32_t bcd = 0;
    for (uint32_t shift = 0; shift < 16; shift += 4) {
        bcd |= (value % 10u) << shift;
        value /= 10u;
    }
    return bcd;
}

/* Two 80-bit slots, class 0 then class 1. Each slot packs:
 * x1[10:0], y1[20:11], x2[31:21], y2[41:32],
 * X BCD[54:42] (0..1279), Y BCD[66:55], FLP Y BCD[78:67], valid[79].
 * Three APB writes/slot; the upper half of the third word is reserved.
 * 0x1c0..0x1d4 deliberately avoids motion's 0x180..0x1bf window. */
static uint32_t cnn_display_submit(void)
{
    uint32_t servo_target=0;
    for (uint32_t cls = 0; cls < 2; ++cls) {
        uint32_t a = 0, b = 0, c = 0;
        if (cnn_display[cls].rank) {
            uint32_t cell = 255u - (cnn_display[cls].rank & 255u);
            uint32_t w0 = cnn_display[cls].w0, w1 = cnn_display[cls].w1;
            int32_t cx = (int32_t)(cell % 20u) * 64 + 32 + half_floor(byte_signed(w0 >> 8));
            int32_t cy = (int32_t)(cell / 20u) * 60 + 30 + half_floor(byte_signed(w0 >> 16));
            int32_t hw = (int32_t)(w0 >> 24) * 4, hh = (int32_t)(w1 & 255u) * 4;
            uint32_t x1 = saturate(cx - hw, 1279), x2 = saturate(cx + hw, 1279);
            uint32_t y1 = saturate(cy - hh, 719), y2 = saturate(cy + hh, 719);
            if(cls==0)servo_target=0x80000000u|((x1+x2)>>1)|(((y1+y2)>>1)<<11);
        }
        /* Servo retains the original raw winner and its own existing filter.
         * Only screen geometry uses the new display tracker. */
        cnn_geometry box;
        if(cnn_tracker_box(cls,&box)) {
            uint32_t x1=saturate(box.cx-box.hw,1279),x2=saturate(box.cx+box.hw,1279);
            uint32_t y1=saturate(box.cy-box.hh,719),y2=saturate(box.cy+box.hh,719);
            uint32_t xb = cnn_label_bcd((x1 + x2) >> 1);
            uint32_t yb = cnn_label_bcd(719u - ((y1 + y2) >> 1));
            uint32_t fb = cnn_label_bcd((y1 + y2 + 1u) >> 1);
            a = x1 | (y1 << 11) | (x2 << 21);
            b = y2 | (xb << 10) | (yb << 23);
            c = (yb >> 9) | (fb << 3) | 0x8000u;
        }
        uint32_t off = CNN_BASE + 0xc0u + cls * 12u;
        mcu_write(off, a); mcu_write(off + 4, b); mcu_write(off + 8, c);
    }
    return servo_target;
}

static void cnn_step(void)
{
    uint32_t status = mcu_read(CNN_BASE + 4);
    if (!(status & 1u)) {
        if (cnn_task.active) { cnn_task.active = 0; ++mcu_perf.abandoned_jobs; }
        return;
    }
    uint32_t token = mcu_read(CNN_BASE + 8);
    if (!cnn_task.active || token != cnn_task.token) {
        cnn_task.active = 1; cnn_task.token = token; cnn_task.index = 0;
        cnn_task.start_cycle = cycle();
        extern uint32_t ui_config[4];
        mcu_cnn_reset(); mcu_write(CNN_BASE + 16, 0);
        cnn_tracker_begin(cnn_task.start_cycle,mcu_read(CNN_BASE+0x74u),ui_config[0]&24u,cnn_data.words);
    }
    if (cnn_task.index < 240) {
        /* Two bounded cells amortize task dispatch/MMIO status overhead.
         * AE is serviced again before the next pair; worst-gap tests retain
         * their original 0.5 ms limit, including top-8 insertions/tracking. */
        for(uint32_t n=0;n<2;n++) {
            uint32_t w0=mcu_read(CNN_BASE+20),w1=mcu_read(CNN_BASE+20);
            mcu_cnn_add(cnn_task.index,w0,w1);
            cnn_tracker_add(cnn_task.index++,w0,w1,cnn_data.words);
        }
        return;
    }
    if (!(mcu_read(CNN_BASE + 4) & 1u) || mcu_read(CNN_BASE + 8) != token) {
        cnn_task.active = 0; ++mcu_perf.abandoned_jobs; return;
    }
    if(cnn_task.index<242) {
        cnn_tracker_finish(cycle(),cnn_data.words,cnn_task.index++-240u);
        return;
    }
    if(cnn_task.index==242) {
        cnn_task.active=mcu_cnn_finish()+1u;
        cnn_task.index=243;
        return; /* AE gets another service opportunity before MMIO packing. */
    }
    uint32_t count=cnn_task.active-1u;
    uint32_t servo_target=cnn_display_submit();
    /* Preserve the original numerical/debug mailbox, including its box-0
     * label ABI. The display uses the separate per-class slots above.
     * Keep the numerical post-processing
     * result intact and attach its label to the reserved low ten bits of
     * result slots 0..3 while writing the existing result mailbox.
     * label[15:0]=X, [27:16]=normal Y, [39:28]=vertically flipped Y.
     * X is already in the mirrored display stream. For an odd endpoint sum,
     * reflecting first and then rounding the screen centre down needs ceil(Y).
     * Use two 32-bit words, avoiding a runtime 64-bit arithmetic helper. */
    uint32_t label_low = 0, label_high = 0;
    if (count) {
        uint32_t w0 = cnn_data.words[0], w1 = cnn_data.words[1];
        uint32_t centre_x = (((w1 >> 11) & 2047u) + (w0 >> 21)) >> 1;
        uint32_t y_sum = (w1 & 2047u) + ((w0 >> 10) & 2047u);
        uint32_t x_bcd = cnn_label_bcd(centre_x);
        uint32_t y_bcd = cnn_label_bcd(719u - (y_sum >> 1));
        uint32_t flipped_y_bcd = cnn_label_bcd((y_sum + 1u) >> 1);
        label_low = x_bcd | (y_bcd << 16) | (flipped_y_bcd << 28);
        label_high = flipped_y_bcd >> 4;
    }
    for (uint32_t i = 0; i < 16; ++i) {
        uint32_t word = cnn_data.words[i];
        if (i < 8 && !(i & 1u)) {
            word = (word & ~1023u) | (label_low & 1023u);
            label_low = (label_low >> 10) | (label_high << 22);
            label_high >>= 10;
        }
        mcu_write(CNN_BASE + 32 + i*4, word);
    }
    mcu_write(CNN_BASE + 24, count);
    mcu_write(CNN_BASE + 28, token);
    uint32_t class_mask=0;
    for(uint32_t i=0;i<count;i++)class_mask|=1u<<((cnn_data.words[i*2+1]>>22)&3u);
    audio_note_commit(token,class_mask);
    if(mcu_capabilities()&MCU_CAP_UI)servo_note_commit(token,servo_target);
    uint32_t elapsed = cycle() - cnn_task.start_cycle;
    if (elapsed > mcu_perf.max_cnn_cycles) mcu_perf.max_cnn_cycles = elapsed;
    ++mcu_perf.cnn_jobs; cnn_task.active = 0;
}

static struct {
    uint32_t active, token, index, blue, start_cycle;
    uint32_t limits, counts, config, r, g, b, count, previous, red;
    uint32_t global_red, global_blue;
    uint32_t phase, corrected_r, corrected_b, deadband;
} awb_task;

static void awb_finish(uint32_t good)
{
    if ((mcu_read(AWB_BASE + 4) & 1u) && mcu_read(AWB_BASE + 8) == awb_task.token) {
        mcu_write(AWB_BASE + 28, good);
        mcu_write(AWB_BASE + 24, awb_task.token);
        uint32_t elapsed = cycle() - awb_task.start_cycle;
        if (elapsed > mcu_perf.max_awb_cycles) mcu_perf.max_awb_cycles = elapsed;
        ++mcu_perf.awb_jobs;
    } else ++mcu_perf.abandoned_jobs;
    awb_task.active = 0;
}

static uint32_t awb_track(uint32_t target, uint32_t previous)
{
    uint32_t distance = target > previous ? target - previous : previous - target;
    if (distance <= awb_task.deadband) return previous;
    uint32_t shift = awb_task.config & 255u;
    uint32_t step = shift >= 32 ? 0u : distance >> shift;
    if (!step) step = 1;
    return target > previous ? previous + step : previous - step;
}

static uint32_t awb_compose(uint32_t base, uint32_t residual)
{
    uint32_t gain = (base * residual) >> 12;
    uint32_t low = awb_task.limits & 65535u, high = awb_task.limits >> 16;
    return gain < low ? low : (gain > high ? high : gain);
}

/* Spatial calibration is immutable during each job. Correct the nine neutral
 * patch sums by their calibrated gains before estimating the illuminant.
 * This avoids a second per-pixel multiplier bank in the FPGA video path. */
static void awb_spatial_auto_step(void)
{
    if (awb_task.phase == 0) {
        uint32_t off = AWB_BASE + 128 + awb_task.index * 16;
        uint32_t r = mcu_read(off), b = mcu_read(off + 8);
        uint32_t base = mcu_read(AWB_BASE + 0x140u + awb_task.index * 4);
        awb_task.corrected_r += (uint32_t)(((uint64_t)r * (base & 65535u)) >> 12);
        awb_task.corrected_b += (uint32_t)(((uint64_t)b * (base >> 16)) >> 12);
        if (++awb_task.index == 9) { awb_task.phase = 1; awb_task.blue = 0; }
        return;
    }
    if (awb_task.phase == 1) {
        uint32_t old = awb_task.blue ? awb_task.previous >> 16 : awb_task.previous & 65535u;
        uint32_t target = mcu_awb_gain(awb_task.g, awb_task.blue ? awb_task.corrected_b : awb_task.corrected_r,
                                       old, awb_task.limits, 0);
        uint32_t gain = awb_track(target, old);
        if (!awb_task.blue) { awb_task.global_red = gain; awb_task.blue = 1; return; }
        awb_task.global_blue = gain;awb_task.phase = 2;awb_task.index = 0;
        return;
    }
    uint32_t base = mcu_read(AWB_BASE + 0x140u + awb_task.index * 4);
    uint32_t r = awb_compose(base & 65535u, awb_task.global_red);
    uint32_t b = awb_compose(base >> 16, awb_task.global_blue);
    mcu_write(AWB_BASE + 32 + awb_task.index * 4, r | (b << 16));
    if (++awb_task.index == 9) {
        mcu_write(AWB_BASE + 32 + 9*4, awb_task.global_red | (awb_task.global_blue << 16));
        awb_finish(1);
    }
}

static void awb_step(void)
{
    if (!(mcu_read(AWB_BASE + 4) & 1u)) {
        if (awb_task.active) { awb_task.active = 0; ++mcu_perf.abandoned_jobs; }
        return;
    }
    uint32_t token = mcu_read(AWB_BASE + 8);
    if (!awb_task.active || token != awb_task.token) {
        awb_task.active = 1; awb_task.token = token; awb_task.index = 9; awb_task.blue = 0;
        awb_task.start_cycle = cycle();
        awb_task.limits = mcu_read(AWB_BASE + 12);
        awb_task.counts = mcu_read(AWB_BASE + 16);
        awb_task.config = mcu_read(AWB_BASE + 20);
        if (awb_task.config & 1024u) {
            awb_task.phase = 0;awb_task.index = 0;
            awb_task.corrected_r = 0;awb_task.corrected_b = 0;
            awb_task.g = mcu_read(AWB_BASE + 128 + 9*16 + 4);
            awb_task.count = mcu_read(AWB_BASE + 128 + 9*16 + 12);
            awb_task.previous = mcu_read(AWB_BASE + 32 + 9*4);
            awb_task.deadband = mcu_read(AWB_BASE + 0x48u);
            if (awb_task.count < (awb_task.counts >> 16)) { awb_finish(0); return; }
        }
    }
    if (awb_task.config & 1024u) { awb_spatial_auto_step();return; }
    if (!awb_task.blue) {
        uint32_t off = AWB_BASE + 128 + awb_task.index * 16;
        awb_task.r = mcu_read(off); awb_task.g = mcu_read(off + 4);
        awb_task.b = mcu_read(off + 8); awb_task.count = mcu_read(off + 12);
        awb_task.previous = mcu_read(AWB_BASE + 32 + awb_task.index*4);
    }
    uint32_t minimum = awb_task.index == 9 ? awb_task.counts >> 16 : awb_task.counts & 65535u;
    uint32_t previous = awb_task.blue ? awb_task.previous >> 16 : awb_task.previous & 65535u;
    uint32_t gain;
    if (awb_task.count < minimum) {
        if (awb_task.index == 9 || (awb_task.config & 256u)) { awb_finish(0); return; }
        /* Legacy optional fallback uses the already-smoothed global gain as
         * the target and then applies the local previous-gain smoothing. */
        uint32_t target = awb_task.blue ? awb_task.global_blue : awb_task.global_red;
        int32_t delta = (int32_t)target - (int32_t)previous;
        uint32_t shift = awb_task.config & 255u;
        gain = (uint32_t)((int32_t)previous + (shift >= 17 ? (delta < 0 ? -1 : 0) : (delta >> shift))) & 65535u;
    } else {
        gain = mcu_awb_gain(awb_task.g, awb_task.blue ? awb_task.b : awb_task.r,
                            previous, awb_task.limits, awb_task.config & 255u);
    }
    if (!awb_task.blue) { awb_task.red = gain; awb_task.blue = 1; return; }
    mcu_write(AWB_BASE + 32 + awb_task.index*4, awb_task.red | (gain << 16));
    if (awb_task.index == 9) { awb_task.global_red = awb_task.red; awb_task.global_blue = gain; }
    awb_task.blue = 0;
    /* Config bit 9 selects continuous global AWB: only one R/B pair per job.
     * Leave the ten-group protocol available for legacy firmware tests. */
    if ((awb_task.config & 512u) || awb_task.index == 8) awb_finish(1);
    else awb_task.index = awb_task.index == 9 ? 0 : awb_task.index + 1;
}

void mcu_tasks_step(uint32_t capabilities)
{
    if(capabilities&MCU_CAP_UI)servo_step();
    if (capabilities & MCU_CAP_CNN) {
        cnn_step();
        // Keep the original two-cell slice while AWB is active. Once AWB is
        // idle, amortize outer scheduler/status polling over at most four
        // cells. AE still runs between every pair of cells; no deadlines or
        // bus protocol are relaxed to pay for the per-class display work.
        if (cnn_task.active) { mcu_service_ae();cnn_step(); }
        if (cnn_task.active && !awb_task.active) {
            mcu_service_ae();cnn_step();
            if (cnn_task.active) { mcu_service_ae();cnn_step(); }
        }
    }
    mcu_service_ae();
    if (capabilities & MCU_CAP_AWB) awb_step();
    if (capabilities & MCU_CAP_HIST) { mcu_service_ae();mcu_histogram_step(); }
    if (capabilities & MCU_CAP_UI) { mcu_service_ae();mcu_ui_step(); }
    // Existing CNN/AWB mailboxes have deadlines. Motion freezes its snapshot
    // and yields the whole slice while either higher-priority job is active.
    if ((capabilities & MCU_CAP_MOTION) && !cnn_task.active && !awb_task.active) {
        mcu_service_ae();mcu_motion_step();
    }
}

uint32_t mcu_background_allowed(void)
{
    return !cnn_task.active && !awb_task.active;
}
