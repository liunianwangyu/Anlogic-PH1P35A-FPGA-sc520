#ifndef CNN_TRACKER_H
#define CNN_TRACKER_H
#include <stdint.h>
/* Display-only policy. Numerical/debug/audio and the existing servo filter
 * retain their original inputs. No additional FPGA pipeline or IP is needed. */
typedef struct { int32_t cx,cy,hw,hh; } cnn_geometry;
void cnn_tracker_begin(uint32_t now, uint32_t generation, uint32_t orientation, uint32_t *scratch);
void cnn_tracker_add(uint32_t cell, uint32_t w0, uint32_t w1, uint32_t *scratch);
void cnn_tracker_finish(uint32_t now, uint32_t *scratch, uint32_t cls);
uint32_t cnn_tracker_box(uint32_t cls, cnn_geometry *box);
#endif
