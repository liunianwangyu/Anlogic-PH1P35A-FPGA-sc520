@echo off
rem SC520 v2.6 GUI launcher. Project paths are selected inside the wizard.
setlocal
set PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe
if not exist "%PS%" set PS=powershell.exe
"%PS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0scripts_v26\dataset_wizard.ps1" %*
endlocal
