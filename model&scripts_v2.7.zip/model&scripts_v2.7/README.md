# SC520 v2.6 模型、训练与部署包

本目录是 v2.6 边缘密度模型的完整训练与部署包。原始 v2.4-8
模型及烧录文件的逐字节副本保存在 `baseline_v2.4-8/`，用于回退。

## 快速入口

双击：

```text
run_dataset_wizard.cmd
```

这是本版本的 GUI 入口。实际脚本位于 `scripts_v26/`，不会调用旧
`scripts/` 中的训练或部署入口。

## 当前模型

- 模型：`dataset1027_edge80_v1`
- 输入：`R,G,B,EDGE_DENSITY`
- 形状：`1x4x90x160 -> 1x8x12x20`
- 边缘密度：板端 Gaussian + 鲁棒中值 Sobel，阈值80，8x8 命中密度
- 推荐显示门限：`131`
- QAT：已完成
- S05 验证显示 AP50：`0.7502`
- S05 验证显示 F1：`0.8313`
- S01 锁定测试：尚未运行
- 实板验收：尚未执行

模型文件、量化参数和部署清单位于 `model/`、`weights/`、`quant/` 和
`deploy/`。

## GUI 使用

1. 在“工程本体目录”选择目标工程；路径可以位于任意盘符。
2. 如需训练，第 3 步可选择第四通道 `density` 或旧模型兼容的 `zero`，
   并设置边缘阈值。默认值为 `density / 80`。
3. 仅部署时勾选“仅部署模型”或点击“直接部署”。
4. 第 4 步选择模型目录、目标工程、部署门限和部署动作。
5. 使用“检查模型包”先做 dry-run，再执行部署。

GUI 会自动读取模型门限、边缘模式和 BIT/BIN 时间。只有输入通道契约一致
的工程才允许安装。

## 重要兼容性

当前 `lab_integrated_sc520_720p_v2.6-5` 基线工程仍使用：

```text
R,G,B,PAD
```

本模型使用：

```text
R,G,B,EDGE_DENSITY
```

因此不能直接把本模型安装到未更新的 v2.6-5 基线。部署工具会在写入前
拒绝该操作。目标工程必须先具备第四通道边缘生成和对应的 RTL 数据通路。
详细说明见 `DEPLOYMENT_COMPATIBILITY_V2.6.md`。

## 训练

训练脚本入口：

```text
scripts_v26/train_cnn.py
```

边缘特征实现：

```text
scripts_v26/edge_feature.py
```

训练配置：

```text
scripts_v26/configs/edge_training_v2.6.json
```

契约：

```text
scripts_v26/configs/cnn_contract.edge.json
```

GUI 自动训练、评估、阈值扫描和部署说明见
`scripts_v26/README_dataset_wizard_v2.6.txt`。

## 回退

不要覆盖 `baseline_v2.4-8/`。如需回到旧运行时，使用该目录内的模型、
量化参数、BIT 和 BIN，并保持 BIT/BIN 配套更新。
