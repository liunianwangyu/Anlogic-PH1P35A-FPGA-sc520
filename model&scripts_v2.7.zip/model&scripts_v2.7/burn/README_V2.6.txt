SC520 v2.6 programming files are not generated yet.

The trained edge-density model exists, but the target RTL must provide the
matching EDGE_DENSITY fourth channel before a valid BIT/BIN pair can be built.

The old v2.4-8 BIT/BIN files were moved to:

    ..\burn_v2.4-8_LEGACY\

They are preserved for rollback and must not be paired with the v2.6 edge
weights in this package.

After deploying to an edge-capable v2.6 project, use:

    scripts_v26\deploy_cnn.ps1 -Out ".." -ProjectRoot "<project-root>" `
      -Python "<python.exe>" -Pnr -Threshold 131

That command writes the new burn artifacts into this directory.
