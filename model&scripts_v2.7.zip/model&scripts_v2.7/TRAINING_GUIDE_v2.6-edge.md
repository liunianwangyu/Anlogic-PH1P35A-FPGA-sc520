# SC520 v2.6 edge-density training guide

## Environment

- Python 3.10 or newer
- PyTorch with CUDA for normal training
- Numpy and Pillow
- ONNX when `--export-onnx` is requested

The GUI can store a machine-specific Python path. If it is blank, the wizard
checks `PYTHON_EXE`, PATH and common installation paths.

## Dataset

The existing dataset and frozen split are supported. No edge images or edge
annotations are needed. Edge density is generated online from the final
augmented 1280x720 RGB frame.

## GUI training

Open the package root launcher:

```text
run_dataset_wizard.cmd
```

On page 3:

- fourth channel: `density`
- edge threshold: `80`
- QAT epochs: nonzero
- fixed split manifest: select the dataset's frozen `split_manifest.json`

If the selected project contract is still `R,G,B,PAD`, the GUI automatically
uses `scripts_v26/configs/cnn_contract.edge.json` for edge training.

## Command-line training

```powershell
python .\scripts_v26\train_cnn.py `
  --data "<dataset-root>" `
  --contract ".\scripts_v26\configs\cnn_contract.edge.json" `
  --out "<new-run-directory>" `
  --edge-mode density `
  --edge-threshold 80 `
  --classes 2 `
  --device cuda `
  --qat on
```

For fine-tuning from an edge checkpoint, use `--init-from` and do not pass
`--zero-edge-init`. That option is only for starting edge training from a
non-edge baseline.

## Deployment condition

An edge-density model requires target RTL that generates the matching
`EDGE_DENSITY` fourth channel. The deployment tool checks this before writing
weights and refuses a PAD baseline.
