# model&scripts_v2.4-8

- Added the dataset1027 grayscale-augmented, empty-weighted model.
- Added frozen train/validation/test manifests and evaluation reports.
- Added training, calibration, quantization, and deployment scripts.
- Restored the four-step WinForms dataset/training GUI for v2.4-8.
- Deployment page now follows recent model outputs, refreshes weight/BIT/BIN and threshold state immediately, and forwards the selected threshold to the existing `deploy_cnn.ps1` entry point.
- Current FPGA BIT and MCU BIN are packaged under `burn/`; physical-board acceptance remains not run.
