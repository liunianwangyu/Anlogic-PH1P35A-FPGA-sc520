SC520 v2.6 CNN training and deployment wizard
================================================

Start
-----
Use the package-level launcher:

    ..\run_dataset_wizard.cmd

Do not use the legacy scripts\ launcher. The v2.6 implementation lives in
scripts_v26\.

Paths
-----
All project and dataset paths are selected in the GUI. They do not need to
match the paths used by the training machine.

The optional Python path can be entered on page 1. If left blank, PYTHON_EXE,
PATH and common installation locations are checked.

Training
--------
Page 3 includes:

- edge mode: density or zero
- edge threshold: default 80
- fixed split manifest
- normal training and QAT parameters

When density mode is selected and the chosen project still uses a PAD
contract, training automatically uses:

    scripts_v26\configs\cnn_contract.edge.json

Deployment
----------
Page 4 reads the model's edge mode and edge threshold from the deployment
manifest. It displays both model and target-project compatibility.

An EDGE_DENSITY model must be installed only into an edge-capable project
using the same layer geometry. The unchanged v2.6-5 PAD baseline is rejected
and must not be forced.

Before deployment:

1. Select the full model package directory.
2. Select the target project root that contains td_project\ and user_source\.
3. Use "检查模型包" for a dry-run.
4. Choose install, verification, or BIT rebuild.

Package check
-------------
Run:

    powershell.exe -NoProfile -ExecutionPolicy Bypass `
      -File .\scripts_v26\verify_package.ps1

To verify a target project:

    powershell.exe -NoProfile -ExecutionPolicy Bypass `
      -File .\scripts_v26\verify_package.ps1 `
      -TargetProject "<project-root>" `
      -PythonExe "<python.exe>"
