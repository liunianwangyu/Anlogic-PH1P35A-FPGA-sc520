param(
    [string]$TargetProject = '',
    [string]$PythonExe = ''
)

$ErrorActionPreference = 'Stop'
$ScriptsRoot = $PSScriptRoot
$PackageRoot = Split-Path -Parent $ScriptsRoot
$checks = [System.Collections.Generic.List[object]]::new()

function Add-Check([string]$Name, [bool]$Ok, [string]$Detail = '') {
    $checks.Add([pscustomobject]@{
        Check = $Name
        Status = if ($Ok) { 'PASS' } else { 'FAIL' }
        Detail = $Detail
    })
}

$required = @(
    'run_dataset_wizard.cmd',
    'verify_package.cmd',
    'README_V2.6.md',
    'DEPLOYMENT_GUIDE_V2.6.md',
    'DEPLOYMENT_COMPATIBILITY_V2.6.md',
    'TRAINING_GUIDE_v2.6-edge.md',
    'VERSION',
    'VERSION.json',
    'PACKAGE_INFO.json',
    'deployment_manifest.json',
    'SHA256SUMS.txt',
    'model\model.pt',
    'model\model.onnx',
    'weights\cnn_weights.dat',
    'quant\quant_params.entries.json',
    'deploy\deploy_manifest.json',
    'deploy\cnn_contract.bundle.json',
    'deploy\cnn_weights.dat',
    'deploy\quant_params.entries.json',
    'model_card.json',
    'meta.json',
    'burn\README_V2.6.txt',
    'scripts_v26\dataset_wizard.ps1',
    'scripts_v26\train_cnn.py',
    'scripts_v26\edge_feature.py',
    'scripts_v26\configs\cnn_contract.edge.json',
    'scripts_v26\configs\edge_training_v2.6.json',
    'scripts_v26\deploy_cnn.ps1',
    'scripts_v26\deploy_model_bundle.py'
)
foreach ($rel in $required) {
    Add-Check ("required: " + $rel) (Test-Path -LiteralPath (Join-Path $PackageRoot $rel) -PathType Leaf)
}

$manifestPath = Join-Path $PackageRoot 'deploy\deploy_manifest.json'
if (Test-Path -LiteralPath $manifestPath) {
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($pair in @(
        @('cnn_weights.dat', $manifest.weights_sha256),
        @('quant_params.entries.json', $manifest.qparams_sha256),
        @('cnn_contract.bundle.json', $manifest.contract_file_sha256)
    )) {
        $p = Join-Path (Join-Path $PackageRoot 'deploy') $pair[0]
        $actual = if (Test-Path -LiteralPath $p) {
            (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()
        } else { '' }
        Add-Check ("sha256: deploy\" + $pair[0]) ($actual -eq [string]$pair[1]) $actual
    }

    Add-Check 'model edge mode' ($manifest.training.edge_mode -eq 'density')
    Add-Check 'model edge threshold 80' (
        [int]$manifest.training.edge_feature.edge_threshold -eq 80)
    $contractPath = Join-Path $PackageRoot 'deploy\cnn_contract.bundle.json'
    if (Test-Path -LiteralPath $contractPath) {
        $contract = Get-Content -LiteralPath $contractPath -Raw -Encoding UTF8 |
            ConvertFrom-Json
        Add-Check 'model input channels' (
            (@($contract.input_frame.channel_order) -join ',') -eq
            'R,G,B,EDGE_DENSITY')
    }
}

$configPath = Join-Path $ScriptsRoot 'dataset_wizard.config.json'
if (Test-Path -LiteralPath $configPath) {
    $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Add-Check 'GUI edge mode default' ($cfg.EdgeMode -eq 'density')
    Add-Check 'GUI edge threshold default' ([int]$cfg.EdgeThreshold -eq 80)
    Add-Check 'GUI deploy threshold default' ([int]$cfg.Threshold -eq 131)
}

$ps = Get-Command powershell.exe -ErrorAction SilentlyContinue
if (-not $ps) { $ps = Get-Command pwsh.exe -ErrorAction SilentlyContinue }
if ($ps) {
    $gui = Join-Path $ScriptsRoot 'dataset_wizard.ps1'
    $output = & $ps.Source -NoProfile -ExecutionPolicy Bypass -STA -File $gui -SelfTest 2>&1
    $exitCode = $LASTEXITCODE
    $text = ($output | Out-String)
    Add-Check 'GUI selftest' ($exitCode -eq 0 -and $text -match 'SELFTEST PASS') `
        ("exit=$exitCode")
} else {
    Add-Check 'PowerShell available' $false
}

if ($TargetProject) {
    if (-not $PythonExe) {
        $PythonExe = if ($env:PYTHON_EXE) { $env:PYTHON_EXE } else { 'python.exe' }
    }
    $deploy = Join-Path $ScriptsRoot 'deploy_model_bundle.py'
    $output = & $PythonExe $deploy --bundle $PackageRoot --project $TargetProject --dry-run 2>&1
    $exitCode = $LASTEXITCODE
    Add-Check 'target contract compatibility' ($exitCode -eq 0) `
        (($output | Out-String).Trim())
}

$checks | Format-Table -AutoSize | Out-String -Width 240
$failed = @($checks | Where-Object Status -eq 'FAIL')
if ($failed.Count -ne 0) {
    Write-Host ("PACKAGE CHECK FAIL: {0} failure(s)" -f $failed.Count)
    exit 2
}
Write-Host 'PACKAGE CHECK PASS'
exit 0
