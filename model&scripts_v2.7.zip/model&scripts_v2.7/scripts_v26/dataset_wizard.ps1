﻿param(
    [switch]$SelfTest
)

$script:SelfTestMode = [bool]$SelfTest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:RootResolver = Join-Path $PSScriptRoot 'resolve_project_root.ps1'
$script:CoreScript = Join-Path $PSScriptRoot 'dataset_core.ps1'
$script:ImportScript = Join-Path $PSScriptRoot 'import_xanylabeling.ps1'
$script:TrainScript = Join-Path $PSScriptRoot 'train_cnn.py'
$script:DeployScript = Join-Path $PSScriptRoot 'deploy_cnn.ps1'
$script:DeployBundleScript = Join-Path $PSScriptRoot 'deploy_model_bundle.py'
$script:ConfigPath = Join-Path $PSScriptRoot 'dataset_wizard.config.json'

. (Join-Path $PSScriptRoot 'find_tool.ps1')
. $script:CoreScript

$script:Step = 1
$script:Busy = $false
$script:DeployOnly = $false
$script:CancelRequested = $false
$script:CurrentProcess = $null
$script:LastRunDir = ''
$script:LogBox = $null
$script:PagePanel = $null
$script:NavPrev = $null
$script:NavNext = $null
$script:NavCancel = $null
$script:NavDeploy = $null
$script:UI = @{}
$script:Pages = @{}
$script:AllButtons = @()
$script:Form = $null
$script:Root = ''

function Log([string]$text) {
    $line = [string]$text
    Write-Host $line
    if ($script:LogBox) {
        $script:LogBox.AppendText($line + [Environment]::NewLine)
        $script:LogBox.SelectionStart = $script:LogBox.TextLength
        $script:LogBox.ScrollToCaret()
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Clear-Log {
    if ($script:LogBox) { $script:LogBox.Clear() }
}

function Get-DefaultConfig {
    return [ordered]@{
        ProjectRoot = ''
        ContractPath = ''
        DatasetRoot = ''
        RawDir = ''
        RunsRoot = ''
        ModelDir = ''
        Tag = 'starve'
        Epochs = 120
        Batch = 16
        Classes = 2
        ValRatio = 0.2
        ClassMap = 'starve=0,genshin=1'
        ExportOnnx = $true
        LearningRate = 0.0003
        BoxWeight = 2.0
        GrayscaleProb = 0.2
        EmptyWeight = 3.0
        QATEpochs = 40
        QATLearningRate = 0.0001
        SplitManifest = ''
        AutoLatestModel = $true
        Threshold = 131
        EdgeMode = 'density'
        EdgeThreshold = 80
        PythonExe = ''
    }
}

function Load-Config {
    $d = Get-DefaultConfig
    $datasetChanged = $false
    $projectChanged = $false
    if (Test-Path -LiteralPath $script:ConfigPath) {
        try {
            $j = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @($d.Keys)) {
                if ($null -ne $j.$k) { $d[$k] = $j.$k }
            }
        } catch { }
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$d.ProjectRoot)) {
        $resolvedProject = Resolve-ProjectRoot ([string]$d.ProjectRoot)
        if ($resolvedProject) {
            $d.ProjectRoot = $resolvedProject
        } else {
            $d.ProjectRoot = ''
            $projectChanged = $true
        }
    }
    if ([string]::IsNullOrWhiteSpace([string]$d.ProjectRoot)) {
        try {
            $auto = & $script:RootResolver
            if ($auto -and (Test-Path -LiteralPath $auto)) {
                $d.ProjectRoot = [string]$auto
                $projectChanged = $true
            }
        } catch { }
    }
    if ([string]::IsNullOrWhiteSpace([string]$d.DatasetRoot) -or
        -not (Test-DatasetRoot ([string]$d.DatasetRoot))) {
        $candidate = Join-Path (Split-Path -Parent $PSScriptRoot) 'datasets\starve&genshin'
        if (Test-Path -LiteralPath $candidate) {
            $d.DatasetRoot = $candidate
            $datasetChanged = $true
        }
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$d.ProjectRoot)) {
        $defaultContract = Join-Path $d.ProjectRoot 'user_source\hdl_source\cnn\cnn_contract.json'
        if ($projectChanged -or [string]::IsNullOrWhiteSpace([string]$d.ContractPath) -or
            -not (Test-Path -LiteralPath ([string]$d.ContractPath))) {
            $d.ContractPath = $defaultContract
        }
    }
    if ((-not [string]::IsNullOrWhiteSpace([string]$d.DatasetRoot)) -and
        ($datasetChanged -or [string]::IsNullOrWhiteSpace([string]$d.RunsRoot))) {
        $d.RunsRoot = Join-Path $d.DatasetRoot 'runs'
    }
    if ($datasetChanged) { $d.RawDir = '' }
    if ($d.RawDir -and -not (Test-Path -LiteralPath ([string]$d.RawDir) -PathType Container)) {
        $d.RawDir = ''
    }
    if ($d.ModelDir -and -not (Test-Path -LiteralPath ([string]$d.ModelDir))) {
        $d.ModelDir = ''
    }
    $d.Classes = [Math]::Max(1, [Math]::Min(3, [int]$d.Classes))
    $d.LearningRate = [Math]::Max(0.000001, [double]$d.LearningRate)
    $d.BoxWeight = [Math]::Max(0.0, [double]$d.BoxWeight)
    $d.GrayscaleProb = [Math]::Max(0.0, [Math]::Min(1.0, [double]$d.GrayscaleProb))
    $d.EmptyWeight = [Math]::Max(1.0, [double]$d.EmptyWeight)
    $d.QATEpochs = [Math]::Max(0, [int]$d.QATEpochs)
    $d.QATLearningRate = [Math]::Max(0.000001, [double]$d.QATLearningRate)
    $d.Threshold = [Math]::Max(0, [Math]::Min(255, [int]$d.Threshold))
    if ([string]$d.EdgeMode -notin @('density', 'zero')) { $d.EdgeMode = 'density' }
    $d.EdgeThreshold = [Math]::Max(0, [Math]::Min(4095, [int]$d.EdgeThreshold))
    if ($d.PythonExe -and -not (Test-Path -LiteralPath ([string]$d.PythonExe) -PathType Leaf)) {
        $d.PythonExe = ''
    }
    $d.AutoLatestModel = [bool]$d.AutoLatestModel
    if (-not (Validate-ClassMap ([string]$d.ClassMap) ([int]$d.Classes))) {
        $names = @('starve', 'genshin', 'class_2')
        $parts = @()
        for ($i = 0; $i -lt [int]$d.Classes; $i++) { $parts += ($names[$i] + '=' + $i) }
        $d.ClassMap = ($parts -join ',')
    }
    if ([string]::IsNullOrWhiteSpace([string]$d.Tag)) { $d.Tag = 'starve' }
    if (([string]$d.Tag -eq 'bear') -and ([string]$d.DatasetRoot -match 'starve')) {
        $d.Tag = 'starve'
    }
    return $d
}

function Save-Config {
    if ($script:SelfTestMode) { return }
    try {
        $script:Cfg | ConvertTo-Json -Depth 4 |
            Set-Content -LiteralPath $script:ConfigPath -Encoding UTF8
    } catch { }
}

function Quote-Arg([string]$s) {
    if ($s -match '[\s"]') {
        return '"' + ($s -replace '"', '\"') + '"'
    }
    return $s
}

function Get-ChildEncoding([string]$exe) {
    $name = [System.IO.Path]::GetFileName($exe).ToLowerInvariant()
    if ($name -like 'python*') { return [System.Text.Encoding]::UTF8 }
    try {
        return [System.Text.Encoding]::GetEncoding(
            [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage)
    } catch {
        return [System.Text.Encoding]::Default
    }
}

function Invoke-Stream([string]$exe, [string[]]$argv, [string]$workDir) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = (($argv | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.WorkingDirectory = $workDir
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $enc = Get-ChildEncoding $exe
    try {
        $psi.StandardOutputEncoding = $enc
        $psi.StandardErrorEncoding = $enc
    } catch { }
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    try { [void]$p.Start() }
    catch { return @{ Code = -1; Text = ('无法启动 ' + $exe + ': ' + $_.Exception.Message) } }
    $script:CurrentProcess = $p
    $script:CancelRequested = $false
    $sb = New-Object System.Text.StringBuilder
    $to = $p.StandardOutput.ReadLineAsync()
    $te = $p.StandardError.ReadLineAsync()
    while (-not ($p.HasExited -and $null -eq $to -and $null -eq $te)) {
        for ($i = 0; $i -lt 200; $i++) {
            $got = $false
            if ($to -and $to.IsCompleted) {
                $line = $to.Result
                if ($null -eq $line) { $to = $null }
                else {
                    [void]$sb.AppendLine($line)
                    Log ('  ' + $line)
                    $to = $p.StandardOutput.ReadLineAsync()
                    $got = $true
                }
            }
            if ($te -and $te.IsCompleted) {
                $line = $te.Result
                if ($null -eq $line) { $te = $null }
                else {
                    [void]$sb.AppendLine($line)
                    Log ('  ! ' + $line)
                    $te = $p.StandardError.ReadLineAsync()
                    $got = $true
                }
            }
            if (-not $got) { break }
        }
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 30
    }
    [void]$p.WaitForExit()
    $code = $p.ExitCode
    if ($script:CancelRequested) { $code = -2 }
    $script:CurrentProcess = $null
    return @{ Code = $code; Text = $sb.ToString(); Cancelled = [bool]$script:CancelRequested }
}

function Resolve-Python {
    if ($script:Cfg.PythonExe -and
        (Test-Path -LiteralPath ([string]$script:Cfg.PythonExe) -PathType Leaf)) {
        return (Resolve-Path -LiteralPath ([string]$script:Cfg.PythonExe)).Path
    }
    return Find-Tool -Name 'python.exe' -EnvVar 'PYTHON_EXE' -Candidates @(
        'D:\开发环境\miniconda3\envs\roi_video\python.exe',
        'D:\开发环境\miniconda3\python.exe',
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
        'C:\Python312\python.exe'
    )
}

function Resolve-ProjectRoot([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $null }
    $r = & $script:RootResolver -Explicit $path
    if ($r -and (Test-Path -LiteralPath $r)) { return $r }
    return $null
}

function Get-DataSummary([string]$root) {
    $imgDir = Join-Path $root 'images'
    $labDir = Join-Path $root 'labels'
    $images = @(Get-ChildItem -LiteralPath $imgDir -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' })
    $native = @(Get-ChildItem -LiteralPath $imgDir -File -Filter '*.json' -ErrorAction SilentlyContinue)
    $labels = @(Get-ChildItem -LiteralPath $labDir -File -Filter '*.json' -ErrorAction SilentlyContinue)
    $pos = 0; $empty = 0; $missing = 0
    foreach ($im in $images) {
        $lp = Join-Path $labDir ($im.BaseName + '.json')
        if (-not (Test-Path -LiteralPath $lp)) { $missing++; continue }
        try {
            $j = Get-Content -LiteralPath $lp -Raw -Encoding UTF8 | ConvertFrom-Json
            if (@($j.boxes).Count -gt 0) { $pos++ } else { $empty++ }
        } catch { $missing++ }
    }
    return [pscustomobject]@{
        Images = $images.Count
        NativeJson = $native.Count
        Labels = $labels.Count
        Positive = $pos
        Empty = $empty
        MissingLabels = $missing
    }
}

function Write-DatasetYaml([string]$root, [int]$classes, [string]$classMap) {
    $names = @{}
    foreach ($part in ($classMap -split ',')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $kv = $part.Split('=')
        if ($kv.Count -eq 2) {
            $names[[int]$kv[1].Trim()] = $kv[0].Trim()
        }
    }
    $lines = @("nc: $classes", 'names:')
    for ($i = 0; $i -lt $classes; $i++) {
        $name = if ($names.ContainsKey($i)) { $names[$i] } else { "class_$i" }
        $lines += "  ${i}: $name"
    }
    Set-Content -LiteralPath (Join-Path $root 'dataset.yaml') -Value $lines -Encoding UTF8
}

function Validate-ClassMap([string]$classMap, [int]$classes) {
    if ([string]::IsNullOrWhiteSpace($classMap)) { return $false }
    $seen = @{}
    $count = 0
    foreach ($part in ($classMap -split ',')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $kv = $part.Split('=')
        if ($kv.Count -ne 2) { return $false }
        $id = 0
        if (-not [int]::TryParse($kv[1].Trim(), [ref]$id)) { return $false }
        if ($id -lt 0 -or $id -ge $classes -or $seen.ContainsKey($id)) { return $false }
        $seen[$id] = $true
        $count++
    }
    return ($count -eq $classes)
}

function Build-ClassMapFromAssignments {
    param(
        [object[]]$Assignments,
        [int]$Classes
    )
    $used = @{}
    $pairs = New-Object System.Collections.Generic.List[object]
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($a in @($Assignments)) {
        $label = [string]$a.Label
        if ([string]::IsNullOrWhiteSpace($label)) { continue }
        if ($null -eq $a.ClassId -or [string]::IsNullOrWhiteSpace([string]$a.ClassId)) {
            $errors.Add(("标签 '{0}' 尚未选择类别号" -f $label))
            continue
        }
        $id = 0
        if (-not [int]::TryParse([string]$a.ClassId, [ref]$id)) {
            $errors.Add(("标签 '{0}' 的类别号不是整数" -f $label))
            continue
        }
        if ($id -lt 0 -or $id -ge $Classes) {
            $errors.Add(("标签 '{0}' 的类别号 {1} 超出 0..{2}" -f $label, $id, ($Classes - 1)))
            continue
        }
        if ($used.ContainsKey($id)) {
            $errors.Add(("类别号 {0} 同时分给了 '{1}' 和 '{2}'" -f $id, $used[$id], $label))
            continue
        }
        $used[$id] = $label
        $pairs.Add([pscustomobject]@{ Label = $label; ClassId = $id })
    }
    for ($i = 0; $i -lt $Classes; $i++) {
        if (-not $used.ContainsKey($i)) {
            $errors.Add(("类别号 {0} 还没有分配标签名" -f $i))
        }
    }
    $map = ''
    if ($errors.Count -eq 0) {
        $map = (@($pairs | Sort-Object ClassId | ForEach-Object {
            ('{0}={1}' -f $_.Label, $_.ClassId)
        }) -join ',')
    }
    return [pscustomobject]@{
        Map = $map
        Errors = $errors.ToArray()
    }
}

function Update-MappingClassChoices {
    if (-not $script:UI.MappingGrid -or -not $script:UI.Classes) { return }
    $grid = $script:UI.MappingGrid
    $classes = [int]$script:UI.Classes.Value
    if ($grid.Columns.Count -lt 3) { return }
    $col = $grid.Columns[2]
    $col.Items.Clear()
    for ($i = 0; $i -lt $classes; $i++) { [void]$col.Items.Add([string]$i) }
    foreach ($row in $grid.Rows) {
        if ($row.IsNewRow) { continue }
        $v = [string]$row.Cells[2].Value
        $id = -1
        if (-not [int]::TryParse($v, [ref]$id) -or $id -lt 0 -or $id -ge $classes) {
            $row.Cells[2].Value = $null
            $row.Cells[3].Value = '请选择类别号'
        }
    }
}

function Get-MappingGridAssignments {
    $rows = New-Object System.Collections.Generic.List[object]
    if (-not $script:UI.MappingGrid) { return $rows.ToArray() }
    foreach ($row in $script:UI.MappingGrid.Rows) {
        if ($row.IsNewRow) { continue }
        $label = [string]$row.Cells[0].Value
        if ([string]::IsNullOrWhiteSpace($label)) { continue }
        $rows.Add([pscustomobject]@{
            Label = $label
            Count = [string]$row.Cells[1].Value
            ClassId = [string]$row.Cells[2].Value
            Status = [string]$row.Cells[3].Value
        })
    }
    return $rows.ToArray()
}

function Update-MappingPreview {
    if (-not $script:UI.MappingGrid) { return $false }
    $classes = if ($script:UI.Classes) { [int]$script:UI.Classes.Value } else { [int]$script:Cfg.Classes }
    $assignments = @(Get-MappingGridAssignments)
    $built = Build-ClassMapFromAssignments $assignments $classes
    foreach ($row in $script:UI.MappingGrid.Rows) {
        if ($row.IsNewRow) { continue }
        $label = [string]$row.Cells[0].Value
        $id = [string]$row.Cells[2].Value
        if ([string]::IsNullOrWhiteSpace($id)) {
            $row.Cells[3].Value = '未分配'
        } elseif ($built.Errors.Count -eq 0) {
            $row.Cells[3].Value = '已映射'
        } else {
            $row.Cells[3].Value = '请检查映射'
        }
    }
    if ($script:UI.ClassMap) { $script:UI.ClassMap.Text = $built.Map }
    if ($script:UI.MappingSummary) {
        if ($built.Errors.Count -eq 0) {
            $script:UI.MappingSummary.Text = '将使用映射：' + $built.Map
            $script:UI.MappingSummary.ForeColor = [System.Drawing.Color]::FromArgb(35, 110, 70)
        } else {
            $script:UI.MappingSummary.Text = '映射未完成：' + ($built.Errors -join '；')
            $script:UI.MappingSummary.ForeColor = [System.Drawing.Color]::Firebrick
        }
    }
    return ($built.Errors.Count -eq 0)
}

function Scan-LabelMapping {
    Sync-UiToConfig
    if (-not (Test-DatasetRoot $script:Cfg.DatasetRoot)) {
        Log '!! 数据集根无效，先完成第 1 步。'
        return $false
    }
    $classes = if ($script:UI.Classes) { [int]$script:UI.Classes.Value } else { [int]$script:Cfg.Classes }
    if ($classes -lt 1 -or $classes -gt 3) {
        Log '!! 类别数必须在 1..3。'
        return $false
    }
    Log '=== 扫描 X-AnyLabeling 标签名并生成映射 ==='
    $n = Get-NativeLabelSummary $script:Cfg.DatasetRoot
    if ($n.LabelCounts.Count -eq 0) {
        Log '!! 原生 JSON 中没有找到任何 shapes[].label。'
        Log '   如果当前只有空场景，仍需要至少一份有目标标注才能建立类别映射。'
        return $false
    }
    $neededClasses = [int]$n.LabelCounts.Count
    if ($neededClasses -gt 3) {
        Log ('!! 检测到 {0} 个不同标签，但网络契约最多支持 3 类。' -f $neededClasses)
        return $false
    }
    if ($neededClasses -gt $classes) {
        $classes = $neededClasses
        if ($script:UI.Classes) { $script:UI.Classes.Value = [decimal]$classes }
        Log ('  检测到 {0} 个标签，已自动把类别数调整为 {0}。' -f $classes)
    }

    $prior = @{}
    foreach ($a in @(Get-MappingGridAssignments)) {
        $id = -1
        if ([int]::TryParse([string]$a.ClassId, [ref]$id) -and $id -ge 0 -and $id -lt $classes) {
            $prior[[string]$a.Label] = $id
        }
    }
    if ($prior.Count -eq 0) {
        foreach ($kv in (Get-ClassMapTable ([string]$script:Cfg.ClassMap)).GetEnumerator()) {
            if ([int]$kv.Value -ge 0 -and [int]$kv.Value -lt $classes) { $prior[[string]$kv.Key] = [int]$kv.Value }
        }
    }

    $labels = @($n.LabelCounts.GetEnumerator() |
        Sort-Object @{ Expression = { [int]$_.Value }; Descending = $true },
                    @{ Expression = { [string]$_.Key }; Descending = $false } |
        ForEach-Object { [string]$_.Key })
    $assigned = @{}
    $selected = @{}
    foreach ($label in $labels) {
        if ($prior.ContainsKey([string]$label) -and -not $assigned.ContainsKey([int]$prior[[string]$label])) {
            $id = [int]$prior[[string]$label]
            $assigned[$id] = [string]$label
            $selected[[string]$label] = $id
        }
    }
    $known = @{ starve = 0; genshin = 1 }
    foreach ($label in $labels) {
        if ($selected.ContainsKey([string]$label)) { continue }
        if ($known.ContainsKey([string]$label)) {
            $id = [int]$known[[string]$label]
            if ($id -lt $classes -and -not $assigned.ContainsKey($id)) {
                $assigned[$id] = [string]$label
                $selected[[string]$label] = $id
            }
        }
    }
    Update-MappingClassChoices
    $grid = $script:UI.MappingGrid
    $grid.Rows.Clear()
    foreach ($label in $labels) {
        $idx = $grid.Rows.Add()
        $row = $grid.Rows[$idx]
        $row.Cells[0].Value = [string]$label
        $row.Cells[1].Value = [string]$n.LabelCounts[$label]
        if ($selected.ContainsKey([string]$label)) {
            $row.Cells[2].Value = [string]$selected[[string]$label]
            $row.Cells[3].Value = '已映射'
        } else {
            $row.Cells[2].Value = $null
            $row.Cells[3].Value = '未自动分配，请手动选择'
        }
        Log ("  标签 '{0}'：{1} 个框 -> 类别 {2}" -f $label, $n.LabelCounts[$label],
             $(if ($selected.ContainsKey([string]$label)) { $selected[[string]$label] } else { '<未分配>' }))
    }
    $ok = Update-MappingPreview
    if ($ok) {
        $script:Cfg.ClassMap = [string]$script:UI.ClassMap.Text
        Log ('  OK：GUI 映射已生成: ' + $script:Cfg.ClassMap)
        if (-not $SelfTest) { Save-Config }
    } else {
        Log '!! 映射未完成，请在下方表格中为每个标签选择类别号。'
    }
    return $ok
}

function Ensure-LabelMappingFromGui {
    Sync-UiToConfig
    if (-not (Test-DatasetRoot $script:Cfg.DatasetRoot)) {
        Log '!! 数据集根无效，先完成第 1 步。'
        return $false
    }
    if (-not $script:UI.MappingGrid -or $script:UI.MappingGrid.Rows.Count -eq 0) {
        if (-not (Scan-LabelMapping)) { return $false }
    }
    $ok = Update-MappingPreview
    if (-not $ok) {
        Log '!! 标签映射还没有完成，请先在上方表格里为每个标签选择类别号。'
        return $false
    }
    $script:Cfg.Classes = [int]$script:UI.Classes.Value
    $script:Cfg.ClassMap = [string]$script:UI.ClassMap.Text
    if (-not (Validate-ClassMap $script:Cfg.ClassMap $script:Cfg.Classes)) {
        Log ('!! 生成的 ClassMap 无效: ' + $script:Cfg.ClassMap)
        return $false
    }
    if (-not $SelfTest) { Save-Config }
    return $true
}

function Get-ClassMapTable([string]$classMap) {
    $map = @{}
    foreach ($part in ($classMap -split ',')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $kv = $part.Split('=')
        if ($kv.Count -eq 2) {
            $id = 0
            if ([int]::TryParse($kv[1].Trim(), [ref]$id)) {
                $map[$kv[0].Trim()] = $id
            }
        }
    }
    return $map
}

function Get-NormalizedFullPath([string]$path, [string]$baseDir) {
    if ([string]::IsNullOrWhiteSpace($path)) { return '' }
    $p = $path.Trim()
    if (-not [System.IO.Path]::IsPathRooted($p)) {
        if ([string]::IsNullOrWhiteSpace($baseDir)) {
            $baseDir = (Get-Location).Path
        }
        $p = Join-Path $baseDir $p
    }
    try { return [System.IO.Path]::GetFullPath($p) } catch { return $p }
}

function Test-DatasetRoot([string]$root) {
    if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) { return $false }
    $img = Join-Path $root 'images'
    if (-not (Test-Path -LiteralPath $img)) { return $false }
    return (@(Get-ChildItem -LiteralPath $img -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' }).Count -gt 0)
}

function Test-VersionDir([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) { return $false }
    $hasBundle = Test-Path -LiteralPath (Join-Path $path 'deploy\deploy_manifest.json')
    $hasWeights = Test-Path -LiteralPath (Join-Path $path 'weights\cnn_weights.dat')
    $hasQuant = Test-Path -LiteralPath (Join-Path $path 'quant\quant_params.entries.json')
    return ($hasBundle -or ($hasWeights -and $hasQuant))
}

function Test-RunsRoot([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $false }
    $full = Get-NormalizedFullPath $path $script:Root
    $leaf = [System.IO.Path]::GetFileName($full.TrimEnd('\', '/'))
    if ($leaf -in @('model', 'weights', 'deploy', 'quant', 'burn', 'scripts', 'images', 'labels')) {
        return $false
    }
    if ((Test-VersionDir $full)) { return $false }
    return $true
}

function Get-LatestVersionDir([string]$runsRoot) {
    if ([string]::IsNullOrWhiteSpace($runsRoot) -or -not (Test-Path -LiteralPath $runsRoot)) {
        return $null
    }
    if (Test-VersionDir $runsRoot) { return (Resolve-Path -LiteralPath $runsRoot).Path }
    $dirs = @(Get-ChildItem -LiteralPath $runsRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-VersionDir $_.FullName } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1)
    if ($dirs.Count -gt 0) { return $dirs[0].FullName }
    return $null
}

function Get-ModelVersionInfo([string]$versionDir) {
    if (-not (Test-VersionDir $versionDir)) { return $null }
    $versionDir = (Resolve-Path -LiteralPath $versionDir).Path
    $modelPt = Join-Path $versionDir 'model\model.pt'
    $weights = Join-Path $versionDir 'weights\cnn_weights.dat'
    if (-not (Test-Path -LiteralPath $weights)) {
        $weights = Join-Path $versionDir 'deploy\cnn_weights.dat'
    }
    $deployStatusPath = Join-Path $versionDir 'burn\deployment_status.json'
    $deployStatus = $null
    if (Test-Path -LiteralPath $deployStatusPath) {
        try {
            $deployStatus = Get-Content -LiteralPath $deployStatusPath -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch { }
    }
    $stampFiles = @(
        foreach ($p in @($modelPt, $weights,
            (Join-Path $versionDir 'model_card.json'),
            (Join-Path $versionDir 'deploy\deploy_manifest.json'),
            (Join-Path $versionDir 'PACKAGE_INFO.json'),
            (Join-Path $versionDir 'burn\camera_to_dsi_display.bit'))) {
            if (Test-Path -LiteralPath $p) { Get-Item -LiteralPath $p }
        }
    )
    $stampFiles += @(Get-ChildItem -LiteralPath (Join-Path $versionDir 'burn') -Filter '*.bin' -File -ErrorAction SilentlyContinue)
    if ($stampFiles.Count -eq 0) { return $null }
    $threshold = $null
    $edgeMode = 'unknown'
    $edgeThreshold = $null
    $manifestPath = Join-Path $versionDir 'deploy\deploy_manifest.json'
    $manifest = $null
    if (Test-Path -LiteralPath $manifestPath) {
        try {
            $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($manifest.training -and $manifest.training.edge_mode) {
                $edgeMode = [string]$manifest.training.edge_mode
            }
            if ($manifest.training -and $manifest.training.edge_feature -and
                $null -ne $manifest.training.edge_feature.edge_threshold) {
                $edgeThreshold = [int]$manifest.training.edge_feature.edge_threshold
            }
        } catch { }
    }
    if ($deployStatus -and $null -ne $deployStatus.deployed_threshold_u8) {
        $threshold = [int]$deployStatus.deployed_threshold_u8
    }
    if ($null -eq $threshold -and $manifest -and $null -ne $manifest.deployed_threshold_u8) {
        $threshold = [int]$manifest.deployed_threshold_u8
    }
    $contractPath = Join-Path $versionDir 'deploy\cnn_contract.bundle.json'
    if (-not (Test-Path -LiteralPath $contractPath)) {
        $contractPath = Join-Path $versionDir 'model\cnn_contract.json'
    }
    if (Test-Path -LiteralPath $contractPath) {
        try {
            $contract = Get-Content -LiteralPath $contractPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($null -eq $threshold -and $null -ne $contract.post.obj_thresh) {
                $threshold = [int]$contract.post.obj_thresh
            }
            if ($edgeMode -eq 'unknown' -and $contract.input_frame.channel_order) {
                $edgeMode = if ([string]$contract.input_frame.channel_order[-1] -eq 'PAD') {
                    'zero'
                } else {
                    'density'
                }
            }
        } catch { }
    }
    if ($null -eq $edgeThreshold -and $edgeMode -eq 'density' -and $manifest -and
        $manifest.training -and $manifest.training.edge_feature) {
        $edgeThreshold = [int]$manifest.training.edge_feature.edge_threshold
    }
    if ($null -eq $edgeThreshold -and $edgeMode -eq 'density') {
        if (Test-Path -LiteralPath $contractPath) {
            try {
                $contract = Get-Content -LiteralPath $contractPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($null -ne $contract.input_frame.edge_feature.edge_threshold) {
                    $edgeThreshold = [int]$contract.input_frame.edge_feature.edge_threshold
                }
            } catch { }
        }
    }
    $weightItem = if (Test-Path -LiteralPath $weights) { Get-Item -LiteralPath $weights } else { $null }
    $bitPath = Join-Path $versionDir 'burn\camera_to_dsi_display.bit'
    $bitItem = if (Test-Path -LiteralPath $bitPath) { Get-Item -LiteralPath $bitPath } else { $null }
    $binItems = @(Get-ChildItem -LiteralPath (Join-Path $versionDir 'burn') -Filter '*.bin' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    $binItem = if ($binItems.Count -gt 0) { $binItems[0] } else { $null }
    $binThreshold = $null
    if ($binItem -and $binItem.Name -match 'thr(\d+)') {
        $binThreshold = [int]$Matches[1]
    }
    $bitCurrent = $false
    if ($bitItem -and $weightItem) {
        $bitCurrent = $bitItem.LastWriteTime -ge $weightItem.LastWriteTime
    }
    $binCurrent = $false
    if ($binItem -and $weightItem) {
        $thresholdMatches = ($null -eq $threshold) -or
            (($null -ne $binThreshold) -and ($binThreshold -eq $threshold))
        $binCurrent = $thresholdMatches -and ($binItem.LastWriteTime -ge $weightItem.LastWriteTime)
    }
    $deployedAt = if ($deployStatus -and $deployStatus.completed_at) {
        [string]$deployStatus.completed_at
    } else {
        ''
    }
    return [pscustomobject]@{
        Path = $versionDir
        Name = Split-Path -Leaf $versionDir
        Updated = ($stampFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
        WeightUpdated = if ($weightItem) { $weightItem.LastWriteTime } else { $null }
        BitUpdated = if ($bitItem) { $bitItem.LastWriteTime } else { $null }
        BinUpdated = if ($binItem) { $binItem.LastWriteTime } else { $null }
        Threshold = $threshold
        EdgeMode = $edgeMode
        EdgeThreshold = $edgeThreshold
        BinThreshold = $binThreshold
        HasBit = $null -ne $bitItem
        HasBin = $null -ne $binItem
        BitCurrent = $bitCurrent
        BinCurrent = $binCurrent
        DeployedAt = $deployedAt
    }
}

function Get-AvailableModelVersions {
    $items = [System.Collections.Generic.List[object]]::new()
    $roots = @()
    if (-not [string]::IsNullOrWhiteSpace([string]$script:Cfg.RunsRoot)) {
        $roots += (Get-NormalizedFullPath $script:Cfg.RunsRoot $script:Root)
    }
    $versionsRoot = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
    if ($versionsRoot) {
        $globalRuns = Join-Path $versionsRoot 'runs'
        if (Test-Path -LiteralPath $globalRuns -PathType Container) {
            $roots += $globalRuns
        }
    }
    $roots += (Split-Path -Parent $PSScriptRoot)
    foreach ($r in @($roots | Select-Object -Unique)) {
        if (-not $r -or -not (Test-Path -LiteralPath $r -PathType Container)) { continue }
        foreach ($d in @(Get-ChildItem -LiteralPath $r -Directory -Recurse -ErrorAction SilentlyContinue)) {
            if (Test-VersionDir $d.FullName) {
                $info = Get-ModelVersionInfo $d.FullName
                if ($info) { $items.Add($info) }
            }
        }
        $top = Get-ModelVersionInfo $r
        if ($top) { $items.Add($top) }
    }
    return @($items | Sort-Object Path -Unique | Sort-Object Updated -Descending)
}

function Update-DeployStatus {
    if (-not $script:UI.DeployStatus) { return }
    $v = Resolve-VersionInput ([string]$script:Cfg.ModelDir) -Quiet
    if (-not $v) {
        if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.ModelDir)) {
            $script:UI.DeployStatus.Text = '请选择训练版本目录，或选择包含多个版本的 runs 目录。'
        } else {
            $script:UI.DeployStatus.Text = '当前路径不是有效模型版本，请刷新或检查模型包。'
        }
        return
    }
    $info = Get-ModelVersionInfo $v
    if ($info) {
        $threshold = if ($null -eq $info.Threshold) { '未标' } else { [string]$info.Threshold }
        $edge = if ($info.EdgeMode -eq 'density') {
            'EDGE@' + $(if ($null -eq $info.EdgeThreshold) { '?' } else { [string]$info.EdgeThreshold })
        } elseif ($info.EdgeMode -eq 'zero') { 'PAD' } else { 'C4未知' }
        $targetThreshold = if ($script:UI.Threshold) { [int]$script:UI.Threshold.Value } else { [int]$script:Cfg.Threshold }
        $bit = if (-not $info.HasBit) { 'BIT未生成' } elseif ($info.BitCurrent) { 'BIT同步' } else { 'BIT早于权重' }
        $binThreshold = if ($null -eq $info.BinThreshold) { '门限未标' } else { 'thr' + $info.BinThreshold }
        $bin = if (-not $info.HasBin) { 'BIN未生成' } elseif ($info.BinCurrent) { 'BIN同步' } else { 'BIN需核对' }
        $targetCompat = '目标工程未选择'
        if ($script:Cfg.ProjectRoot) {
            $targetContractPath = Join-Path $script:Cfg.ProjectRoot 'user_source\hdl_source\cnn\cnn_contract.json'
            if (Test-Path -LiteralPath $targetContractPath -PathType Leaf) {
                try {
                    $targetContract = Get-Content -LiteralPath $targetContractPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    $targetEdge = (@($targetContract.input_frame.channel_order)[-1] -ne 'PAD')
                    $modelEdge = ($info.EdgeMode -eq 'density')
                    $targetCompat = if ($targetEdge -eq $modelEdge) {
                        '目标契约兼容'
                    } else {
                        '目标契约不兼容：模型 ' + $info.EdgeMode +
                        '，工程 ' + $(if ($targetEdge) { 'EDGE_DENSITY' } else { 'PAD' })
                    }
                } catch {
                    $targetCompat = '目标契约读取失败'
                }
            } else {
                $targetCompat = '目标工程缺少 CNN 契约'
            }
        }
        $script:UI.DeployStatus.Text = (
            '模型：{0} | 第四通道：{1} | 权重：{2:yyyy-MM-dd HH:mm:ss} | 包/部署门限：{3}，目标：{4} | {5} {6} | {7}' -f
            $info.Name, $edge, $info.WeightUpdated, $threshold, $targetThreshold, $bit, ($bin + '(' + $binThreshold + ')'), $targetCompat)
    } else {
        $script:UI.DeployStatus.Text = '已识别模型版本：' + $v
    }
}

function Refresh-LatestModelSelection {
    Sync-UiToConfig
    $versions = @(Get-AvailableModelVersions)
    if ($versions.Count -eq 0) {
        Update-DeployStatus
        return
    }
    $latest = $versions[0]
    $current = Resolve-VersionInput ([string]$script:Cfg.ModelDir) -Quiet
    $auto = $true
    if ($script:UI.AutoLatestModel) { $auto = [bool]$script:UI.AutoLatestModel.Checked }
    if ($auto -or -not $current) {
        $script:Cfg.ModelDir = $latest.Path
        if ($script:UI.ModelDir) { $script:UI.ModelDir.Text = $latest.Path }
        Save-Config
    }
    Update-DeployStatus
}

function Get-NextVersionDir([string]$runsRoot, [string]$tag) {
    $safeTag = ($tag -replace '[\\/:*?"<>|]', '_').Trim()
    if ([string]::IsNullOrWhiteSpace($safeTag)) { $safeTag = 'model' }
    New-Item -ItemType Directory -Force -Path $runsRoot | Out-Null
    $n = 0
    Get-ChildItem -LiteralPath $runsRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Name -match '_v(\d+)_') {
            $k = [int]$Matches[1]
            if ($k -gt $n) { $n = $k }
        }
    }
    $n++
    return (Join-Path $runsRoot ('{0}_v{1}_{2}' -f $safeTag, $n, (Get-Date).ToString('yyyyMMdd-HHmmss')))
}

function Resolve-VersionInput([string]$path, [switch]$Quiet) {
    if ([string]::IsNullOrWhiteSpace($path)) {
        if (-not $Quiet) { Log '!! 请选择训练版本目录，或其上一级 runs 目录。' }
        return $null
    }
    $full = Get-NormalizedFullPath $path $script:Root
    if (-not (Test-Path -LiteralPath $full)) {
        if (-not $Quiet) { Log ('!! 路径不存在: ' + $full) }
        return $null
    }
    $leaf = [System.IO.Path]::GetFileName($full.TrimEnd('\', '/'))
    if ($leaf -in @('weights', 'model', 'deploy', 'quant', 'burn')) {
        if (-not $Quiet) {
            Log ('!! 你选到了 ' + $leaf + '\ 子目录。请退一级，选择整个版本目录。')
        }
        return $null
    }
    if (Test-VersionDir $full) { return (Resolve-Path -LiteralPath $full).Path }
    $latest = Get-LatestVersionDir $full
    if ($latest) { return $latest }
    if (-not $Quiet) {
        Log ('!! 该目录下没有有效模型版本（缺 deploy\deploy_manifest.json，或 weights + quant）: ' + $full)
    }
    return $null
}

function Get-NativeLabelSummary([string]$datasetRoot) {
    $imgDir = Join-Path $datasetRoot 'images'
    $images = @(Get-ChildItem -LiteralPath $imgDir -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' })
    $json = @{}
    Get-ChildItem -LiteralPath $imgDir -File -Filter '*.json' -ErrorAction SilentlyContinue |
        ForEach-Object { $json[$_.BaseName] = $_.FullName }
    $withJson = 0
    $withShapes = 0
    $emptyShapes = 0
    $missing = 0
    $bad = 0
    $labelCounts = @{}
    foreach ($im in $images) {
        if (-not $json.ContainsKey($im.BaseName)) { $missing++; continue }
        $withJson++
        try {
            $j = Get-Content -LiteralPath $json[$im.BaseName] -Raw -Encoding UTF8 | ConvertFrom-Json
            $shapes = @($j.shapes)
            if ($shapes.Count -eq 0) {
                $emptyShapes++
            } else {
                $withShapes++
                foreach ($s in $shapes) {
                    $name = [string]$s.label
                    if ($name) {
                        if (-not $labelCounts.ContainsKey($name)) { $labelCounts[$name] = 0 }
                        $labelCounts[$name]++
                    }
                }
            }
        } catch {
            $bad++
        }
    }
    return [pscustomobject]@{
        Images = $images.Count
        Json = $json.Count
        WithJson = $withJson
        WithShapes = $withShapes
        EmptyShapes = $emptyShapes
        MissingJson = $missing
        BadJson = $bad
        LabelCounts = $labelCounts
    }
}

function Get-InternalLabelSummary([string]$datasetRoot) {
    $labDir = Join-Path $datasetRoot 'labels'
    $files = @(Get-ChildItem -LiteralPath $labDir -File -Filter '*.json' -ErrorAction SilentlyContinue)
    $positive = 0
    $empty = 0
    $bad = 0
    $boxes = 0
    $classes = @{}
    foreach ($f in $files) {
        try {
            $j = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $b = @($j.boxes)
            if ($b.Count -eq 0) {
                $empty++
            } else {
                $positive++
                $boxes += $b.Count
                foreach ($x in $b) {
                    $c = [int]$x.cls
                    if (-not $classes.ContainsKey($c)) { $classes[$c] = 0 }
                    $classes[$c]++
                }
            }
        } catch {
            $bad++
        }
    }
    return [pscustomobject]@{
        Files = $files.Count
        Positive = $positive
        Empty = $empty
        Bad = $bad
        Boxes = $boxes
        Classes = $classes
    }
}

function Invoke-Captured([scriptblock]$sb) {
    $obj = New-Object System.Collections.Generic.List[object]
    foreach ($x in @(& $sb 6>&1)) {
        if ($x -is [System.Management.Automation.InformationRecord]) {
            Log ('  ' + $x.ToString())
        } else {
            $obj.Add($x)
        }
    }
    return $obj.ToArray()
}

function Show-Summary([string]$text) {
    $pats = @(
        '数据集:', '划分:', 'obj 训练格', '^\s*L\d', '^---',
        '浮点 F32', 'PTQ\s+int8', 'QAT\s+int8', '掉点', '空场景',
        'bias>>shift', '量化余量', '框尺寸标度', '回滚到', '打包完成',
        'model\.pt', 'model\.onnx', 'deploy_manifest', 'model_card',
        '训练结束', 'PASS ', 'FAIL ', 'Traceback', 'Error', 'error:'
    )
    foreach ($line in ($text -split "\r?\n")) {
        foreach ($p in $pats) {
            if ($line -match $p) {
                Log ('>> ' + $line.Trim())
                break
            }
        }
    }
}

# ---------------------------------------------------------------- WinForms helpers
function Add-UiButton {
param(
        [System.Windows.Forms.Control]$Parent,
        [int]$X,
        [int]$Y,
        [int]$Width,
        [int]$Height,
        [string]$Text,
        [scriptblock]$OnClick
    )
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = New-Object System.Drawing.Point $X, $Y
    $b.Size = New-Object System.Drawing.Size $Width, $Height
    if ($OnClick) { $b.Add_Click($OnClick) }
    $Parent.Controls.Add($b)
    $script:AllButtons += $b
    return $b
}

function Add-InfoBox {
    param(
        [System.Windows.Forms.Control]$Parent,
        [int]$X,
        [int]$Y,
        [int]$Width,
        [int]$Height,
        [string]$Text
    )
    $box = New-Object System.Windows.Forms.TextBox
    $box.Multiline = $true
    $box.ReadOnly = $true
    $box.BorderStyle = 'FixedSingle'
    $box.BackColor = [System.Drawing.Color]::White
    $box.ScrollBars = 'Vertical'
    $box.WordWrap = $true
    $box.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 9
    $box.Location = New-Object System.Drawing.Point $X, $Y
    $box.Size = New-Object System.Drawing.Size $Width, $Height
    $box.Text = $Text
    $box.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($box)
    return $box
}

function Add-SectionTitle {
    param(
        [System.Windows.Forms.Control]$Parent,
        [int]$X,
        [int]$Y,
        [int]$Width,
        [string]$Text
    )
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.Location = New-Object System.Drawing.Point $X, $Y
    $l.Size = New-Object System.Drawing.Size $Width, 24
    $l.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 10, ([System.Drawing.FontStyle]::Bold)
    $l.ForeColor = [System.Drawing.Color]::FromArgb(35, 75, 120)
    $l.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($l)
    return $l
}

function Pick-PathDialog([string]$kind, [string]$title, [string]$current) {
    if ($kind -in @('file', 'python')) {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Title = $title
        $dlg.Filter = if ($kind -eq 'python') {
            'Python 解释器 (python.exe)|python.exe|可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*'
        } else {
            'JSON 文件 (*.json)|*.json|所有文件 (*.*)|*.*'
        }
        if ($current -and (Test-Path -LiteralPath $current)) {
            $dlg.InitialDirectory = Split-Path -Parent $current
            $dlg.FileName = Split-Path -Leaf $current
        }
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
        return $null
    }
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $title
    $dlg.ShowNewFolderButton = $true
    if ($current -and (Test-Path -LiteralPath $current)) { $dlg.SelectedPath = $current }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.SelectedPath }
    return $null
}

function Check-PathByKind([string]$kind, [string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) {
        Log '!! 路径为空。'
        return $false
    }
    $full = Get-NormalizedFullPath $path $script:Root
    if ($kind -in @('file', 'python')) {
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            Log ('OK 文件存在: ' + $full)
            return $true
        }
        Log ('!! 文件不存在: ' + $full)
        return $false
    }
    if (-not (Test-Path -LiteralPath $full -PathType Container)) {
        Log ('!! 目录不存在: ' + $full)
        return $false
    }
    switch ($kind) {
        'project' {
            $r = Resolve-ProjectRoot $full
            if ($r) {
                Log ('OK 工程本体: ' + $r)
                return $true
            }
            Log '!! 这个目录不是工程本体。必须包含 td_project 和 user_source。'
            return $false
        }
        'dataset' {
            if (Test-DatasetRoot $full) {
                Log ('OK 数据集根: ' + $full)
                return $true
            }
            Log '!! 数据集根必须包含非空的 images\。labels\ 由 2b 导入生成。'
            return $false
        }
        'raw' {
            $n = @(Get-ChildItem -LiteralPath $full -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' }).Count
            if ($n -gt 0) {
                Log ("OK 原始图片目录: $full（第一层 $n 张图片）")
                return $true
            }
            Log '!! 原始图片目录第一层没有图片。预处理不会递归扫描子目录。'
            return $false
        }
        'runs' {
            if (Test-RunsRoot $full) {
                Log ('OK 训练输出父目录: ' + $full)
                return $true
            }
            Log '!! 这里不能是版本目录、model/weights/deploy/quant/burn/scripts/images/labels 子目录。'
            return $false
        }
        'version' {
            $v = Resolve-VersionInput $full
            if ($v) {
                Log ('OK 模型版本: ' + $v)
                return $true
            }
            return $false
        }
        default {
            Log ('OK 目录存在: ' + $full)
            return $true
        }
    }
}

function Add-PathRow {
    param(
        [System.Windows.Forms.Control]$Parent,
        [int]$Y,
        [string]$Key,
        [string]$Label,
        [string]$Value,
        [string]$Help,
        [string]$Kind = 'folder'
    )
    $lb = New-Object System.Windows.Forms.Label
    $lb.Text = $Label
    $lb.Location = New-Object System.Drawing.Point 10, ($Y + 4)
    $lb.Size = New-Object System.Drawing.Size 142, 22
    $Parent.Controls.Add($lb)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Location = New-Object System.Drawing.Point 154, $Y
    $tb.Size = New-Object System.Drawing.Size 742, 25
    $tb.Text = [string]$Value
    $tb.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($tb)

    $browse = New-Object System.Windows.Forms.Button
    $browse.Text = '浏览...'
    $browse.Location = New-Object System.Drawing.Point 906, ($Y - 1)
    $browse.Size = New-Object System.Drawing.Size 76, 27
    $browse.Anchor = 'Top,Right'
    $browse.Tag = [pscustomobject]@{ TextBox = $tb; Kind = $Kind; Title = $Label }
    $browse.Add_Click({
        $tag = $this.Tag
        $p = Pick-PathDialog $tag.Kind $tag.Title $tag.TextBox.Text
        if ($p) { $tag.TextBox.Text = $p }
    })
    $Parent.Controls.Add($browse)
    $script:AllButtons += $browse

    $check = New-Object System.Windows.Forms.Button
    $check.Text = '检测'
    $check.Location = New-Object System.Drawing.Point 988, ($Y - 1)
    $check.Size = New-Object System.Drawing.Size 60, 27
    $check.Anchor = 'Top,Right'
    $check.Tag = [pscustomobject]@{ TextBox = $tb; Kind = $Kind }
    $check.Add_Click({
        $tag = $this.Tag
        [void](Check-PathByKind $tag.Kind $tag.TextBox.Text)
    })
    $Parent.Controls.Add($check)
    $script:AllButtons += $check

    $h = New-Object System.Windows.Forms.Label
    $h.Text = $Help
    $h.Location = New-Object System.Drawing.Point 154, ($Y + 27)
    $h.Size = New-Object System.Drawing.Size 894, 22
    $h.ForeColor = [System.Drawing.Color]::DimGray
    $h.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($h)

    $script:UI[$Key] = $tb
    return $tb
}

function Add-ReadOnlyValue {
    param(
        [System.Windows.Forms.Control]$Parent,
        [int]$Y,
        [string]$Key,
        [string]$Label,
        [string]$Help
    )
    $lb = New-Object System.Windows.Forms.Label
    $lb.Text = $Label
    $lb.Location = New-Object System.Drawing.Point 10, ($Y + 4)
    $lb.Size = New-Object System.Drawing.Size 142, 22
    $Parent.Controls.Add($lb)
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Location = New-Object System.Drawing.Point 154, $Y
    $tb.Size = New-Object System.Drawing.Size 894, 25
    $tb.ReadOnly = $true
    $tb.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
    $tb.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($tb)
    $h = New-Object System.Windows.Forms.Label
    $h.Text = $Help
    $h.Location = New-Object System.Drawing.Point 154, ($Y + 27)
    $h.Size = New-Object System.Drawing.Size 894, 22
    $h.ForeColor = [System.Drawing.Color]::DimGray
    $h.Anchor = 'Top,Left,Right'
    $Parent.Controls.Add($h)
    $script:UI[$Key] = $tb
    return $tb
}

function Set-BusyState([bool]$busy) {
    $script:Busy = $busy
    foreach ($b in $script:AllButtons) {
        try { $b.Enabled = -not $busy } catch { }
    }
    if ($script:Form) {
        $script:Form.Cursor = if ($busy) {
            [System.Windows.Forms.Cursors]::WaitCursor
        } else {
            [System.Windows.Forms.Cursors]::Default
        }
    }
    Update-Navigation
    [System.Windows.Forms.Application]::DoEvents()
}

function Invoke-UiTask([scriptblock]$work) {
    if ($script:Busy) { return }
    Set-BusyState $true
    try {
        & $work
    } catch {
        Log ('!! 异常: ' + $_.Exception.Message)
        if ($_.ScriptStackTrace) { Log ('   ' + $_.ScriptStackTrace) }
    } finally {
        $script:CurrentProcess = $null
        Set-BusyState $false
        Save-Config
        Refresh-DerivedUi
    }
}

function Confirm-Action([string]$message, [string]$title) {
    $r = [System.Windows.Forms.MessageBox]::Show($message, $title, 'YesNo', 'Question')
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Request-CancelOrStop {
    if ($script:Busy) {
        if (-not (Confirm-Action "当前任务仍在运行。停止可能留下不完整的版本目录或临时文件。`r`n`r`n确定停止？" '停止任务')) {
            return
        }
        $script:CancelRequested = $true
        $p = $script:CurrentProcess
        if ($p -and -not $p.HasExited) {
            try {
                $p.Kill()
                Log '!! 已发送停止命令，请等待当前步骤退出。'
            } catch {
                Log ('!! 无法停止子进程: ' + $_.Exception.Message)
            }
        }
        return
    }
    if (Confirm-Action '确定关闭训练向导？已保存的路径配置不会丢失。' '取消') {
        $script:Form.Close()
    }
}

# ---------------------------------------------------------------- configuration and navigation
function Sync-UiToConfig {
    $oldProject = [string]$script:Cfg.ProjectRoot
    $oldContract = [string]$script:Cfg.ContractPath
    $oldDataset = [string]$script:Cfg.DatasetRoot
    $oldRuns = [string]$script:Cfg.RunsRoot
    if ($script:UI.ProjectRoot) { $script:Cfg.ProjectRoot = $script:UI.ProjectRoot.Text.Trim() }
    if ($script:UI.DatasetRoot) { $script:Cfg.DatasetRoot = $script:UI.DatasetRoot.Text.Trim() }
    if ($script:UI.RawDir) { $script:Cfg.RawDir = $script:UI.RawDir.Text.Trim() }
    if ($script:UI.ContractPath) { $script:Cfg.ContractPath = $script:UI.ContractPath.Text.Trim() }
    if ($script:UI.RunsRoot) { $script:Cfg.RunsRoot = $script:UI.RunsRoot.Text.Trim() }
    if ($script:UI.ModelDir) { $script:Cfg.ModelDir = $script:UI.ModelDir.Text.Trim() }
    if ($script:UI.Tag) { $script:Cfg.Tag = $script:UI.Tag.Text.Trim() }
    if ($script:UI.Epochs) { $script:Cfg.Epochs = [int]$script:UI.Epochs.Value }
    if ($script:UI.Batch) { $script:Cfg.Batch = [int]$script:UI.Batch.Value }
    if ($script:UI.Classes) { $script:Cfg.Classes = [int]$script:UI.Classes.Value }
    if ($script:UI.ValRatio) { $script:Cfg.ValRatio = [double]$script:UI.ValRatio.Value }
    if ($script:UI.ExportOnnx) { $script:Cfg.ExportOnnx = [bool]$script:UI.ExportOnnx.Checked }
    if ($script:UI.LearningRate) { $script:Cfg.LearningRate = [double]$script:UI.LearningRate.Value }
    if ($script:UI.BoxWeight) { $script:Cfg.BoxWeight = [double]$script:UI.BoxWeight.Value }
    if ($script:UI.GrayscaleProb) { $script:Cfg.GrayscaleProb = [double]$script:UI.GrayscaleProb.Value }
    if ($script:UI.EmptyWeight) { $script:Cfg.EmptyWeight = [double]$script:UI.EmptyWeight.Value }
    if ($script:UI.QATEpochs) { $script:Cfg.QATEpochs = [int]$script:UI.QATEpochs.Value }
    if ($script:UI.QATLearningRate) { $script:Cfg.QATLearningRate = [double]$script:UI.QATLearningRate.Value }
    if ($script:UI.SplitManifest) { $script:Cfg.SplitManifest = $script:UI.SplitManifest.Text.Trim() }
    if ($script:UI.AutoLatestModel) { $script:Cfg.AutoLatestModel = [bool]$script:UI.AutoLatestModel.Checked }
    if ($script:UI.Threshold) { $script:Cfg.Threshold = [int]$script:UI.Threshold.Value }
    if ($script:UI.EdgeMode) { $script:Cfg.EdgeMode = [string]$script:UI.EdgeMode.SelectedItem }
    if ($script:UI.EdgeThreshold) { $script:Cfg.EdgeThreshold = [int]$script:UI.EdgeThreshold.Value }
    if ($script:UI.PythonExe) { $script:Cfg.PythonExe = $script:UI.PythonExe.Text.Trim() }
    if ($script:UI.MappingGrid -and $script:UI.MappingGrid.Rows.Count -gt 0) {
        $built = Build-ClassMapFromAssignments @(Get-MappingGridAssignments) ([int]$script:Cfg.Classes)
        if ($built.Errors.Count -eq 0) { $script:Cfg.ClassMap = [string]$built.Map }
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$script:Cfg.ProjectRoot)) {
        $newContract = Join-Path $script:Cfg.ProjectRoot 'user_source\hdl_source\cnn\cnn_contract.json'
        $oldDefaultContract = if ($oldProject) {
            Join-Path $oldProject 'user_source\hdl_source\cnn\cnn_contract.json'
        } else { '' }
        if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.ContractPath) -or
            ((-not [string]::Equals($oldProject, $script:Cfg.ProjectRoot, [System.StringComparison]::OrdinalIgnoreCase)) -and
             ([string]::Equals($oldContract, $oldDefaultContract, [System.StringComparison]::OrdinalIgnoreCase)))) {
            $script:Cfg.ContractPath = $newContract
            if ($script:UI.ContractPath) { $script:UI.ContractPath.Text = $newContract }
        }
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$script:Cfg.DatasetRoot)) {
        $newRuns = Join-Path $script:Cfg.DatasetRoot 'runs'
        $oldDefaultRuns = if ($oldDataset) { Join-Path $oldDataset 'runs' } else { '' }
        if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.RunsRoot) -or
            ((-not [string]::Equals($oldDataset, $script:Cfg.DatasetRoot, [System.StringComparison]::OrdinalIgnoreCase)) -and
             ([string]::Equals($oldRuns, $oldDefaultRuns, [System.StringComparison]::OrdinalIgnoreCase)))) {
            $script:Cfg.RunsRoot = $newRuns
            if ($script:UI.RunsRoot) { $script:UI.RunsRoot.Text = $newRuns }
        }
    }
}

function Refresh-DerivedUi {
    if ($script:UI.ImportDataset) { $script:UI.ImportDataset.Text = [string]$script:Cfg.DatasetRoot }
    if ($script:UI.TrainDataset) { $script:UI.TrainDataset.Text = [string]$script:Cfg.DatasetRoot }
    if ($script:UI.TrainProject) { $script:UI.TrainProject.Text = [string]$script:Cfg.ProjectRoot }
    if ($script:UI.TrainContract) { $script:UI.TrainContract.Text = [string]$script:Cfg.ContractPath }
    if ($script:UI.DeployProject) { $script:UI.DeployProject.Text = [string]$script:Cfg.ProjectRoot }
    Update-QuickCounts
}

function Update-QuickCounts {
    if ($script:UI.DatasetSummary) {
        $root = [string]$script:Cfg.DatasetRoot
        if (Test-DatasetRoot $root) {
            $imgDir = Join-Path $root 'images'
            $labDir = Join-Path $root 'labels'
            $imgs = @(Get-ChildItem -LiteralPath $imgDir -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' }).Count
            $jsons = @(Get-ChildItem -LiteralPath $imgDir -File -Filter '*.json' -ErrorAction SilentlyContinue).Count
            $labs = @(Get-ChildItem -LiteralPath $labDir -File -Filter '*.json' -ErrorAction SilentlyContinue).Count
            $script:UI.DatasetSummary.Text =
                ("图片 {0} | 原生 JSON {1} | 内部标签 {2}（详细正负样本统计请在第 2 步点【检查标注状态】）" -f
                 $imgs, $jsons, $labs)
        } else {
            $script:UI.DatasetSummary.Text = '数据集尚未就绪：请先选择包含 images\ 的目录，或完成预处理。'
        }
    }
    if ($script:UI.ImportStatus) {
        $root = [string]$script:Cfg.DatasetRoot
        if (Test-DatasetRoot $root) {
            $imgDir = Join-Path $root 'images'
            $imgs = @(Get-ChildItem -LiteralPath $imgDir -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' }).Count
            $jsons = @(Get-ChildItem -LiteralPath $imgDir -File -Filter '*.json' -ErrorAction SilentlyContinue).Count
            $script:UI.ImportStatus.Text = ("图片 {0} | 原生 JSON {1}；点【检查标注状态】查看有框/空场景/缺标签。" -f $imgs, $jsons)
        } else {
            $script:UI.ImportStatus.Text = '先完成第 1 步，选择有效数据集。'
        }
    }
    if ($script:UI.TrainResult -and $script:LastRunDir) {
        $script:UI.TrainResult.Text = '最近训练输出：' + $script:LastRunDir
    }
    if ($script:UI.DeployStatus) {
        Update-DeployStatus
    }
}

function Update-PageSummaries {
    if ($script:UI.DatasetSummary) {
        $root = [string]$script:Cfg.DatasetRoot
        if (Test-DatasetRoot $root) {
            $s = Get-DataSummary $root
            $script:UI.DatasetSummary.Text =
                ("图片 {0} | 原生 JSON {1} | 内部标签 {2} | 有目标 {3} | 空场景 {4} | 缺标签 {5}" -f
                 $s.Images, $s.NativeJson, $s.Labels, $s.Positive, $s.Empty, $s.MissingLabels)
        } else {
            $script:UI.DatasetSummary.Text = '数据集尚未就绪：请先选择包含 images\ 的目录，或完成预处理。'
        }
    }
    if ($script:UI.ImportStatus) {
        $root = [string]$script:Cfg.DatasetRoot
        if (Test-DatasetRoot $root) {
            $n = Get-NativeLabelSummary $root
            $script:UI.ImportStatus.Text =
                ("X-AnyLabeling JSON：有框 {0} / 空场景 {1} / 未标注 {2} / JSON 异常 {3}" -f
                 $n.WithShapes, $n.EmptyShapes, $n.MissingJson, $n.BadJson)
        } else {
            $script:UI.ImportStatus.Text = '先完成第 1 步，选择有效数据集。'
        }
    }
    if ($script:UI.TrainResult) {
        if ($script:LastRunDir) {
            $script:UI.TrainResult.Text = '最近训练输出：' + $script:LastRunDir
        } else {
            $script:UI.TrainResult.Text = '尚未在本向导中完成训练。'
        }
    }
    if ($script:UI.DeployStatus) {
        Update-DeployStatus
    }
}

function Show-Step([int]$step) {
    $script:Step = [Math]::Max(1, [Math]::Min(4, $step))
    foreach ($n in 1..4) {
        if ($script:Pages.ContainsKey($n)) {
            $script:Pages[$n].Visible = ($n -eq $script:Step)
        }
    }
    Update-Navigation
    if ($script:Step -eq 2) { Update-QuickCounts }
    if ($script:Step -eq 4) { Refresh-LatestModelSelection }
}

function Update-Navigation {
    if (-not $script:NavPrev) { return }
    $script:NavPrev.Enabled = (-not $script:Busy) -and ($script:Step -gt 1)
    $script:NavNext.Enabled = -not $script:Busy
    if ($script:Step -eq 4) {
        $script:NavNext.Text = '完成'
    } elseif ($script:DeployOnly) {
        $script:NavNext.Text = '进入部署'
    } else {
        $script:NavNext.Text = '下一步'
    }
    if ($script:NavDeploy) { $script:NavDeploy.Enabled = (-not $script:Busy) -and ($script:Step -lt 4) }
    if ($script:Busy) {
        $script:NavCancel.Text = '停止任务'
        $script:NavCancel.Enabled = $true
    } else {
        $script:NavCancel.Text = '取消'
        $script:NavCancel.Enabled = $true
    }
    $titles = @{
        1 = '1 / 4  路径与预处理'
        2 = '2 / 4  导入标签（X-AnyLabeling 2b）'
        3 = '3 / 4  训练与导出'
        4 = '4 / 4  部署到工程'
    }
    if ($script:UI.StepTitle) { $script:UI.StepTitle.Text = $titles[$script:Step] }
}

function Test-StepBeforeNext {
    if ($script:DeployOnly) { return $true }
    Sync-UiToConfig
    if ($script:Step -eq 1) {
        $root = Resolve-ProjectRoot $script:Cfg.ProjectRoot
        if (-not $root) {
            Log '!! 第 1 步未通过：工程本体目录无效。必须包含 td_project 和 user_source。'
            return $false
        }
        if (-not (Test-DatasetRoot $script:Cfg.DatasetRoot)) {
            Log '!! 第 1 步未通过：数据集根无效。必须包含非空的 images\；若还没预处理，请选择原始图片目录并点“运行预处理”。'
            return $false
        }
        $contract = Get-NormalizedFullPath $script:Cfg.ContractPath $root
        if (-not (Test-Path -LiteralPath $contract -PathType Leaf)) {
            Log ('!! 第 1 步未通过：契约不存在: ' + $contract)
            return $false
        }
        $script:Root = $root
        $env:QIANSAI_PROJECT = $root
        if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.RunsRoot)) {
            $script:Cfg.RunsRoot = Join-Path $script:Cfg.DatasetRoot 'runs'
        }
        return $true
    }
    if ($script:Step -eq 2) {
        $classes = [int]$script:Cfg.Classes
        if (-not (Validate-ClassMap ([string]$script:Cfg.ClassMap) $classes)) {
            Log '!! 第 2 步未通过：请在标签映射表中为每个标签选择唯一类别号，并覆盖全部类别。'
            return $false
        }
        $labDir = Join-Path $script:Cfg.DatasetRoot 'labels'
        $labelFiles = @(Get-ChildItem -LiteralPath $labDir -File -Filter '*.json' -ErrorAction SilentlyContinue)
        if ($labelFiles.Count -eq 0) {
            Log '!! 第 2 步未通过：还没有 labels\*.json。请先点“导入 X-AnyLabeling JSON”。'
            return $false
        }
        $images = @(Get-ChildItem -LiteralPath (Join-Path $script:Cfg.DatasetRoot 'images') -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' })
        $missing = 0
        foreach ($im in $images) {
            if (-not (Test-Path -LiteralPath (Join-Path $labDir ($im.BaseName + '.json')))) { $missing++ }
        }
        if ($missing -gt 0) {
            $msg = ("有 {0} 张图片没有内部标签，训练时会跳过这些图片。`r`n`r`n" +
                    "如果它们尚未标注，建议先回 X-AnyLabeling 完成；`r`n" +
                    "如果它们确实是空场景，请在 X-AnyLabeling 保存 shapes=[] 的 JSON 后再导入。`r`n`r`n仍要继续吗？") -f $missing
            if (-not (Confirm-Action $msg '仍有未标注图片')) { return $false }
        }
        return $true
    }
    if ($script:Step -eq 3) {
        if (-not (Test-RunsRoot $script:Cfg.RunsRoot)) {
            Log '!! 第 3 步未通过：训练输出父目录无效。不要选版本目录或 model/weights/deploy 等子目录。'
            return $false
        }
        return $true
    }
    return $true
}

# ---------------------------------------------------------------- form and pages
$script:Cfg = Load-Config

$form = New-Object System.Windows.Forms.Form
$script:Form = $form
$form.Text = 'CNN 数据集与模型训练向导'
$form.ClientSize = New-Object System.Drawing.Size 1120, 850
$form.MinimumSize = New-Object System.Drawing.Size 1010, 720
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 9

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.ColumnCount = 1
$layout.RowCount = 4
$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent), 100)) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute), 68)) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent), 100)) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute), 174)) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute), 52)) | Out-Null
$form.Controls.Add($layout)

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Fill'
$header.BackColor = [System.Drawing.Color]::FromArgb(30, 64, 105)
$layout.Controls.Add($header, 0, 0)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'CNN 数据集与模型训练向导'
$title.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 15, ([System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::White
$title.Location = New-Object System.Drawing.Point 18, 8
$title.Size = New-Object System.Drawing.Size 520, 30
$header.Controls.Add($title)

$script:UI.StepTitle = New-Object System.Windows.Forms.Label
$script:UI.StepTitle.Text = '1 / 4  路径与预处理'
$script:UI.StepTitle.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 10, ([System.Drawing.FontStyle]::Bold)
$script:UI.StepTitle.ForeColor = [System.Drawing.Color]::FromArgb(210, 225, 245)
$script:UI.StepTitle.Location = New-Object System.Drawing.Point 20, 40
$script:UI.StepTitle.Size = New-Object System.Drawing.Size 480, 22
$header.Controls.Add($script:UI.StepTitle)

$route = New-Object System.Windows.Forms.Label
$route.Text = '1 路径/预处理  ->  2 X-AnyLabeling 2b  ->  3 训练  ->  4 部署'
$route.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 9
$route.ForeColor = [System.Drawing.Color]::FromArgb(210, 225, 245)
$route.TextAlign = 'MiddleRight'
$route.Location = New-Object System.Drawing.Point 550, 20
$route.Size = New-Object System.Drawing.Size 545, 28
$route.Anchor = 'Top,Right'
$header.Controls.Add($route)

$contentHost = New-Object System.Windows.Forms.Panel
$contentHost.Dock = 'Fill'
$contentHost.Padding = New-Object System.Windows.Forms.Padding 10, 8, 10, 4
$layout.Controls.Add($contentHost, 0, 1)

function New-WizardPage {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.Size = New-Object System.Drawing.Size 1096, 540
    $p.Visible = $false
    $contentHost.Controls.Add($p)
    return $p
}

# ---------------- page 1
$p1 = New-WizardPage
$script:Pages[1] = $p1
[void](Add-InfoBox $p1 0 0 1090 92 (
    "这一步只决定工程、数据集、原图在哪里。`r`n" +
    "红色重点：数据集根不是原始视频/图片目录，也不是 runs 输出目录；它应包含 images\，导入标签后还会有 labels\ 和 report\。`r`n" +
    "先预处理时：原始图片目录只扫描第一层；处理后图片统一为 1280x720、从 0001 开始编号。`r`n" +
    "如果 images\ 里已经有标注，不要重复预处理，否则旧 JSON 可能与新图错位。"))
[void](Add-PathRow $p1 102 'ProjectRoot' '工程本体目录' $script:Cfg.ProjectRoot '必须包含 td_project\ 和 user_source\。不要选 Versions 根目录，也不要选 scripts 目录。' 'project')
[void](Add-PathRow $p1 160 'DatasetRoot' '数据集根目录' $script:Cfg.DatasetRoot '必须包含非空的 images\。例如 ...\datasets\starve&genshin；不是 images 本身。' 'dataset')
[void](Add-PathRow $p1 218 'RawDir' '原始图片目录' $script:Cfg.RawDir '只用于“运行预处理”。脚本只读第一层图片，不递归扫描子目录。已有数据集时通常不用填。' 'raw')
[void](Add-PathRow $p1 276 'ContractPath' 'CNN 契约文件' $script:Cfg.ContractPath '默认是 <工程本体>\user_source\hdl_source\cnn\cnn_contract.json；训练时用于确定网络几何。' 'file')
[void](Add-PathRow $p1 334 'PythonExe' 'Python 解释器' $script:Cfg.PythonExe '可选；留空时依次使用 PYTHON_EXE、PATH 和常见安装路径。队友机器路径不同可直接浏览选择。' 'python')

$btnPre = Add-UiButton $p1 154 386 150 31 '运行预处理' {
    Invoke-UiTask { Run-PreprocessFromUi }
}
$btnOpenDataset = Add-UiButton $p1 316 386 150 31 '打开数据集目录' {
    Sync-UiToConfig
    if (Test-Path -LiteralPath $script:Cfg.DatasetRoot) {
        Start-Process -FilePath $script:Cfg.DatasetRoot
    } else {
        Log ('!! 目录不存在: ' + $script:Cfg.DatasetRoot)
    }
}
$script:UI.DeployOnly = New-Object System.Windows.Forms.CheckBox
$script:UI.DeployOnly.Text = '仅部署模型（跳过数据集和训练检查）'
$script:UI.DeployOnly.Location = New-Object System.Drawing.Point 492, 389
$script:UI.DeployOnly.Size = New-Object System.Drawing.Size 340, 25
$script:UI.DeployOnly.Add_CheckedChanged({
    $script:DeployOnly = [bool]$this.Checked
    if ($script:DeployOnly) {
        Log '已启用仅部署模式：第 2、3 步的数据集、标签和训练输出检查将跳过。'
    } else {
        Log '已关闭仅部署模式。'
    }
    Update-Navigation
})
$p1.Controls.Add($script:UI.DeployOnly)
$script:UI.DatasetSummary = New-Object System.Windows.Forms.Label
$script:UI.DatasetSummary.Location = New-Object System.Drawing.Point 154, 430
$script:UI.DatasetSummary.Size = New-Object System.Drawing.Size 910, 24
$script:UI.DatasetSummary.ForeColor = [System.Drawing.Color]::FromArgb(55, 90, 130)
$p1.Controls.Add($script:UI.DatasetSummary)

$p1Note = New-Object System.Windows.Forms.Label
$p1Note.Text = '队友只安装/烧录模型时，可勾选“仅部署模型”，然后点“进入部署”或底部的“直接部署”；数据集根可以留空。'
$p1Note.Location = New-Object System.Drawing.Point 154, 464
$p1Note.Size = New-Object System.Drawing.Size 900, 24
$p1Note.ForeColor = [System.Drawing.Color]::DimGray
$p1.Controls.Add($p1Note)

# ---------------- page 2
$p2 = New-WizardPage
$script:Pages[2] = $p2
$script:UI.ImportRouteText = Add-InfoBox $p2 0 0 1090 142 (
    "本向导的标签导入统一使用 X-AnyLabeling 2b 路线。`r`n" +
    "操作：用 X-AnyLabeling 直接打开 <数据集根>\images 里的图片，画矩形并填写准确标签名，保存原生同名 JSON（例如 S01_starve_0001.json）。`r`n" +
    "空场景也必须保存 shapes=[] 的 JSON；导入时会被写成 boxes=[] 的负样本。`r`n" +
    "标签映射已改到下方表格：点【扫描标签并生成映射】，确认每个标签对应的类别号后直接导入，不需要输入 ClassMap 命令。")
[void](Add-ReadOnlyValue $p2 148 'ImportDataset' '数据集根目录' '这是第 1 步选定的目录；2b 会读取 images\*.json，把结果写到 labels\*.json。')

$lbClass = New-Object System.Windows.Forms.Label
$lbClass.Text = '类别数'
$lbClass.Location = New-Object System.Drawing.Point 10, 203
$lbClass.Size = New-Object System.Drawing.Size 60, 22
$p2.Controls.Add($lbClass)
$script:UI.Classes = New-Object System.Windows.Forms.NumericUpDown
$script:UI.Classes.Location = New-Object System.Drawing.Point 75, 199
$script:UI.Classes.Size = New-Object System.Drawing.Size 64, 25
$script:UI.Classes.Minimum = 1
$script:UI.Classes.Maximum = 3
$script:UI.Classes.Value = [decimal][Math]::Max(1, [Math]::Min(3, [int]$script:Cfg.Classes))
$p2.Controls.Add($script:UI.Classes)

$lbMap = New-Object System.Windows.Forms.Label
$lbMap.Text = '映射预览'
$lbMap.Location = New-Object System.Drawing.Point 158, 203
$lbMap.Size = New-Object System.Drawing.Size 130, 22
$p2.Controls.Add($lbMap)
$script:UI.ClassMap = New-Object System.Windows.Forms.TextBox
$script:UI.ClassMap.Location = New-Object System.Drawing.Point 292, 199
$script:UI.ClassMap.Size = New-Object System.Drawing.Size 620, 25
$script:UI.ClassMap.Text = [string]$script:Cfg.ClassMap
$script:UI.ClassMap.ReadOnly = $true
$script:UI.ClassMap.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
$script:UI.ClassMap.Anchor = 'Top,Left,Right'
$p2.Controls.Add($script:UI.ClassMap)

$btnScanMap = Add-UiButton $p2 154 240 180 31 '扫描标签并生成映射' {
    Invoke-UiTask { [void](Scan-LabelMapping) }
}
$btnCheckXany = Add-UiButton $p2 344 240 145 31 '检查标注状态' {
    Invoke-UiTask { Run-LabelCheck }
}
$btnImportXany = Add-UiButton $p2 499 240 205 31 '导入 X-AnyLabeling JSON' {
    Invoke-UiTask { Run-XanyImport2b }
}
$btnOpenImages = Add-UiButton $p2 714 240 145 31 '打开 images 目录' {
    Sync-UiToConfig
    $p = Join-Path $script:Cfg.DatasetRoot 'images'
    if (Test-Path -LiteralPath $p) { Start-Process -FilePath $p } else { Log ('!! 目录不存在: ' + $p) }
}

$script:UI.ImportStatus = New-Object System.Windows.Forms.Label
$script:UI.ImportStatus.Location = New-Object System.Drawing.Point 154, 280
$script:UI.ImportStatus.Size = New-Object System.Drawing.Size 910, 24
$script:UI.ImportStatus.ForeColor = [System.Drawing.Color]::FromArgb(55, 90, 130)
$p2.Controls.Add($script:UI.ImportStatus)

$mapTitle = New-Object System.Windows.Forms.Label
$mapTitle.Text = '标签名到类别号的映射（数字用于训练和硬件，标签名来自 X-AnyLabeling）'
$mapTitle.Location = New-Object System.Drawing.Point 10, 306
$mapTitle.Size = New-Object System.Drawing.Size 900, 22
$mapTitle.Font = New-Object System.Drawing.Font 'Microsoft YaHei UI', 9, ([System.Drawing.FontStyle]::Bold)
$mapTitle.ForeColor = [System.Drawing.Color]::FromArgb(35, 75, 120)
$p2.Controls.Add($mapTitle)

$script:UI.MappingGrid = New-Object System.Windows.Forms.DataGridView
$script:UI.MappingGrid.Location = New-Object System.Drawing.Point 10, 328
$script:UI.MappingGrid.Size = New-Object System.Drawing.Size 1070, 94
$script:UI.MappingGrid.Anchor = 'Top,Left,Right'
$script:UI.MappingGrid.AllowUserToAddRows = $false
$script:UI.MappingGrid.AllowUserToDeleteRows = $false
$script:UI.MappingGrid.AllowUserToResizeRows = $false
$script:UI.MappingGrid.RowHeadersVisible = $false
$script:UI.MappingGrid.MultiSelect = $false
$script:UI.MappingGrid.SelectionMode = 'FullRowSelect'
$script:UI.MappingGrid.AutoSizeColumnsMode = 'None'
$script:UI.MappingGrid.BackgroundColor = [System.Drawing.Color]::White
$script:UI.MappingGrid.EditMode = 'EditOnEnter'

$colLabel = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colLabel.HeaderText = 'X-AnyLabeling 标签名'
$colLabel.ReadOnly = $true
$colLabel.Width = 260
$script:UI.MappingGrid.Columns.Add($colLabel) | Out-Null
$colCount = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colCount.HeaderText = '框数量'
$colCount.ReadOnly = $true
$colCount.Width = 110
$script:UI.MappingGrid.Columns.Add($colCount) | Out-Null
$colClass = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
$colClass.HeaderText = '类别号'
$colClass.Width = 140
$colClass.FlatStyle = 'Flat'
$script:UI.MappingGrid.Columns.Add($colClass) | Out-Null
$colState = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colState.HeaderText = '状态'
$colState.ReadOnly = $true
$colState.AutoSizeMode = 'Fill'
$script:UI.MappingGrid.Columns.Add($colState) | Out-Null
$p2.Controls.Add($script:UI.MappingGrid)

$script:UI.MappingSummary = New-Object System.Windows.Forms.Label
$script:UI.MappingSummary.Location = New-Object System.Drawing.Point 10, 426
$script:UI.MappingSummary.Size = New-Object System.Drawing.Size 1070, 24
$script:UI.MappingSummary.Text = '点【扫描标签并生成映射】：扫描 images\*.json 中实际出现的标签名。'
$script:UI.MappingSummary.ForeColor = [System.Drawing.Color]::DimGray
$p2.Controls.Add($script:UI.MappingSummary)

$mapHelp = New-Object System.Windows.Forms.Label
$mapHelp.Text = '导入时直接使用表格映射，不需要输入命令。通常只需 starve=0、genshin=1；empty 和 both 不是类别。'
$mapHelp.Location = New-Object System.Drawing.Point 10, 452
$mapHelp.Size = New-Object System.Drawing.Size 1070, 24
$mapHelp.ForeColor = [System.Drawing.Color]::DimGray
$p2.Controls.Add($mapHelp)

$script:UI.MappingGrid.Add_CellValueChanged({
    if ($script:Busy) { return }
    [void](Update-MappingPreview)
})
$script:UI.MappingGrid.Add_CurrentCellDirtyStateChanged({
    if ($this.IsCurrentCellDirty) {
        $this.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit)
    }
})
$script:UI.Classes.Add_ValueChanged({
    if ($script:Busy) { return }
    Update-MappingClassChoices
    [void](Update-MappingPreview)
})
Update-MappingClassChoices

# ---------------- page 3
$p3 = New-WizardPage
$script:Pages[3] = $p3
[void](Add-InfoBox $p3 0 0 1090 92 (
    "训练会读取第 2 步生成的 labels\*.json，并固定导出 model.pt、部署包 deploy\、weights\ 与 quant\。`r`n" +
    "【训练输出父目录】只负责创建新版本目录；不要选某个版本目录，也不要选 model\、weights\、deploy\。`r`n" +
    "每次训练都会新建 <标签>_vN_<时间>，旧版本不会被覆盖。"))
[void](Add-ReadOnlyValue $p3 102 'TrainDataset' '数据集根目录' '与第 1/2 步使用同一个目录；训练脚本会读取 images\ 和 labels\。')
[void](Add-PathRow $p3 160 'RunsRoot' '训练输出父目录' $script:Cfg.RunsRoot '只选版本目录的上一级，例如 <数据集根>\runs。每次训练自动新建子目录。' 'runs')
[void](Add-ReadOnlyValue $p3 218 'TrainContract' 'CNN 契约文件' '来自第 1 步；通过 --contract 显式传给训练脚本，避免队友机器自动找错工程。')

$lbEpoch = New-Object System.Windows.Forms.Label
$lbEpoch.Text = 'epochs'
$lbEpoch.Location = New-Object System.Drawing.Point 154, 270
$lbEpoch.Size = New-Object System.Drawing.Size 50, 22
$p3.Controls.Add($lbEpoch)
$script:UI.Epochs = New-Object System.Windows.Forms.NumericUpDown
$script:UI.Epochs.Location = New-Object System.Drawing.Point 204, 266
$script:UI.Epochs.Size = New-Object System.Drawing.Size 72, 25
$script:UI.Epochs.Minimum = 1
$script:UI.Epochs.Maximum = 20000
$script:UI.Epochs.Value = [decimal][Math]::Max(1, [int]$script:Cfg.Epochs)
$p3.Controls.Add($script:UI.Epochs)

$lbBatch = New-Object System.Windows.Forms.Label
$lbBatch.Text = 'batch'
$lbBatch.Location = New-Object System.Drawing.Point 293, 270
$lbBatch.Size = New-Object System.Drawing.Size 45, 22
$p3.Controls.Add($lbBatch)
$script:UI.Batch = New-Object System.Windows.Forms.NumericUpDown
$script:UI.Batch.Location = New-Object System.Drawing.Point 338, 266
$script:UI.Batch.Size = New-Object System.Drawing.Size 60, 25
$script:UI.Batch.Minimum = 1
$script:UI.Batch.Maximum = 512
$script:UI.Batch.Value = [decimal][Math]::Max(1, [int]$script:Cfg.Batch)
$p3.Controls.Add($script:UI.Batch)

$lbVal = New-Object System.Windows.Forms.Label
$lbVal.Text = '验证比例'
$lbVal.Location = New-Object System.Drawing.Point 417, 270
$lbVal.Size = New-Object System.Drawing.Size 65, 22
$p3.Controls.Add($lbVal)
$script:UI.ValRatio = New-Object System.Windows.Forms.NumericUpDown
$script:UI.ValRatio.Location = New-Object System.Drawing.Point 482, 266
$script:UI.ValRatio.Size = New-Object System.Drawing.Size 64, 25
$script:UI.ValRatio.DecimalPlaces = 2
$script:UI.ValRatio.Increment = [decimal]0.05
$script:UI.ValRatio.Minimum = [decimal]0.0
$script:UI.ValRatio.Maximum = [decimal]0.5
$script:UI.ValRatio.Value = [decimal][Math]::Max(0.0, [Math]::Min(0.5, [double]$script:Cfg.ValRatio))
$p3.Controls.Add($script:UI.ValRatio)

$lbTag = New-Object System.Windows.Forms.Label
$lbTag.Text = '版本标签'
$lbTag.Location = New-Object System.Drawing.Point 565, 270
$lbTag.Size = New-Object System.Drawing.Size 65, 22
$p3.Controls.Add($lbTag)
$script:UI.Tag = New-Object System.Windows.Forms.TextBox
$script:UI.Tag.Location = New-Object System.Drawing.Point 630, 266
$script:UI.Tag.Size = New-Object System.Drawing.Size 150, 25
$script:UI.Tag.Text = [string]$script:Cfg.Tag
$p3.Controls.Add($script:UI.Tag)

$script:UI.ExportOnnx = New-Object System.Windows.Forms.CheckBox
$script:UI.ExportOnnx.Text = '同时导出 model.onnx'
$script:UI.ExportOnnx.Location = New-Object System.Drawing.Point 800, 267
$script:UI.ExportOnnx.Size = New-Object System.Drawing.Size 190, 24
$script:UI.ExportOnnx.Checked = [bool]$script:Cfg.ExportOnnx
$p3.Controls.Add($script:UI.ExportOnnx)

$lbLr = New-Object System.Windows.Forms.Label
$lbLr.Text = '学习率'
$lbLr.Location = New-Object System.Drawing.Point 154, 304
$lbLr.Size = New-Object System.Drawing.Size 55, 22
$p3.Controls.Add($lbLr)
$script:UI.LearningRate = New-Object System.Windows.Forms.NumericUpDown
$script:UI.LearningRate.Location = New-Object System.Drawing.Point 210, 300
$script:UI.LearningRate.Size = New-Object System.Drawing.Size 92, 25
$script:UI.LearningRate.DecimalPlaces = 6
$script:UI.LearningRate.Increment = [decimal]0.0001
$script:UI.LearningRate.Minimum = [decimal]0.000001
$script:UI.LearningRate.Maximum = [decimal]1
$script:UI.LearningRate.Value = [decimal]$script:Cfg.LearningRate
$p3.Controls.Add($script:UI.LearningRate)

$lbBox = New-Object System.Windows.Forms.Label
$lbBox.Text = 'box权重'
$lbBox.Location = New-Object System.Drawing.Point 315, 304
$lbBox.Size = New-Object System.Drawing.Size 65, 22
$p3.Controls.Add($lbBox)
$script:UI.BoxWeight = New-Object System.Windows.Forms.NumericUpDown
$script:UI.BoxWeight.Location = New-Object System.Drawing.Point 382, 300
$script:UI.BoxWeight.Size = New-Object System.Drawing.Size 55, 25
$script:UI.BoxWeight.DecimalPlaces = 1
$script:UI.BoxWeight.Minimum = [decimal]0.0
$script:UI.BoxWeight.Maximum = [decimal]20
$script:UI.BoxWeight.Value = [decimal]$script:Cfg.BoxWeight
$p3.Controls.Add($script:UI.BoxWeight)

$lbGray = New-Object System.Windows.Forms.Label
$lbGray.Text = '灰度概率'
$lbGray.Location = New-Object System.Drawing.Point 450, 304
$lbGray.Size = New-Object System.Drawing.Size 65, 22
$p3.Controls.Add($lbGray)
$script:UI.GrayscaleProb = New-Object System.Windows.Forms.NumericUpDown
$script:UI.GrayscaleProb.Location = New-Object System.Drawing.Point 518, 300
$script:UI.GrayscaleProb.Size = New-Object System.Drawing.Size 60, 25
$script:UI.GrayscaleProb.DecimalPlaces = 2
$script:UI.GrayscaleProb.Increment = [decimal]0.05
$script:UI.GrayscaleProb.Minimum = [decimal]0
$script:UI.GrayscaleProb.Maximum = [decimal]1
$script:UI.GrayscaleProb.Value = [decimal]$script:Cfg.GrayscaleProb
$p3.Controls.Add($script:UI.GrayscaleProb)

$lbEmpty = New-Object System.Windows.Forms.Label
$lbEmpty.Text = '空场景权重'
$lbEmpty.Location = New-Object System.Drawing.Point 590, 304
$lbEmpty.Size = New-Object System.Drawing.Size 80, 22
$p3.Controls.Add($lbEmpty)
$script:UI.EmptyWeight = New-Object System.Windows.Forms.NumericUpDown
$script:UI.EmptyWeight.Location = New-Object System.Drawing.Point 672, 300
$script:UI.EmptyWeight.Size = New-Object System.Drawing.Size 55, 25
$script:UI.EmptyWeight.DecimalPlaces = 1
$script:UI.EmptyWeight.Minimum = [decimal]1
$script:UI.EmptyWeight.Maximum = [decimal]20
$script:UI.EmptyWeight.Value = [decimal]$script:Cfg.EmptyWeight
$p3.Controls.Add($script:UI.EmptyWeight)

$lbQat = New-Object System.Windows.Forms.Label
$lbQat.Text = 'QAT轮数'
$lbQat.Location = New-Object System.Drawing.Point 740, 304
$lbQat.Size = New-Object System.Drawing.Size 60, 22
$p3.Controls.Add($lbQat)
$script:UI.QATEpochs = New-Object System.Windows.Forms.NumericUpDown
$script:UI.QATEpochs.Location = New-Object System.Drawing.Point 802, 300
$script:UI.QATEpochs.Size = New-Object System.Drawing.Size 55, 25
$script:UI.QATEpochs.Minimum = 0
$script:UI.QATEpochs.Maximum = 1000
$script:UI.QATEpochs.Value = [decimal]$script:Cfg.QATEpochs
$p3.Controls.Add($script:UI.QATEpochs)

$lbQatLr = New-Object System.Windows.Forms.Label
$lbQatLr.Text = 'QAT学习率'
$lbQatLr.Location = New-Object System.Drawing.Point 870, 304
$lbQatLr.Size = New-Object System.Drawing.Size 75, 22
$p3.Controls.Add($lbQatLr)
$script:UI.QATLearningRate = New-Object System.Windows.Forms.NumericUpDown
$script:UI.QATLearningRate.Location = New-Object System.Drawing.Point 948, 300
$script:UI.QATLearningRate.Size = New-Object System.Drawing.Size 112, 25
$script:UI.QATLearningRate.DecimalPlaces = 6
$script:UI.QATLearningRate.Increment = [decimal]0.00005
$script:UI.QATLearningRate.Minimum = [decimal]0.000001
$script:UI.QATLearningRate.Maximum = [decimal]0.1
$script:UI.QATLearningRate.Value = [decimal]$script:Cfg.QATLearningRate
$p3.Controls.Add($script:UI.QATLearningRate)

$lbEdgeMode = New-Object System.Windows.Forms.Label
$lbEdgeMode.Text = '第四通道'
$lbEdgeMode.Location = New-Object System.Drawing.Point 154, 340
$lbEdgeMode.Size = New-Object System.Drawing.Size 80, 22
$p3.Controls.Add($lbEdgeMode)
$script:UI.EdgeMode = New-Object System.Windows.Forms.ComboBox
$script:UI.EdgeMode.DropDownStyle = 'DropDownList'
$script:UI.EdgeMode.Location = New-Object System.Drawing.Point 240, 336
$script:UI.EdgeMode.Size = New-Object System.Drawing.Size 150, 25
[void]$script:UI.EdgeMode.Items.AddRange(@('density', 'zero'))
$script:UI.EdgeMode.SelectedItem = [string]$script:Cfg.EdgeMode
$p3.Controls.Add($script:UI.EdgeMode)

$lbEdgeThreshold = New-Object System.Windows.Forms.Label
$lbEdgeThreshold.Text = '边缘阈值'
$lbEdgeThreshold.Location = New-Object System.Drawing.Point 410, 340
$lbEdgeThreshold.Size = New-Object System.Drawing.Size 75, 22
$p3.Controls.Add($lbEdgeThreshold)
$script:UI.EdgeThreshold = New-Object System.Windows.Forms.NumericUpDown
$script:UI.EdgeThreshold.Location = New-Object System.Drawing.Point 490, 336
$script:UI.EdgeThreshold.Size = New-Object System.Drawing.Size 64, 25
$script:UI.EdgeThreshold.Minimum = 0
$script:UI.EdgeThreshold.Maximum = 4095
$script:UI.EdgeThreshold.Value = [decimal]$script:Cfg.EdgeThreshold
$p3.Controls.Add($script:UI.EdgeThreshold)

$edgeHint = New-Object System.Windows.Forms.Label
$edgeHint.Text = 'density = 板端 8×8 边缘密度；zero = 旧模型兼容。阈值必须与 RTL 配置一致。'
$edgeHint.Location = New-Object System.Drawing.Point 580, 340
$edgeHint.Size = New-Object System.Drawing.Size 500, 22
$edgeHint.ForeColor = [System.Drawing.Color]::DimGray
$p3.Controls.Add($edgeHint)

[void](Add-PathRow $p3 374 'SplitManifest' '固定划分清单' $script:Cfg.SplitManifest '可选；数据集已有 split_manifest.json 时建议指定，防止重新随机划分。' 'file')

$btnTrain = Add-UiButton $p3 154 430 220 34 '开始训练并导出模型' {
    Invoke-UiTask { Run-TrainFromUi }
}
$btnOpenRuns = Add-UiButton $p3 384 430 150 34 '打开输出父目录' {
    Sync-UiToConfig
    $p = Get-NormalizedFullPath $script:Cfg.RunsRoot $script:Root
    if (Test-Path -LiteralPath $p) { Start-Process -FilePath $p } else { Log ('!! 目录不存在: ' + $p) }
}

$script:UI.TrainResult = New-Object System.Windows.Forms.Label
$script:UI.TrainResult.Location = New-Object System.Drawing.Point 154, 472
$script:UI.TrainResult.Size = New-Object System.Drawing.Size 910, 28
$script:UI.TrainResult.ForeColor = [System.Drawing.Color]::FromArgb(55, 90, 130)
$p3.Controls.Add($script:UI.TrainResult)

[void](Add-InfoBox $p3 0 505 1090 30 (
    "训练完成后，把整个版本目录发给队友即可。部署页选择该版本目录；队友不需要你的数据集，也不需要重新训练。"))

# ---------------- page 4
$p4 = New-WizardPage
$script:Pages[4] = $p4
[void](Add-InfoBox $p4 0 0 1090 166 (
    "部署会修改工程本体 user_source\hdl_source\cnn\ 下的权重、qparam 与生成文件，并在改动前备份。`r`n" +
    "【只安装权重】 = 安装 + 重新生成 ROM/契约检查，不跑 ModelSim。`r`n" +
    "【安装 + 验收】 = 再加 ModelSim 逐层逐字对拍。`r`n" +
    "【安装 + 验收 + 编译 bit】 = 最后跑 TD P&R，约 10~20 分钟，并在 <版本目录>\burn 生成比特流。`r`n" +
    "MCU BIN 不由 TD P&R 生成；状态栏会按文件名中的 thr 门限和权重时间提示是否需要另编固件。`r`n" +
    "若模型包与目标工程的 contract 几何不匹配，必须停止并换正确工程；不要使用强制安装。"))
[void](Add-PathRow $p4 174 'ModelDir' '模型版本目录' $script:Cfg.ModelDir '选单个版本目录（含 model.pt/weights/deploy），或选 runs 父目录自动取最新。不要选 weights 或 model 子目录。' 'version')
[void](Add-PathRow $p4 232 'DeployProject' '目标工程本体' $script:Cfg.ProjectRoot '要安装到哪个工程。必须包含 td_project\ 和 user_source\；盘符可以和训练机不同。' 'project')

$script:UI.AutoLatestModel = New-Object System.Windows.Forms.CheckBox
$script:UI.AutoLatestModel.Text = '自动跟随最新训练模型'
$script:UI.AutoLatestModel.Location = New-Object System.Drawing.Point 154, 266
$script:UI.AutoLatestModel.Size = New-Object System.Drawing.Size 235, 24
$script:UI.AutoLatestModel.Checked = [bool]$script:Cfg.AutoLatestModel
$p4.Controls.Add($script:UI.AutoLatestModel)

$lbThreshold = New-Object System.Windows.Forms.Label
$lbThreshold.Text = '目标门限'
$lbThreshold.Location = New-Object System.Drawing.Point 405, 269
$lbThreshold.Size = New-Object System.Drawing.Size 65, 22
$p4.Controls.Add($lbThreshold)
$script:UI.Threshold = New-Object System.Windows.Forms.NumericUpDown
$script:UI.Threshold.Location = New-Object System.Drawing.Point 468, 265
$script:UI.Threshold.Size = New-Object System.Drawing.Size 55, 25
$script:UI.Threshold.Minimum = 0
$script:UI.Threshold.Maximum = 255
$script:UI.Threshold.Value = [decimal]$script:Cfg.Threshold
$p4.Controls.Add($script:UI.Threshold)

$btnRefreshLatest = Add-UiButton $p4 598 263 165 29 '刷新最新模型' {
    Sync-UiToConfig
    Refresh-LatestModelSelection
}

$grpMode = New-Object System.Windows.Forms.GroupBox
$grpMode.Text = '部署动作'
$grpMode.Location = New-Object System.Drawing.Point 10, 292
$grpMode.Size = New-Object System.Drawing.Size 430, 64
$p4.Controls.Add($grpMode)
$script:UI.ModeInstall = New-Object System.Windows.Forms.RadioButton
$script:UI.ModeInstall.Text = '只安装权重'
$script:UI.ModeInstall.Location = New-Object System.Drawing.Point 12, 24
$script:UI.ModeInstall.Size = New-Object System.Drawing.Size 110, 24
$grpMode.Controls.Add($script:UI.ModeInstall)
$script:UI.ModeVerify = New-Object System.Windows.Forms.RadioButton
$script:UI.ModeVerify.Text = '安装 + 验收'
$script:UI.ModeVerify.Location = New-Object System.Drawing.Point 130, 24
$script:UI.ModeVerify.Size = New-Object System.Drawing.Size 110, 24
$script:UI.ModeVerify.Checked = $true
$grpMode.Controls.Add($script:UI.ModeVerify)
$script:UI.ModeBit = New-Object System.Windows.Forms.RadioButton
$script:UI.ModeBit.Text = '安装 + 验收 + 编译 bit'
$script:UI.ModeBit.Location = New-Object System.Drawing.Point 248, 24
$script:UI.ModeBit.Size = New-Object System.Drawing.Size 170, 24
$grpMode.Controls.Add($script:UI.ModeBit)

$btnCheckModel = Add-UiButton $p4 460 304 145 34 '检查模型包' {
    Invoke-UiTask { Run-ModelDryRun }
}
$btnDeploy = Add-UiButton $p4 615 304 220 34 '开始部署' {
    Invoke-UiTask { Run-DeployFromUi }
}
$btnOpenBurn = Add-UiButton $p4 845 304 160 34 '打开 burn 目录' {
    Sync-UiToConfig
    $v = Resolve-VersionInput $script:Cfg.ModelDir
    if ($v) {
        $p = Join-Path $v 'burn'
        if (Test-Path -LiteralPath $p) { Start-Process -FilePath $p } else { Log ('!! 还没有 burn 目录: ' + $p) }
    }
}

$script:UI.DeployStatus = New-Object System.Windows.Forms.Label
$script:UI.DeployStatus.Location = New-Object System.Drawing.Point 154, 360
$script:UI.DeployStatus.Size = New-Object System.Drawing.Size 910, 28
$script:UI.DeployStatus.ForeColor = [System.Drawing.Color]::FromArgb(55, 90, 130)
$p4.Controls.Add($script:UI.DeployStatus)
$script:UI.AutoLatestModel.Add_CheckedChanged({
    if ($script:Busy) { return }
    Sync-UiToConfig
    if ($script:UI.AutoLatestModel.Checked) {
        Refresh-LatestModelSelection
    } else {
        Update-DeployStatus
    }
})
$script:UI.ModelDir.Add_TextChanged({
    if ($script:Busy) { return }
    Sync-UiToConfig
    Update-DeployStatus
})
$script:UI.Threshold.Add_ValueChanged({
    if ($script:Busy) { return }
    Sync-UiToConfig
    Update-DeployStatus
})

# ---------------- log
$grpLog = New-Object System.Windows.Forms.GroupBox
$grpLog.Text = '运行日志（所有页面共用；路径与命令的实际结果看这里）'
$grpLog.Dock = 'Fill'
$grpLog.Padding = New-Object System.Windows.Forms.Padding 8
$layout.Controls.Add($grpLog, 0, 2)
$script:LogBox = New-Object System.Windows.Forms.TextBox
$script:LogBox.Multiline = $true
$script:LogBox.ReadOnly = $true
$script:LogBox.ScrollBars = 'Both'
$script:LogBox.WordWrap = $false
$script:LogBox.Dock = 'Fill'
$script:LogBox.Font = New-Object System.Drawing.Font 'Consolas', 8.5
$script:LogBox.BackColor = [System.Drawing.Color]::FromArgb(250, 250, 250)
$grpLog.Controls.Add($script:LogBox)

# ---------------- navigation
$nav = New-Object System.Windows.Forms.Panel
$nav.Dock = 'Fill'
$nav.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
$layout.Controls.Add($nav, 0, 3)

$navHint = New-Object System.Windows.Forms.Label
$navHint.Text = '训练流程会检查数据路径；只部署模型时点“直接部署”。'
$navHint.Location = New-Object System.Drawing.Point 16, 16
$navHint.Size = New-Object System.Drawing.Size 530, 22
$navHint.ForeColor = [System.Drawing.Color]::DimGray
$nav.Controls.Add($navHint)

$script:NavDeploy = New-Object System.Windows.Forms.Button
$script:NavDeploy.Text = '直接部署'
$script:NavDeploy.Location = New-Object System.Drawing.Point 570, 9
$script:NavDeploy.Size = New-Object System.Drawing.Size 110, 34
$script:NavDeploy.Anchor = 'Top,Right'
$script:NavDeploy.Add_Click({
    if ($script:Busy) { return }
    if ($script:UI.DeployOnly) {
        $script:UI.DeployOnly.Checked = $true
    }
    $script:DeployOnly = $true
    Sync-UiToConfig
    Log '已直接进入第 4 步部署，不检查数据集和训练输出。'
    Show-Step 4
})
$nav.Controls.Add($script:NavDeploy)

$script:NavCancel = New-Object System.Windows.Forms.Button
$script:NavCancel.Text = '取消'
$script:NavCancel.Location = New-Object System.Drawing.Point 695, 9
$script:NavCancel.Size = New-Object System.Drawing.Size 110, 34
$script:NavCancel.Anchor = 'Top,Right'
$script:NavCancel.Add_Click({ Request-CancelOrStop })
$nav.Controls.Add($script:NavCancel)

$script:NavPrev = New-Object System.Windows.Forms.Button
$script:NavPrev.Text = '上一步'
$script:NavPrev.Location = New-Object System.Drawing.Point 820, 9
$script:NavPrev.Size = New-Object System.Drawing.Size 110, 34
$script:NavPrev.Anchor = 'Top,Right'
$script:NavPrev.Add_Click({
    if ($script:Busy) { return }
    Sync-UiToConfig
    if ($script:DeployOnly -and $script:Step -eq 4) {
        Show-Step 1
    } else {
        Show-Step ($script:Step - 1)
    }
})
$nav.Controls.Add($script:NavPrev)

$script:NavNext = New-Object System.Windows.Forms.Button
$script:NavNext.Text = '下一步'
$script:NavNext.Location = New-Object System.Drawing.Point 940, 9
$script:NavNext.Size = New-Object System.Drawing.Size 110, 34
$script:NavNext.Anchor = 'Top,Right'
$script:NavNext.Add_Click({
    if ($script:Busy) { return }
    if ($script:Step -ge 4) {
        $form.Close()
        return
    }
    if ($script:DeployOnly) {
        Refresh-DerivedUi
        Show-Step 4
        return
    }
    if (Test-StepBeforeNext) {
        Refresh-DerivedUi
        Save-Config
        Show-Step ($script:Step + 1)
    }
})
$nav.Controls.Add($script:NavNext)

$form.Add_FormClosing({
    if ($script:Busy) {
        $r = [System.Windows.Forms.MessageBox]::Show(
            '任务仍在运行。关闭窗口会终止子进程，是否继续？',
            '任务运行中', 'YesNo', 'Warning')
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) {
            $_.Cancel = $true
            return
        }
        $script:CancelRequested = $true
        if ($script:CurrentProcess -and -not $script:CurrentProcess.HasExited) {
            try { $script:CurrentProcess.Kill() } catch { }
        }
    }
    Save-Config
})

# ---------------------------------------------------------------- actions
function Run-PreprocessFromUi {
    Sync-UiToConfig
    if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.RawDir)) {
        Log '!! 请先选择原始图片目录。'
        return
    }
    if ([string]::IsNullOrWhiteSpace([string]$script:Cfg.DatasetRoot)) {
        Log '!! 请先选择数据集根目录。'
        return
    }
    if (-not (Test-Path -LiteralPath $script:Cfg.RawDir -PathType Container)) {
        Log ('!! 原始图片目录不存在: ' + $script:Cfg.RawDir)
        return
    }
    $status = @(Get-ChildItem -LiteralPath $script:Cfg.RawDir -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' })
    if ($status.Count -eq 0) {
        Log '!! 原始图片目录第一层没有图片。脚本不会递归扫描子目录。'
        return
    }

    $imgDir = Join-Path $script:Cfg.DatasetRoot 'images'
    $existing = 0
    $existingJson = 0
    if (Test-Path -LiteralPath $imgDir) {
        $existing = @(Get-ChildItem -LiteralPath $imgDir -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in '.jpg', '.jpeg', '.png', '.bmp' }).Count
        $existingJson = @(Get-ChildItem -LiteralPath $imgDir -File -Filter '*.json' -ErrorAction SilentlyContinue).Count
    }
    if ($existing -gt 0 -or $existingJson -gt 0) {
        $msg = ("数据集 images\ 里已有 {0} 张图片、{1} 个 JSON。`r`n`r`n" +
                "预处理会从 0001 重新生成图片，可能让已有 X-AnyLabeling JSON 与图片错位。`r`n" +
                "只有确认这是全新的数据集，或已完整备份并准备重新标注时才继续。`r`n`r`n确定运行？") -f $existing, $existingJson
        if (-not (Confirm-Action $msg '覆盖已有 images\')) {
            Log '  已取消预处理。'
            return
        }
    }

    Log '=== 步骤 1/4  预处理 ==='
    Log ('  输入: ' + $script:Cfg.RawDir)
    Log ('  输出: ' + $imgDir)
    $r = Invoke-Captured {
        Invoke-Preprocess -InDir $script:Cfg.RawDir -OutRoot $script:Cfg.DatasetRoot
    }
    if ($r.Count -gt 0) {
        Log ('  完成: {0} 张；亮度告警 {1} 张。' -f $r[0].Count, $r[0].WarnCount)
    }
    $script:Cfg.RunsRoot = Join-Path $script:Cfg.DatasetRoot 'runs'
    if ($script:UI.RunsRoot) { $script:UI.RunsRoot.Text = $script:Cfg.RunsRoot }
    Save-Config
}

function Run-LabelCheck {
    if (-not (Ensure-LabelMappingFromGui)) {
        return
    }

    $n = Get-NativeLabelSummary $script:Cfg.DatasetRoot
    $map = Get-ClassMapTable ([string]$script:Cfg.ClassMap)
    Log '=== 检查 X-AnyLabeling 原生标注 ==='
    Log ("  图片 {0} 张；有 JSON {1} 张；有框 {2} 张；空场景 {3} 张；缺 JSON {4} 张；坏 JSON {5} 张。" -f
         $n.Images, $n.WithJson, $n.WithShapes, $n.EmptyShapes, $n.MissingJson, $n.BadJson)
    $unknown = @()
    foreach ($k in @($n.LabelCounts.Keys)) {
        $count = $n.LabelCounts[$k]
        Log ("  标签 '{0}'：{1} 个框" -f $k, $count)
        if (-not $map.ContainsKey([string]$k)) { $unknown += [string]$k }
    }
    if ($unknown.Count -gt 0) {
        Log ('!! ClassMap 缺少这些标签: ' + ($unknown -join ', '))
        Log '   必须先补全 ClassMap，否则导入时这些框会被跳过。'
    } else {
        Log '  OK：原生 JSON 里出现的所有标签名都在 ClassMap 中。'
    }
    if ($n.MissingJson -gt 0) {
        Log ("  提示：{0} 张图片还没有同名 JSON。未标注图片不会进入训练；空场景请保存 shapes=[]。" -f $n.MissingJson)
    }
    $internal = Get-InternalLabelSummary $script:Cfg.DatasetRoot
    Log ("  当前内部标签：{0} 个文件，有目标 {1}，空场景 {2}，框 {3}，坏文件 {4}。" -f
         $internal.Files, $internal.Positive, $internal.Empty, $internal.Boxes, $internal.Bad)
    Save-Config
}

function Run-XanyImport2b {
    if (-not (Ensure-LabelMappingFromGui)) {
        return
    }

    $n = Get-NativeLabelSummary $script:Cfg.DatasetRoot
    if ($n.Images -eq 0) {
        Log '!! images\ 里没有图片。'
        return
    }
    if ($n.WithJson -eq 0) {
        Log '!! images\ 里没有与图片同名的 X-AnyLabeling JSON。'
        return
    }
    $map = Get-ClassMapTable ([string]$script:Cfg.ClassMap)
    $unknown = @()
    foreach ($k in @($n.LabelCounts.Keys)) {
        if (-not $map.ContainsKey([string]$k)) { $unknown += [string]$k }
    }
    if ($unknown.Count -gt 0) {
        Log ('!! 导入已停止。ClassMap 缺少标签: ' + ($unknown -join ', '))
        Log '   请补全 ClassMap 后重新导入；本向导不会把未知标签自动映射到 class 0。'
        return
    }

    Log '=== 步骤 2/4  导入 X-AnyLabeling 原生 JSON（仅 2b）==='
    Log ('  images : ' + (Join-Path $script:Cfg.DatasetRoot 'images'))
    Log ('  labels : ' + (Join-Path $script:Cfg.DatasetRoot 'labels'))
    Log ('  classes: ' + $script:Cfg.Classes)
    Log ('  map    : ' + $script:Cfg.ClassMap)
    $wd = if ($script:Root -and (Test-Path -LiteralPath $script:Root)) { $script:Root } else { $PSScriptRoot }
    $argv = @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $script:ImportScript,
        '-ImgDir', (Join-Path $script:Cfg.DatasetRoot 'images'),
        '-NumClass', [string][int]$script:Cfg.Classes,
        '-ClassMap', [string]$script:Cfg.ClassMap,
        '-KeepEmpty'
    )
    $r = Invoke-Stream 'powershell.exe' $argv $wd
    if ($r.Code -ne 0) {
        if ($r.Cancelled) { Log '!! 导入已停止。' } else { Log ('!! X-AnyLabeling 导入失败（退出码 ' + $r.Code + '）。') }
        return
    }

    Write-DatasetYaml $script:Cfg.DatasetRoot ([int]$script:Cfg.Classes) ([string]$script:Cfg.ClassMap)
    $internal = Get-InternalLabelSummary $script:Cfg.DatasetRoot
    Log ("  OK：内部标签 {0} 个；有目标 {1}；空场景 {2}；框 {3}；坏文件 {4}。" -f
         $internal.Files, $internal.Positive, $internal.Empty, $internal.Boxes, $internal.Bad)
    Log ('  dataset.yaml: ' + (Join-Path $script:Cfg.DatasetRoot 'dataset.yaml'))
    Log ('  报告: ' + (Join-Path $script:Cfg.DatasetRoot 'report\import_xanylabeling.txt'))
    Save-Config
}

function Test-TrainingCoreOutputs([string]$versionDir, [bool]$expectOnnx) {
    $required = @(
        'weights\cnn_weights.dat',
        'quant\quant_params.entries.json',
        'model\model.pt',
        'deploy\deploy_manifest.json',
        'deploy\cnn_contract.bundle.json',
        'deploy\cnn_weights.dat',
        'deploy\quant_params.entries.json',
        'model_card.json',
        'meta.json'
    )
    if ($expectOnnx) { $required += 'model\model.onnx' }
    $missing = @()
    foreach ($rel in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $versionDir $rel))) { $missing += $rel }
    }
    if ($missing.Count -gt 0) {
        Log ('!! 训练返回成功，但输出不完整，缺少: ' + ($missing -join ', '))
        return $false
    }
    Log '  OK：model.pt / deploy 包 / 量化权重 / ONNX（若勾选）均存在。'
    return $true
}

function Run-TrainFromUi {
    Sync-UiToConfig
    $root = Resolve-ProjectRoot $script:Cfg.ProjectRoot
    if (-not $root) {
        Log '!! 工程本体无效：必须包含 td_project 和 user_source。'
        return
    }
    $script:Root = $root
    $env:QIANSAI_PROJECT = $root
    if (-not (Test-DatasetRoot $script:Cfg.DatasetRoot)) {
        Log '!! 数据集根无效。'
        return
    }
    $contract = Get-NormalizedFullPath $script:Cfg.ContractPath $root
    $bundledEdgeContract = Join-Path $PSScriptRoot 'configs\cnn_contract.edge.json'
    $edgeMode = [string]$script:Cfg.EdgeMode
    if ($edgeMode -eq 'density') {
        $contractEdge = $false
        if (Test-Path -LiteralPath $contract -PathType Leaf) {
            try {
                $contractData = Get-Content -LiteralPath $contract -Raw -Encoding UTF8 | ConvertFrom-Json
                $contractEdge = (@($contractData.input_frame.channel_order)[-1] -ne 'PAD')
            } catch { }
        }
        if ((-not $contractEdge) -and (Test-Path -LiteralPath $bundledEdgeContract -PathType Leaf)) {
            $contract = $bundledEdgeContract
            Log ('  项目契约仍为 PAD，本次边缘训练改用包内契约: ' + $contract)
        }
    }
    if (-not (Test-Path -LiteralPath $contract -PathType Leaf)) {
        Log ('!! CNN 契约文件不存在: ' + $contract)
        return
    }
    if (-not (Test-RunsRoot $script:Cfg.RunsRoot)) {
        Log '!! 训练输出父目录无效：不要选版本目录或 model/weights/deploy 等子目录。'
        return
    }
    $classes = [int]$script:Cfg.Classes
    if (-not (Validate-ClassMap ([string]$script:Cfg.ClassMap) $classes)) {
        Log '!! ClassMap 无效，请先回第 2 步修正。'
        return
    }
    $py = Resolve-Python
    if (-not $py) {
        Log '!! 找不到 python.exe。请设置 PYTHON_EXE、加入 PATH，或安装到常见位置。'
        return
    }

    $runsRoot = Get-NormalizedFullPath $script:Cfg.RunsRoot $root
    $versionDir = Get-NextVersionDir $runsRoot $script:Cfg.Tag
    New-Item -ItemType Directory -Force -Path $versionDir | Out-Null
    Log '=== 步骤 3/4  训练 + 量化 + 导出模型 ==='
    Log ('  python  : ' + $py)
    Log ('  数据集  : ' + $script:Cfg.DatasetRoot)
    Log ('  契约    : ' + $contract)
    Log ('  输出父目录: ' + $runsRoot)
    Log ('  本次版本: ' + $versionDir)

    $argv = @(
        '-u', $script:TrainScript,
        '--data', $script:Cfg.DatasetRoot,
        '--contract', $contract,
        '--out', $versionDir,
        '--epochs', [string][int]$script:Cfg.Epochs,
        '--batch', [string][int]$script:Cfg.Batch,
        '--lr', [string]([double]$script:Cfg.LearningRate),
        '--box-weight', [string]([double]$script:Cfg.BoxWeight),
        '--grayscale-prob', [string]([double]$script:Cfg.GrayscaleProb),
        '--empty-weight', [string]([double]$script:Cfg.EmptyWeight),
        '--qat', $(if ([int]$script:Cfg.QATEpochs -gt 0) { 'on' } else { 'off' }),
        '--qat-epochs', [string][int]$script:Cfg.QATEpochs,
        '--qat-lr', [string]([double]$script:Cfg.QATLearningRate),
        '--edge-mode', [string]$script:Cfg.EdgeMode,
        '--edge-threshold', [string][int]$script:Cfg.EdgeThreshold,
        '--classes', [string]$classes,
        '--val-ratio', [string]([double]$script:Cfg.ValRatio),
        '--model-name', [string]$script:Cfg.Tag,
        '--export-bundle'
    )
    if (-not [string]::IsNullOrWhiteSpace([string]$script:Cfg.SplitManifest)) {
        $splitPath = Get-NormalizedFullPath $script:Cfg.SplitManifest $root
        if (-not (Test-Path -LiteralPath $splitPath -PathType Leaf)) {
            Log ('!! 固定划分清单不存在: ' + $splitPath)
            return
        }
        $argv += @('--split-manifest', $splitPath)
    }
    if ($script:UI.ExportOnnx.Checked) { $argv += '--export-onnx' }
    $r = Invoke-Stream $py $argv $root
    Show-Summary $r.Text
    if ($r.Code -ne 0) {
        if ($r.Cancelled) {
            Log ('!! 训练已停止，保留未完成目录: ' + $versionDir)
        } else {
            Log ('!! 训练失败（退出码 ' + $r.Code + '）：' + $versionDir)
        }
        return
    }

    $ok = Test-TrainingCoreOutputs $versionDir ([bool]$script:UI.ExportOnnx.Checked)
    $versionText = @(
        ('version   = ' + (Split-Path -Leaf $versionDir)),
        ('tag       = ' + $script:Cfg.Tag),
        ('time      = ' + (Get-Date).ToString('s')),
        ('dataset   = ' + $script:Cfg.DatasetRoot),
        ('contract  = ' + $contract),
        ('classes   = ' + $classes),
        ('class_map = ' + $script:Cfg.ClassMap),
        ('epochs    = ' + $script:Cfg.Epochs),
        ('batch     = ' + $script:Cfg.Batch),
        ('lr        = ' + $script:Cfg.LearningRate),
        ('box_weight= ' + $script:Cfg.BoxWeight),
        ('gray_prob = ' + $script:Cfg.GrayscaleProb),
        ('empty_weight = ' + $script:Cfg.EmptyWeight),
        ('qat_epochs= ' + $script:Cfg.QATEpochs),
        ('qat_lr    = ' + $script:Cfg.QATLearningRate),
        ('edge_mode = ' + $script:Cfg.EdgeMode),
        ('edge_threshold = ' + $script:Cfg.EdgeThreshold),
        ('split_manifest = ' + $script:Cfg.SplitManifest),
        ('val_ratio = ' + $script:Cfg.ValRatio),
        ('onnx      = ' + [bool]$script:UI.ExportOnnx.Checked)
    )
    Set-Content -LiteralPath (Join-Path $versionDir 'VERSION') -Value $versionText -Encoding UTF8
    if (-not $ok) { return }

    $script:LastRunDir = $versionDir
    $script:Cfg.ModelDir = $versionDir
    if ($script:UI.ModelDir) { $script:UI.ModelDir.Text = $versionDir }
    Update-DeployStatus
    Log ('  训练完成。完整版本目录: ' + $versionDir)
    Log '  可把整个版本目录发给队友；不要只发 model\ 或 deploy\。'
    Save-Config
}

function Run-ModelDryRun {
    if ($script:UI.DeployProject -and -not [string]::IsNullOrWhiteSpace($script:UI.DeployProject.Text)) {
        $selectedProject = $script:UI.DeployProject.Text.Trim()
        $script:UI.ProjectRoot.Text = $selectedProject
        $script:UI.ContractPath.Text = Join-Path $selectedProject 'user_source\hdl_source\cnn\cnn_contract.json'
    }
    Sync-UiToConfig
    $root = Resolve-ProjectRoot $script:Cfg.ProjectRoot
    if (-not $root) {
        Log '!! 目标工程本体无效：必须包含 td_project 和 user_source。'
        return
    }
    $py = Resolve-Python
    if (-not $py) { Log '!! 找不到 python.exe。'; return }
    $ver = Resolve-VersionInput $script:Cfg.ModelDir
    if (-not $ver) { return }
    $script:Cfg.ModelDir = $ver
    if ($script:UI.ModelDir) { $script:UI.ModelDir.Text = $ver }

    Log '=== 检查模型包（只读 dry-run）==='
    Log ('  模型版本: ' + $ver)
    Log ('  目标工程: ' + $root)
    if (Test-Path -LiteralPath (Join-Path $ver 'deploy\deploy_manifest.json')) {
        $r = Invoke-Stream $py @(
            '-u', $script:DeployBundleScript,
            '--bundle', $ver,
            '--project', $root,
            '--dry-run'
        ) $root
        if ($r.Code -ne 0) {
            Log '!! 模型包检查未通过。重点看 contract geometry 是否 MATCH。'
            return
        }
        Log '  OK：模型包完整，且目标工程契约几何检查通过。'
    } else {
        Log '  这是旧布局（weights + quant），没有 deploy_manifest.json；后续将走 train_cnn.py --install。'
        if (-not (Test-Path -LiteralPath (Join-Path $ver 'weights\cnn_weights.dat'))) {
            Log '!! 旧布局也缺 weights\cnn_weights.dat。'
            return
        }
    }
    Update-DeployStatus
    Save-Config
}

function Run-DeployFromUi {
    if ($script:UI.DeployProject -and -not [string]::IsNullOrWhiteSpace($script:UI.DeployProject.Text)) {
        $selectedProject = $script:UI.DeployProject.Text.Trim()
        $script:UI.ProjectRoot.Text = $selectedProject
        $script:UI.ContractPath.Text = Join-Path $selectedProject 'user_source\hdl_source\cnn\cnn_contract.json'
    }
    Sync-UiToConfig
    $root = Resolve-ProjectRoot $script:Cfg.ProjectRoot
    if (-not $root) {
        Log '!! 目标工程本体无效：必须包含 td_project 和 user_source。'
        return
    }
    $py = Resolve-Python
    if (-not $py) { Log '!! 找不到 python.exe。'; return }
    $ver = Resolve-VersionInput $script:Cfg.ModelDir
    if (-not $ver) { return }
    $mode = 'verify'
    if ($script:UI.ModeInstall.Checked) { $mode = 'install' }
    elseif ($script:UI.ModeBit.Checked) { $mode = 'bit' }
    $modeText = @{
        install = '只安装权重（跳过 ModelSim）'
        verify = '安装 + ModelSim 验收'
        bit = '安装 + ModelSim 验收 + TD P&R 编译 bit'
    }[$mode]
    $msg = ("模型版本: {0}`r`n目标工程: {1}`r`n动作: {2}`r`n目标门限: {3}`r`n`r`n" +
            "这会修改目标工程的 CNN 权重、qparam 和生成文件。继续？") -f $ver, $root, $modeText, $script:Cfg.Threshold
    if (-not (Confirm-Action $msg '开始部署')) {
        Log '  已取消部署。'
        return
    }

    Log '=== 步骤 4/4  部署 ==='
    Log ('  模型版本: ' + $ver)
    Log ('  目标工程: ' + $root)
    Log ('  动作: ' + $modeText)
    Log ('  目标门限: ' + $script:Cfg.Threshold)
    $argv = @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $script:DeployScript,
        '-Out', $ver,
        '-ProjectRoot', $root,
        '-Threshold', [string]$script:Cfg.Threshold,
        '-Python', $py
    )
    if ($mode -eq 'install') { $argv += '-NoVerify' }
    if ($mode -eq 'bit') { $argv += '-Pnr' }
    $r = Invoke-Stream 'powershell.exe' $argv $root
    Show-Summary $r.Text
    Update-DeployStatus
    if ($r.Code -ne 0) {
        if ($r.Cancelled) { Log '!! 部署已停止。' } else { Log ('!! 部署失败（退出码 ' + $r.Code + '）。') }
        return
    }

    $burn = Join-Path $ver 'burn'
    $weights = Join-Path $burn 'cnn_weights.dat'
    if (-not (Test-Path -LiteralPath $weights)) {
        Log ('!! 部署脚本返回成功，但未找到 ' + $weights)
        return
    }
    Log ('  OK：部署产物目录: ' + $burn)
    if ($mode -eq 'bit') {
        $bit = Join-Path $burn 'camera_to_dsi_display.bit'
        if (Test-Path -LiteralPath $bit) {
            Log ('  OK：比特流: ' + $bit)
        } else {
            Log '!! 已要求编译 bit，但没有找到 camera_to_dsi_display.bit。'
        }
    } elseif ($mode -eq 'install') {
        Log '  权重/qparam/ROM 已安装；尚未跑 ModelSim 验收。'
    } else {
        Log '  ModelSim 逐层逐字对拍已通过（以部署脚本退出码和 PASS 日志为准）。'
        Log '  上板前仍需另跑 TD P&R 生成新 bit，或改用“安装 + 验收 + 编译 bit”。'
    }
    Update-DeployStatus
    Save-Config
}

function Invoke-WizardSelfTest {
    $savedStep = $script:Step
    $savedDataset = [string]$script:UI.DatasetRoot.Text
    $script:Step = 1
    $script:UI.DatasetRoot.Text = ''
    $script:UI.DeployOnly.Checked = $true
    $deployOnlyBypass = Test-StepBeforeNext
    $script:UI.DeployOnly.Checked = $false
    $script:UI.DatasetRoot.Text = $savedDataset
    $script:Step = $savedStep

    $td = Join-Path $env:TEMP ('dataset_wizard_selftest_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
    $imgDir = Join-Path $td 'images'
    New-Item -ItemType Directory -Force -Path $imgDir | Out-Null
    Log '=== SelfTest: X-AnyLabeling 2b only ==='
    Log ('  临时目录: ' + $td)

    $samples = @(
        @{ Name = 'S01_starve_0001'; Label = 'starve'; Empty = $false },
        @{ Name = 'S01_genshin_0001'; Label = 'genshin'; Empty = $false },
        @{ Name = 'S01_empty_0001'; Label = ''; Empty = $true }
    )
    foreach ($s in $samples) {
        $imgPath = Join-Path $imgDir ($s.Name + '.jpg')
        $bmp = New-Object System.Drawing.Bitmap 1280, 720
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.Clear([System.Drawing.Color]::FromArgb(80, 100, 120))
        $g.FillRectangle([System.Drawing.Brushes]::Orange, 320, 160, 360, 360)
        $g.Dispose()
        $bmp.Save($imgPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        $bmp.Dispose()

        $shapes = @()
        if (-not $s.Empty) {
            $shapes = @([pscustomobject]@{
                label = $s.Label
                shape_type = 'rectangle'
                points = @(@(320.0, 160.0), @(680.0, 520.0))
            })
        }
        $native = [pscustomobject]@{
            imagePath = ($s.Name + '.jpg')
            imageWidth = 1280
            imageHeight = 720
            shapes = $shapes
        }
        $jsonPath = Join-Path $imgDir ($s.Name + '.json')
        [System.IO.File]::WriteAllText(
            $jsonPath,
            ($native | ConvertTo-Json -Depth 8),
            (New-Object System.Text.UTF8Encoding($false)))
    }

    $script:UI.DatasetRoot.Text = $td
    $script:UI.Classes.Value = [decimal]1
    $script:Cfg.DatasetRoot = $td
    $script:Cfg.Classes = 1
    $script:Cfg.ClassMap = ''
    $scanOk = Scan-LabelMapping
    $map = [string]$script:Cfg.ClassMap
    $mapOk = Validate-ClassMap $map 2
    $badMapRejected = -not (Validate-ClassMap 'starve=0' 2)
    $gridRows = if ($script:UI.MappingGrid) { $script:UI.MappingGrid.Rows.Count } else { 0 }
    $gridSummaryHasMap = ([string]$script:UI.MappingSummary.Text -match 'starve=0')
    Run-XanyImport2b
    $root = $td
    $summary = Get-DataSummary $root
    $internal = Get-InternalLabelSummary $root
    $routeOnly2b = ([string]$script:UI.ImportRouteText.Text -match 'X-AnyLabeling 2b')
    $packageRoot = Split-Path -Parent $PSScriptRoot
    $packageInfo = Get-ModelVersionInfo $packageRoot
    $savedModelDir = [string]$script:Cfg.ModelDir
    $deployStatusText = ''
    if ($packageInfo) {
        $script:UI.ModelDir.Text = $packageInfo.Path
        Update-DeployStatus
        $deployStatusText = [string]$script:UI.DeployStatus.Text
        $script:UI.ModelDir.Text = $savedModelDir
    }

    $checks = [ordered]@{
        '仅部署模式跳过数据集检查' = [bool]$deployOnlyBypass
        'GUI 扫描标签成功' = [bool]$scanOk
        'GUI 自动把类别数从 1 调到 2' = ([int]$script:UI.Classes.Value -eq 2)
        'GUI 映射表生成 2 行' = ($gridRows -eq 2)
        'GUI 映射预览显示结果' = $gridSummaryHasMap
        'ClassMap 两类别通过' = [bool]$mapOk
        'ClassMap 缺类别被拒绝' = [bool]$badMapRejected
        'GUI 2b 导入完成' = (Test-Path -LiteralPath (Join-Path $root 'labels\S01_starve_0001.json'))
        '图片 3 / 内部标签 3' = (($summary.Images -eq 3) -and ($summary.Labels -eq 3))
        '正样本 2' = ($summary.Positive -eq 2)
        '空场景 1' = ($summary.Empty -eq 1)
        '类别分布 0/1 都有' = ($internal.Classes.ContainsKey(0) -and $internal.Classes.ContainsKey(1))
        'dataset.yaml 已生成' = (Test-Path -LiteralPath (Join-Path $root 'dataset.yaml'))
        '导入页使用 X-AnyLabeling 2b 路线' = $routeOnly2b
    }
    if ($packageInfo) {
        $checks['部署页可识别当前模型包'] = ($packageInfo.Path -eq (Resolve-Path -LiteralPath $packageRoot).Path)
        $checks['部署页识别门限 131'] = ($packageInfo.Threshold -eq 131)
        $checks['部署页识别权重时间'] = ($null -ne $packageInfo.WeightUpdated)
        $checks['部署页状态即时显示模型/门限'] =
            ($deployStatusText -match [regex]::Escape($packageInfo.Name)) -and
            ($deployStatusText -match '131')
        $checks['部署页识别边缘第四通道'] =
            ($packageInfo.EdgeMode -eq 'density') -and
            ($packageInfo.EdgeThreshold -eq 80) -and
            ($deployStatusText -match 'EDGE@80')
        $checks['训练页边缘参数已同步'] =
            ($script:UI.EdgeMode -and ([string]$script:UI.EdgeMode.SelectedItem -eq 'density')) -and
            ($script:UI.EdgeThreshold -and ([int]$script:UI.EdgeThreshold.Value -eq 80))
        $checks['部署页显示BIT/BIN状态'] =
            ($deployStatusText -match 'BIT') -and ($deployStatusText -match 'BIN')
        $candidatePaths = @(Get-AvailableModelVersions | ForEach-Object { $_.Path })
        $checks['自动跟随包含当前模型包'] = $candidatePaths -contains $packageInfo.Path
        $globalRuns = Join-Path (
            Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
        ) 'runs'
        $latestGlobalRun = Get-LatestVersionDir $globalRuns
        if ($latestGlobalRun) {
            $checks['自动跟随扫描Versions\runs'] = $candidatePaths -contains $latestGlobalRun
        }
    }
    $failed = @()
    foreach ($k in $checks.Keys) {
        if ($checks[$k]) { Log ('  PASS ' + $k) } else { Log ('  FAIL ' + $k); $failed += $k }
    }
    if ($failed.Count -eq 0) {
        Log 'SELFTEST PASS'
        return 0
    }
    Log ('SELFTEST FAIL: ' + ($failed -join '; '))
    return 2
}

# ---------------------------------------------------------------- startup
$env:QIANSAI_PROJECT = [string]$script:Cfg.ProjectRoot
Show-Step 1
Refresh-DerivedUi
Save-Config

Log ('配置文件: ' + $script:ConfigPath)
Log ('工程本体: ' + $(if ($script:Cfg.ProjectRoot) { $script:Cfg.ProjectRoot } else { '<未选择>' }))
Log ('数据集  : ' + $(if ($script:Cfg.DatasetRoot) { $script:Cfg.DatasetRoot } else { '<未选择>' }))
Log ('训练输出: ' + $(if ($script:Cfg.RunsRoot) { $script:Cfg.RunsRoot } else { '<未选择>' }))
$py0 = Resolve-Python
if ($py0) { Log ('python  : ' + $py0) } else { Log 'python  : 未找到（训练会失败）' }
Log '就绪。第 2 步仅支持 X-AnyLabeling 原生 JSON（2b）。'

if ($SelfTest) {
    $code = Invoke-WizardSelfTest
    exit $code
}

[void]$form.ShowDialog()
