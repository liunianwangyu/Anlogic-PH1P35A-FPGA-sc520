# SC520 dataset1027 grayscale20 model training

Training run: `dataset1027_gray20_empty3_accuracy_v1`

Dataset root: `D:\Works\QianSai\Versions\datasets\dataset1027`

```text
Input: 4x90x160 (R,G,B,PAD)
Classes: starve=0, genshin=1
Training: 2727 images, validation: 395, locked test: 1848
Base epochs: 100, best epoch: 50
QAT epochs: 40, best epoch: 15
Grayscale augmentation: 20% with (R>>2)+(G>>1)+(B>>2)
Empty-frame sampling weight: 3.0
```

Reproduce from the packaged scripts with a frozen split manifest and the same seed. Do not tune against the locked S01 test split.
