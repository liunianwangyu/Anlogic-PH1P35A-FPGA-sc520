# model&scripts_v2.4-8

This package contains the trained model, training scripts, the current FPGA BIT, the threshold-131 MCU BIN, and evaluation evidence.

## GUI

Launch `scripts\run_dataset_wizard.cmd` to use the retained four-step GUI:

1. Paths and preprocessing
2. Label import
3. Training and export
4. Weight deployment

The deployment page follows the newest trained model by default, shows the current weight/BIT/BIN timestamps and threshold state, refreshes when the selection changes, and passes the selected threshold to `deploy_cnn.ps1`.

## Deployment

Use the existing one-click script `scripts/deploy_cnn.ps1`, or the GUI deployment page which invokes that same entry point. It synchronizes the selected threshold, installs weights/qparams, generates the four RTL weight images, checks the contract, runs ModelSim, and with `-Pnr` rebuilds the FPGA BIT.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8\scripts\deploy_cnn.ps1' -Out 'D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8' -ProjectRoot '<PROJECT_ROOT>' -Pnr
```

The same script can run on a copied/new project tree. It requires the target project's `tools/cnn_contract.py`, ModelSim, TD, and Python. The package includes the helper scripts used by `deploy_cnn.ps1`.

Prebuilt programming files are in `burn/`; `SHA256SUMS.txt` records their hashes.

Physical-board acceptance remains `NOT_RUN`.
