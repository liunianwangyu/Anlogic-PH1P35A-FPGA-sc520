#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Board-aligned edge-density feature for the fourth CNN input channel.

The feature follows the existing ISP edge path:
  RGB888 -> board Gaussian -> pairwise luma downsample
  -> robust 3x3 median Sobel -> fixed threshold
  -> one edge-density value per 8x8 source tile.

No edge annotations or cached edge-image dataset are required.  Call
``edge_density8`` on the final augmented 1280x720 RGB image so that training
and deployment use the same intensity domain.
"""

import numpy as np


SOURCE_WIDTH = 1280
SOURCE_HEIGHT = 720
FEATURE_WIDTH = 160
FEATURE_HEIGHT = 90
DEFAULT_EDGE_THRESHOLD = 80


def median3(a, b, c):
    """Elementwise median of three arrays using min/max comparators."""
    return np.maximum(np.minimum(a, b),
                      np.minimum(np.maximum(a, b), c))


def board_gaussian_rgb(rgb):
    """Match gaussian_rgb4's integer 3x3 Gaussian and causal crop."""
    rgb = np.asarray(rgb)
    if rgb.shape != (SOURCE_HEIGHT, SOURCE_WIDTH, 3):
        raise ValueError("expected RGB image shape (720,1280,3), got %r" %
                         (rgb.shape,))

    a = rgb.astype(np.int32, copy=False)
    rank = a.copy()
    rank[:, 2:] = median3(a[:, :-2], a[:, 1:-1], a[:, 2:])
    horizontal = rank[:, :-2] + 2 * rank[:, 1:-1] + rank[:, 2:]
    out = a.copy()
    out[2:, 4:] = (
        horizontal[:-2, 2:]
        + 2 * horizontal[1:-1, 2:]
        + horizontal[2:, 2:]
        + 8
    ) >> 4
    return out.astype(np.uint8)


def edge_density8(rgb, threshold=DEFAULT_EDGE_THRESHOLD):
    """Return a 90x160 int8 edge-density map in the range 0..127.

    The existing RTL edge path emits two samples per four-pixel beat.  An
    original 8x8 tile therefore contains four horizontal samples per row and
    eight rows, for 32 binary samples.  Multiplying by four maps the maximum
    32 hits to 128, then clamps to the signed positive maximum 127.
    """
    if not 0 <= int(threshold) <= 4095:
        raise ValueError("edge threshold must be in 0..4095")

    a = board_gaussian_rgb(rgb).astype(np.int32, copy=False)
    gray = (a[:, :, 0] >> 2) + (a[:, :, 1] >> 1) + (a[:, :, 2] >> 2)
    sampled = (gray[:, ::2] + gray[:, 1::2]) >> 1

    left = median3(sampled[:-2, :-2],
                   sampled[1:-1, :-2],
                   sampled[2:, :-2])
    right = median3(sampled[:-2, 2:],
                    sampled[1:-1, 2:],
                    sampled[2:, 2:])
    top = median3(sampled[:-2, :-2],
                  sampled[:-2, 1:-1],
                  sampled[:-2, 2:])
    bottom = median3(sampled[2:, :-2],
                     sampled[2:, 1:-1],
                     sampled[2:, 2:])

    magnitude = np.zeros_like(sampled)
    valid = np.zeros_like(sampled, dtype=bool)
    magnitude[2:, 2:] = 4 * (
        np.abs(right - left) + np.abs(top - bottom)
    )
    valid[2:, 2:] = True

    hits = valid & (magnitude >= int(threshold))
    counts = hits.reshape(
        FEATURE_HEIGHT, 8, FEATURE_WIDTH, 4
    ).sum(axis=(1, 3))
    return np.minimum(counts * 4, 127).astype(np.int8)


def feature_metadata(threshold=DEFAULT_EDGE_THRESHOLD):
    return {
        "mode": "edge_density_8x8",
        "source": "augmented_rgb1280x720_before_8x8_box_mean",
        "filter": "board_gaussian_then_robust_median_sobel",
        "edge_threshold": int(threshold),
        "samples_per_tile": 32,
        "scale": 4,
        "clamp": [0, 127],
        "dtype": "int8_nonnegative",
    }


__all__ = [
    "DEFAULT_EDGE_THRESHOLD",
    "board_gaussian_rgb",
    "edge_density8",
    "feature_metadata",
    "median3",
]
