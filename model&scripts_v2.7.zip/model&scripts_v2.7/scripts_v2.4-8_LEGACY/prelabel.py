#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
prelabel.py -- 用训练好的 model_fp32.pt 给图片做"预标注"，直接产出 X-AnyLabeling 的 json

特点：
  · 预处理与训练完全一致（直接复用 train_cnn.load_frame：1280x720 -> 8x8 均值 -> 160x90x4）
  · 输出是 X-AnyLabeling 原生格式（shapes + points），打开文件夹即可看到框
  · 默认每个目标只给 1 个框（top-1），避免一堆误检

用法：
    python prelabel.py --model <run>\weights\model_fp32.pt --images <图片目录>
    python prelabel.py --model ... --images ... --out <输出目录> --copy-images --topk 1 --thr 0.0

注意：
    · 默认输出到 <图片目录>\_prelabel，不会覆盖你已有的同名 json
    · --copy-images 会把图片一起复制到输出目录，方便直接把该目录丢给 X-AnyLabeling
"""
import argparse, json, shutil, sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import train_cnn as T   # 复用 Net / load_frame / 常量


def decode_head(y, thr=0.0, topk=1, W=1280, H=720, cell_w=64, cell_h=60, min_px=16):
    """y: (8,12,20) float -> [{'x1','y1','x2','y2','obj'}]（按 obj 降序，含简单 NMS）"""
    obj = y[0]
    cand = []
    for gy in range(obj.shape[0]):
        for gx in range(obj.shape[1]):
            o = float(obj[gy, gx])
            if o < thr:
                continue
            dx, dy = float(y[1, gy, gx]), float(y[2, gy, gx])
            w_i, h_i = float(y[3, gy, gx]), float(y[4, gy, gx])
            cx = gx * cell_w + cell_w / 2.0 + dx / 2.0     # dx 单位 0.5 像素
            cy = gy * cell_h + cell_h / 2.0 + dy / 2.0
            w_px = max(w_i * 8.0, min_px)                  # w/h 单位 8 像素
            h_px = max(h_i * 8.0, min_px)
            x1, y1 = cx - w_px / 2.0, cy - h_px / 2.0
            x2, y2 = cx + w_px / 2.0, cy + h_px / 2.0
            x1 = max(0.0, min(W - 1.0, x1)); x2 = max(0.0, min(W - 1.0, x2))
            y1 = max(0.0, min(H - 1.0, y1)); y2 = max(0.0, min(H - 1.0, y2))
            if x2 - x1 < 1 or y2 - y1 < 1:
                continue
            cand.append(dict(x1=x1, y1=y1, x2=x2, y2=y2, obj=o))
    cand.sort(key=lambda d: d['obj'], reverse=True)

    def iou(a, b):
        ix = max(0.0, min(a['x2'], b['x2']) - max(a['x1'], b['x1']))
        iy = max(0.0, min(a['y2'], b['y2']) - max(a['y1'], b['y1']))
        inter = ix * iy
        ua = (a['x2'] - a['x1']) * (a['y2'] - a['y1']) + (b['x2'] - b['x1']) * (b['y2'] - b['y1']) - inter
        return inter / ua if ua > 0 else 0.0

    keep = []
    for c in cand:
        if all(iou(c, k) <= 0.5 for k in keep):
            keep.append(c)
        if len(keep) >= topk:
            break
    return keep


def xany_json(name, boxes, label, W=1280, H=720):
    shapes = []
    for b in boxes:
        pts = [[round(b['x1'], 1), round(b['y1'], 1)],
               [round(b['x2'], 1), round(b['y1'], 1)],
               [round(b['x2'], 1), round(b['y2'], 1)],
               [round(b['x1'], 1), round(b['y2'], 1)]]
        shapes.append(dict(label=label, score=None, points=pts, group_id=None,
                           description='obj=%.2f' % b['obj'], difficult=False,
                           shape_type='rectangle', flags={}, attributes={}, kie_linking=[]))
    return dict(version='3.3.10', flags={}, shapes=shapes, imagePath=name,
                imageData=None, imageHeight=H, imageWidth=W)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--images', required=True)
    ap.add_argument('--out')
    ap.add_argument('--topk', type=int, default=1)
    ap.add_argument('--thr', type=float, default=0.0, help='obj logit 阈值（0 与 RTL 判定点一致）')
    ap.add_argument('--label', default='bear')
    ap.add_argument('--copy-images', action='store_true')
    ap.add_argument('--edge-mode', choices=['auto', 'zero', 'density'], default='auto',
                    help='auto reads the model training metadata')
    ap.add_argument('--edge-threshold', type=int,
                    help='Defaults to model metadata, else 80')
    a = ap.parse_args()

    mp = Path(a.model)
    if not mp.exists():
        raise SystemExit('model 不存在: %s' % mp)
    d = torch.load(mp, map_location='cpu', weights_only=False)
    training = d.get('training', {}) or {}
    edge_mode = training.get('edge_mode', 'zero') if a.edge_mode == 'auto' else a.edge_mode
    edge_feature = training.get('edge_feature') or {}
    edge_threshold = (a.edge_threshold if a.edge_threshold is not None
                      else int(edge_feature.get('edge_threshold', 80)))
    net = T.Net(d['layers'])
    net.load_state_dict(d['state_dict'])
    net.eval()
    print('模型: %s  (%d 张量)' % (mp.name, len(d['state_dict'])))

    img_dir = Path(a.images)
    out = Path(a.out) if a.out else (img_dir / '_prelabel')
    out.mkdir(parents=True, exist_ok=True)
    exts = {'.jpg', '.jpeg', '.png', '.bmp'}
    imgs = sorted(p for p in img_dir.iterdir() if p.suffix.lower() in exts)
    print('图片: %d 张 -> %s' % (len(imgs), out))
    if a.copy_images:
        print('  (同时复制图片到输出目录)')

    n_box = 0; n_empty = 0
    with torch.no_grad():
        for p in imgs:
            x = T.load_frame(
                str(p), edge_mode=edge_mode,
                edge_threshold=edge_threshold)              # (4,90,160) int8
            y = net(torch.from_numpy(x[None].astype(np.float32)))[0].numpy()
            boxes = decode_head(y, thr=a.thr, topk=a.topk)
            js = xany_json(p.name, boxes, a.label)
            (out / (p.stem + '.json')).write_text(json.dumps(js, ensure_ascii=False, indent=1),
                                                  encoding='utf-8')
            if a.copy_images:
                shutil.copyfile(p, out / p.name)
            n_box += len(boxes)
            if not boxes:
                n_empty += 1
            print('  %-12s boxes=%d%s' % (p.name, len(boxes),
                  '' if not boxes else '  obj=%.2f' % boxes[0]['obj']))
    print('完成: %d 张, %d 个框, %d 张空' % (len(imgs), n_box, n_empty))
    print('输出目录: %s' % out)


if __name__ == '__main__':
    main()
