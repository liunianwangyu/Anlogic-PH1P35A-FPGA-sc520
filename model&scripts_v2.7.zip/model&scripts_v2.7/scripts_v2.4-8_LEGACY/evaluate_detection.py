"""Detection metrics and the existing MCU Top-8/NMS/display reference.

Integer heads use the current firmware's raw class-byte ordering and unsigned
size-byte semantics. No scale conversion or tracking is silently introduced.
AP50 is all-points interpolated AP, with class-aware one-to-one IoU matching.
"""
import argparse
import json
from pathlib import Path
import numpy as np


def iou(a, b):
    inter = max(0, min(a[2], b[2])-max(a[0], b[0])+1) * max(0, min(a[3], b[3])-max(a[1], b[1])+1)
    aa = (a[2]-a[0]+1)*(a[3]-a[1]+1)
    bb = (b[2]-b[0]+1)*(b[3]-b[1]+1)
    return inter/max(aa+bb-inter, 1)


def decode_head(head, threshold=128, integer=True, num_classes=3):
    y = np.asarray(head)
    if y.shape != (8, 12, 20):
        raise ValueError('Expected head [8,12,20]')
    candidates = []
    winners = {}
    for cell in range(240):
        row, col = divmod(cell, 20)
        v = y[:, row, col]
        if float(v[0])+128 < threshold:
            continue
        w, h = ((int(v[3]) & 255), (int(v[4]) & 255)) if integer else (float(v[3]), float(v[4]))
        if w <= 0 or h <= 0:
            continue
        cls_count = max(1, min(int(num_classes), 3))
        cls = int(np.argmax(v[5:5 + cls_count]))
        score = float(v[5+cls])+128
        dx, dy = (int(v[1])//2, int(v[2])//2) if integer else (float(v[1])/2, float(v[2])/2)
        cx, cy = col*64+32+dx, row*60+30+dy
        box = [max(0, min(1279, cx-4*w)), max(0, min(719, cy-4*h)),
               max(0, min(1279, cx+4*w)), max(0, min(719, cy+4*h))]
        d = dict(cls=cls, score=score, box=box, cell=cell, obj=float(v[0])+128)
        candidates.append(d)
        if cls < 2 and (cls not in winners or score > winners[cls]['score']):
            winners[cls] = d
    candidates.sort(key=lambda d: (-d['score'], d['cell']))
    kept = []
    for d in candidates[:8]:
        if not any(k['cls'] == d['cls'] and iou(k['box'], d['box']) > .5 for k in kept):
            kept.append(d)
    return kept, [winners[k] for k in sorted(winners)]


def detection_metrics(records, class_ids=(0, 1)):
    """records: {pred: [{cls,score,box}], gt: [{cls,box}]} per image."""
    result = {}
    all_tp = all_fp = all_fn = 0
    empty = sum(not r['gt'] for r in records)
    empty_fp = sum(len(r['pred']) for r in records if not r['gt'])
    classes = sorted(set(class_ids) | {d['cls'] for r in records for d in r['pred']+r['gt']})
    for cls in classes:
        ngt = sum(sum(g['cls'] == cls for g in r['gt']) for r in records)
        preds = [(d['score'], i, j, d) for i, r in enumerate(records)
                 for j, d in enumerate(r['pred']) if d['cls'] == cls]
        preds.sort(key=lambda x: (-x[0], x[1], x[2]))
        matched = set()
        tp, fp = [], []
        for _, i, _, d in preds:
            choices = [(iou(d['box'], g['box']), k) for k, g in enumerate(records[i]['gt'])
                       if g['cls'] == cls and (i, k) not in matched]
            overlap, k = max(choices, default=(0, -1))
            ok = overlap >= .5
            if ok:
                matched.add((i, k))
            tp.append(int(ok)); fp.append(int(not ok))
        ntp, nfp = sum(tp), sum(fp)
        recall = np.cumsum(tp)/max(ngt, 1)
        precision = np.cumsum(tp)/np.maximum(np.cumsum(tp)+np.cumsum(fp), 1)
        rec = np.r_[0, recall, 1]
        pre = np.r_[0, precision, 0]
        pre = np.maximum.accumulate(pre[::-1])[::-1]
        ap = float(np.sum(np.diff(rec)*pre[1:])) if ngt else None
        result[str(cls)] = dict(tp=ntp, fp=nfp, fn=ngt-ntp, ap50=ap, gt=ngt)
        all_tp += ntp; all_fp += nfp; all_fn += ngt-ntp
    p = all_tp/max(all_tp+all_fp, 1); r = all_tp/max(all_tp+all_fn, 1)
    aps = [result[str(k)]['ap50'] for k in class_ids if result[str(k)]['ap50'] is not None]
    return dict(tp=all_tp, fp=all_fp, fn=all_fn, precision=p, recall=r,
                f1=2*p*r/max(p+r, 1e-12), map50=float(np.mean(aps)) if aps else 0.,
                per_class=result, empty_images=empty, empty_false_boxes=empty_fp,
                empty_fp_per_image=empty_fp/max(empty, 1),
                missing_gt_classes=[k for k in class_ids if result[str(k)]['gt'] == 0])


def evaluate_model(net, items, num_class=3, layers=None, contract=None,
                   threshold=128, grayscale=False,
                   edge_mode='zero', edge_threshold=80):
    import torch
    import train_cnn as tc
    records, display = [], []
    device = next(net.parameters()).device
    net.eval()
    with torch.no_grad():
        for ip, lp, _ in items:
            x = tc.load_frame(
                ip, force_grayscale=grayscale,
                edge_mode=edge_mode, edge_threshold=edge_threshold)
            if layers is None:
                xb = torch.from_numpy(x.astype(np.float32))[None].to(device)
                y = net(xb)[0].cpu().numpy()
            else:
                y = tc.integer_forward_fast(layers, x, contract['layers'])[-1]
            pred, shown = decode_head(y, threshold, integer=layers is not None,
                                      num_classes=num_class)
            boxes = tc.load_targets(lp, num_class)[-1]
            gt = [dict(cls=int(b['cls']), box=[b['x1'], b['y1'], b['x2'], b['y2']]) for b in boxes]
            records.append(dict(pred=pred, gt=gt)); display.append(dict(pred=shown, gt=gt))
    class_ids = tuple(range(int(num_class)))
    return dict(numerical=detection_metrics(records, class_ids=class_ids),
                display=detection_metrics(display, class_ids=class_ids),
                threshold_u8=threshold)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', required=True); ap.add_argument('--data', required=True)
    ap.add_argument('--split', choices=['val', 'test'], default='val')
    ap.add_argument('--threshold', type=int, default=128)
    ap.add_argument('--float', action='store_true', dest='floating')
    ap.add_argument('--grayscale', action='store_true',
                    help='Evaluate after the board RGB->gray conversion')
    ap.add_argument('--edge-mode', choices=['auto', 'zero', 'density'], default='auto',
                    help='Fourth channel; auto reads model training metadata')
    ap.add_argument('--edge-threshold', type=int,
                    help='Defaults to the threshold stored in model metadata, else 80')
    ap.add_argument('--output', required=True)
    ap.add_argument('--split-manifest', help='Use the same frozen data split when comparing the original bundle')
    a = ap.parse_args()
    import torch
    import train_cnn as tc
    run = Path(a.run)
    ckp = torch.load(run/'model/model.pt', map_location='cpu', weights_only=False)
    c = ckp['contract']; net = tc.build_net(c); net.load_state_dict(ckp['state_dict'])
    training = ckp.get('training', {}) or {}
    edge_mode = training.get('edge_mode', 'zero') if a.edge_mode == 'auto' else a.edge_mode
    edge_feature = training.get('edge_feature') or {}
    edge_threshold = (a.edge_threshold if a.edge_threshold is not None
                      else int(edge_feature.get('edge_threshold', 80)))
    items = tc.collect_dataset(Path(a.data), int(c['post']['num_class']))
    from training_policy import load_fixed_split, digest
    split_path = Path(a.split_manifest) if a.split_manifest else run/'split_manifest.json'
    parts = load_fixed_split(items, split_path)
    weights_path = run/'weights/cnn_weights.dat'
    if not weights_path.exists(): weights_path = run/'deploy/cnn_weights.dat'
    layers = None
    if not a.floating:
        words = [int(s, 16) for s in weights_path.read_text().split()]
        layers = tc.layers_from_contract(c, tc.unpack_weights(words, c['layers']))
    num_class = int(c['post']['num_class'])
    out = evaluate_model(net, parts[a.split], num_class=num_class, layers=layers,
                         contract=c, threshold=a.threshold,
                         grayscale=a.grayscale, edge_mode=edge_mode,
                         edge_threshold=edge_threshold)
    out.update(split=a.split, images=len(parts[a.split]), model_pt_sha256=digest(run/'model/model.pt'),
               weights_sha256=digest(weights_path), split_sha256=digest(split_path),
               grayscale=bool(a.grayscale))
    Path(a.output).write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
