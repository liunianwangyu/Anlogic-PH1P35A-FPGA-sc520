param(
    [ValidateSet('pretrain', 'formal')]
    [string]$Mode = 'pretrain',
    [string]$PythonExe = 'D:\开发环境\miniconda3\envs\roi_video\python.exe',
    [string]$DataRoot = 'D:\Works\QianSai\Versions\datasets\dataset1027',
    [string]$Output,
    [switch]$Force,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $PSScriptRoot
$ConfigPath = Join-Path $PackageRoot 'configs\edge_training_v1.json'
$TrainScript = Join-Path $PSScriptRoot 'train_cnn.py'

if (-not (Test-Path -LiteralPath $PythonExe)) {
    throw "Python interpreter not found: $PythonExe"
}
if (-not (Test-Path -LiteralPath $TrainScript)) {
    throw "Training script not found: $TrainScript"
}
if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Edge training config not found: $ConfigPath"
}

$Config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 |
    ConvertFrom-Json
$Profile = if ($Mode -eq 'pretrain') { $Config.pretrain } else { $Config.formal }
if (-not $Output) { $Output = $Profile.output }

$OutputHasFiles = (Test-Path -LiteralPath $Output) -and
    [bool](Get-ChildItem -LiteralPath $Output -Force | Select-Object -First 1)
$FormalPackageTarget = $Mode -eq 'formal' -and
    [System.IO.Path]::GetFullPath($Output).TrimEnd('\') -eq
    [System.IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
if ($OutputHasFiles -and -not $FormalPackageTarget -and -not $Force) {
    throw "Output directory is not empty: $Output. Use -Force only after reviewing it."
}

$Baseline = if ($Mode -eq 'pretrain') {
    $Config.pretrain_init_model
} else {
    $Config.formal_init_model
}
$Contract = $Config.contract
$Split = $Config.split_manifest
foreach ($Path in @($Baseline, $Contract, $Split)) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Required input not found: $Path"
    }
}

& $PythonExe -c "import sys, torch, numpy, PIL; assert torch.cuda.is_available(); print(sys.executable); print(torch.__version__); print(torch.cuda.get_device_name(0))"
if ($LASTEXITCODE -ne 0) { throw 'CUDA training environment check failed.' }

$Args = @(
    $TrainScript,
    '--data', $DataRoot,
    '--contract', $Contract,
    '--split-manifest', $Split,
    '--init-from', $Baseline,
    '--out', $Output,
    '--edge-mode', $Config.edge_mode,
    '--edge-threshold', [string]$Config.edge_threshold,
    '--classes', '2',
    '--device', 'cuda',
    '--epochs', [string]$Profile.epochs,
    '--batch', [string]$Profile.batch,
    '--lr', [string]$Profile.learning_rate,
    '--num-workers', [string]$Profile.num_workers,
    '--grayscale-prob', '0.2',
    '--empty-weight', '3.0',
    '--box-weight', '2.0',
    '--calibration-count', [string]$Profile.calibration_count,
    '--qat', [string]$Profile.qat,
    '--seed', '20261017',
    '--model-name', 'dataset1027_edge80_v1'
)

if ($Mode -eq 'pretrain') {
    $Args += '--zero-edge-init'
}
if ($Mode -eq 'formal') {
    $Args += @(
        '--qat-epochs', [string]$Profile.qat_epochs,
        '--qat-lr', [string]$Profile.qat_learning_rate
    )
    if ($Profile.export_bundle) { $Args += '--export-bundle' }
    if ($Profile.export_onnx) { $Args += '--export-onnx' }
}

Write-Host "Mode=$Mode"
Write-Host "Output=$Output"
Write-Host "Baseline=$Baseline"
Write-Host "Edge threshold=$($Config.edge_threshold)"

if ($DryRun) {
    Write-Host 'Dry run only; training was not started.'
    Write-Host ($Args -join ' ')
    exit 0
}

& $PythonExe @Args
if ($LASTEXITCODE -ne 0) {
    throw "Edge training failed with exit code $LASTEXITCODE"
}
