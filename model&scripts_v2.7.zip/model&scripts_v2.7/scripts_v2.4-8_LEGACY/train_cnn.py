#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
train_cnn.py -- CNN 目标检测训练 + 量化 + 模型包导出

产出（全部落在一个版本目录里）：
    weights\cnn_weights.dat            按契约布局的 int8 权重包（RTL 直接吃）
    quant\quant_params.entries.json    36 条 {shift,bias}（合并进 cnn_contract.json）
    exp\exp_L0..L3.hex                 整数参考逐层输出（供 -Check -Mode external 逐层对拍）
    logs\train.log                     训练日志
    meta.json                          版本/时间/超参/数据集指纹

用法：
    # 端到端自测（合成数据，不需要真实数据集）
    python scripts\train_cnn.py --selftest

    # 真实训练
    python scripts\train_cnn.py --data <数据集根> --out <版本目录> --epochs 300 --batch 16

    # 安装到 RTL 侧（写 cnn_weights.dat + 把 36 条 qparam 合并进 cnn_contract.json）
    python scripts\train_cnn.py --install --out <版本目录>

    # 逐层逐字对拍：按 verification\cnn_flow 的 w_rtl.hex/in_frame.hex 算整数参考 -> exp_L*.hex
    python scripts\train_cnn.py --flow-check verification\cnn_flow

数据集目录要求（由 GUI 第 2 步 2b 导入生成）：
    <数据集根>\images\<名称>.jpg      与 X-AnyLabeling 原生 JSON 同名
    <数据集根>\labels\<名称>.json     内部标注（含 boxes：像素坐标 + cls + gx/gy/dx/dy/w/h）

关键语义（必须与 RTL 完全一致，出自 cnn_contract.json）：
  * 输入 int8 居中域：byte = clamp(round(8x8均值),0,255)+128，按有符号读 -> 值 = 该通道均值-128
    （R/G/B 各自做 8x8 箱式平均；ch3 可恒 0 或为板端边缘密度 0..127）
  * 中间激活 clamp(0,127)；head 有符号 [-128,127]
  * out = clamp( (acc + bias) >>> shift )，>>> 是**算术右移 = floor 除法**
  * 权重对称 int8；bias 是 int16（累加器尺度），**必须 |bias| <= 32767**
"""
import argparse, copy, csv, hashlib, json, math, os, random, shutil, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from _project_root import resolve_project_root
except Exception:
    resolve_project_root = None

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from training_policy import (validate_boxes, fixed_split, save_fixed_split,
                             load_fixed_split, stratified_calibration, digest)
from evaluate_detection import evaluate_model
from edge_feature import edge_density8, feature_metadata

try:
    ROOT = resolve_project_root() if resolve_project_root else None
except (Exception, SystemExit):
    ROOT = None
CONTRACT = ((ROOT / 'user_source' / 'hdl_source' / 'cnn' / 'cnn_contract.json')
            if ROOT else None)
INT8_MIN, INT8_MAX = -128, 127
BIAS_LIMIT = 32767

# ---------------------------------------------------------------- 工具
def select_device(name='cuda'):
    """Resolve the training device; integer/oracle paths remain CPU-side."""
    if name == 'auto':
        return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device = torch.device(name)
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise SystemExit('请求了 CUDA，但当前 PyTorch 构建或驱动不可用')
    return device

def batch_to_device(batch, device):
    return tuple(t.to(device, non_blocking=(device.type == 'cuda')) for t in batch)

def loader_options(args, device):
    workers = max(0, int(getattr(args, 'num_workers', 0)))
    options = dict(num_workers=workers, pin_memory=(device.type == 'cuda'))
    if workers > 0:
        options['persistent_workers'] = True
    return options

def log(msg, fh=None):
    line = str(msg)
    print(line)
    if fh is not None:
        fh.write(line + '\n'); fh.flush()

def load_contract(path=None):
    p = Path(path) if path else CONTRACT
    if p is None:
        raise SystemExit('找不到 cnn_contract.json：请用 --contract 指定，'
                         '或设置 QIANSAI_PROJECT / project_root.txt')
    return json.loads(Path(p).read_text(encoding='utf-8'))

def sat8(v):
    return INT8_MIN if v < INT8_MIN else (INT8_MAX if v > INT8_MAX else int(v))

def clamp_relu127(v):
    return 0 if v < 0 else (127 if v > 127 else int(v))

# ---------------------------------------------------------------- 数据集
def box_mean8_rgb(img):
    """(H,W,3) uint8 -> (90,160,3) 逐通道 8x8 箱式平均（不做灰度化）

    与 cnn_capture.v 逐位对齐（原文 L163-171）：
        水平 (Σ8像素 + 4) >>> 3 ；垂直 (Σ8行水平均值 + 4) >>> 3
    硬件 acc[] 存的是 R/G/B 三个独立通道（acc_rd[10:0]/[21:11]/[32:22]），
    输入帧字 = {8'h00, B, G, R}（cnn_capture.v L190），
    即 ch0=R ch1=G ch2=B ch3=0（README_training.md L42）。
    """
    a = img.astype(np.int32)
    H, W, _ = a.shape
    h = a.reshape(H, W // 8, 8, 3).sum(axis=2)                  # (H, W/8, 3)
    h = (h + 4) >> 3
    v = h.reshape(H // 8, 8, W // 8, 3).sum(axis=1)              # (H/8, W/8, 3)
    v = (v + 4) >> 3
    return np.clip(v, 0, 255).astype(np.int32)                   # (90,160,3)

def load_frame(path, W=1280, H=720, augment=False, grayscale_prob=0.0,
               force_grayscale=False, edge_mode='zero', edge_threshold=80):
    """图片 -> (4,90,160) int8，通道序 R,G,B,CH3。

    CH3 is either zero for backward compatibility or the board-aligned edge
    density in 0..127. Edge generation intentionally runs after all
    photometric/grayscale augmentation.
    """
    if edge_mode not in ('zero', 'density'):
        raise ValueError("edge_mode must be 'zero' or 'density'")
    try:
        from PIL import Image
    except Exception:
        raise RuntimeError('需要 Pillow：pip install pillow')
    im = Image.open(path).convert('RGB')
    if im.size != (W, H):
        im = im.resize((W, H), Image.BICUBIC)
    a = np.asarray(im)
    if augment or force_grayscale:
        pixels = a.transpose(2, 0, 1).astype(np.float32)-128
        if augment:
            # Nonlinear photometric transforms precede the two integer box averages.
            pixels = augment_rgb(pixels, grayscale_prob=grayscale_prob)
        else:
            pixels = board_grayscale_rgb(pixels)
        a = np.clip(np.rint(pixels+128), 0, 255).astype(np.uint8).transpose(1, 2, 0)
    rgb = box_mean8_rgb(a)                                       # (90,160,3) 0..255
    v = (rgb - 128).astype(np.int8)                              # 居中域（硬件字节 = 该值 + 128）
    out = np.zeros((4, 90, 160), dtype=np.int8)
    out[0] = v[:, :, 0]                                          # R
    out[1] = v[:, :, 1]                                          # G
    out[2] = v[:, :, 2]                                          # B
    out[3] = (edge_density8(a, threshold=edge_threshold)
              if edge_mode == 'density' else 0)
    return out

def load_targets(label_path, num_class, GW=20, GH=12):
    """内部标注 -> head 目标 (8,12,20) float + 掩码"""
    d = json.loads(Path(label_path).read_text(encoding='utf-8-sig'))
    objm = np.zeros((GH, GW), np.float32)
    boxm = np.zeros((4, GH, GW), np.float32)     # dx,dy,w,h 归一化到 ±1 / 0..1
    clsm = np.zeros((num_class, GH, GW), np.float32)
    has = np.zeros((GH, GW), np.float32)
    validate_boxes(d.get('boxes', []), num_class, GW, GH)
    for b in d.get('boxes', []):
        gy, gx = int(b['gy']), int(b['gx'])
        objm[gy, gx] = 1.0; has[gy, gx] = 1.0
        # 单位就是 int8 语义单位（README_training.md §2）：dx/dy 单位 0.5 格、w/h 单位 8 px。
        # 不能归一到 0..1：head 只有一个 act_out，归一化后框通道量化到 int8 会全变 0，
        # RTL 的 size_ok(w!=0 && h!=0) 会把所有框滤掉（已实测 box_ratio=0.000）。
        boxm[0, gy, gx] = float(b['dx'])
        boxm[1, gy, gx] = float(b['dy'])
        boxm[2, gy, gx] = float(b['w'])
        boxm[3, gy, gx] = float(b['h'])
        clsm[int(b['cls']), gy, gx] = 1.0
    return objm, boxm, clsm, has, d.get('boxes', [])

def board_grayscale_rgb(x):
    """Apply the board's RGB->gray formula to centered int8-domain pixels.

    isp_top.v uses Gray=(R>>2)+(G>>1)+(B>>2).  Keeping this exact formula is
    important: Pillow/OpenCV luminance coefficients would create a small but
    systematic train/deployment mismatch.
    """
    rgb = np.clip(np.rint(x + 128.0), 0, 255).astype(np.uint16)
    gray = (rgb[0] >> 2) + (rgb[1] >> 1) + (rgb[2] >> 2)
    centered = gray.astype(np.float32) - 128.0
    return np.repeat(centered[None, :, :], 3, axis=0)


def augment_rgb(x, grayscale_prob=0.0):
    """颜色/光照增强（README_training.md §4 的硬要求，不是可选优化）

    三条实板依据（verification\板级验收_20261017.md）：
      1) 中心测光对强光源"蹦迪"：AG 抖 ~20 台阶   -> 亮度/对比度抖动要覆盖这个幅度
      2) 强光源占画面大时主体被压暗（单次曝光动态范围固有）
      3) 画面整体偏暗、饱和度低（AE 目标 112~128，无 gamma/CCM）
    所以白平衡 / 亮度对比度 / 饱和度 / 伽马 四种都要做，缺一个就会在对应场景掉点。
    """
    if not 0.0 <= grayscale_prob <= 1.0:
        raise ValueError('grayscale_prob must be in [0, 1]')
    if grayscale_prob and random.random() < grayscale_prob:
        x = board_grayscale_rgb(x)
    wb = np.array([random.uniform(0.88, 1.12) for _ in range(3)], np.float32)
    g = (x + 128.0) * wb[:, None, None]  # White balance operates in pixel space.
    g = g * random.uniform(0.75, 1.30) + random.uniform(-25, 25)     # ② 亮度/对比度
    lum = g.mean(axis=0, keepdims=True)
    g = lum + (g - lum) * random.uniform(0.60, 1.35)                 # ③ 饱和度
    gm = random.uniform(0.80, 1.25)                                  # ④ 伽马（居中域 -128..127）
    v = np.clip(g, 0.0, 255.0) / 255.0
    g = np.power(v, gm) * 255.0 - 128.0
    return np.clip(np.rint(g), -128, 127).astype(np.float32)

class DS(torch.utils.data.Dataset):
    def __init__(self, items, num_class, augment=False, grayscale_prob=0.0,
                 force_grayscale=False, edge_mode='zero', edge_threshold=80):
        self.items = items; self.num_class = num_class; self.augment = augment
        self.grayscale_prob = grayscale_prob
        self.force_grayscale = force_grayscale
        self.edge_mode = edge_mode
        self.edge_threshold = edge_threshold
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        ip, lp = self.items[i][0], self.items[i][1]     # 第 3 项是"原始文件名"，只给划分用
        x = load_frame(ip, augment=self.augment,
                       grayscale_prob=self.grayscale_prob,
                       force_grayscale=self.force_grayscale,
                       edge_mode=self.edge_mode,
                       edge_threshold=self.edge_threshold).astype(np.float32)
        o, b, c, h, _ = load_targets(lp, self.num_class)
        return torch.from_numpy(x), torch.from_numpy(o), torch.from_numpy(b), \
               torch.from_numpy(c), torch.from_numpy(h)


def make_train_loader(items, num_class, args, device):
    """Build the augmented training loader with optional empty-frame weighting."""
    empty_weight = float(getattr(args, 'empty_weight', 1.0))
    if empty_weight < 1.0:
        raise ValueError('empty_weight must be >= 1')
    dataset = DS(items, num_class, augment=True,
                 grayscale_prob=args.grayscale_prob,
                 edge_mode=getattr(args, 'edge_mode', 'zero'),
                 edge_threshold=getattr(args, 'edge_threshold', 80))
    sampler = None
    if empty_weight > 1.0:
        weights = [
            empty_weight if not load_targets(label_path, num_class)[-1] else 1.0
            for _, label_path, _ in items
        ]
        sampler = torch.utils.data.WeightedRandomSampler(
            weights, num_samples=len(items), replacement=True)
    return torch.utils.data.DataLoader(
        dataset, batch_size=args.batch, shuffle=sampler is None, sampler=sampler,
        drop_last=False, **loader_options(args, device))


# ---------------------------------------------------------------- 网络（严格按契约）
class Net(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.convs = nn.ModuleList()
        for l in cfg:
            k = 3 if l['ksel'] else 1
            self.convs.append(nn.Conv2d(l['in_ch'], l['out_ch'], k, l['stride'], 1 if k == 3 else 0))
    def forward(self, x):
        for i, m in enumerate(self.convs):
            x = m(x)
            if self.cfg[i]['relu6']:
                x = F.relu(x)                 # 浮点阶段用无上限 ReLU；量化时靠 act_scale 映射到 [0,127]
        return x

def build_net(c):
    return Net(c['layers'])

def compute_loss(y, o, b, cl, h, NC, pos_weight=1.0, box_weight=2.0):
    """Per-image hard negatives, normalized positive SmoothL1, class BCE.

    pos_weight remains a compatibility argument; combining it with mining is
    rejected by the CLI. Empty images contribute their 32 hardest negatives.
    """
    obj = y[:, 0]; boxp = y[:, 1:5]; clsp = y[:, 5:5 + NC]
    bce = F.binary_cross_entropy_with_logits(obj, o, reduction='none')
    terms = []
    for loss, target in zip(bce, o):
        positive = target > .5
        pos = loss[positive]; neg = loss[~positive]
        k = min(neg.numel(), max(32, 3*pos.numel()))
        terms.append((pos.mean() if pos.numel() else loss.sum()*0) +
                     (neg.topk(k).values.mean() if k else loss.sum()*0))
    l_obj = torch.stack(terms).mean()
    m = h.unsqueeze(1)                                  # 只有目标格参与框/类回归
    unit = y.new_tensor([64., 64., 32., 32.]).view(1,4,1,1)
    l_box = (F.smooth_l1_loss(boxp/unit, b/unit, beta=.1, reduction='none') * m).sum() / (m.sum()*4+1e-6)
    bce_c = F.binary_cross_entropy_with_logits(clsp, cl, reduction='none')
    l_cls = (bce_c * m).sum() / (m.sum() * NC + 1e-6)
    return l_obj + box_weight*l_box + l_cls, l_obj.item(), l_box.item(), l_cls.item()

# ---------------------------------------------------------------- 量化（契约数学）
def quantize(net, calib_x, c, logfh):
    """校准式 PTQ：逐 OC 权重 scale；激活 scale 中间层逐层、head 逐 OC -> 每 OC 的 shift/bias
       推导：out = clamp( (acc + bias) >> shift )，acc = real_acc / acc_scale
             bias = b_float / acc_scale ; 2^shift = act_out / acc_scale
             acc_scale = s_w(oc) * act_in_scale
    """
    L = c['layers']
    layers = []
    calibration_max = [np.zeros(int(ly['out_ch']), dtype=np.float64) for ly in L]
    device = next(net.parameters()).device
    # One network traversal per small calibration batch; accumulate maxima by C.
    # Avoid retaining all intermediate feature maps or repeating prefixes L times.
    with torch.no_grad():
        for start in range(0, len(calib_x), 16):
            cur = calib_x[start:start+16].to(device)
            for li, conv in enumerate(net.convs):
                cur = conv(cur)
                if L[li]['relu6']: cur = F.relu(cur)
                a = cur.detach().cpu().numpy()
                a = a.transpose(1,0,2,3).reshape(a.shape[1],-1)
                channel_max = a.max(axis=1) if L[li]['relu6'] else np.abs(a).max(axis=1)
                calibration_max[li] = np.maximum(calibration_max[li], channel_max)
    act_in_scale = 1.0                       # 输入就是 int8，scale 恰好是 1
    for li, ly in enumerate(L):
        conv = net.convs[li]
        W = conv.weight.detach().cpu().numpy().astype(np.float64)   # (oc,ic,k,k)
        B = conv.bias.detach().cpu().numpy().astype(np.float64)
        oc_n = W.shape[0]
        # 逐 OC 权重 scale
        sw = np.maximum(np.abs(W).reshape(oc_n, -1).max(axis=1) / 127.0, 1e-12)
        # Power-of-two accumulator scales yield exactly shared effective scales
        # across hidden channels and class logits; head box units remain 1.
        sw = np.maximum(sw, np.abs(B)/(BIAS_LIMIT*act_in_scale))
        acc_scale = np.power(2., np.ceil(np.log2(np.maximum(sw*act_in_scale, 1e-12))))
        sw = acc_scale / act_in_scale
        Wq = np.clip(np.round(W / sw[:, None, None, None]), -127, 127).astype(np.int32)
        # 校准：跑一遍拿每个 OC 的激活幅度
        act_max = calibration_max[li]
        if act_max is None or float(np.max(act_max)) <= 0.0:
            log('  !! L%d 校准激活恒 0，act_out 退化（会整层饱和）' % li, logfh)
        # 中间层：下游要求"所有输入通道同一标度"，只能整层一个 act_out。
        # head  ：无下游，且各通道量纲差 ~100 倍（obj/cls 是 logit，w/h 是 8px 单位）
        #         -> 逐 OC 定标。RTL 的 shift 本来就是逐 OC 的，所以这里不用动 RTL。
        if li == len(L) - 1:
            act_out = np.maximum(np.asarray(act_max, np.float64) / 127.0, 1e-12)     # (oc,)
            # head = obj(1) + box(4) + cls(3)。框通道的 RTL 语义是"int8 字节就是原生单位"
            # （w/h 单位 8px、dx/dy 单位 0.5 格），所以它们的量化步长必须 =1.0；
            # 跟着校准幅度走会把整框放大/缩小一个比例（实测 box_ratio 会偏到 3.3）。
            # 只有 obj/cls 是 logits，才该按各自幅度定标。
            act_out[1:5] = 1.0
            act_out[5:] = max(float(np.max(act_out[5:])), float(np.max(acc_scale[5:])))
            act_out[0] = max(act_out[0], acc_scale[0])
            if np.any(acc_scale[1:5] > 1):
                raise ValueError('Head box scale cannot express native unit 1; inspect weights/bias')
        else:
            act_out = max(float(np.max(act_max))/127., float(np.max(acc_scale)), 1e-12)
        act_out = np.power(2., np.ceil(np.log2(act_out)))
        acc_scale = sw * act_in_scale                       # (oc,)
        shift = np.round(np.log2(np.asarray(act_out) / acc_scale)).astype(np.int64)
        if np.any((shift < 0) | (shift > 31)):
            raise ValueError('Shift outside hardware range [0,31]')
        bias_q = np.round(B / acc_scale).astype(np.int64)
        over = np.where(np.abs(bias_q) > BIAS_LIMIT)[0]
        if over.size:
            raise ValueError('INT16 bias overflow: layer %d channels %s' % (li, over.tolist()))
        layers.append(dict(Wq=Wq, bias=bias_q, shift=shift, oc=oc_n,
                           sw=sw, acc_scale=acc_scale, act_out=act_out,
                           relu6=int(ly['relu6'])))
        ao = np.asarray(act_out, np.float64)
        log('  L%d: act_out=[%.4f..%.4f]  acc_scale=[%.4g..%.4g]  shift=[%d..%d]  |bias_q|max=%d/%d'
            % (li, ao.min(), ao.max(), acc_scale.min(), acc_scale.max(),
               shift.min(), shift.max(), int(np.abs(bias_q).max()), BIAS_LIMIT), logfh)
        act_in_scale = act_out
    return layers

def int_forward(layers, x_i8, L, c):
    """整数参考前向，严格对照 RTL 的语义（算术右移=floor、clamp）"""
    acts = []
    cur = x_i8.astype(np.int32)                     # (ic,H,W)
    for li, ly in enumerate(L):
        W = layers[li]['Wq']; bias = layers[li]['bias']; sh = layers[li]['shift']
        k = 3 if ly['ksel'] else 1; st = int(ly['stride']); pad = 1 if k == 3 else 0
        oc_n, ic_n = W.shape[0], W.shape[1]
        ow, oh = int(ly['out_w']), int(ly['out_h'])
        padded = np.pad(cur, ((0, 0), (pad, pad), (pad, pad))) if pad else cur
        out = np.zeros((oc_n, oh, ow), np.int32)
        for oy in range(oh):
            for ox in range(ow):
                blk = padded[:, oy * st:oy * st + k, ox * st:ox * st + k]
                for oc in range(oc_n):
                    acc = int(bias[oc]) + int((W[oc] * blk).sum())
                    acc = acc >> int(sh[oc])          # Python >> 即 floor 除法，与 RTL >>> 一致
                    out[oc, oy, ox] = clamp_relu127(acc) if ly['relu6'] else sat8(acc)
        cur = out
        acts.append(cur)
    return acts


def integer_forward_fast(layers, x_i8, L):
    """CPU float64 convolution carries exact bounded integer accumulations.

    Used for frequent QAT validation; int_forward remains the independent
    scalar export/RTL oracle. Neither path runs a backward pass.
    """
    cur = torch.as_tensor(np.asarray(x_i8), dtype=torch.float64)[None]
    acts = []
    with torch.no_grad():
        for q, ly in zip(layers, L):
            w = torch.as_tensor(q['Wq'], dtype=torch.float64)
            b = torch.as_tensor(q['bias'], dtype=torch.float64)
            acc = F.conv2d(cur, w, b, stride=int(ly['stride']), padding=1 if ly['ksel'] else 0)
            divisor = torch.as_tensor(2.**np.asarray(q['shift']), dtype=torch.float64).view(1,-1,1,1)
            cur = torch.floor(acc/divisor).clamp(0 if ly['relu6'] else -128, 127)
            acts.append(cur[0].numpy().astype(np.int32))
    return acts

# ---------------------------------------------------------------- 权重打包（RTL 布局）
def pack_weights(layers, L, c, logfh):
    """4 实例；每路深度来自契约。字地址 = w_base + cog*taps*n_g + ct*n_g + cg；禁止回绕
       字的字节 k = 输入通道 (cg*4+k)；实例 m = 一个 OC 组内的第 m 个 OC"""
    lane_words = int(c["weight_layout"]["words_per_instance"])
    pack = [0] * (4*lane_words)
    TAPS = [3 * 3 if l['ksel'] else 1 for l in L]
    for li, ly in enumerate(L):
        W = layers[li]['Wq']                        # (oc,ic,k,k)
        expected=(int(ly['out_ch']),int(ly['in_ch']),3 if ly['ksel'] else 1,3 if ly['ksel'] else 1)
        assert tuple(W.shape)==expected, ('weight tensor/contract mismatch',li,W.shape,expected)
        assert W.min()>=-128 and W.max()<=127, ('INT8 weight overflow',li)
        oc_n, ic_n = W.shape[0], W.shape[1]
        tap_n = TAPS[li]; ng = ic_n // 4; nocg = oc_n // 4; wbase = int(ly['w_base'])
        Wt = W.reshape(oc_n, ic_n, tap_n)           # 行优先展开成 ct
        for cog in range(nocg):
            for m in range(4):
                for ct in range(tap_n):
                    for cg in range(ng):
                        a = wbase + cog * tap_n * ng + ct * ng + cg
                        assert 0 <= a < lane_words, ("weight address overflow", a, lane_words)
                        wd = 0
                        for k in range(4):
                            occ = cog * 4 + m; icc = cg * 4 + k
                            v = int(Wt[occ, icc, ct]) if icc < ic_n else 0
                            wd |= (v & 0xFF) << (8 * k)
                        pack[m * lane_words + a] = wd
    nz = sum(1 for v in pack if v != 0)
    log('  打包完成：非零字 %d/%d' % (nz,len(pack)), logfh)
    return pack

def layer_words(act, ly):
    """把整数层的 (oc,oh,ow) 排成 RTL 的字序列：idx = oy*(ow*n_g) + ox*n_g + cg"""
    oc_n, oh, ow = act.shape
    ng = oc_n // 4
    out = []
    for oy in range(oh):
        for ox in range(ow):
            for cg in range(ng):
                wd = 0
                for k in range(4):
                    wd |= (int(act[cg * 4 + k, oy, ox]) & 0xFF) << (8 * k)
                out.append(wd)
    return out

# ---------------------------------------------------------------- RTL 侧安装 / 逐层对拍
def read_text_raw(p):
    with open(p, 'r', encoding='utf-8', newline='') as f:
        return f.read()

def write_text_raw(p, s):
    with open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)

def unpack_weights(words, L):
    """pack_weights 的严格逆：契约布局 -> 每层 (oc,ic,k,k) int32（按 RTL 的读法反解）

    这一步是"训练产物 == RTL 实际读到的权重"的等价性保证：正反两向用同一公式，
    任何布局错误都会在 exp_L*.hex 与 rtl_L*.hex 的逐字比较里暴露。
    """
    assert len(words)%4 == 0
    lane_words = len(words)//4
    Ws = []
    for li, ly in enumerate(L):
        oc_n, ic_n = int(ly['out_ch']), int(ly['in_ch'])
        tap_n = 9 if ly['ksel'] else 1
        k = 3 if ly['ksel'] else 1
        ng = ic_n // 4; nocg = oc_n // 4; wbase = int(ly['w_base'])
        W = np.zeros((oc_n, ic_n, tap_n), np.int32)
        for cog in range(nocg):
            for m in range(4):
                for ct in range(tap_n):
                    for cg in range(ng):
                        a = wbase + cog * tap_n * ng + ct * ng + cg
                        assert 0 <= a < lane_words, ("weight address overflow", a, lane_words)
                        wd = int(words[m * lane_words + a])
                        for kk in range(4):
                            occ = cog * 4 + m; icc = cg * 4 + kk
                            if icc < ic_n:
                                b = (wd >> (8 * kk)) & 0xFF
                                W[occ, icc, ct] = b - 256 if b >= 128 else b
        Ws.append(W.reshape(oc_n, ic_n, k, k))
    return Ws

def layers_from_contract(c, Ws):
    """用 cnn_contract.json 的 q_base/shift/bias 组装 int_forward 需要的层结构"""
    ent = c['quant_params']['entries']
    out = []
    for li, ly in enumerate(c['layers']):
        qb = int(ly['q_base']); oc_n = int(ly['out_ch'])
        out.append(dict(Wq=Ws[li],
                        shift=np.array([int(ent[qb + oc]['shift']) for oc in range(oc_n)], np.int64),
                        bias=np.array([int(ent[qb + oc]['bias']) for oc in range(oc_n)], np.int64),
                        relu6=int(ly['relu6'])))
    return out

# ---------------------------------------------------------------- 评估（判据与 RTL 一致）
def cell_metrics_float(net, items, NC, edge_mode='zero', edge_threshold=80):
    """浮点侧：head 的 obj logit >= 0 视为"有目标"

    RTL 判据（cnn_post.v L88-89）：obj_u8 = obj_int8 + 0x80，obj_ok = obj_u8 >= 128
    等价于 obj_int8 >= 0。所以浮点侧用 logit >= 0 才是同一个决策点。
    """
    tp = fp = fn = 0; margins = []; empty_fp = 0; n_empty = 0
    device = next(net.parameters()).device
    with torch.no_grad():
        for ip, lp, _ in items:
            x = torch.from_numpy(load_frame(
                ip, edge_mode=edge_mode,
                edge_threshold=edge_threshold).astype(np.float32))[None].to(device)
            y = net(x)[0].cpu().numpy()
            o = load_targets(lp, NC)[0]
            pred = y[0] >= 0.0
            gt = o > 0.5
            tp += int((pred & gt).sum()); fp += int((pred & ~gt).sum()); fn += int((~pred & gt).sum())
            if gt.any() and (~gt).any():
                margins.append(float(y[0][gt].min() - y[0][~gt].max()))
            if not gt.any():
                n_empty += 1; empty_fp += int(pred.sum())
    return _pack_metrics(tp, fp, fn, margins, empty_fp, n_empty)

def cell_metrics_int8(layers, items, L, c, NC,
                      edge_mode='zero', edge_threshold=80):
    """int8 侧：int_forward 给出与 RTL 逐位相同的 head 输出，再按 RTL 判据统计

    另外统计 box_ratio = median(w_pred_int8 / w_true_int8)：
    RTL 把 head 的 w/h 字节当作"8px 为单位"的语义值用，所以理想值是 1.0。
    明显偏离 1 就说明 head 的 w/h 量化标度与语义单位不一致（框会整体放大/缩小）。
    """
    tp = fp = fn = 0; margins = []; empty_fp = 0; n_empty = 0; ratios = []
    for ip, lp, _ in items:
        xi = load_frame(ip, edge_mode=edge_mode,
                        edge_threshold=edge_threshold).astype(np.int32)
        y = int_forward(layers, xi, L, c)[-1]
        o, b = load_targets(lp, NC)[:2]
        obj = y[0]; wch = y[3]; hch = y[4]
        pred = obj >= 0
        gt = o > 0.5
        tp += int((pred & gt).sum()); fp += int((pred & ~gt).sum()); fn += int((~pred & gt).sum())
        if gt.any() and (~gt).any():
            margins.append(int(obj[gt].min() - obj[~gt].max()))
        if gt.any():
            wpred = np.maximum(y[3][gt].astype(np.float64), 0.0)
            wtrue = b[2][gt].astype(np.float64)                # 目标本身就是 int8 语义单位
            sel = wtrue > 0
            if sel.any():
                ratios.append(float(np.median(wpred[sel] / wtrue[sel])))
        if not gt.any():
            n_empty += 1
            empty_fp += int(((obj >= 0) & (wch != 0) & (hch != 0)).sum())   # RTL 完整过滤条件
    return _pack_metrics(tp, fp, fn, margins, empty_fp, n_empty, ratios)

def _pack_metrics(tp, fp, fn, margins, empty_fp, n_empty, ratios=None):
    prec = tp / max(tp + fp, 1); rec = tp / max(tp + fn, 1)
    f1 = 2 * prec * rec / max(prec + rec, 1e-9)
    return dict(tp=tp, fp=fp, fn=fn, precision=round(prec, 4), recall=round(rec, 4),
                f1=round(f1, 4), n_pos=tp + fn, margin=(min(margins) if margins else None),
                empty_fp=empty_fp, n_empty=n_empty,
                box_ratio=(round(float(np.median(ratios)), 3) if ratios else None))

def log_metrics(tag, m, logfh):
    log('  %s  P=%.3f R=%.3f F1=%.3f  (TP=%d FP=%d FN=%d)  margin=%s  空场景虚检=%d/%d'
        % (tag, m['precision'], m['recall'], m['f1'], m['tp'], m['fp'], m['fn'],
           'n/a' if m['margin'] is None else m['margin'], m['empty_fp'], m['n_empty']), logfh)

# ---------------------------------------------------------------- QAT（量化感知微调）
def _ste_round(v, lo, hi):
    """round+clamp 的前向，恒等反向（straight-through estimator）"""
    q = torch.round(v).clamp(lo, hi)
    return v + (q - v).detach()

def qat_forward(net, layers, L, x_int):
    """按 RTL 的整数语义逐层前向（整数用 float 张量承载），梯度用 STE 回传

        acc = Σ round(w/sw)·x_int + round(b/acc_scale)      <- 整数累加
        out = clamp( floor(acc / 2^shift) )                 <- floor 等价于算术右移
    前向数值就是将来 RTL 会算出的值，反向仍能更新浮点权重。
    """
    cur = x_int
    for li, ly in enumerate(L):
        conv = net.convs[li]
        device = cur.device
        sw = torch.as_tensor(layers[li]['sw'], dtype=torch.float32,
                             device=device).view(-1, 1, 1, 1)
        accs = torch.as_tensor(layers[li]['acc_scale'], dtype=torch.float32,
                               device=device).view(-1)
        pw = torch.as_tensor(np.power(2.0, layers[li]['shift'].astype(np.float32)),
                             dtype=torch.float32, device=device).view(1, -1, 1, 1)
        k = 3 if ly['ksel'] else 1
        wq = _ste_round(conv.weight / sw, -127, 127)
        bq = _ste_round(conv.bias / accs, -32767, 32767)
        acc = F.conv2d(cur, wq, bias=bq, stride=int(ly['stride']), padding=1 if k == 3 else 0)
        sc = acc / pw
        out = torch.floor(sc) + (sc - sc.detach())
        cur = out.clamp(0, 127) if int(ly['relu6']) else out.clamp(-128, 127)
    return cur

def run_qat(net, layers, L, tr, NC, pos_weight, args, logfh, val, contract):
    """用冻结的 sw/shift/act_out（来自 PTQ）做量化感知微调"""
    opt = torch.optim.Adam(net.parameters(), lr=args.qat_lr)
    t0 = time.time(); n_ep = max(1, int(args.qat_epochs))
    best_sd = copy.deepcopy(net.state_dict())
    best_score = evaluate_model(
        net, val, NC, layers, contract,
        edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)['numerical']['map50']
    best_ep = 0
    device = next(net.parameters()).device
    dl = make_train_loader(tr, NC, args, device)
    for ep in range(1, n_ep + 1):
        net.train(); s = 0.0; nb = 0
        for x, o, b, cl, h in dl:
            x, o, b, cl, h = batch_to_device((x, o, b, cl, h), device)
            opt.zero_grad()
            yi = qat_forward(net, layers, L, x)         # x 本身就是整数域，yi 是 int8 语义值
            # obj/cls 是 logits：乘回 s_eff = acc_scale*2^shift 得到浮点量纲（BCE 的 lr 才合理）
            # 框通道保持 int8 单位（目标也是 int8 单位），直接算 MSE
            s_eff = torch.as_tensor(layers[-1]['acc_scale'] * np.power(2.0, layers[-1]['shift']),
                                    dtype=torch.float32, device=device).view(1, -1, 1, 1)
            yo = torch.cat([yi[:, 0:1] * s_eff[:, 0:1], yi[:, 1:5],
                            yi[:, 5:5 + NC] * s_eff[:, 5:5 + NC], yi[:, 5 + NC:]], dim=1)
            l = compute_loss(yo, o, b, cl, h, NC, pos_weight, args.box_weight)[0]
            l.backward(); opt.step()
            s += float(l.detach()); nb += 1
        if ep == 1 or ep % max(1, n_ep // 5) == 0:
            log('  qat %3d/%d  train %.5f  (%.1fs)'
                % (ep, n_ep, s / max(nb, 1), time.time() - t0), logfh)
        if ep % 5 == 0 or ep == n_ep:
            candidate = reproject(net, copy.deepcopy(layers), contract, logfh)
            score = evaluate_model(
                net, val, NC, candidate, contract,
                edge_mode=args.edge_mode,
                edge_threshold=args.edge_threshold)['numerical']['map50']
            log('  integer validation AP50 %.6f' % score, logfh)
            if score > best_score:
                best_score = score; best_ep = ep; best_sd = copy.deepcopy(net.state_dict())
    net.load_state_dict(best_sd)
    log('  restore QAT epoch %d, integer validation AP50 %.6f' % (best_ep, best_score), logfh)
    return dict(epoch=best_ep, map50=best_score)

def reproject(net, layers, c, logfh):
    """QAT 后按冻结的 sw/acc_scale 重新取整；shift/act_out 保持不变"""
    for li in range(len(c['layers'])):
        W = net.convs[li].weight.detach().cpu().numpy().astype(np.float64)
        B = net.convs[li].bias.detach().cpu().numpy().astype(np.float64)
        sw = layers[li]['sw']; acc_scale = layers[li]['acc_scale']
        layers[li]['Wq'] = np.clip(np.round(W / sw[:, None, None, None]), -127, 127).astype(np.int32)
        bq = np.round(B / acc_scale).astype(np.int64)
        over = np.where(np.abs(bq) > BIAS_LIMIT)[0]
        if over.size:
            raise ValueError('QAT INT16 bias overflow at layer %d; reduce learning rate or recalibrate' % li)
        layers[li]['bias'] = bq
    nz = sum(int((layers[li]['Wq'] != 0).sum()) for li in range(len(c['layers'])))
    log('  重新取整完成：非零权重 %d' % nz, logfh)
    return layers

def frame_from_words(words, c):
    """Input words -> (4,90,160) int32 with all four signed channels restored."""
    iw = int(c['input_frame']['w']); ih = int(c['input_frame']['h'])
    x = np.zeros((4, ih, iw), np.int32)
    for y in range(ih):
        for xx in range(iw):
            wd = int(words[y * iw + xx])
            for k in range(4):
                b = (wd >> (8 * k)) & 0xFF
                x[k, y, xx] = b - 256 if b >= 128 else b
    return x

def install_artifacts(outdir, logfh, contract_path=None):
    """把 outdir 的权重与 qparam 装进 RTL 侧：cnn_weights.dat(行数来自契约) + cnn_contract.json(36 条)"""
    contract_path = Path(contract_path) if contract_path else CONTRACT
    if contract_path is None:
        log('  !! 找不到 cnn_contract.json：请用 --contract 指定', logfh)
        return 1
    wsrc = outdir / 'weights' / 'cnn_weights.dat'
    qsrc = outdir / 'quant' / 'quant_params.entries.json'
    if not wsrc.exists() or not qsrc.exists():
        log('  !! 缺 %s 或 %s' % (wsrc, qsrc), logfh); return 1
    wdst = contract_path.parent / 'cnn_weights.dat'
    lines = [t for t in read_text_raw(wsrc).split() if t]
    expected = 4*load_contract(contract_path)["weight_layout"]["words_per_instance"]
    if len(lines) != expected:
        log('  !! cnn_weights.dat 行数 %d != %d，拒绝安装' % (len(lines),expected), logfh); return 1
    newtxt = '\n'.join(lines) + '\n'
    if wdst.exists() and read_text_raw(wdst) == newtxt:
        log('  权重: 内容未变，跳过写入（避免把 mtime 推新，导致"bit 过期"误判）', logfh)
    else:
        write_text_raw(wdst, newtxt)
        log('  权重: %s -> %s (%d 行)' % (wsrc.name, wdst, len(lines)), logfh)

    ents = json.loads(qsrc.read_text(encoding='utf-8'))
    txt = read_text_raw(contract_path)
    nl = '\r\n' if '\r\n' in txt else '\n'
    i0 = txt.find('"entries"')
    if i0 < 0: log('  !! cnn_contract.json 里找不到 "entries"', logfh); return 1
    i1 = txt.find(']', i0)
    if i1 < 0: log('  !! "entries" 数组没有闭合', logfh); return 1
    body = '[' + nl + (',' + nl).join(
        '      { "oc": %d, "shift": %d, "bias": %d }' % (e['oc'], e['shift'], e['bias']) for e in ents
    ) + nl + '    ]'
    txt = txt[:i0] + '"entries": ' + body + txt[i1 + 1:]
    for old in ('"status": "临时占位，不是训练结果"',
                '"status": "selfcheck (P3-d: 可预测权重端到端自检；用 -Restore 还原)"'):
        if old in txt:
            txt = txt.replace(old, '"status": "trained: %s"' % outdir.name)
    if read_text_raw(contract_path) == txt:
        log('  qparam: 契约内容未变，跳过写入', logfh)
    else:
        write_text_raw(contract_path, txt)
    j = json.loads(read_text_raw(contract_path))     # 回读校验（写坏契约就立刻停）
    n = len(j['quant_params']['entries'])
    if n != 36 or int(j['quant_params']['entries'][0]['oc']) != 0:
        log('  !! 契约回读异常（%d 条）' % n, logfh); return 1
    log('  qparam: %s -> %s  (%d 条，回读 OK)' % (qsrc.name, contract_path, n), logfh)
    project_root = contract_path.resolve().parents[3]
    project_tool = project_root / 'tools' / 'cnn_contract.py'
    if project_tool.exists():
        log('  接着必须: cd "%s"' % project_root, logfh)
        log('            python tools\\cnn_contract.py --generate', logfh)
        log('            python tools\\cnn_contract.py --check', logfh)
        log('            (v2.3+ 使用四路 cnn_weight_*.dath，不使用 cnn_wrom.v)', logfh)
    else:
        log('  接着必须: .\\scripts\\cnn_contract.ps1 -GenW ; -GenQrom ; -GenVh ; -Check', logfh)
    return 0

def flow_check(dirp, logfh, contract_path=None):
    """按 verification/cnn_flow 的 w_rtl.hex + in_frame.hex + 契约 qparam 算整数参考 -> exp_L*.hex"""
    c = load_contract(contract_path); L = c['layers']
    wp = dirp / 'w_rtl.hex'; fp = dirp / 'in_frame.hex'
    for q in (wp, fp):
        if not q.exists(): log('  !! 缺 %s' % q, logfh); return 1
    words = [int(t, 16) for t in read_text_raw(wp).split()]
    fw = [int(t, 16) for t in read_text_raw(fp).split()]
    if len(words) != 4*c['weight_layout']['words_per_instance']: log('  !! w_rtl.hex 行数与契约不符', logfh); return 1
    x = frame_from_words(fw, c)
    acts = int_forward(layers_from_contract(c, unpack_weights(words, L)), x, L, c)
    for li in range(len(L)):
        w = layer_words(acts[li], L[li])
        f = dirp / ('exp_L%d.hex' % li)
        write_text_raw(f, '\n'.join('%08x' % v for v in w) + '\n')
        log('  %s  (%d 字)' % (f.name, len(w)), logfh)
    log('  接着跑: .\\scripts\\cnn_flow.ps1 -Check -Mode external', logfh)
    return 0


# ---------------------------------------------------------------- 可分享模型包
def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _contract_geometry(c):
    """只保留与权重布局/网络几何有关的字段，排除会随训练变化的 qparam entries。"""
    ignore = {'version', 'frozen', 'purpose', 'device', 'status',
              'placeholder_weights', 'quant_params'}
    geo = {k: v for k, v in c.items() if k not in ignore}
    qp = c.get('quant_params', {}) or {}
    geo['quant_params'] = {k: v for k, v in qp.items() if k != 'entries'}
    return geo


def _contract_geometry_sha256(c):
    raw = json.dumps(_contract_geometry(c), sort_keys=True,
                     ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def export_model_bundle(outdir, net, c, args, meta, logfh):
    """训练结束后生成可独立分享的 model.pt / model.onnx / deploy 包。

    这个函数不依赖工程根目录，也不写 RTL 工程；队友拿到 deploy 目录后，
    用 scripts/deploy_model_bundle.py 单独安装权重即可。
    """
    outdir = Path(outdir)
    model_dir = outdir / 'model'
    deploy_dir = outdir / 'deploy'
    model_dir.mkdir(parents=True, exist_ok=True)
    deploy_dir.mkdir(parents=True, exist_ok=True)

    wsrc = outdir / 'weights' / 'cnn_weights.dat'
    qsrc = outdir / 'quant' / 'quant_params.entries.json'
    if not wsrc.exists() or not qsrc.exists():
        log('  !! 导出模型包失败：缺 weights/cnn_weights.dat 或 quant/quant_params.entries.json',
            logfh)
        return None

    entries = json.loads(qsrc.read_text(encoding='utf-8'))
    bundle_contract = copy.deepcopy(c)
    bundle_contract.setdefault('quant_params', {})['entries'] = entries
    bundle_contract['status'] = 'trained: %s' % outdir.name
    contract_bundle = deploy_dir / 'cnn_contract.bundle.json'
    contract_bundle.write_text(
        json.dumps(bundle_contract, ensure_ascii=False, indent=2),
        encoding='utf-8')

    shutil.copy2(wsrc, deploy_dir / 'cnn_weights.dat')
    shutil.copy2(qsrc, deploy_dir / 'quant_params.entries.json')
    for source in [outdir/'quant/quantization_meta.json', outdir/'split_manifest.json',
                   outdir/'calibration_manifest.json', outdir/'detection_validation.json']:
        if source.exists(): shutil.copy2(source, deploy_dir/source.name)

    iw = int(c['input_frame']['w'])
    ih = int(c['input_frame']['h'])
    ic = int(c['input_frame']['ch'])
    last = c['layers'][-1]
    ow, oh, oc = int(last['out_w']), int(last['out_h']), int(last['out_ch'])
    nc = int(c['post']['num_class'])
    input_shape = [1, ic, ih, iw]
    output_shape = [1, oc, oh, ow]

    ds_names = (meta.get('dataset_yaml') or {}).get('names')
    if isinstance(ds_names, dict):
        class_names = [ds_names.get(str(i), ds_names.get(i, 'class_%d' % i))
                       for i in range(nc)]
    elif isinstance(ds_names, list):
        class_names = [str(ds_names[i]) if i < len(ds_names) else 'class_%d'%i for i in range(nc)]
    else:
        class_names = [(['starve','genshin'][i] if i < 2 else 'class_%d'%i) for i in range(nc)]

    training_info = {
        'samples': meta.get('samples'), 'train': meta.get('train'),
        'val': meta.get('val'), 'epochs': meta.get('epochs'),
        'batch': meta.get('batch'), 'lr': meta.get('lr'),
        'seed': meta.get('seed'), 'qat': meta.get('qat'),
        'grayscale_prob': meta.get('grayscale_prob'),
        'grayscale_formula': meta.get('grayscale_formula'),
        'empty_weight': meta.get('empty_weight'),
        'edge_mode': meta.get('edge_mode'),
        'edge_feature': meta.get('edge_feature'),
        'init_from': meta.get('init_from'),
        'classes_in_data': meta.get('label_classes'),
        'selection_metric': meta.get('selection_metric'),
        'split_sha256': meta.get('split_sha256'),
        'test_evaluated': False,
    }
    ckpt = {
        'format': 'qiansai_cnn_checkpoint_v1',
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'state_dict': {k: v.detach().cpu() for k, v in net.state_dict().items()},
        'contract': bundle_contract,
        'input_shape': input_shape,
        'output_shape': output_shape,
        'class_names': class_names,
        'metrics': meta.get('metrics', {}),
        'detection_validation': meta.get('detection_validation', {}),
        'training': training_info,
    }
    pt_path = model_dir / 'model.pt'
    torch.save(ckpt, pt_path)
    log('  %s  (state_dict + contract + metrics)' % pt_path, logfh)

    onnx_path = model_dir / 'model.onnx'
    if getattr(args, 'export_onnx', False):
        try:
            net_cpu = build_net(c)
            net_cpu.load_state_dict({k: v.detach().cpu() for k, v in net.state_dict().items()})
            net_cpu.eval()
            dummy = torch.zeros(*input_shape, dtype=torch.float32)
            try:
                # PyTorch 2.6+ 默认 dynamo 导出会额外依赖 onnxscript；
                # 这个网络结构简单，legacy exporter 足够且依赖更少。
                torch.onnx.export(
                    net_cpu, dummy, str(onnx_path),
                    input_names=['input'], output_names=['head'],
                    opset_version=13, do_constant_folding=True, dynamo=False)
            except TypeError:
                torch.onnx.export(
                    net_cpu, dummy, str(onnx_path),
                    input_names=['input'], output_names=['head'],
                    opset_version=13, do_constant_folding=True)
            log('  %s  (float/QAT reference)' % onnx_path, logfh)
        except Exception as exc:
            log('  !! ONNX 导出失败: %s' % exc, logfh)
            log('     如缺依赖：python -m pip install onnx', logfh)
            raise RuntimeError('Requested ONNX export failed; candidate bundle is incomplete') from exc
    else:
        log('  未导出 ONNX（加 --export-onnx 可导出）', logfh)

    geo_hash = _contract_geometry_sha256(c)
    weights_sha = _sha256_file(deploy_dir / 'cnn_weights.dat')
    qparams_sha = _sha256_file(deploy_dir / 'quant_params.entries.json')
    contract_sha = _sha256_file(contract_bundle)
    card = {
        'format': 'qiansai_cnn_model_card_v1',
        'model_name': getattr(args, 'model_name', None) or outdir.name,
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'training_run': outdir.name,
        'tool': 'train_cnn.py',
        'contract_geometry_sha256': geo_hash,
        'contract_file_sha256': contract_sha,
        'weights_sha256': weights_sha,
        'qparams_sha256': qparams_sha,
        'input_shape': input_shape,
        'output_shape': output_shape,
        'class_names': class_names,
        'metrics': meta.get('metrics', {}),
        'detection_validation': meta.get('detection_validation', {}),
        'training': training_info,
        'files': {
            'pytorch': 'model/model.pt',
            'onnx': 'model/model.onnx' if onnx_path.exists() else None,
            'deploy_weights': 'deploy/cnn_weights.dat',
            'deploy_qparams': 'deploy/quant_params.entries.json',
            'deploy_contract': 'deploy/cnn_contract.bundle.json',
        },
    }
    (outdir / 'model_card.json').write_text(
        json.dumps(card, ensure_ascii=False, indent=2), encoding='utf-8')

    manifest = dict(card)
    manifest['format'] = 'qiansai_cnn_deploy_bundle_v1'
    manifest['weights_file'] = 'cnn_weights.dat'
    manifest['qparams_file'] = 'quant_params.entries.json'
    manifest['contract_file'] = 'cnn_contract.bundle.json'
    (deploy_dir / 'deploy_manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

    (deploy_dir / 'README.md').write_text(
        '# X-AnyLabeling / CNN 部署包\n\n'
        '这个目录是训练产物的部署子包，不依赖训练项目。\n\n'
        '## 安装到工程\n\n'
        '```bat\n'
        'python "<Versions>\\scripts\\deploy_model_bundle.py" --bundle "<本目录>" '
        '--project "<工程本体目录>" --dry-run\n'
        'python "<Versions>\\scripts\\deploy_model_bundle.py" --bundle "<本目录>" '
        '--project "<工程本体目录>"\n'
        '```\n\n'
        '安装后在目标工程生成硬件初始化文件并检查。v2.3+ 工程使用：\n\n'
        '```bat\n'
        'cd /d "<工程本体目录>"\n'
        'python tools\\cnn_contract.py --generate\n'
        'python tools\\cnn_contract.py --check\n'
        '```\n\n'
        '旧 v1.7 工程使用：\n\n'
        '```bat\n'
        'cd /d "<Versions>"\n'
        '.\\scripts\\cnn_contract.ps1 -GenW ; -GenQrom ; -GenVh ; -Check\n'
        '.\\scripts\\cnn_flow.ps1 -Check -Mode external\n'
        '.\\scripts\\cnn_regress.ps1\n'
        'cd /d "<工程本体目录>"\n'
        '.\\build.ps1\n'
        '```\n\n'
        '`model.onnx` 是 float/QAT 参考模型；板上精确部署以 '
        '`cnn_weights.dat` + `quant_params.entries.json` 为准。\n',
        encoding='utf-8')

    log('  %s' % (deploy_dir / 'deploy_manifest.json'), logfh)
    log('  %s' % (outdir / 'model_card.json'), logfh)
    return card


# ---------------------------------------------------------------- 主流程
def run(args):
    if args.calibration_count < 1:
        raise ValueError('--calibration-count must be positive')
    if not 0.0 <= args.grayscale_prob <= 1.0:
        raise ValueError('--grayscale-prob must be in [0, 1]')
    if args.empty_weight < 1.0:
        raise ValueError('--empty-weight must be >= 1')
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    device = select_device(args.device)
    if device.type == 'cuda':
        torch.cuda.manual_seed_all(args.seed)
        torch.backends.cudnn.benchmark = True
    contract_path = Path(args.contract).expanduser() if args.contract else CONTRACT
    if contract_path is None:
        raise SystemExit('必须给 --contract，或设置 QIANSAI_PROJECT / project_root.txt')
    c = load_contract(contract_path); L = c['layers']
    NC = int(c['post']['num_class'])        # head 固定 8 通道 = obj + box4 + cls3，必须全训
    if int(args.classes) > NC:
        raise SystemExit('--classes %d 超过契约 post.num_class=%d' % (int(args.classes), NC))
    t_start = time.time()
    if args.install or args.flow_check:
        od = (Path(args.out) if args.out else
              ((ROOT / 'verification' / 'train_selftest') if ROOT
               else (Path.cwd() / 'verification' / 'train_selftest')))
        (od / 'logs').mkdir(parents=True, exist_ok=True)
        logfh = open(od / 'logs' / 'install.log', 'a', encoding='utf-8')
        log('=' * 60, logfh)
        log('CNN 模型安装/对拍  ' + time.strftime('%Y-%m-%d %H:%M:%S'), logfh)
        rc = 0
        if args.install:    rc |= install_artifacts(od, logfh, contract_path)
        if args.flow_check: rc |= flow_check(Path(args.flow_check), logfh, contract_path)
        logfh.close()
        return rc
    if args.selftest:
        outdir = (Path(args.out) if args.out else
                  ((ROOT / 'verification' / 'train_selftest') if ROOT
                   else (Path.cwd() / 'verification' / 'train_selftest')))
        data_items, calib_items = make_selftest_data(c, outdir / 'synth')
    else:
        if not args.data: raise SystemExit('必须给 --data，或用 --selftest')
        outdir = Path(args.out) if args.out else (Path(args.data) / 'runs' / ('train_' + time.strftime('%Y%m%d_%H%M%S')))
        data_items = collect_dataset(Path(args.data), NC)
        calib_items = data_items
    outdir.mkdir(parents=True, exist_ok=True)
    for sub in ('weights', 'quant', 'exp', 'logs'):
        (outdir / sub).mkdir(exist_ok=True)
    logfh = open(outdir / 'logs' / 'train.log', 'w', encoding='utf-8')

    # 可选：<data>\dataset.yaml（path / train / labels / nc / names）
    ds_nc = None; ds_names = None
    if args.data:
        # 两处都找：<数据根>\dataset.yaml 或 <数据根>\images\dataset.yaml
        _yp = None
        for _q in (Path(args.data) / 'dataset.yaml', Path(args.data) / 'images' / 'dataset.yaml'):
            if _q.exists():
                _yp = _q
                break
        if _yp is not None:
            try:
                import yaml
                _cfg = yaml.safe_load(_yp.read_text(encoding='utf-8')) or {}
                ds_nc = _cfg.get('nc'); ds_names = _cfg.get('names')
                log('dataset.yaml: nc=%s  names=%s' % (ds_nc, ds_names), logfh)
                if ds_nc is not None and int(ds_nc) != int(args.classes):
                    log('  !! dataset.yaml 的 nc=%s 与 --classes %s 不一致（以 --classes 为准）'
                        % (ds_nc, args.classes), logfh)
            except Exception as _e:
                log('  !! dataset.yaml 读取失败: %s' % _e, logfh)

    log('=' * 60, logfh)
    log('CNN 模型训练  ' + time.strftime('%Y-%m-%d %H:%M:%S'), logfh)
    log('输出目录: %s' % outdir, logfh)
    log('训练设备: %s' % (torch.cuda.get_device_name(device) if device.type == 'cuda'
                          else str(device)), logfh)
    log('数据集样本: %d' % len(data_items), logfh)
    used_cls = set()
    for _it in data_items:
        _clm = load_targets(_it[1], NC)[2]
        for _c in range(NC):
            if (_clm[_c] > 0.5).any():
                used_cls.add(_c)
    log('类别数: head %d 通道（契约固定），数据里实际用到 %d 类 %s   epoch: %d   batch: %d   lr: %g'
        % (NC, len(used_cls), sorted(used_cls), args.epochs, args.batch, args.lr), logfh)
    if len(used_cls) < NC:
        log('  注: 没用到的类别通道按"全负样本"训练——否则 RTL 的 argmax 会读到没训过的随机通道', logfh)

    # ---- 训练/验证划分（按文件名前缀分组，防泄漏）----
    if args.split_manifest:
        parts = load_fixed_split(data_items, args.split_manifest)
    else:
        parts = fixed_split(data_items, args.val_ratio, args.test_ratio, args.seed)
    tr, va = parts['train'], parts['val']
    save_fixed_split(parts, outdir/'split_manifest.json')
    sp_mode = 'by-scene'
    readiness = {}
    for name, items in parts.items():
        labels = [load_targets(it[1], NC)[-1] for it in items]
        classes = sorted({int(b['cls']) for boxes in labels for b in boxes})
        readiness[name] = dict(samples=len(items), classes=classes, empty=sum(not b for b in labels))
    (outdir/'data_audit.json').write_text(json.dumps(readiness, indent=2), encoding='utf-8')
    if args.audit_only:
        log(json.dumps(readiness, indent=2), logfh); logfh.close(); return 0
    if any(any(k not in row['classes'] for k in range(args.classes)) or not row['empty'] for row in readiness.values()):
        raise ValueError('Every split must contain each active class and empty backgrounds; see data_audit.json')
    nsc = len(set(scene_key(it) for it in data_items))
    log('划分: %s  场景数 %d  训练 %d / 验证 %d'
        % ('按场景组' if sp_mode == 'by-scene' else '逐图随机（场景组不足，可能有同场景泄漏）',
           nsc, len(tr), len(va)), logfh)
    if len(va) == 0 and len(data_items) > 2:
        log('  !! 验证集为空：所有样本的"场景前缀"相同。检查原始文件名是否带前缀，', logfh)
        log('     以及 id_map.csv 里的 src_file 列是否完整（划分按 src_file 的第一个下划线前分组）。', logfh)
    # Log imbalance; hard-negative mining replaces automatic positive weighting.
    npos = sum(int((load_targets(lp, NC)[0] > 0.5).sum()) for _, lp, _ in tr)
    nneg = len(tr) * 240 - npos
    if str(args.pos_weight).lower() not in ('auto', '1', '1.0'):
        raise ValueError('Hard-negative mining cannot be combined with pos_weight')
    pw = 1.
    log('obj: %d positive / %d negative; per-image hard negatives, no pos_weight' % (npos,nneg), logfh)

    trl = make_train_loader(tr, NC, args, device)
    empty_train = sum(not load_targets(lp, NC)[-1] for _, lp, _ in tr)
    log('augment: grayscale=%.0f%% board-formula; empty-weight=%.2f (%d/%d empty frames)'
        % (100.0 * args.grayscale_prob, args.empty_weight, empty_train, len(tr)), logfh)
    net = build_net(c).to(device); opt = torch.optim.Adam(net.parameters(), lr=args.lr)
    best = dict(loss=None, best_loss=None, f1=None, ep=0, sd=None)
    best_checkpoint = outdir / 'weights' / 'best_training.pt'
    valloader = torch.utils.data.DataLoader(
        DS(va, NC, edge_mode=args.edge_mode,
           edge_threshold=args.edge_threshold),
        batch_size=args.batch, **loader_options(args, device))

    init_info = None
    if args.init_from:
        _p = Path(args.init_from)
        if not _p.exists():
            raise SystemExit('--init-from 文件不存在: %s' % _p)
        _d = torch.load(_p, map_location='cpu', weights_only=False)
        net.load_state_dict(_d['state_dict'])
        if args.edge_mode == 'density' and args.zero_edge_init:
            with torch.no_grad():
                net.convs[0].weight[:, 3].zero_()
        init_info = dict(
            path=str(_p), sha256=digest(_p),
            edge_weights_zeroed=bool(
                args.edge_mode == 'density' and args.zero_edge_init))
        log('  从 %s 初始化权重（%d 个张量）' % (_p.name, len(_d['state_dict'])), logfh)
        if args.edge_mode == 'density' and args.zero_edge_init:
            log('  边缘密度模式：首层 CH3 权重已置零，旧 R/G/B 行为作为起点', logfh)

    def loss_fn(x, o, b, cl, h):
        return compute_loss(net(x), o, b, cl, h, NC, pw, args.box_weight)

    t0 = time.time()
    for ep in range(1, args.epochs + 1):
        net.train(); s = 0.0; nb = 0
        branches = np.zeros(3); grad_norm = 0.
        for x, o, b, cl, h in trl:
            x, o, b, cl, h = batch_to_device((x, o, b, cl, h), device)
            opt.zero_grad(); l, lo, lb, lc = loss_fn(x, o, b, cl, h); l.backward()
            gn = sum(float(p.grad.detach().square().sum()) for p in net.parameters() if p.grad is not None)**.5
            if not math.isfinite(gn): raise ValueError('Non-finite training gradient')
            grad_norm += gn; branches += [lo,lb,lc]; opt.step()
            s += float(l.detach()); nb += 1
        do_val = (ep == 1) or (ep % max(1, args.epochs // 10) == 0)
        if do_val or (ep % max(1, int(args.log_every)) == 0):
            vtxt = '   -   '; ftxt = '     -    '
            mark = ''
            if do_val:
                net.eval(); vs = 0.0; vn = 0
                with torch.no_grad():
                    for x, o, b, cl, h in valloader:
                        x, o, b, cl, h = batch_to_device((x, o, b, cl, h), device)
                        l, _, _, _ = loss_fn(x, o, b, cl, h); vs += float(l); vn += 1
                vl = vs / max(vn, 1)
                vtxt = '%.5f' % vl
                if len(va) > 0:
                    f1v = evaluate_model(
                        net, va, NC,
                        edge_mode=args.edge_mode,
                        edge_threshold=args.edge_threshold)['numerical']['map50']
                    ftxt = 'AP50 %.3f' % f1v
                    # Model selection uses decoded class-aware detection AP50.
                    if (best['f1'] is None) or (f1v > best['f1'] + 1e-9):
                        best['f1'] = f1v; best['ep'] = ep; best['best_loss'] = vl
                        best['sd'] = copy.deepcopy(net.state_dict())
                        tmp_checkpoint = best_checkpoint.with_suffix('.tmp')
                        torch.save(dict(
                            epoch=ep, validation_ap50=f1v, validation_loss=vl,
                            state_dict={k: v.detach().cpu()
                                        for k, v in net.state_dict().items()},
                            contract=c), tmp_checkpoint)
                        os.replace(tmp_checkpoint, best_checkpoint)
                        mark = '  *best'
                best['loss'] = vl
            per = (time.time() - t0) / ep
            eta = per * (args.epochs - ep)
            log('  epoch %4d/%d  train %.5f  val %s  %s  (%.1fs, %.2fs/ep, ETA %dm%02ds)%s'
                % (ep, args.epochs, s / max(nb, 1), vtxt, ftxt, time.time() - t0, per,
                   int(eta // 60), int(eta % 60), mark), logfh)
            log('    obj/box/cls=%s gradient_norm=%.6f' % ((branches/max(nb,1)).tolist(),grad_norm/max(nb,1)),logfh)
    log('训练结束，用时 %.1f s' % (time.time() - t0), logfh)
    if best['sd'] is not None and not args.keep_last:
        net.load_state_dict(best['sd'])
        log('  回滚到 validation AP50 最高的第 %d 轮（AP50=%.3f, val loss=%.5f）；最后一轮用 --keep-last'
            % (best['ep'], best['f1'], best['best_loss']), logfh)

    # ---- 量化 ----
    log('', logfh); log('--- 量化（校准式 PTQ）---', logfh)
    net.eval()
    with torch.no_grad():
        calib_items = stratified_calibration(tr, args.calibration_count, args.seed)
        calib_manifest = [
            dict(image=Path(it[0]).name, sha256=digest(it[0]), variant='rgb')
            for it in calib_items
        ]
        calib_parts = [
            DS(calib_items, NC, edge_mode=args.edge_mode,
               edge_threshold=args.edge_threshold)[i][0]
            for i in range(len(calib_items))
        ]
        gray_count = int(round(len(calib_items) * args.grayscale_prob))
        if gray_count:
            gray_items = random.Random(args.seed ^ 0x47524159).sample(
                calib_items, gray_count)
            calib_parts.extend(
                DS([it], NC, force_grayscale=True,
                   edge_mode=args.edge_mode,
                   edge_threshold=args.edge_threshold)[0][0]
                for it in gray_items)
            calib_manifest.extend(
                dict(image=Path(it[0]).name, sha256=digest(it[0]),
                     variant='board_gray') for it in gray_items)
        (outdir/'calibration_manifest.json').write_text(
            json.dumps(calib_manifest, indent=2), encoding='utf-8')
        calib = torch.stack(calib_parts)
    layers = quantize(net, calib, c, logfh)

    # ---- PTQ 掉点度量（判据 = RTL 的 obj_int8>=0）----
    ev = va if len(va) else tr
    ev_tag = '验证集' if len(va) else '无验证集,退回训练集'
    log('', logfh)
    log('--- PTQ 掉点度量（%s %d 张，判据 = RTL 的 obj_int8>=0）---' % (ev_tag, len(ev)), logfh)
    mf = cell_metrics_float(
        net, ev, NC, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    mq = cell_metrics_int8(
        layers, ev, L, c, NC, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    log_metrics('浮点 F32 ', mf, logfh)
    log_metrics('PTQ  int8', mq, logfh)
    pre_float = evaluate_model(
        net, ev, NC, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    pre_int = evaluate_model(
        net, ev, NC, layers, c, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    drop = 100.*(pre_float['numerical']['map50']-pre_int['numerical']['map50'])
    log('  detection validation AP50 drop = %+.2f pp; grid F1 above is auxiliary only' % drop, logfh)

    # ---- QAT：按需触发（冻结 PTQ 的 sw/shift/act_out）----
    qat_done = False
    qat_best = None
    if args.qat == 'off':
        log('  -> 不做 QAT（--qat off）', logfh)
    elif args.qat == 'auto' and drop <= 3.0:
        log('  -> 不做 QAT（掉点 <= 3 个百分点）', logfh)
    elif len(ev) == 0:
        log('  -> 不做 QAT（没有可评估的样本）', logfh)
    else:
        log('', logfh)
        log('--- QAT（%d epoch, lr=%g）---' % (args.qat_epochs, args.qat_lr), logfh)
        qat_best = run_qat(net, layers, L, tr, NC, pw, args, logfh, va, c)
        layers = reproject(net, layers, c, logfh)
        mq = cell_metrics_int8(
            layers, ev, L, c, NC, edge_mode=args.edge_mode,
            edge_threshold=args.edge_threshold)
        log_metrics('QAT  int8', mq, logfh)
        log('  QAT 后掉点 ΔF1 = %+.2f 个百分点' % (100.0 * (mf['f1'] - mq['f1'])), logfh)
        qat_done = True

    # ---- 验收④ + 量化底线（"输入无贡献"时不得越线）----
    log('', logfh); log('--- 验收④ / 量化底线 ---', logfh)
    log('  空场景(没有任何框) obj>=0 的格子: %d 个 / %d 张空场景（判据 ≈0）'
        % (mq['empty_fp'], mq['n_empty']), logfh)
    sh0 = int(layers[-1]['shift'][0]); b0 = int(layers[-1]['bias'][0])
    log('  head obj 通道 bias>>shift = %d（判据 < 0，否则"输入无贡献"的格子必然虚检）'
        % (b0 >> sh0), logfh)
    log('  obj 量化余量 margin = %s（判据 >= 32；负数说明有重叠）'
        % ('n/a' if mq['margin'] is None else '%d' % mq['margin']), logfh)
    log('  框尺寸标度 w_pred/w_true = %s（判据 ≈1.0；偏离说明 head 的 w/h 量化标度与"8px 单位"语义不一致）'
        % ('n/a' if mq.get('box_ratio') is None else '%.3f' % mq['box_ratio']), logfh)

    # ---- 整数参考前向 + 逐层数值体检 ----
    log('', logfh); log('--- 整数参考前向 + 逐层数值体检 ---', logfh)
    sample = DS(
        calib_items[:1], NC, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)[0][0].numpy().astype(np.int32)
    acts = int_forward(layers, sample, L, c)
    for li, ly in enumerate(L):
        a = acts[li]
        if li == len(L) - 1:
            sat = 100.0 * float(((a >= 127) | (a <= -128)).mean())
            log('  L%d HEAD int8 范围 [%d, %d]  形状 %s  饱和占比 %.2f%%  非零占比 %.1f%%'
                % (li, a.min(), a.max(), a.shape, sat, 100.0 * (a != 0).mean()), logfh)
        else:
            sat = 100.0 * float((a >= 127).mean())
            log('  L%d 输出 int8 范围 [%d, %d]  形状 %s  上限(127)占比 %.2f%%  非零占比 %.1f%%'
                % (li, a.min(), a.max(), a.shape, sat, 100.0 * (a != 0).mean()), logfh)

    # ---- 导出 ----
    log('', logfh); log('--- 导出 ---', logfh)
    pack = pack_weights(layers, L, c, logfh)
    wdat = outdir / 'weights' / 'cnn_weights.dat'
    wdat.write_text('\n'.join('%08x' % v for v in pack) + '\n', encoding='ascii')
    log('  %s  (%d 行)' % (wdat, len(pack)), logfh)

    entries = []
    for li, ly in enumerate(L):
        qbase = int(ly['q_base']); oc_n = int(ly['out_ch'])
        for oc in range(oc_n):
            entries.append(dict(oc=qbase + oc, shift=int(layers[li]['shift'][oc]),
                                bias=int(layers[li]['bias'][oc])))
    qj = outdir / 'quant' / 'quant_params.entries.json'
    qj.write_text(json.dumps(entries, indent=1), encoding='utf-8')
    log('  %s  (%d 条)' % (qj, len(entries)), logfh)
    scale_meta = dict(format='sc520_quantization_v2', layers=[dict(
        sw=q['sw'].tolist(), acc_scale=q['acc_scale'].tolist(), shift=q['shift'].tolist(),
        effective_scale=(q['acc_scale']*np.power(2., q['shift'])).tolist()) for q in layers],
        box_units='dx/dy=0.5 pixel; w/h=8 pixels',
        class_comparison='shared effective scale; MCU raw-byte argmax remains compatible')
    (outdir/'quant/quantization_meta.json').write_text(json.dumps(scale_meta, indent=2), encoding='utf-8')
    det_float = evaluate_model(
        net, va, NC, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    det_int = evaluate_model(
        net, va, NC, layers, c, edge_mode=args.edge_mode,
        edge_threshold=args.edge_threshold)
    (outdir/'detection_validation.json').write_text(json.dumps(dict(float=det_float, integer=det_int), indent=2), encoding='utf-8')

    for li in range(len(L)):
        f = outdir / 'exp' / ('exp_L%d.hex' % li)
        f.write_text('\n'.join('%08x' % v for v in layer_words(acts[li], L[li])) + '\n', encoding='ascii')
        log('  %s  (%d 字)' % (f, len(layer_words(acts[li], L[li]))), logfh)

    meta = dict(version=outdir.name, time=time.strftime('%Y-%m-%d %H:%M:%S'),
                samples=len(data_items), train=len(tr), val=len(va),
                epochs=args.epochs, batch=args.batch, lr=args.lr, classes=NC,
                label_classes=int(args.classes), seed=args.seed, selftest=bool(args.selftest),
                qat=('on' if qat_done else args.qat),
                edge_mode=args.edge_mode,
                edge_feature=(feature_metadata(args.edge_threshold)
                              if args.edge_mode == 'density' else None),
                init_from=init_info,
                grayscale_prob=args.grayscale_prob,
                grayscale_formula='(R>>2)+(G>>1)+(B>>2)',
                empty_weight=args.empty_weight,
                metrics=dict(float=mf, final=mq, ptq_drop_ap50_pp=round(drop, 2), grid_metrics_auxiliary=True),
                dataset_yaml=dict(nc=ds_nc, names=ds_names),
                device=dict(type=device.type,
                            name=(torch.cuda.get_device_name(device)
                                  if device.type == 'cuda' else 'cpu'),
                            torch=torch.__version__, cuda=torch.version.cuda),
                seconds=round(time.time() - t_start, 1))
    meta.update(selection_metric='validation mAP50 (class-aware IoU>=0.5)',
                selected_epoch=(args.epochs if args.keep_last else best['ep']),
                selected_validation_ap50=(None if args.keep_last else best['f1']),
                selected_validation_loss=(None if args.keep_last else best['best_loss']),
                best_checkpoint_sha256=(digest(best_checkpoint)
                                        if best_checkpoint.exists() else None),
                detection_validation=dict(float=det_float, integer=det_int),
                split_sha256=digest(outdir/'split_manifest.json'),
                test_evaluated=False, box_weight=args.box_weight, qat_best=qat_best,
                quantization_meta_sha256=digest(outdir/'quant/quantization_meta.json'))
    (outdir / 'meta.json').write_text(json.dumps(meta, indent=1, ensure_ascii=False), encoding='utf-8')
    log('  %s' % (outdir / 'meta.json'), logfh)

    if not args.no_pt:
        pt = outdir / 'weights' / 'model_fp32.pt'
        torch.save(dict(state_dict={k: v.detach().cpu() for k, v in net.state_dict().items()},
                        layers=c['layers'], meta=meta), pt)
        log('  %s  (%.1f KB, state_dict + layers + meta)' % (pt, pt.stat().st_size / 1024.0), logfh)

    if getattr(args, 'export_bundle', False):
        export_model_bundle(outdir, net, c, args, meta, logfh)

    log('', logfh)
    log('部署建议：', logfh)
    log('  python scripts\\deploy_model_bundle.py --bundle "%s" --project "<目标工程本体>"' % (outdir / 'deploy'), logfh)
    log('  v2.3+: cd <目标工程本体> && python tools\\cnn_contract.py --generate && python tools\\cnn_contract.py --check', logfh)
    log('  v1.7 : .\\scripts\\cnn_contract.ps1 -GenW ; -GenQrom ; -GenVh ; -Check', logfh)
    log('  python scripts\\train_cnn.py --flow-check verification\\cnn_flow   <- 按同一输入帧算 exp_L*.hex', logfh)
    log('  .\\scripts\\cnn_flow.ps1 -Check -Mode external   <- 验收②：逐层逐字 0 mismatch', logfh)
    log('  .\\scripts\\cnn_regress.ps1                      <- 回归清单全部通过', logfh)
    log('  推荐 GUI：scripts\\run_dataset_wizard.cmd -> 第 4 步（选择本版本目录）', logfh)
    logfh.close()
    return 0

# ---------------------------------------------------------------- 数据集辅助
def collect_dataset(root, NC):
    """扫 images/*.jpg + labels/*.json。

    每项 = (图片路径, 标注路径, 原始文件名)。
    第 3 项只用于划分：dataset_core.ps1 会把图片统一改名成 0001.jpg（场景前缀没了），
    原始文件名记在 id_map.csv 的 src_file 列里，必须从那里取，否则防泄漏分组会退化成一组。
    """
    # 只认图片扩展名：X-AnyLabeling 会把原生 0001.json 直接写在图片旁边，
    # 用 images/* 通配会把 json 也当成图片（实测 51 张被算成 102 张，PIL 直接报错）
    IMG_EXT = ('.jpg', '.jpeg', '.png', '.bmp')
    imgs = sorted(p for p in (root / 'images').glob('*') if p.suffix.lower() in IMG_EXT)
    lab = root / 'labels'
    names = {}
    mp = root / 'id_map.csv'
    if mp.exists():
        with open(mp, 'r', encoding='utf-8-sig', newline='') as fh:
            for row in csv.DictReader(fh):
                k = (row.get('new_file') or '').strip()
                v = (row.get('src_file') or '').strip()
                if k and v:
                    names[k] = v
    items = []
    missing = []
    for p in imgs:
        lp = lab / (p.stem + '.json')
        if lp.exists():
            items.append((str(p), str(lp), names.get(p.name, p.name)))
        else:
            missing.append(p.name)
    if missing:
        raise ValueError('Images without internal labels (empty scenes also need boxes=[]): '+str(missing[:20]))
    if not items:
        raise SystemExit('数据集里没有 (图片, 标注) 配对：%s' % root)
    nsrc = sum(1 for it in items if it[2] != Path(it[0]).name)
    print('  数据集: %d 张有标注（%d 张从 id_map.csv 取到原始名）' % (len(items), nsrc))
    return items

def scene_key(item):
    """用【原始文件名】第一个下划线之前的部分当"场景"，用于防验证集泄漏"""
    n = Path(item[2]).stem
    return n.split('_')[0] if '_' in n else '__all__'

def split_by_scene(items, ratio, seed):
    """Compatibility entry point: scene-isolated train/val, with held-out test."""
    parts = fixed_split(items, ratio, .2, seed)
    return parts['train'], parts['val'], 'by-scene'

# ---------------------------------------------------------------- 自测数据
def make_selftest_data(c, base_dir=None):
    """合成数据集：浅底 + 深色小方块（模拟"黑色目标 on 浅色背景"）"""
    from PIL import Image, ImageDraw
    d = (Path(base_dir) if base_dir else
         ((ROOT / 'verification' / 'train_selftest' / 'synth') if ROOT
          else (Path.cwd() / 'verification' / 'train_selftest' / 'synth')))
    (d / 'images').mkdir(parents=True, exist_ok=True)
    (d / 'labels').mkdir(parents=True, exist_ok=True)
    items = []
    rnd = random.Random(7)
    for i in range(40):
        scene = ['desk', 'wall', 'dark', 'floor'][i % 4]
        W, H = 1280, 720
        bg = {'desk': 200, 'wall': 185, 'dark': 70, 'floor': 150}[scene]
        im = Image.new('RGB', (W, H), (bg, bg - 6, bg - 12))
        dr = ImageDraw.Draw(im)
        for _ in range(30):                      # 木纹
            y = rnd.randint(0, H); dr.line([(0, y), (W, y + rnd.randint(-3, 3))],
                                           fill=(bg - 25, bg - 30, bg - 35), width=1)
        sz = rnd.randint(240, 360)
        x1 = rnd.randint(60, W - sz - 60); y1 = rnd.randint(40, H - sz - 40)
        x2, y2 = x1 + sz, y1 + sz
        dr.rounded_rectangle([x1, y1, x2, y2], radius=sz // 5, fill=(22, 22, 24))
        dr.ellipse([x1 + sz // 5, y1 + sz // 5, x1 + sz // 5 + sz // 6, y1 + sz // 5 + sz // 6],
                   fill=(210, 170, 115))
        name = '%s_%02d' % (scene, i)
        im.save(d / 'images' / (name + '.jpg'), quality=95)
        # 内部标注（与 dataset_core.ps1 的格式一致）
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        gx = min(19, int(cx // 64)); gy = min(11, int(cy // 60))
        rec = dict(image=name + '.jpg', src_file=name + '.jpg', boxes=[dict(
            cls=0, x1=x1, y1=y1, x2=x2, y2=y2, cx=cx, cy=cy,
            gx=gx, gy=gy,
            dx=int(round((cx - (gx * 64 + 32)) * 2)),
            dy=int(round((cy - (gy * 60 + 30)) * 2)),
            w=int(round((x2 - x1) / 8)), h=int(round((y2 - y1) / 8)),
            clipped=False, height_share=round((y2 - y1) / H, 3))])
        (d / 'labels' / (name + '.json')).write_text(json.dumps(rec, ensure_ascii=False), encoding='utf-8')
        items.append((str(d / 'images' / (name + '.jpg')), str(d / 'labels' / (name + '.json')), name + '.jpg'))
    return items, items

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='CNN 训练、量化与模型包导出')
    ap.add_argument('--data'); ap.add_argument('--out')
    ap.add_argument('--contract', help='cnn_contract.json 路径（独立训练时必填；默认取工程根）')
    ap.add_argument('--epochs', type=int, default=200)
    ap.add_argument('--batch', type=int, default=16)
    ap.add_argument('--lr', type=float, default=2e-3)
    ap.add_argument('--classes', type=int, default=1, help='数据里实际用到的类别数（head 类别通道固定 3；单类数据集保持 1）')
    ap.add_argument('--val-ratio', type=float, default=0.2)
    ap.add_argument('--test-ratio', type=float, default=0.2)
    ap.add_argument('--split-manifest', help='Frozen train/val/test manifest with content hashes')
    ap.add_argument('--audit-only', action='store_true', help='Audit labels/splits and exit before creating optimizer')
    ap.add_argument('--calibration-count', type=int, default=256)
    ap.add_argument('--device', choices=['auto', 'cpu', 'cuda'], default='cuda',
                    help='训练设备；默认 CUDA，不可用时明确失败；CPU 必须显式指定')
    ap.add_argument('--num-workers', type=int, default=4,
                    help='DataLoader 预处理进程数；Windows 推荐 4')
    ap.add_argument('--box-weight', type=float, choices=[1.,2.,4.], default=2.)
    ap.add_argument('--grayscale-prob', type=float, default=0.0,
                    help='训练时按板端公式转为灰度的概率；建议从 0.2 开始')
    ap.add_argument('--edge-mode', choices=['zero', 'density'], default='zero',
                    help='第4通道：zero=旧模型兼容；density=板端8x8边缘密度')
    ap.add_argument('--edge-threshold', type=int, default=80,
                    help='边缘密度固定阈值；必须与RTL保持一致')
    ap.add_argument('--zero-edge-init', action='store_true',
                    help='从非边缘模型热启动时清空首层 CH3 权重；续训必须关闭')
    ap.add_argument('--empty-weight', type=float, default=1.0,
                    help='空场景训练采样权重；数据集1027建议从 3.0 开始')
    ap.add_argument('--seed', type=int, default=20261017)
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--install', action='store_true', help='把 --out 的产物装进 RTL 侧')
    ap.add_argument('--flow-check', metavar='DIR', help='按 DIR 的 w_rtl/in_frame 算 exp_L*.hex')
    ap.add_argument('--qat', choices=['auto', 'on', 'off'], default='auto',
                    help='QAT: auto uses validation detection AP50 drop >3 pp')
    ap.add_argument('--pos-weight', default='1', help='Compatibility only: 1/auto disables pos_weight under hard mining')
    ap.add_argument('--keep-last', action='store_true', help='Explicit experimental override; default selects validation AP50')
    ap.add_argument('--log-every', type=int, default=1, help='每 N 轮打一行进度（默认每轮，便于终端观察）')
    ap.add_argument('--no-pt', action='store_true', help='不保存 weights\\model_fp32.pt（默认保存）')
    ap.add_argument('--init-from', metavar='PT', help='从 model_fp32.pt 初始化，继续训练/微调')
    ap.add_argument('--qat-epochs', type=int, default=60)
    ap.add_argument('--qat-lr', type=float, default=2e-4)
    ap.add_argument('--export-bundle', action='store_true',
                    help='训练后生成 model.pt + deploy 部署包（可分享给队友）')
    ap.add_argument('--export-onnx', action='store_true',
                    help='同时导出 model.onnx（需要 onnx 包）')
    ap.add_argument('--model-name', help='模型名，写入 model_card.json')
    sys.exit(run(ap.parse_args()))
