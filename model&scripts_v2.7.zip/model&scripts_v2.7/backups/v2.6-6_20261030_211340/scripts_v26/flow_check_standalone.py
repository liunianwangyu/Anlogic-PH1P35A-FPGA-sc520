#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
flow_check_standalone.py -- 不依赖 PyTorch 的整数参考前向

部署侧只需要 numpy 就能按契约重算 exp_L*.hex，再交给 ModelSim/cnn_flow.ps1 对拍。
这样队友部署权重时不需要安装 torch/torchvision。

用法：
  python scripts\flow_check_standalone.py ^
    --contract "<project>\user_source\hdl_source\cnn\cnn_contract.json" ^
    --flow-dir "<project>\verification\cnn_flow"
"""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

INT8_MIN, INT8_MAX = -128, 127


def sat8(v):
    return INT8_MIN if v < INT8_MIN else (INT8_MAX if v > INT8_MAX else int(v))


def clamp_relu127(v):
    return 0 if v < 0 else (127 if v > 127 else int(v))


def read_text_raw(path):
    with open(path, 'r', encoding='utf-8', newline='') as f:
        return f.read()


def write_text_raw(path, text):
    with open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(text)


def frame_from_words(words, c):
    iw = int(c['input_frame']['w'])
    ih = int(c['input_frame']['h'])
    x = np.zeros((4, ih, iw), np.int32)
    for y in range(ih):
        for xx in range(iw):
            wd = int(words[y * iw + xx])
            for k in range(3):
                b = (wd >> (8 * k)) & 0xFF
                x[k, y, xx] = b - 256 if b >= 128 else b
    return x


def unpack_weights(words, L):
    assert len(words)%4 == 0
    lane_words = len(words)//4
    Ws = []
    for li, ly in enumerate(L):
        oc_n, ic_n = int(ly['out_ch']), int(ly['in_ch'])
        tap_n = 9 if ly['ksel'] else 1
        k = 3 if ly['ksel'] else 1
        ng = ic_n // 4
        nocg = oc_n // 4
        wbase = int(ly['w_base'])
        W = np.zeros((oc_n, ic_n, tap_n), np.int32)
        for cog in range(nocg):
            for m in range(4):
                for ct in range(tap_n):
                    for cg in range(ng):
                        a = wbase + cog * tap_n * ng + ct * ng + cg
                        assert 0 <= a < lane_words, ("weight address overflow", a, lane_words)
                        wd = int(words[m * lane_words + a])
                        for kk in range(4):
                            occ = cog * 4 + m
                            icc = cg * 4 + kk
                            if icc < ic_n:
                                b = (wd >> (8 * kk)) & 0xFF
                                W[occ, icc, ct] = b - 256 if b >= 128 else b
        Ws.append(W.reshape(oc_n, ic_n, k, k))
    return Ws


def layers_from_contract(c, Ws):
    ent = c['quant_params']['entries']
    out = []
    for li, ly in enumerate(c['layers']):
        qb = int(ly['q_base'])
        oc_n = int(ly['out_ch'])
        out.append(dict(
            Wq=Ws[li],
            shift=np.array([int(ent[qb + oc]['shift']) for oc in range(oc_n)], np.int64),
            bias=np.array([int(ent[qb + oc]['bias']) for oc in range(oc_n)], np.int64),
            relu6=int(ly['relu6'])))
    return out


def int_forward(layers, x_i8, L, c):
    acts = []
    cur = x_i8.astype(np.int32)
    for li, ly in enumerate(L):
        W = layers[li]['Wq']
        bias = layers[li]['bias']
        sh = layers[li]['shift']
        k = 3 if ly['ksel'] else 1
        st = int(ly['stride'])
        pad = 1 if k == 3 else 0
        oc_n = W.shape[0]
        ow, oh = int(ly['out_w']), int(ly['out_h'])
        padded = np.pad(cur, ((0, 0), (pad, pad), (pad, pad))) if pad else cur
        out = np.zeros((oc_n, oh, ow), np.int32)
        for oy in range(oh):
            for ox in range(ow):
                blk = padded[:, oy * st:oy * st + k, ox * st:ox * st + k]
                for oc in range(oc_n):
                    acc = int(bias[oc]) + int((W[oc] * blk).sum())
                    acc = acc >> int(sh[oc])
                    out[oc, oy, ox] = clamp_relu127(acc) if ly['relu6'] else sat8(acc)
        cur = out
        acts.append(cur)
    return acts


def layer_words(act, ly):
    oc_n, oh, ow = act.shape
    ng = oc_n // 4
    out = []
    for oy in range(oh):
        for ox in range(ow):
            for cg in range(ng):
                wd = 0
                for k in range(4):
                    wd |= (int(act[cg * 4 + k, oy, ox]) & 0xFF) << (8 * k)
                out.append(wd)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--contract', required=True)
    ap.add_argument('--flow-dir', required=True)
    args = ap.parse_args()

    contract_path = Path(args.contract).resolve()
    flow_dir = Path(args.flow_dir).resolve()
    wpath = flow_dir / 'w_rtl.hex'
    fpath = flow_dir / 'in_frame.hex'
    for p in (wpath, fpath):
        if not p.exists():
            raise SystemExit('缺文件: %s' % p)

    c = json.loads(contract_path.read_text(encoding='utf-8'))
    L = c['layers']
    words = [int(t, 16) for t in read_text_raw(wpath).split()]
    fw = [int(t, 16) for t in read_text_raw(fpath).split()]
    expected = 4*c["weight_layout"]["words_per_instance"]
    if len(words) != expected:
        raise SystemExit('w_rtl.hex 行数 %d != %d' % (len(words),expected))
    iw = int(c['input_frame']['w'])
    ih = int(c['input_frame']['h'])
    if len(fw) != iw * ih:
        raise SystemExit('in_frame.hex 行数 %d != %d' % (len(fw), iw * ih))

    x = frame_from_words(fw, c)
    acts = int_forward(layers_from_contract(c, unpack_weights(words, L)), x, L, c)
    for li in range(len(L)):
        out = flow_dir / ('exp_L%d.hex' % li)
        write_text_raw(out, '\n'.join('%08x' % v for v in layer_words(acts[li], L[li])) + '\n')
        print('  %s  (%d 字)' % (out.name, len(layer_words(acts[li], L[li]))))
    print('PASS FLOW_REF: %d 层整数参考已生成' % len(L))
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    raise SystemExit(main())
