# Edge-density training preflight

Status: ready for observation-only pretraining. No training run has been
started and no hardware or v2.6 root model has been replaced.

## Baseline preservation

- Original package remains at
  `D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8`.
- A complete byte-identical copy exists at `baseline_v2.4-8/`.
- Core baseline files compared with SHA256:
  `model/model.pt`, `weights/model_fp32.pt`, `weights/best_training.pt`,
  `deploy/cnn_weights.dat`, `deploy/quant_params.entries.json`,
  `VERSION.json`, `model_card.json`, the MCU BIN and the FPGA BIT.
- All core comparisons pass.
- The source package's SHA256SUMS has 87 matching entries and one mismatch,
  `scripts/dataset_wizard.config.json`. This is wizard UI configuration, not
  model, quantization, firmware or FPGA application content.

## Dataset audit

- Dataset: `D:\Works\QianSai\Versions\datasets\dataset1027`
- All 4970 images are RGB and exactly 1280x720.
- Train: 2727 images from S02/S03/S04, including 156 empty scenes.
- Validation: 395 images from S05, including 180 empty scenes.
- Locked test: 1848 images from S01, including 356 empty scenes.
- No image, label or split changes are needed.

## Edge feature checks

- The optimized median-3 implementation was compared against the existing
  sort-based spatial oracle on four independent 1280x720 random images.
- C4 mismatch count: 0.
- A real S05 frame produced C4 range 0..127 with 12.6% nonzero tiles.
- A baseline checkpoint loads into the unchanged four-channel model and
  completes a forward pass with the new input path.
- All package Python scripts pass `py_compile`.
- The PowerShell training wrapper parses and its CUDA dry run resolves
  PyTorch 2.7.1+cu118 on the RTX 4060.

## Observation-only run

Command:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File "D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.6\scripts\train_edge.ps1" `
  -Mode pretrain
```

Configuration:

- Output: `D:\Works\QianSai\Versions\runs\edge_test0`
- Initialization: `baseline_v2.4-8\weights\best_training.pt`
- CH3 first-layer weights: zero
- Edge mode: density
- Edge threshold: 80
- Epochs: 5
- Batch: 32
- Learning rate: 5e-5
- QAT: off
- Calibration samples: 128
- Export bundle/ONNX: off

The pretrain run is observational. Its model must not be installed as the
final deployable model until the validation result is reviewed.
