# Deployment guide: model&scripts_v2.4-8

Use only `scripts/deploy_cnn.ps1` as the deployment entry point.

For the retained four-step GUI, launch `scripts\run_dataset_wizard.cmd`. Its deployment page uses the same `deploy_cnn.ps1` entry point and refreshes the selected model, weight timestamp, BIT/BIN state, and threshold after deployment.

1. Choose the target project root.
2. Run the packaged one-click command with `-Pnr`.
3. Require `PASS CNN_CONTRACT`, `PASS CNN_FLOW_TB`, `PASS CNN_FLOW`, and `REBUILD_FLOW_RETURNED`.
4. The script installs `cnn_weights.dat`, merges 36 qparams, synchronizes threshold 131, generates `.dath` inputs and rebuilds the BIT.
5. The `burn/` directory also contains the matching MCU BIN. Program it at Flash offset `0x00E00000`.
6. Complete physical-board acceptance after programming.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8\scripts\deploy_cnn.ps1' -Out 'D:\Works\QianSai\Versions\model&scripts\model&scripts_v2.4-8' -ProjectRoot '<PROJECT_ROOT>' -Pnr
```
