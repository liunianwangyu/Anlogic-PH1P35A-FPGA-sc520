# SC520 v2.6 model deployment

The trained int8 weights, quantized parameters, contract and deployment
manifest are in `deploy/`.

## Verify

```powershell
& "<python.exe>" `
  ".\scripts_v26\deploy_model_bundle.py" `
  --bundle "." `
  --project "<target-project-root>" `
  --dry-run
```

## Install

```powershell
& "<python.exe>" `
  ".\scripts_v26\deploy_model_bundle.py" `
  --bundle "." `
  --project "<target-project-root>"
```

The target project must declare:

```text
R,G,B,EDGE_DENSITY
```

Projects using `R,G,B,PAD` are rejected. Do not force installation into an
unchanged v2.6-5 baseline because its RTL sends zero on CH3.

For a full install with contract generation and ModelSim validation:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File ".\scripts_v26\deploy_cnn.ps1" `
  -Out "." -ProjectRoot "<target-project-root>" `
  -Python "<python.exe>" -Threshold 131
```

The BIT must be rebuilt after installing ROM-initialized weights. Files under
top-level `burn/` are still the old non-edge baseline and must not be paired
with this model.
