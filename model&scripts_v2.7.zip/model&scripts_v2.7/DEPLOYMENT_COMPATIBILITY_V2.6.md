# Deployment compatibility

## Supported model contract

- Channel order: `R,G,B,EDGE_DENSITY`
- Input shape: `1x4x90x160`
- Edge threshold: `80`
- Recommended post-processing threshold: `131`
- Contract geometry SHA256:
  `88ae3dce7f0896eb45cc5df951876e9498a02026394cb19cf027a51c74135714`

## Target-project requirement

The target project must use the same CNN layer geometry and provide a
non-zero fourth input channel generated from the board-aligned 8x8 edge
density path.

The current baseline directory
`lab_integrated_sc520_720p_v2.6-5` still declares:

```text
R,G,B,PAD
```

It is therefore intentionally rejected by the deployment tool. Installing
these weights into the unchanged baseline would produce incorrect inference
because the RTL would send zero on CH3.

## Check

Run from the package directory:

```powershell
& "D:\开发环境\miniconda3\envs\roi_video\python.exe" `
  ".\scripts_v26\deploy_model_bundle.py" `
  --bundle "." --project "<target-v2.6-project>" --dry-run
```

Expected for a compatible project:

```text
input channels: R,G,B,EDGE_DENSITY -> R,G,B,EDGE_DENSITY
contract geometry: 88ae... (MATCH)
[dry-run] 未写入任何文件。
```

Expected for the unchanged PAD baseline:

```text
输入通道契约不匹配，拒绝安装
```
