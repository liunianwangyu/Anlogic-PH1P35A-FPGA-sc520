puts "REBUILD_BEGIN"
cd [file dirname [file normalize [info script]]]
if {[catch {
import_device ph1_35p.db -package PH1P35MDG324 -speed 3
open_project camera_to_dsi_display.al
# Reproducible official placement seed; original project timing constraints.
set_param place seed 2 -run phy_1
set_param route effort normal -run phy_1
if {[info exists ::env(TD_PHY_ONLY)] && $::env(TD_PHY_ONLY) eq "1"} {
    reset_runs phy_1
    file mkdir camera_to_dsi_display_Runs/phy_1
    file copy -force guarded_physical_flow.tcl camera_to_dsi_display_Runs/phy_1/camera_to_dsi_display.tcl
    launch_runs phy_1 -jobs 1
} else {
    reset_runs syn_1
    file mkdir camera_to_dsi_display_Runs/phy_1
    file copy -force guarded_physical_flow.tcl camera_to_dsi_display_Runs/phy_1/camera_to_dsi_display.tcl
    launch_runs {syn_1 phy_1} -jobs 1
    wait_run syn_1 -quiet
}
wait_run phy_1 -quiet
close_project
} message]} {
    puts stderr "REBUILD_FAILED: $message"
    catch {close_project}
    exit 1
}
puts "REBUILD_FLOW_RETURNED"
exit



