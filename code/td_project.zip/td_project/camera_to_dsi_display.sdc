create_clock -name {sys_clk_50m} -period 20.000 -waveform {0.000 10.000} [get_ports {I_sys_clk}]
create_clock -name {mipi_rx_ck_pad} -period 2.415 -waveform {0.000 1.208} [get_nets {IO_rx_clk_pad_p}]

# v1.5 hard-MCU AHB DPLL output is 100 MHz and has independent phase.
create_clock -name {MCU_AHB_CLK} -period 10.000 -waveform {0.000 5.000} [get_pins {*PH1P_PHY_MCU*.ahb_clk}]

derive_clocks

# Official reset IP: except only the first request CDC stage.
set_false_path -to [get_regs {u_system_reset/u_low_per_fun/cdc_synchronization_external[0]}]

rename_clock -name {pll_clk_100m} [get_clocks {u_PLL/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.clkc[0]}]
rename_clock -name {pll_clk_24m} [get_clocks {u_PLL/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.clkc[1]}]
rename_clock -name {HDMI_PIXEL_CLK} [get_clocks {u_PLL/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.clkc[4]}]
rename_clock -name {HDMI_SERIAL_CLK} [get_clocks {u_PLL/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.clkc[5]}]

rename_clock -name {MIPI_RX_BYTE_CLK} [get_clocks {u_mipi_dphy_rx_ph1p_mipiio_wrapper/u_ph1p_mipiio_rx_wrapper/u_PH1P_LOGIC_DPHY_MIPI_RX.o_fabric_div4_8_clk}]


set_clock_groups -asynchronous \
    -group [get_clocks {mipi_rx_ck_pad MIPI_RX_BYTE_CLK}] \
    -group [get_clocks {sys_clk_50m pll_clk_100m pll_clk_24m HDMI_PIXEL_CLK HDMI_SERIAL_CLK}] \
    -group [get_clocks {u_ph1p35_324_ddr_wrapper/u_ddr2/ddr_clk u_ph1p35_324_ddr_wrapper/u_ddr2/usr_clk}]

# The 24 MHz to HDMI paths terminate at the diagnostic/status synchronizers'
# first stages. They are sampled asynchronously; later display logic remains
# timed by HDMI_PIXEL_CLK. The 24 MHz to CSI effect configuration handshake
# is covered by the asynchronous clock groups above.
set_false_path -from [get_clocks {pll_clk_24m}] \
    -to [get_clocks {HDMI_PIXEL_CLK}]

# Coherent AE mailbox: only handshake/status first synchronizer stages are
# asynchronous endpoints. Bundled data is held through the complete handshake.
set_false_path -to [get_regs {*u_mailbox/ack_meta *u_mailbox/done_meta *u_mailbox/req_meta *u_mailbox/status_meta* *u_mailbox/event_meta}]
set_max_delay 20.000 -from [get_regs {*u_mailbox/request_bundle*}] -to [get_regs {*u_mailbox/snapshot*}]
set_false_path -hold -from [get_regs {*u_mailbox/request_bundle*}] -to [get_regs {*u_mailbox/snapshot*}]
# Result bounds/update also feed scheduler state. The immutable result bank is
# observed only after done_meta -> done_sync -> O_done, at least three control
# edges after COMMIT. Bound every result fanout to one 42 ns control period.
set_max_delay 40.000 -from [get_regs {*u_mailbox/result_params* *u_mailbox/result_update}] -to [get_regs {*u_scheduler/*}]
set_false_path -hold -from [get_regs {*u_mailbox/result_params* *u_mailbox/result_update}] -to [get_regs {*u_scheduler/*}]

# MCU migration: one four-phase/toggle APB mailbox crosses independent
# MCU_AHB_CLK and MIPI_RX_BYTE_CLK. Only first handshake synchronizer stages
# are asynchronous; each second synchronizer and all intra-domain logic stay
# timed. Request/response bundles remain immutable until acknowledgement.
# The receiver captures after two complete destination clock intervals
# (minimum 2*9.660 ns), so bound data routing to 18 ns rather than declaring
# the bundled data paths unbounded false paths. Existing video periods and
# existing timing exceptions above are unchanged.
set_false_path -to [get_regs {u_mcu_csi_bus/req_meta u_mcu_csi_bus/ack_meta u_mcu_csi_bus/abort_meta}]
set_max_delay 18.000 -from [get_regs {u_mcu_csi_bus/request_data*}] -to [get_regs {u_mcu_csi_bus/dst_data*}]
set_false_path -hold -from [get_regs {u_mcu_csi_bus/request_data*}] -to [get_regs {u_mcu_csi_bus/dst_data*}]
set_max_delay 18.000 -from [get_regs {u_mcu_csi_bus/response_data* u_mcu_csi_bus/response_error}] -to [get_regs {u_mcu_csi_bus/reply_data* u_mcu_csi_bus/reply_error}]
set_false_path -hold -from [get_regs {u_mcu_csi_bus/response_data* u_mcu_csi_bus/response_error}] -to [get_regs {u_mcu_csi_bus/reply_data* u_mcu_csi_bus/reply_error}]

# v1.8: independent MCU-to-HDMI histogram mailbox. Only the first handshake
# stages are asynchronous. Bundles settle before the synchronized toggle is
# consumed; 18 ns is below two cycles of either 100 MHz AHB or 75 MHz HDMI.
set_false_path -to [get_regs {u_mcu_histogram_bus/req_meta u_mcu_histogram_bus/ack_meta u_mcu_histogram_bus/abort_meta}]
set_max_delay 18.000 -from [get_regs {u_mcu_histogram_bus/request_data*}] -to [get_regs {u_mcu_histogram_bus/dst_data*}]
set_false_path -hold -from [get_regs {u_mcu_histogram_bus/request_data*}] -to [get_regs {u_mcu_histogram_bus/dst_data*}]
set_max_delay 18.000 -from [get_regs {u_mcu_histogram_bus/response_data* u_mcu_histogram_bus/response_error}] -to [get_regs {u_mcu_histogram_bus/reply_data* u_mcu_histogram_bus/reply_error}]
set_false_path -hold -from [get_regs {u_mcu_histogram_bus/response_data* u_mcu_histogram_bus/response_error}] -to [get_regs {u_mcu_histogram_bus/reply_data* u_mcu_histogram_bus/reply_error}]

# The bus reset is asynchronous to each peripheral. Only its entry into the
# dedicated reset synchronizer is excepted. The synchronizer's two local
# stages, and local reset release into all peripheral state/data registers,
# retain their normal setup/hold and recovery/removal checks.
set_false_path -from [get_regs {*u_ae_mcu/bus_reset_release*}] \
    -to [get_regs {u_mcu_histogram_bus/dst_reset_release* u_mcu_csi_bus/dst_reset_release*}]

# v1.8 MCU menu: except only asynchronous first-stage handshake/IO FFs.
# Config buses stay immutable until ACK; both destinations capture after
# two complete local edges. SRAM writes never target the displayed bank.
set_false_path -to [get_regs {u_ui_control_cdc/req_meta u_ui_control_cdc/ack_meta u_ui_pixel_cdc/req_meta u_ui_pixel_cdc/ack_meta u_ui_ae_status_cdc/req_meta u_ui_ae_status_cdc/ack_meta u_ui_osd/pub_meta u_ui_osd/ack_meta u_ui_osd/valid_meta u_ui_osd/key_meta* u_ui_osd/sw_meta*}]
set_max_delay 18.000 -from [get_regs {u_ui_control_cdc/src_hold* u_ui_pixel_cdc/src_hold*}] -to [get_regs {u_ui_control_cdc/dst_pending* u_ui_pixel_cdc/dst_pending*}]
set_false_path -hold -from [get_regs {u_ui_control_cdc/src_hold* u_ui_pixel_cdc/src_hold*}] -to [get_regs {u_ui_control_cdc/dst_pending* u_ui_pixel_cdc/dst_pending*}]
set_max_delay 18.000 -from [get_regs {u_ui_ae_status_cdc/mean_hold*}] -to [get_regs {u_ui_ae_status_cdc/O_mean*}]
set_false_path -hold -from [get_regs {u_ui_ae_status_cdc/mean_hold*}] -to [get_regs {u_ui_ae_status_cdc/O_mean*}]

# TF/voice v2.1. Only handshake first stages are asynchronous exceptions.
set_false_path -to [get_regs {u_audio/u_player/time_meta*}]
set_false_path -to [get_regs {u_audio/calibrated_meta}]
set_false_path -to [get_regs {u_audio/u_register_cdc/req_meta u_audio/u_register_cdc/ack_meta u_audio/u_register_cdc/abort_meta u_audio/u_work_ram/req_meta u_audio/u_work_ram/ack_meta}]
set_max_delay 18.000 -from [get_regs {u_audio/u_register_cdc/request_data*}] -to [get_regs {u_audio/u_register_cdc/dst_data*}]
set_false_path -hold -from [get_regs {u_audio/u_register_cdc/request_data*}] -to [get_regs {u_audio/u_register_cdc/dst_data*}]
set_max_delay 18.000 -from [get_regs {u_audio/u_register_cdc/response_data* u_audio/u_register_cdc/response_error}] -to [get_regs {u_audio/u_register_cdc/reply_data* u_audio/u_register_cdc/reply_error}]
set_false_path -hold -from [get_regs {u_audio/u_register_cdc/response_data* u_audio/u_register_cdc/response_error}] -to [get_regs {u_audio/u_register_cdc/reply_data* u_audio/u_register_cdc/reply_error}]
set_max_delay 18.000 -from [get_regs {u_audio/u_work_ram/request_data*}] -to [get_regs {u_audio/u_work_ram/dst_data*}]
set_false_path -hold -from [get_regs {u_audio/u_work_ram/request_data*}] -to [get_regs {u_audio/u_work_ram/dst_data*}]
set_max_delay 18.000 -from [get_regs {u_audio/u_work_ram/response_data* u_audio/u_work_ram/response_error}] -to [get_regs {u_audio/u_work_ram/reply_data* u_audio/u_work_ram/reply_error}]
set_false_path -hold -from [get_regs {u_audio/u_work_ram/response_data* u_audio/u_work_ram/response_error}] -to [get_regs {u_audio/u_work_ram/reply_data* u_audio/u_work_ram/reply_error}]
set_false_path -from [get_regs {*u_ae_mcu/bus_reset_release*}] -to [get_regs {u_audio/u_register_cdc/dst_reset_release*}]

# Mode0 changes data at falling SCLK; the earliest capture is four AHB cycles
# later. 17 ns reserves card clock-to-output and PCB delay at 12.5 MHz.
set_input_delay -clock [get_clocks {MCU_AHB_CLK}] -max 17.000 [get_ports {I_sd_miso}]
set_input_delay -clock [get_clocks {MCU_AHB_CLK}] -min 2.000 [get_ports {I_sd_miso}]
set_multicycle_path 4 -setup -from [get_ports {I_sd_miso}] -to [get_regs {u_audio/u_sd/rx*}]
set_multicycle_path 3 -hold -from [get_ports {I_sd_miso}] -to [get_regs {u_audio/u_sd/rx*}]
set_output_delay -clock [get_clocks {MCU_AHB_CLK}] -max 0.000 [get_ports {O_sd_cs_n O_sd_clk O_sd_mosi}]
set_output_delay -clock [get_clocks {MCU_AHB_CLK}] -min 0.000 [get_ports {O_sd_cs_n O_sd_clk O_sd_mosi}]


# Registered asynchronous servo outputs; no external synchronous receiver.
set_output_delay -clock [get_clocks {MCU_AHB_CLK}] -max 0.000 [get_ports {O_servo_pan O_servo_tilt}]
set_output_delay -clock [get_clocks {MCU_AHB_CLK}] -min 0.000 [get_ports {O_servo_pan O_servo_tilt}]

# SPOT_STATUS_CDC_BEGIN
# New read-only HDMI -> independent-phase MCU status handshake.
# Except only first synchronizer stages; payload is immutable until ACK.
# 18 ns is below the two 100 MHz destination edges before bundle capture.
set_false_path -to [get_regs {u_spot_status_cdc/req_meta u_spot_status_cdc/ack_meta}]
set_max_delay 18.000 -from [get_regs {u_spot_status_cdc/src_hold*}] -to [get_regs {u_spot_status_cdc/dst_pending*}]
set_false_path -hold -from [get_regs {u_spot_status_cdc/src_hold*}] -to [get_regs {u_spot_status_cdc/dst_pending*}]
# SPOT_STATUS_CDC_END
