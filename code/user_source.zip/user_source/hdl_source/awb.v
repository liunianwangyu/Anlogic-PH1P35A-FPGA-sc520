`timescale 1ns/1ps
// Runtime AWB: fixed camera spatial compensation plus a tracked illuminant.
// CALIBRATION_ENABLE is retained for solver regressions, disabled in the ISP.
module awb #(
    parameter integer SOLVE_USE_MCU=0,
    parameter IMG_HEIGHT=1080,IMG_WIDTH=1920,
    parameter [7:0] AWB_DARK_TH=8'd24,AWB_CLIP_TH=8'd240,AWB_SAT_TH=8'd80,
    parameter [19:0] AWB_GAIN_MIN=20'h08000,AWB_GAIN_MAX=20'h20000,
    parameter integer AWB_MIN_LOCAL=32,AWB_MIN_GLOBAL=64,
    parameter integer AWB_SMOOTH_SHIFT=3,AWB_DEADBAND=8,
    parameter integer CALIBRATION_ENABLE=0,
    // Real camera MAN/VALID S01 (photo B), confirmed by the user 2026-10-18.
    // Q4.12, each word is {B,R}; nodes are in sensor order, before mirror/flip.
    // Group 9 retains the measured global reference as metadata. Runtime
    // residual illuminant starts at unity, independently of this reference.
    parameter integer AWB_FACTORY_VALID=1,
    parameter [319:0] AWB_FACTORY_PROFILE={
        32'h1748149B, // G
        32'h153D1207, // P8 bottom right
        32'h19BB172D, // P7 bottom centre
        32'h15E61265, // P6 bottom left
        32'h14C311F0, // P5 middle right
        32'h1A8018B6, // P4 centre
        32'h15C11258, // P3 middle left
        32'h14071184, // P2 top right
        32'h17A81588, // P1 top centre
        32'h14C111CD  // P0 top left
    }
)(
    input I_clk,I_rst_n,I_tlast,I_tuser,
    input [95:0] I_tdata,input I_tvalid,input I_cal_toggle,
    input I_auto_enable,
    output [331:0] O_wb_telemetry,
    output reg[1:0] O_cal_status,
    output I_tready,output O_tlast,output reg O_tuser,
    output[95:0] O_tdata,output O_tvalid,input O_tready,
    input[8:0] I_paddr,input I_psel,I_penable,I_pwrite,
    input[31:0] I_pwdata,output[31:0] O_prdata,output O_pready,O_pslverr
);
    localparam integer BEATS=IMG_WIDTH/4;
    localparam integer XW=(BEATS>1)?$clog2(BEATS):1,YW=$clog2(IMG_HEIGHT+1);
    localparam integer XM=BEATS/2,XL=XM-128,XR=XM+128;
    localparam integer YM=IMG_HEIGHT/2,YT=YM-256,YB=YM+256;
    localparam[15:0] UNITY=16'h1000;
    localparam WAIT_FRAME=2'd0,CAPTURE=2'd1,SOLVE=2'd2,COMMIT=2'd3;
    reg[1:0] cal_state;
    reg job_calibration,capture_second,cal_pending;
    (* async_reg="true" *) reg cal_meta,cal_sync,auto_meta,auto_sync;
    reg cal_seen,auto_active,cal_valid;
    reg[7:0] cal_sequence;
    wire cal_request=CALIBRATION_ENABLE&&(cal_sync!=cal_seen);
    wire requested_auto=auto_sync;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin cal_meta<=0;cal_sync<=0;cal_seen<=0;auto_meta<=!CALIBRATION_ENABLE;auto_sync<=!CALIBRATION_ENABLE;end
        else begin
            cal_meta<=I_cal_toggle;cal_sync<=cal_meta;cal_seen<=cal_sync;
            auto_meta<=I_auto_enable;auto_sync<=auto_meta;
        end
    end
    reg[XW-1:0] x;reg[YW-1:0] y;
    reg frame_seen,frame_bad;
    reg[95:0] data0,data1;reg valid0,valid1,fs0,fs1;
    wire[XW-1:0] bx=fs1?{XW{1'b0}}:x;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin data0<=0;data1<=0;valid0<=0;valid1<=0;fs0<=0;fs1<=0;end
        else begin data0<=I_tdata;data1<=data0;valid0<=I_tvalid;valid1<=valid0;fs0<=I_tuser;fs1<=fs0;end
    end
    function[7:0] max3;input[7:0] a,b,c;
        begin max3=(a>b)?((a>c)?a:c):((b>c)?b:c);end
    endfunction
    function[7:0] min3;input[7:0] a,b,c;
        begin min3=(a<b)?((a<c)?a:c):((b<c)?b:c);end
    endfunction
    function[7:0] saturate;input[23:0] product;
        begin saturate=(|product[23:20])?8'd255:product[19:12];end
    endfunction
    wire[1:0] col=(x<XM-64)?2'd0:((x<XM+64)?2'd1:2'd2);
    wire[1:0] row=(y<YM-128)?2'd0:((y<YM+128)?2'd1:2'd2);
    wire[3:0] zone={2'd0,col}+((row==0)?4'd0:((row==1)?4'd3:4'd6));
    wire x_patch=((x>=XL-16)&&(x<XL+16))||((x>=XM-16)&&(x<XM+16))||((x>=XR-16)&&(x<XR+16));
    wire y_patch=((y>=YT-32)&&(y<YT+32))||((y>=YM-32)&&(y<YM+32))||((y>=YB-32)&&(y<YB+32));
    wire meter_sample=(cal_state==CAPTURE)&&valid1&&frame_seen&&!fs1&&
                      (y<IMG_HEIGHT)&&((x%8)==4)&&((y%8)==4)&&
                      (job_calibration||(x_patch&&y_patch));
    wire[1:0] sample_lane=(x/8)^(y/8);
    reg[23:0] sample_rgb;reg sample_fire,sample_patch;reg[3:0] sample_zone;
    wire[7:0] sr=sample_rgb[23:16],sg=sample_rgb[15:8],sb=sample_rgb[7:0];
    wire[7:0] hi=max3(sr,sg,sb),lo=min3(sr,sg,sb),chroma=hi-lo;
    wire neutral=(lo>AWB_DARK_TH)&&(hi<AWB_CLIP_TH)&&
                 (job_calibration||((chroma<=AWB_SAT_TH)&&(chroma<=lo)));
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin sample_rgb<=0;sample_fire<=0;sample_patch<=0;sample_zone<=0;end
        else begin
            sample_fire<=meter_sample;
            if(meter_sample)begin
                sample_rgb<=data1[sample_lane*24+:24];sample_zone<=zone;sample_patch<=x_patch&&y_patch;
            end
            if(fs1)sample_fire<=0;
        end
    end
    // A 32-beat x 64-line patch sampled every eighth beat/line contains
    // at most 32 pixels per frame. Size local and global accumulators
    // separately, then zero-extend into the unchanged 24/16-bit MCU ABI.
    localparam integer LOCAL_SAMPLES=CALIBRATION_ENABLE?64:32;
    localparam integer GLOBAL_SAMPLES=CALIBRATION_ENABLE?
        (2*((BEATS+7)/8)*((IMG_HEIGHT+7)/8)):288;
    localparam integer LS=$clog2(LOCAL_SAMPLES*255+1),LC=$clog2(LOCAL_SAMPLES+1);
    localparam integer GS=$clog2(GLOBAL_SAMPLES*255+1),GC=$clog2(GLOBAL_SAMPLES+1);
    reg[LS-1:0] sum_r[0:8],sum_g[0:8],sum_b[0:8];reg[LC-1:0] count[0:8];
    reg[GS-1:0] global_sum_r,global_sum_g,global_sum_b;
    reg[GC-1:0] global_count;
    wire[879:0] snapshot;
    genvar s,p;
    generate for(s=0;s<9;s=s+1)begin: frozen_stats
        assign snapshot[s*88+:88]={{(16-LC){1'b0}},count[s],
            {(24-LS){1'b0}},sum_b[s],{(24-LS){1'b0}},sum_g[s],{(24-LS){1'b0}},sum_r[s]};
    end endgenerate
    assign snapshot[9*88+:88]={{(16-GC){1'b0}},global_count,
        {(24-GS){1'b0}},global_sum_b,{(24-GS){1'b0}},global_sum_g,{(24-GS){1'b0}},global_sum_r};
    reg snapshot_valid;
    wire[319:0] solved_profile;wire solved_done,solved_good;
    reg[319:0] calibration_profile,auto_profile;
    // Runtime MANUAL freezes the last applied automatic map. Factory spatial
    // compensation remains present; calibration regression mode is unchanged.
    wire[319:0] profile=(auto_active||!CALIBRATION_ENABLE)?auto_profile:calibration_profile;
    // Expose the selected, actually applied gain map. Group 9 is the global
    // white-paper reference in MANUAL and residual illuminant in AUTO.
    assign O_wb_telemetry={cal_sequence,cal_valid,auto_active,O_cal_status,profile};
    wire[15:0] active_r=profile[0+:16],active_b=profile[16+:16];
    wire[31:0] active_pair={active_b,active_r};
    wire frame_auto=fs1?requested_auto:auto_active;
    wire[319:0] committed_profile=job_calibration?
        (frame_auto?{32'h10001000,solved_profile[287:0]}:solved_profile):solved_profile;
    wire[319:0] frame_profile=(fs1&&(cal_state==COMMIT)&&
        (job_calibration||frame_auto))?committed_profile:
        ((frame_auto||!CALIBRATION_ENABLE)?auto_profile:calibration_profile);
    integer j;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            x<=0;y<=0;frame_seen<=0;frame_bad<=0;cal_state<=WAIT_FRAME;
            job_calibration<=0;capture_second<=0;cal_pending<=0;snapshot_valid<=0;O_cal_status<=0;
            auto_active<=!CALIBRATION_ENABLE;cal_valid<=AWB_FACTORY_VALID;cal_sequence<=0;
            calibration_profile<=AWB_FACTORY_PROFILE;
            auto_profile<={32'h10001000,AWB_FACTORY_PROFILE[287:0]};
            global_sum_r<=0;global_sum_g<=0;global_sum_b<=0;global_count<=0;
            for(j=0;j<9;j=j+1)begin sum_r[j]<=0;sum_g[j]<=0;sum_b[j]<=0;count[j]<=0;end
        end else begin
            snapshot_valid<=0;
            if(cal_request)cal_pending<=1;
            if((cal_state==SOLVE)&&solved_done)begin
                if(solved_good)cal_state<=COMMIT;
                else begin cal_state<=WAIT_FRAME;O_cal_status<=3;end
            end
            if(fs1)begin
                auto_active<=requested_auto;
                case(cal_state)
                    WAIT_FRAME,COMMIT:begin
                        if(cal_state==COMMIT)begin
                            if(job_calibration)begin
                                calibration_profile<=solved_profile;
                                auto_profile<={32'h10001000,solved_profile[287:0]};
                                cal_valid<=1;cal_sequence<=cal_sequence+1'b1;
                            end else if(requested_auto)auto_profile<=solved_profile;
                            O_cal_status<=2;
                        end
                        if(cal_pending||cal_request||requested_auto)begin
                            job_calibration<=cal_pending||cal_request;capture_second<=0;
                            if(cal_pending||cal_request)begin cal_pending<=0;O_cal_status<=1;end
                            else if(O_cal_status==0)O_cal_status<=1;
                            cal_state<=CAPTURE;
                            global_sum_r<=0;global_sum_g<=0;global_sum_b<=0;global_count<=0;
                            for(j=0;j<9;j=j+1)begin sum_r[j]<=0;sum_g[j]<=0;sum_b[j]<=0;count[j]<=0;end
                        end else cal_state<=WAIT_FRAME;
                    end
                    CAPTURE:begin
                        if(!job_calibration&&!requested_auto)cal_state<=WAIT_FRAME;
                        else if(frame_seen&&!frame_bad&&(x==0)&&(y==IMG_HEIGHT)&&!sample_fire)begin
                            if(job_calibration&&!capture_second)capture_second<=1;
                            else begin snapshot_valid<=1;cal_state<=SOLVE;end
                        end else begin
                            global_sum_r<=0;global_sum_g<=0;global_sum_b<=0;global_count<=0;
                            for(j=0;j<9;j=j+1)begin sum_r[j]<=0;sum_g[j]<=0;sum_b[j]<=0;count[j]<=0;end
                            if(job_calibration)cal_state<=WAIT_FRAME;
                            O_cal_status<=3;
                        end
                    end
                    default:begin end
                endcase
                x<=valid1?1:0;y<=0;frame_seen<=1;frame_bad<=0;
            end else if(valid1&&frame_seen)begin
                if(y==IMG_HEIGHT)frame_bad<=1;
                else if(x==BEATS-1)begin x<=0;y<=y+1'b1;end
                else x<=x+1'b1;
            end
            if(sample_fire&&!fs1&&(cal_state==CAPTURE)&&neutral)begin
                global_sum_r<=global_sum_r+sr;global_sum_g<=global_sum_g+sg;
                global_sum_b<=global_sum_b+sb;global_count<=global_count+1'b1;
                if(!job_calibration||sample_patch)begin
                    sum_r[sample_zone]<=sum_r[sample_zone]+sr;sum_g[sample_zone]<=sum_g[sample_zone]+sg;
                    sum_b[sample_zone]<=sum_b[sample_zone]+sb;count[sample_zone]<=count[sample_zone]+1'b1;
                end
            end
        end
    end
    generate if(SOLVE_USE_MCU)begin: g_mcu_solver
        awb_mcu_solver #(.GAIN_MIN(AWB_GAIN_MIN[19:4]),.GAIN_MAX(AWB_GAIN_MAX[19:4]),
            .MIN_LOCAL(AWB_MIN_LOCAL),.MIN_GLOBAL(AWB_MIN_GLOBAL),.SMOOTH_SHIFT(AWB_SMOOTH_SHIFT),
            .REQUIRE_ALL_LOCAL(1),.SPATIAL_AUTO(1),.DEADBAND(AWB_DEADBAND)) u_gain_solver(
            .I_clk(I_clk),.I_rst_n(I_rst_n),.I_start(snapshot_valid),.I_stats(snapshot),
            .I_previous(auto_profile),.I_base(calibration_profile),.I_auto_job(!job_calibration),
            .O_profile(solved_profile),.O_done(solved_done),.O_good(solved_good),
            .I_paddr(I_paddr),.I_psel(I_psel),.I_penable(I_penable),.I_pwrite(I_pwrite),
            .I_pwdata(I_pwdata),.O_prdata(O_prdata),.O_pready(O_pready),.O_pslverr(O_pslverr));
    end else begin: g_rtl_solver
        assign O_prdata=0;assign O_pready=1;assign O_pslverr=I_psel&&I_penable;
        awb_spatial_solver #(.GAIN_MIN(AWB_GAIN_MIN[19:4]),.GAIN_MAX(AWB_GAIN_MAX[19:4]),
            .MIN_LOCAL(AWB_MIN_LOCAL),.MIN_GLOBAL(AWB_MIN_GLOBAL),.SMOOTH_SHIFT(AWB_SMOOTH_SHIFT),
            .DEADBAND(AWB_DEADBAND)) u_gain_solver(
            .I_clk(I_clk),.I_rst_n(I_rst_n),.I_start(snapshot_valid),.I_auto_job(!job_calibration),
            .I_stats(snapshot),.I_base(calibration_profile),.I_previous(auto_profile),
            .O_profile(solved_profile),.O_done(solved_done),.O_good(solved_good));
    end endgenerate

    // The anchors are 512 pixels apart horizontally, 256 lines vertically.
    // Q4.12 gains retain eight extra fractional bits vertically and seven
    // horizontally. Accumulated differences implement bilinear interpolation
    // exactly at the four-pixel beat origins; clamped margins extend anchors.
    reg signed[23:0] vr[0:2],vb[0:2];
    reg signed[16:0] vra[0:2],vrb[0:2],vba[0:2],vbb[0:2];
    reg signed[22:0] hr,hb;
    reg signed[16:0] hra,hrb,hba,hbb;
    // Select the increment before adding: each accumulator needs one adder,
    // shared by the two interpolation intervals. Signed extension and every
    // update enable are identical to the original two-branch recurrence.
    wire signed[16:0] hstep_r=(x<XM)?hra:hrb;
    wire signed[16:0] hstep_b=(x<XM)?hba:hbb;
    wire signed[16:0] vstep_r[0:2],vstep_b[0:2];
    wire[15:0] line_r[0:2],line_b[0:2];
    generate for(p=0;p<3;p=p+1)begin: row_gains
        assign line_r[p]=vr[p][23:8];assign line_b[p]=vb[p][23:8];
        assign vstep_r[p]=(y<YM)?vra[p]:vrb[p];
        assign vstep_b[p]=(y<YM)?vba[p]:vbb[p];
    end endgenerate
    wire[15:0] gain_r=fs1?frame_profile[0+:16]:((bx==0)?line_r[0]:hr[22:7]);
    wire[15:0] gain_b=fs1?frame_profile[16+:16]:((bx==0)?line_b[0]:hb[22:7]);
    integer c;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            hr<={UNITY,7'd0};hb<={UNITY,7'd0};hra<=0;hrb<=0;hba<=0;hbb<=0;
            for(c=0;c<3;c=c+1)begin
                vr[c]<={UNITY,8'd0};vb[c]<={UNITY,8'd0};
                vra[c]<=0;vrb[c]<=0;vba[c]<=0;vbb[c]<=0;
            end
        end else if(fs1)begin
            hr<={frame_profile[0+:16],7'd0};hb<={frame_profile[16+:16],7'd0};
            hra<=$signed({1'b0,frame_profile[32+:16]})-$signed({1'b0,frame_profile[0+:16]});
            hrb<=$signed({1'b0,frame_profile[64+:16]})-$signed({1'b0,frame_profile[32+:16]});
            hba<=$signed({1'b0,frame_profile[48+:16]})-$signed({1'b0,frame_profile[16+:16]});
            hbb<=$signed({1'b0,frame_profile[80+:16]})-$signed({1'b0,frame_profile[48+:16]});
            for(c=0;c<3;c=c+1)begin
                vr[c]<={frame_profile[c*32+:16],8'd0};vb[c]<={frame_profile[c*32+16+:16],8'd0};
                vra[c]<=$signed({1'b0,frame_profile[(c+3)*32+:16]})-$signed({1'b0,frame_profile[c*32+:16]});
                vrb[c]<=$signed({1'b0,frame_profile[(c+6)*32+:16]})-$signed({1'b0,frame_profile[(c+3)*32+:16]});
                vba[c]<=$signed({1'b0,frame_profile[(c+3)*32+16+:16]})-$signed({1'b0,frame_profile[c*32+16+:16]});
                vbb[c]<=$signed({1'b0,frame_profile[(c+6)*32+16+:16]})-$signed({1'b0,frame_profile[(c+3)*32+16+:16]});
            end
        end else if(valid1&&frame_seen&&(y<IMG_HEIGHT))begin
            if(x==0)begin
                hr<={line_r[0],7'd0};hb<={line_b[0],7'd0};
                hra<=$signed({1'b0,line_r[1]})-$signed({1'b0,line_r[0]});
                hrb<=$signed({1'b0,line_r[2]})-$signed({1'b0,line_r[1]});
                hba<=$signed({1'b0,line_b[1]})-$signed({1'b0,line_b[0]});
                hbb<=$signed({1'b0,line_b[2]})-$signed({1'b0,line_b[1]});
            end else if((x>=XL)&&(x<XR))begin hr<=hr+hstep_r;hb<=hb+hstep_b;end
            if((x==BEATS-1)&&(y>=YT)&&(y<YB))begin
                for(c=0;c<3;c=c+1)begin
                    vr[c]<=vr[c]+vstep_r[c];vb[c]<=vb[c]+vstep_b[c];
                end
            end
        end
    end

    reg[23:0] r_product[0:3],b_product[0:3];
    reg[7:0] g_pixel[0:3];
    reg core_valid,core_last;
    wire[95:0] core_rgb;
    integer lane;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            core_valid<=0;O_tuser<=0;core_last<=0;
            for(lane=0;lane<4;lane=lane+1)begin r_product[lane]<=0;b_product[lane]<=0;g_pixel[lane]<=0;end
        end else begin
            core_valid<=valid1;O_tuser<=fs1;core_last<=valid1&&(bx==BEATS-1);
            if(valid1)for(lane=0;lane<4;lane=lane+1)begin
                r_product[lane]<=gain_r*data1[lane*24+16+:8];
                b_product[lane]<=gain_b*data1[lane*24+:8];
                g_pixel[lane]<=data1[lane*24+8+:8];
            end
        end
    end
    generate for(p=0;p<4;p=p+1)begin: output_pixels
        assign core_rgb[p*24+:24]={saturate(r_product[p]),g_pixel[p],saturate(b_product[p])};
    end endgenerate
    // Preserve the existing 3-clock SOF and 51-clock data/valid/last delay.
    // The early marker is required by video_in's asynchronous FIFO reset.
    localparam integer FIFO_RESET_LEAD=48;
    wire[95:0] rgb_delayed;
    awb_rgb_delay #(.DELAY(FIFO_RESET_LEAD)) u_rgb_delay(
        .I_clk(I_clk),.I_rst_n(I_rst_n),.I_rgb(core_rgb),.O_rgb(rgb_delayed));
    reg[FIFO_RESET_LEAD-1:0] valid_delay,last_delay;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin valid_delay<=0;last_delay<=0;end
        else begin valid_delay<={valid_delay[FIFO_RESET_LEAD-2:0],core_valid};
            last_delay<={last_delay[FIFO_RESET_LEAD-2:0],core_last};end
    end
    assign O_tvalid=valid_delay[FIFO_RESET_LEAD-1];
    assign O_tlast=last_delay[FIFO_RESET_LEAD-1];
    assign O_tdata=O_tvalid?rgb_delayed:96'd0;
    assign I_tready=O_tready;
endmodule

// Fixed delay, one sample every clock including blanking. A synchronous RAM
// read supplies one stage; the ring supplies DELAY-1 stages. Read-before-write
// returns the old word at the current address, preserving the shift-chain ABI.
// RAM contents need no reset: AWB's valid pipeline masks all unfilled entries.
module awb_rgb_delay #(parameter integer DELAY=48)(
    input I_clk,I_rst_n,input [95:0] I_rgb,output reg [95:0] O_rgb
);
    localparam integer DEPTH=DELAY-1, AW=$clog2(DEPTH);
    (* ram_style="bram" *) reg [95:0] pixels[0:DEPTH-1];
    reg [AW-1:0] address;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)address<=0;
        else address<=(address==DEPTH-1)?0:address+1'b1;
    always @(posedge I_clk)begin
        pixels[address]<=I_rgb;
        O_rgb<=pixels[address];
    end
endmodule

// One 36/24 restoring divider; GLOBAL_ONLY solves just the global R/B pair.
// The ten-pair mode is retained for legacy solver regression. The stats
// source holds its snapshot; frame jobs restart on a new snapshot, so a short
// frame or unusually short blank never lets two frame banks mix.
module awb_gain_solver #(
    parameter[15:0] GAIN_MIN=16'h0800,GAIN_MAX=16'h2000,
    parameter integer MIN_LOCAL=64,MIN_GLOBAL=512,SMOOTH_SHIFT=2,REQUIRE_ALL_LOCAL=0,GLOBAL_ONLY=0
)(input I_clk,I_rst_n,I_start,input[879:0] I_stats,input[319:0] I_previous,
  output reg[319:0] O_profile,output reg O_done,O_good);
    localparam IDLE=3'd0,LOAD=3'd1,DIVIDE=3'd2,APPLY=3'd3,FINISH=3'd4;
    reg[2:0] state;
    reg[3:0] index;
    reg blue;
    wire[23:0] sr[0:9],sg[0:9],sb[0:9];wire[15:0] sc[0:9];
    wire[15:0] pr[0:9],pb[0:9];
    genvar k;
    generate for(k=0;k<10;k=k+1)begin: fields
        assign sr[k]=I_stats[k*88+:24];assign sg[k]=I_stats[k*88+24+:24];
        assign sb[k]=I_stats[k*88+48+:24];assign sc[k]=I_stats[k*88+72+:16];
        assign pr[k]=I_previous[k*32+:16];assign pb[k]=I_previous[k*32+16+:16];
    end endgenerate
    reg[35:0] quotient;
    reg[24:0] remainder;
    reg[23:0] denominator;
    reg[5:0] bit_count;
    wire[24:0] trial={remainder[23:0],quotient[35]};
    wire take=trial>={1'b0,denominator};
    wire[35:0] q_next={quotient[34:0],take};
    reg[15:0] target,global_r,global_b;
    wire[3:0] slot=GLOBAL_ONLY?4'd9:index;
    wire[15:0] previous=blue?pb[slot]:pr[slot];
    wire signed[16:0] delta=$signed({1'b0,target})-$signed({1'b0,previous});
    wire signed[16:0] smoothed=$signed({1'b0,previous})+(delta>>>SMOOTH_SHIFT);
    function[15:0] clamp;
        input[35:0] value;
        begin
            if((|value[35:16])||(value[15:0]>GAIN_MAX))clamp=GAIN_MAX;
            else if(value[15:0]<GAIN_MIN)clamp=GAIN_MIN;
            else clamp=value[15:0];
        end
    endfunction
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            state<=IDLE;index<=0;blue<=0;quotient<=0;remainder<=0;denominator<=0;bit_count<=0;
            target<=16'h1000;global_r<=16'h1000;global_b<=16'h1000;
            O_profile<={10{32'h10001000}};O_done<=0;O_good<=0;
        end else begin
            O_done<=0;
            if(I_start)begin state<=LOAD;index<=9;blue<=0;O_good<=0;end
            else case(state)
                IDLE: begin end
                LOAD: begin
                    if((index==9)&&(sc[9]<MIN_GLOBAL))begin O_done<=1;O_good<=0;state<=IDLE;end
                    else if((index!=9)&&(sc[index]<MIN_LOCAL))begin
                        if(REQUIRE_ALL_LOCAL)begin O_done<=1;O_good<=0;state<=IDLE;end
                        else begin target<=blue?global_b:global_r;state<=APPLY;end
                    end
                    else begin
                        denominator<=blue?sb[slot]:sr[slot];quotient<={sg[slot],12'd0};
                        remainder<=0;bit_count<=35;state<=DIVIDE;
                    end
                end
                DIVIDE: begin
                    quotient<=q_next;remainder<=take?(trial-{1'b0,denominator}):trial;
                    if(bit_count==0)begin target<=clamp(q_next);state<=APPLY;end
                    else bit_count<=bit_count-1'b1;
                end
                APPLY: begin
                    if(blue)O_profile[slot*32+16+:16]<=smoothed[15:0];
                    else O_profile[slot*32+:16]<=smoothed[15:0];
                    if(index==9)begin if(blue)global_b<=smoothed[15:0];else global_r<=smoothed[15:0];end
                    if(!blue)begin blue<=1;state<=LOAD;end
                    else begin
                        blue<=0;
                        if(GLOBAL_ONLY||(index==8))state<=FINISH;
                        else begin index<=(index==9)?4'd0:index+1'b1;state<=LOAD;end
                    end
                end
                FINISH: begin O_done<=1;O_good<=1;state<=IDLE;end
                default: state<=IDLE;
            endcase
        end
    end
endmodule

// Pure-RTL fallback. One bit-serial multiplier is shared by patch correction
// and gain composition; the default MCU implementation needs no extra DSP.
module awb_spatial_solver #(
    parameter[15:0] GAIN_MIN=16'h0800,GAIN_MAX=16'h2000,
    parameter integer MIN_LOCAL=32,MIN_GLOBAL=64,SMOOTH_SHIFT=3,DEADBAND=8
)(input I_clk,I_rst_n,I_start,I_auto_job,
  input[879:0] I_stats,input[319:0] I_base,I_previous,
  output reg[319:0] O_profile,output reg O_done,O_good);
    localparam IDLE=0,LOAD_SUM=1,MUL_SUM=2,ACCUMULATE=3,DIV_START=4,DIV_WAIT=5,
               LOAD_GAIN=6,MUL_GAIN=7,STORE_GAIN=8,FINISH=9;
    reg[3:0] state,index;reg blue,auto_job;
    reg[39:0] multiplicand,product;reg[15:0] multiplier;reg[4:0] bit_count;
    wire[39:0] product_next=product+(multiplier[0]?multiplicand:40'd0);
    reg[23:0] corrected_r,corrected_b;
    reg[15:0] residual_r,residual_b;
    reg div_start;
    wire[879:0] div_stats={I_stats[864+:16],corrected_b,I_stats[816+:24],corrected_r,792'd0};
    wire[319:0] cal_profile,div_profile;wire cal_done,cal_good,div_done,div_good;
    awb_gain_solver #(.GAIN_MIN(GAIN_MIN),.GAIN_MAX(GAIN_MAX),.MIN_LOCAL(MIN_LOCAL),
        .MIN_GLOBAL(MIN_GLOBAL),.SMOOTH_SHIFT(0),.REQUIRE_ALL_LOCAL(1)) calibration(
        .I_clk(I_clk),.I_rst_n(I_rst_n),.I_start(I_start&&!I_auto_job),.I_stats(I_stats),
        .I_previous(I_previous),.O_profile(cal_profile),.O_done(cal_done),.O_good(cal_good));
    awb_gain_solver #(.GAIN_MIN(GAIN_MIN),.GAIN_MAX(GAIN_MAX),.MIN_GLOBAL(MIN_GLOBAL),
        .SMOOTH_SHIFT(0),.GLOBAL_ONLY(1)) illuminant(
        .I_clk(I_clk),.I_rst_n(I_rst_n),.I_start(div_start),.I_stats(div_stats),
        .I_previous(I_previous),.O_profile(div_profile),.O_done(div_done),.O_good(div_good));
    function[15:0] track;input[15:0] target,previous;reg[15:0] distance,step;
        begin
            distance=(target>previous)?target-previous:previous-target;
            step=distance>>SMOOTH_SHIFT;
            if((step==0)&&(distance>DEADBAND))step=1;
            if(distance<=DEADBAND)track=previous;
            else track=(target>previous)?previous+step:previous-step;
        end
    endfunction
    function[15:0] clamp_product;input[39:0] value;reg[39:0] gain;
        begin
            gain=value>>12;
            if(gain>GAIN_MAX)clamp_product=GAIN_MAX;
            else if(gain<GAIN_MIN)clamp_product=GAIN_MIN;
            else clamp_product=gain[15:0];
        end
    endfunction
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            state<=IDLE;index<=0;blue<=0;auto_job<=0;product<=0;multiplicand<=0;multiplier<=0;
            bit_count<=0;corrected_r<=0;corrected_b<=0;residual_r<=16'h1000;residual_b<=16'h1000;
            div_start<=0;O_profile<={10{32'h10001000}};O_done<=0;O_good<=0;
        end else begin
            O_done<=0;div_start<=0;
            if(I_start)begin
                auto_job<=I_auto_job;state<=I_auto_job?LOAD_SUM:IDLE;
                index<=0;blue<=0;corrected_r<=0;corrected_b<=0;O_good<=0;
            end else if(!auto_job&&cal_done)begin
                O_profile<=cal_profile;O_done<=1;O_good<=cal_good;
            end else case(state)
                IDLE:begin end
                LOAD_SUM:begin
                    multiplicand<={16'd0,I_stats[index*88+(blue?48:0)+:24]};
                    multiplier<=I_base[index*32+(blue?16:0)+:16];product<=0;bit_count<=0;state<=MUL_SUM;
                end
                MUL_SUM,MUL_GAIN:begin
                    product<=product_next;multiplicand<=multiplicand<<1;multiplier<=multiplier>>1;
                    if(bit_count==15)state<=(state==MUL_SUM)?ACCUMULATE:STORE_GAIN;
                    else bit_count<=bit_count+1'b1;
                end
                ACCUMULATE:begin
                    if(blue)corrected_b<=corrected_b+product[35:12];
                    else corrected_r<=corrected_r+product[35:12];
                    if(!blue)begin blue<=1;state<=LOAD_SUM;end
                    else begin
                        blue<=0;
                        if(index==8)state<=DIV_START;
                        else begin index<=index+1'b1;state<=LOAD_SUM;end
                    end
                end
                DIV_START:begin div_start<=1;state<=DIV_WAIT;end
                DIV_WAIT:if(div_done)begin
                    if(!div_good)begin O_done<=1;O_good<=0;state<=IDLE;end
                    else begin
                        residual_r<=track(div_profile[288+:16],I_previous[288+:16]);
                        residual_b<=track(div_profile[304+:16],I_previous[304+:16]);
                        O_profile[288+:16]<=track(div_profile[288+:16],I_previous[288+:16]);
                        O_profile[304+:16]<=track(div_profile[304+:16],I_previous[304+:16]);
                        index<=0;blue<=0;state<=LOAD_GAIN;
                    end
                end
                LOAD_GAIN:begin
                    multiplicand<={24'd0,I_base[index*32+(blue?16:0)+:16]};
                    multiplier<=blue?residual_b:residual_r;product<=0;bit_count<=0;state<=MUL_GAIN;
                end
                STORE_GAIN:begin
                    O_profile[index*32+(blue?16:0)+:16]<=clamp_product(product);
                    if(!blue)begin blue<=1;state<=LOAD_GAIN;end
                    else begin
                        blue<=0;
                        if(index==8)state<=FINISH;
                        else begin index<=index+1'b1;state<=LOAD_GAIN;end
                    end
                end
                FINISH:begin O_done<=1;O_good<=1;state<=IDLE;end
                default:state<=IDLE;
            endcase
        end
    end
endmodule

