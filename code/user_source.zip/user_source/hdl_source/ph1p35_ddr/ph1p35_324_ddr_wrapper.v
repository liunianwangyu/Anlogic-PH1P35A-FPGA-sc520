
module ph1p35_324_ddr_wrapper (
    input wire         I_sys_clk,
    input wire         I_sys_rst_n,

    output wire        O_ddr_clk,
    output  wire       O_init_calib_complete,
    input  wire[24:0]  I_mc_app_addr,
    input  wire[2:0]   I_mc_app_cmd,
    input  wire        I_mc_app_en,
    input  wire[127:0] I_mc_app_wdf_data,
    input  wire        I_mc_app_wdf_end,
    input  wire[15:0]  I_mc_app_wdf_mask,
    input  wire        I_mc_app_wdf_wren,
    output wire[127:0] O_mc_app_rd_data,
    output wire        O_mc_app_rd_data_end,
    output wire        O_mc_app_rd_data_valid,
    output wire        O_mc_app_rdy,
    output wire        O_mc_app_wdf_rdy,

// DDR3 signals
    output wire[12:0]  ddr_addr,
    output wire[1:0]   ddr_ba,
    output wire        ddr_cke,
    output wire        ddr_odt,
    output wire        ddr_cs_n,
    output wire        ddr_ras_n,
    output wire        ddr_cas_n,
    output wire        ddr_we_n,
    output wire        ddr_ck_p,
    output wire        ddr_ck_n,
    inout wire[1:0]    ddr_dm,
    inout wire[15:0]   ddr_dq,
    inout wire[1:0]    ddr_dqs_p,
    inout wire[1:0]    ddr_dqs_n   

);

    wire         ddrphy_rdy;
    wire dhi_clk;

    wire [24:0]  paxi_awaddr;
    wire         paxi_awvalid;
    wire         paxi_awready;
       
    wire [127:0] paxi_wdata;
    wire [15:0]  paxi_wstrb;
    wire         paxi_wvalid;
    wire         paxi_wlast;
    wire         paxi_wready;
                                 
    wire [24:0]  paxi_araddr;
    wire         paxi_arvalid;
    wire         paxi_arready;

    wire [127:0] paxi_rdata;
    wire         paxi_rlast;
    wire         paxi_rvalid;
    wire         paxi_rready;                                    

    assign O_init_calib_complete = ddrphy_rdy;
    assign O_ddr_clk = dhi_clk;

    // One elastic transaction slot converts the coupled application beat to
    // independent pseudo-AXI AW/W/AR handshakes. A stalled channel retains its
    // VALID and payload. Completion can refill the slot on the same edge, so
    // an always-ready controller still receives one transaction per clock.
    reg pending,is_read,aw_sent,w_sent;
    reg [24:0] address_hold;
    reg [127:0] data_hold;
    reg [15:0] mask_hold;
    reg end_hold;
    wire read_complete=pending&&is_read&&paxi_arready;
    wire write_complete=pending&&!is_read&&
                        (aw_sent||paxi_awready)&&(w_sent||paxi_wready);
    wire slot_ready=!pending||read_complete||write_complete;
    assign O_mc_app_rdy=slot_ready;
    assign O_mc_app_wdf_rdy=slot_ready;
    always @(posedge dhi_clk or negedge I_sys_rst_n)begin
        if(!I_sys_rst_n)begin pending<=0;is_read<=0;aw_sent<=0;w_sent<=0;end
        else begin
            if(pending&&!is_read)begin
                if(paxi_awready)aw_sent<=1;
                if(paxi_wready)w_sent<=1;
            end
            if(read_complete||write_complete)pending<=0;
            if(I_mc_app_en&&slot_ready)begin
                pending<=1;is_read<=I_mc_app_cmd[0];aw_sent<=0;w_sent<=0;
            end
        end
    end
    // Payload needs no reset: pending is reset and gates every controller VALID.
    always @(posedge dhi_clk)if(I_mc_app_en&&slot_ready)begin
        address_hold<=I_mc_app_addr;
        if(!I_mc_app_cmd[0])begin
            data_hold<=I_mc_app_wdf_data;mask_hold<=I_mc_app_wdf_mask;
            end_hold<=I_mc_app_wdf_end;
        end
    end
    assign paxi_awaddr=address_hold;
    assign paxi_awvalid=pending&&!is_read&&!aw_sent;
    assign paxi_wdata=data_hold;
    assign paxi_wstrb=mask_hold;
    assign paxi_wvalid=pending&&!is_read&&!w_sent;
    assign paxi_wlast=end_hold;
    assign paxi_araddr=address_hold;
    assign paxi_arvalid=pending&&is_read;
    assign paxi_rready=1'b1;
    assign O_mc_app_rd_data=paxi_rdata;
    assign O_mc_app_rd_data_valid=paxi_rvalid;
    assign O_mc_app_rd_data_end=paxi_rlast;

    ddr2 u_ddr2 (
        .ref_clk      ( I_sys_clk    ),
        .sys_rst_n    ( I_sys_rst_n  ),
        .apb_pclk     ( I_sys_clk    ),
        .apb_prst_n   ( I_sys_rst_n  ),                 
        .dhi_clk      ( dhi_clk      ),
        .cfg_clk      (  ),
        .ddrphy_rst_n (  ),
        .ddrphy_rdy   ( ddrphy_rdy   ),

        .paxi_awaddr  ( paxi_awaddr  ),
        .paxi_awvalid ( paxi_awvalid ),
        .paxi_awready ( paxi_awready ),
        .paxi_wdata   ( paxi_wdata   ),
        .paxi_wstrb   ( paxi_wstrb   ),
        .paxi_wvalid  ( paxi_wvalid  ),
        .paxi_wlast   ( paxi_wlast   ),
        .paxi_wready  ( paxi_wready  ),
        .paxi_araddr  ( paxi_araddr  ),
        .paxi_arvalid ( paxi_arvalid ),
        .paxi_arready ( paxi_arready ),
        .paxi_rdata   ( paxi_rdata   ),
        .paxi_rlast   ( paxi_rlast   ),
        .paxi_rvalid  ( paxi_rvalid  ),
        .paxi_rready  ( paxi_rready  ),

        .ddr_ck_p     ( ddr_ck_p     ),
        .ddr_ck_n     ( ddr_ck_n     ),
        .ddr_cke      ( ddr_cke      ),
        .ddr_odt      ( ddr_odt      ),
        .ddr_cs_n     ( ddr_cs_n     ),
        .ddr_ras_n    ( ddr_ras_n    ),
        .ddr_cas_n    ( ddr_cas_n    ),
        .ddr_we_n     ( ddr_we_n     ),
        .ddr_ba       ( ddr_ba       ),
        .ddr_addr     ( ddr_addr     ),
        .ddr_dqs_p    ( ddr_dqs_p    ),
        .ddr_dqs_n    ( ddr_dqs_n    ),
        .ddr_dq       ( ddr_dq       ),
        .ddr_dm       ( ddr_dm       )
    );





endmodule
