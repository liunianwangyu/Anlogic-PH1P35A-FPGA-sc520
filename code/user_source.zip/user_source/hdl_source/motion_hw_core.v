// Exact registration accelerator for motion_task.c. One interpolator, one
// clipped residual accumulator and one serial /98. No candidate unrolling,
// DSP, DDR traffic, generated clock, video ready or pixel pipeline stage.
// Snapshot ownership remains with motion_video until MCU COMMIT and VS swap.
module motion_hw_core #(parameter WATCHDOG=2000000)(
 input I_clk,I_rst_n,I_start,I_abort,
 output reg [11:0] O_snapshot_addr,input [7:0] I_snapshot_data,
 output reg O_done,O_reference_valid,O_fault,
 output reg signed [5:0] O_dx,O_dy,output reg signed [6:0] O_bias,
 output reg [11:0] O_score,output reg [20:0] O_cycles
);
 localparam IDLE=0,BEGIN_CANDIDATE=1,POINT=2,READ_WAIT=3,READ_CORNER=4,
  INTERPOLATE=5,ACCUMULATE=6,DIV_BEGIN=7,DIVIDE=8,RESTART_POINTS=9,
  CANDIDATE_DONE=10,NEXT_CANDIDATE=11,COPY_BEGIN=12,COPY_WAIT=13,
  COPY_GET=14,COPY_DONE=15;
 reg [3:0] state;
 reg reference_valid,pass;
 reg [1:0] search;
 reg [2:0] cx,cy;
 reg signed [5:0] dx,dy,coarse_dx,coarse_dy;
 reg signed [12:0] scan_sum;
 reg signed [6:0] bias;
 reg [11:0] score;
 reg [6:0] point_index;
 reg [5:0] x,y;
 reg [11:0] base,copy_index;
 reg [1:0] fx,fy,corner;
 reg [7:0] a,b,c,current,interpolated;
 reg [3:0] copy_low;
 reg [10:0] ref_addr,ref_waddr;
 reg [7:0] ref_wdata;
 reg ref_we;
 wire [7:0] ref_q;
 // 1152 packed bytes fit one native ERAM20K in 2048x8 mode. The unused
 // tail is never addressed. RAM contents have no reset fanout.
 motion_ram #(.AW(11)) u_reference(
  .I_wclk(I_clk),.I_we(ref_we),.I_waddr(ref_waddr),.I_data(ref_wdata),
  .I_rclk(I_clk),.I_raddr(ref_addr),.O_data(ref_q));
 wire signed [9:0] xx=$signed({1'b0,x,2'b00})+$signed(dx);
 wire signed [9:0] yy=$signed({1'b0,y,2'b00})+$signed(dy);
 wire [7:0] qx=xx<0?8'd0:(xx>251?8'd251:xx[7:0]);
 wire [7:0] qy=yy<0?8'd0:(yy>139?8'd139:yy[7:0]);
 wire [11:0] origin={qy[7:2],qx[7:2]};
 wire [11:0] corner_address=base+(corner==0?12'd0:corner==1?12'd1:corner==2?12'd64:12'd65);
 wire [11:0] next_address=base+(corner==0?12'd1:corner==1?12'd64:12'd65);
 wire [7:0] ref_value=corner_address[0]?{ref_q[7:4],4'h8}:{ref_q[3:0],4'h8};
 // All weights are 0..4. Explicit shifts/adds avoid multiplier inference.
 function [13:0] mix;
  input [11:0] u,v;input [1:0] fraction;
  begin case(fraction)
   0:mix={u,2'b00};
   1:mix=({2'd0,u}<<1)+u+v;
   2:mix=({2'd0,u}+v)<<1;
   3:mix=u+({2'd0,v}<<1)+v;
  endcase end
 endfunction
 wire [13:0] horizontal0=mix({4'd0,a},{4'd0,b},fx);
 wire [13:0] horizontal1=mix({4'd0,c},{4'd0,ref_value},fx);
 reg [9:0] row0,row1;
 wire [13:0] bilinear=mix({2'd0,row0},{2'd0,row1},fy)+14'd8;
 wire signed [9:0] difference=$signed({1'b0,current})-$signed({1'b0,interpolated});
 wire signed [9:0] residual=difference-$signed(bias);
 wire [9:0] abs_residual=residual<0?-residual:residual;
 wire signed [12:0] clipped=difference>32?13'sd32:(difference< -32?-13'sd32:difference);
 wire [11:0] score_next=score+(abs_residual>24?12'd24:{2'd0,abs_residual});
 function [5:0] cost;
  input signed [5:0] u,v;
  reg [5:0] au,av;
  begin au=u<0?-u:u;av=v<0?-v:v;cost=au+av;end
 endfunction
 wire improves=score<O_score||(score==O_score&&cost(dx,dy)<cost(O_dx,O_dy));
 reg [11:0] div_number,div_quotient;
 reg [6:0] div_remainder;
 reg [3:0] div_step;
 reg div_negative;
 wire [7:0] trial={div_remainder,div_number[11]};
 wire take=trial>=98;
 wire [11:0] quotient_next={div_quotient[10:0],take};
 always @(posedge I_clk or negedge I_rst_n)
  if(!I_rst_n)begin
   state<=IDLE;reference_valid<=0;O_snapshot_addr<=0;O_done<=0;
   O_reference_valid<=0;O_fault<=0;O_dx<=0;O_dy<=0;O_bias<=0;O_score<=0;O_cycles<=0;
   pass<=0;search<=0;cx<=0;cy<=0;dx<=0;dy<=0;coarse_dx<=0;coarse_dy<=0;
   scan_sum<=0;bias<=0;score<=0;point_index<=0;x<=0;y<=0;base<=0;
   copy_index<=0;fx<=0;fy<=0;corner<=0;a<=0;b<=0;c<=0;current<=0;
   interpolated<=0;copy_low<=0;ref_addr<=0;ref_waddr<=0;ref_wdata<=0;ref_we<=0;
   row0<=0;row1<=0;div_number<=0;div_quotient<=0;div_remainder<=0;div_step<=0;div_negative<=0;
  end else begin
   O_done<=0;ref_we<=0;
   if(state!=IDLE)O_cycles<=O_cycles+1'b1;
   if(I_abort)begin state<=IDLE;reference_valid<=0;O_reference_valid<=0;end
   else if(state!=IDLE&&O_cycles>=WATCHDOG-1)begin
    state<=IDLE;reference_valid<=0;O_reference_valid<=0;O_fault<=1;O_done<=1;
   end else case(state)
    IDLE:if(I_start)begin
     O_cycles<=0;O_fault<=0;O_reference_valid<=reference_valid;
     O_dx<=0;O_dy<=0;O_bias<=0;O_score<=4095;
     search<=0;cx<=0;cy<=0;dx<=0;dy<=0;state<=reference_valid?BEGIN_CANDIDATE:COPY_BEGIN;
    end
    BEGIN_CANDIDATE:begin
     scan_sum<=0;score<=0;bias<=0;pass<=0;point_index<=0;x<=4;y<=4;state<=POINT;
    end
    POINT:begin
     O_snapshot_addr<={y,x};current<=0;
     base<=origin;fx<=qx[1:0];fy<=qy[1:0];corner<=0;ref_addr<=origin[11:1];state<=READ_WAIT;
    end
    READ_WAIT:state<=READ_CORNER;
    READ_CORNER:begin
     case(corner)
      0:begin a<=ref_value;current<=I_snapshot_data;end
      1:b<=ref_value;
      2:c<=ref_value;
      3:begin row0<=horizontal0[9:0];row1<=horizontal1[9:0];end
     endcase
     if(corner==3)state<=INTERPOLATE;
     else begin ref_addr<=next_address[11:1];corner<=corner+1'b1;state<=READ_WAIT;end
    end
    INTERPOLATE:begin interpolated<=bilinear[11:4];state<=ACCUMULATE;end
    ACCUMULATE:begin
     if(!pass)scan_sum<=scan_sum+clipped;else score<=score_next;
     if(point_index==97)state<=pass?CANDIDATE_DONE:DIV_BEGIN;
     else begin
      point_index<=point_index+1'b1;
      if(x==56)begin x<=4;y<=y+4;end else x<=x+4;
      state<=POINT;
     end
    end
    DIV_BEGIN:begin
     div_number<=scan_sum<0?-scan_sum:scan_sum;div_negative<=scan_sum<0;
     div_quotient<=0;div_remainder<=0;div_step<=0;state<=DIVIDE;
    end
    DIVIDE:begin
     div_number<=div_number<<1;div_quotient<=quotient_next;
     div_remainder<=take?trial-8'd98:trial;
     if(div_step==11)begin bias<=div_negative?-$signed(quotient_next[6:0]):$signed(quotient_next[6:0]);state<=RESTART_POINTS;end
     else div_step<=div_step+1'b1;
    end
    RESTART_POINTS:begin pass<=1;point_index<=0;x<=4;y<=4;state<=POINT;end
    CANDIDATE_DONE:begin
     if(improves)begin O_score<=score;O_dx<=dx;O_dy<=dy;O_bias<=bias;end
     state<=NEXT_CANDIDATE;
    end
    NEXT_CANDIDATE:begin
     if(search==0)begin
      if(O_score<=588)state<=COPY_BEGIN;
      else begin search<=1;cx<=0;cy<=0;dx<=-8;dy<=-8;state<=BEGIN_CANDIDATE;end
     end else if(search==1&&cx==4&&cy==4)begin
      search<=2;cx<=0;cy<=0;coarse_dx<=O_dx;coarse_dy<=O_dy;
      dx<=O_dx-3;dy<=O_dy-3;state<=BEGIN_CANDIDATE;
     end else if(search==2&&cx==6&&cy==6)state<=COPY_BEGIN;
     else begin
      if(cx==(search==1?4:6))begin
       cx<=0;cy<=cy+1'b1;dx<=search==1?-6'sd8:coarse_dx-6'sd3;dy<=dy+(search==1?6'sd4:6'sd1);
      end else begin cx<=cx+1'b1;dx<=dx+(search==1?6'sd4:6'sd1);end
      state<=BEGIN_CANDIDATE;
     end
    end
    COPY_BEGIN:begin copy_index<=0;O_snapshot_addr<=0;state<=COPY_WAIT;end
    COPY_WAIT:state<=COPY_GET;
    COPY_GET:begin
     if(!copy_index[0])copy_low<=I_snapshot_data[7:4];
     else begin ref_we<=1;ref_waddr<=copy_index[11:1];ref_wdata<={I_snapshot_data[7:4],copy_low};end
     if(copy_index==2303)state<=COPY_DONE;
     else begin copy_index<=copy_index+1'b1;O_snapshot_addr<=copy_index+1'b1;state<=COPY_WAIT;end
    end
    COPY_DONE:begin reference_valid<=1;O_done<=1;state<=IDLE;end
    default:begin state<=IDLE;reference_valid<=0;O_fault<=1;O_done<=1;end
   endcase
  end
endmodule
