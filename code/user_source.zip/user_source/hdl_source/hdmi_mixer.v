module hdmi_mixer #(
    parameter SCREEN_FONT_FILE = "G:/FPGAcompetition/test/lab_integrated_sc520_720p_v2.7-4/lab_integrated_sc520_720p_v2.7/user_source/hdl_source/screen_chinese_font.dat",
    parameter H_OFFSET = 128,
    parameter V_OFFSET = 60,
    parameter IMG_WIDTH = 1280,
    parameter IMG_HEIGHT = 720,
    parameter integer PIXEL_CLOCK_HZ = 75000000,
    parameter integer SPOT_TIMEOUT_MS = 400,
    parameter integer DEBUG_MODE = 0,
    parameter integer RUNTIME_MOTION = 0,
    parameter integer HIDE_FRAME_CONTROLLED = 0,
    // Legacy input ports remain available for IP-level compatibility tests.
    // The board wrapper enables the compact MCU-selected two-class path.
    parameter integer MCU_CLASS_DISPLAY = 0
)(
    input wire        I_clk,
    input wire        I_rst_n,

    input wire        I_video_vsync,
    input wire        I_video_hsync,
    input wire        I_video_de,
    input wire        I_video_user,
    input wire        I_video_last,

    input wire[3:0]   I_debug_status,
    input wire[3:0]   I_diag_button,
    input wire[3:0]   I_diag_switch,
    input wire[2:0]   I_diag_mode,
    input wire[2:0]   I_diag_active,

    // Exposure / gain readout.  I_ae_value and I_ag_value come from ae_set in
    // the 24 MHz control domain; I_disp_toggle flips once after the two values
    // have been stable for at least one 24 MHz clock, so a two stage
    // synchroniser here is enough to capture them coherently.
    input wire[15:0]  I_ae_value,
    input wire[15:0]  I_ag_value,
    input wire        I_disp_toggle,

    // Applied orientation state, shown on the status panel (v0.8 P4).
    input wire        I_view_mir,
    input wire        I_view_flp,

    // v1.2: original-image compare (SW4). This only drives the panel hint;
    // the image mode itself is forced at the ISP request in design_top_wrapper.
    input wire        I_orig_view,

    // Stable 24 MHz snapshot: {Rlo,Rhi,Glo,Ghi,Blo,Bhi,selected field}.
    // Coherent HDMI-domain SET status: {extended,menu,custom,target,sens,fill}.
    input wire[9:0]   I_v11_status,
    // HDMI-domain coherent status: bit 0 AUTO, bit 1 CENTER; upper bits reserved.
    input wire[3:0]   I_auto_modes,
    input wire[19:0]  I_ae_diag, // {cfg,id_ok,fault,retry_seen,frame_seq,write_seq,RAW mean}
    input wire[1:0]   I_wb_status,
    input wire        I_saturation, // coherent HDMI-domain request
    input wire[50:0]  I_threshold_data,
    input wire        I_threshold_toggle,

    // v1.7 CNN 检测框叠加（接 cnn_result_cdc 的 HDMI 域副本，帧内稳定）
    //   I_cnn_boxes: 8 x 48 位，布局见 cnn_post.v 5b：
    //     [47:46]=0 [45:44]=cls [43:33]=x1 [32:22]=y1 [21:11]=x2 [10:0]=y2
    //   I_cnn_nbox : 本帧框数（0..8），只有前 nbox 个被画；为 0 时叠加完全关闭
    input wire I_spot_enable,I_spot_fresh,I_result_valid,
    input wire[159:0] I_cnn_display,
    input wire[383:0] I_cnn_boxes,
    // Atomic MCU metadata: X[15:0], bottom-origin Y[27:16], FLP Y[39:28].
    // Four X and three Y decimal digits, packed BCD. No pixel-rate division.
    input wire[39:0]  I_cnn_label_bcd,
    input wire[3:0]   I_cnn_nbox,
    // v1.7 P3-c：CNN 诊断行用的整帧锁存值（诊断行几何见 CNN_DIAG_X/Y）
    input wire[15:0]  I_cnn_frame_cnt,
    input wire[14:0]  I_cnn_wr_cnt,
    input wire        I_cnn_err,
    // v1.7 P4：CNN 总开关。0 = 不画框、不显示诊断行（其余像素逐位不变）
    input wire        I_cnn_on,

    input wire [15:0] I_latency_bcd,
    input wire [1:0] I_latency_status,
    input wire I_hide,I_ui_hit,
    input wire I_motion_enable,I_motion_fill,I_motion_box,I_motion_camera,
    input wire [6:0] I_motion_count,
    input wire [7:0] I_motion_count_bcd,
    input wire [23:0] I_ui_color,
    output wire [11:0] O_ui_x,O_ui_y,
    output wire O_ui_de,
    output wire       O_video_rd_en,
    input wire[23:0]  I_video_rd_data,

    output reg        O_hdmi_vsync,
    output reg        O_hdmi_hsync,
    output reg        O_hdmi_de,
    output reg[23:0]  O_hdmi_data,
    // Same-cycle pre-OSD image and overlay mask, used by histogram post-stage.
    output reg[23:0]  O_image_rgb,
    output reg        O_osd_hit,
    output reg [7:0]  O_spot_status // previous mask-seen, historic error, action-fresh, ROI-valid, reason
);

    // The five-clock mixer and DDR request timing are unchanged. Old REQ/CAP,
    // raw-key, health, threshold and CNN diagnostic OSD logic has been removed.
    localparam integer MIXER_LATENCY=5;
    reg S_video_vsync_1d,S_video_vsync_2d,S_video_vsync_3d,S_video_vsync_4d;
    reg S_video_hsync_1d,S_video_hsync_2d,S_video_hsync_3d,S_video_hsync_4d;
    reg S_video_de_1d,S_video_de_2d,S_video_de_3d,S_video_de_4d;
    reg [11:0] S_x,S_y,S_x_1d,S_y_1d,S_x_2d,S_y_2d;
    reg S_frame_user_d;
    wire S_frame_start=I_video_user&&!S_frame_user_d;
    reg [3:0] S_cnt_d0,S_cnt_d1,S_cnt_d2,S_cnt_d3,S_cnt_d4,S_cnt_d5;
    wire [15:0] S_fps_bcd;
    wire S_frame_stats_valid;
    hdmi_frame_stats #(.CLOCK_HZ(PIXEL_CLOCK_HZ)) u_frame_stats (
        .I_clk(I_clk),.I_rst_n(I_rst_n),.I_frame_start(S_frame_start),
        .O_fps_bcd(S_fps_bcd),.O_valid(S_frame_stats_valid));
    (* async_reg="true" *) reg [1:0] orig_sync,flip_sync;
    reg saturation_frame;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n) begin orig_sync<=0;flip_sync<=0;saturation_frame<=0;end
        else begin
            orig_sync<={orig_sync[0],I_orig_view};
            flip_sync<={flip_sync[0],I_view_flp};
            if(I_video_user)saturation_frame<=I_saturation&&!orig_sync[1];
        end
    wire saturation_for_pixel=I_video_user?(I_saturation&&!orig_sync[1]):saturation_frame;
    wire [23:0] S_video_data_4d;
    saturation_rgb_pipeline u_saturation_rgb (
        .I_clk(I_clk),.I_rst_n(I_rst_n),.I_rgb(I_video_rd_data),
        .I_enable(saturation_for_pixel),.O_rgb(S_video_data_4d));
    assign O_video_rd_en=I_video_de;
    assign O_ui_x=S_x_1d;assign O_ui_y=S_y_1d;
    assign O_ui_de=S_video_de_1d;
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin S_x<=0;S_y<=0;S_x_1d<=0;S_y_1d<=0;S_x_2d<=0;S_y_2d<=0;end
        else begin
            if(I_video_user)begin S_x<=0;S_y<=0;end
            else if(I_video_de)begin
                if(I_video_last)begin S_x<=0;S_y<=S_y+1'b1;end
                else S_x<=S_x+1'b1;
            end
            S_x_1d<=S_x;S_y_1d<=S_y;S_x_2d<=S_x_1d;S_y_2d<=S_y_1d;
        end
    end
    // A stretched SOF must not count twice. Digits change only at SOF,
    // hence remain stable throughout the visible row. First frame is 000001;
    // modulo-1,000,000 rollover is intentional (about 4.63 h at 60 fps).
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) S_frame_user_d <= 1'b0;
        else S_frame_user_d <= I_video_user;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_cnt_d0 <= 4'd0;
            S_cnt_d1 <= 4'd0;
            S_cnt_d2 <= 4'd0;
            S_cnt_d3 <= 4'd0;
            S_cnt_d4 <= 4'd0;
            S_cnt_d5 <= 4'd0;
        end
        else if(S_frame_start) begin
            if(S_cnt_d0 == 4'd9) begin
                S_cnt_d0 <= 4'd0;
                if(S_cnt_d1 == 4'd9) begin
                    S_cnt_d1 <= 4'd0;
                    if(S_cnt_d2 == 4'd9) begin
                        S_cnt_d2 <= 4'd0;
                        if(S_cnt_d3 == 4'd9) begin
                            S_cnt_d3 <= 4'd0;
                            if(S_cnt_d4 == 4'd9) begin
                                S_cnt_d4 <= 4'd0;
                                if(S_cnt_d5 == 4'd9)
                                    S_cnt_d5 <= 4'd0;
                                else
                                    S_cnt_d5 <= S_cnt_d5 + 4'd1;
                            end
                            else
                                S_cnt_d4 <= S_cnt_d4 + 4'd1;
                        end
                        else
                            S_cnt_d3 <= S_cnt_d3 + 4'd1;
                    end
                    else
                        S_cnt_d2 <= S_cnt_d2 + 4'd1;
                end
                else
                    S_cnt_d1 <= S_cnt_d1 + 4'd1;
            end
            else
                S_cnt_d0 <= S_cnt_d0 + 4'd1;
        end
    end


    function [15:0] F_brand_glyph;
        input lu;
        input [3:0] row;
        begin
            case ({lu,row})
                5'd0: F_brand_glyph = 16'h0200;
                5'd1: F_brand_glyph = 16'h7ff0;
                5'd2: F_brand_glyph = 16'h4410;
                5'd3: F_brand_glyph = 16'h0400;
                5'd4: F_brand_glyph = 16'h7ff0;
                5'd5: F_brand_glyph = 16'h0840;
                5'd6: F_brand_glyph = 16'h1040;
                5'd7: F_brand_glyph = 16'h1c80;
                5'd8: F_brand_glyph = 16'h0300;
                5'd9: F_brand_glyph = 16'h0cc0;
                5'd10: F_brand_glyph = 16'h7020;
                5'd11: F_brand_glyph = 16'h0000;
                5'd12: F_brand_glyph = 16'h0000;
                5'd13: F_brand_glyph = 16'h0000;
                5'd14: F_brand_glyph = 16'h0000;
                5'd15: F_brand_glyph = 16'h0000;
                5'd16: F_brand_glyph = 16'h79e0;
                5'd17: F_brand_glyph = 16'h4a20;
                5'd18: F_brand_glyph = 16'h4d40;
                5'd19: F_brand_glyph = 16'h7880;
                5'd20: F_brand_glyph = 16'h1140;
                5'd21: F_brand_glyph = 16'h1630;
                5'd22: F_brand_glyph = 16'h5be0;
                5'd23: F_brand_glyph = 16'h5220;
                5'd24: F_brand_glyph = 16'h5220;
                5'd25: F_brand_glyph = 16'h5be0;
                5'd26: F_brand_glyph = 16'h6220;
                5'd27: F_brand_glyph = 16'h0000;
                5'd28: F_brand_glyph = 16'h0000;
                5'd29: F_brand_glyph = 16'h0000;
                5'd30: F_brand_glyph = 16'h0000;
                5'd31: F_brand_glyph = 16'h0000;
                default: F_brand_glyph = 16'd0;
            endcase
        end
    endfunction

    function [3:0] F_brand_coord;
        input [4:0] value;
        begin
            case (value)
                0,1: F_brand_coord=0; 2: F_brand_coord=1;
                3,4: F_brand_coord=2; 5: F_brand_coord=3;
                6,7: F_brand_coord=4; 8: F_brand_coord=5;
                9,10: F_brand_coord=6; 11: F_brand_coord=7;
                12,13: F_brand_coord=8; 14: F_brand_coord=9;
                15,16: F_brand_coord=10; 17: F_brand_coord=11;
                18,19: F_brand_coord=12; 20: F_brand_coord=13;
                21,22: F_brand_coord=14; 23: F_brand_coord=15;
                default: F_brand_coord=0;
            endcase
        end
    endfunction

    function [7:0] F_frame_char;
        input row;
        input [3:0] col;
        input [23:0] count_bcd;
        input [15:0] fps_bcd;
        input valid;
        begin
            F_frame_char = 8'd0;
            if (!row) begin
                case (col)
                    0: F_frame_char = 8'd128;
                    1: F_frame_char = 8'd129;
                    2: F_frame_char = 0;
                    3: F_frame_char = ":";
                    4: F_frame_char = 8'h30 + {4'd0, count_bcd[23:20]};
                    5: F_frame_char = 8'h30 + {4'd0, count_bcd[19:16]};
                    6: F_frame_char = 8'h30 + {4'd0, count_bcd[15:12]};
                    7: F_frame_char = 8'h30 + {4'd0, count_bcd[11:8]};
                    8: F_frame_char = 8'h30 + {4'd0, count_bcd[7:4]};
                    9: F_frame_char = 8'h30 + {4'd0, count_bcd[3:0]};
                    default: begin end
                endcase
            end else begin
                case (col)
                    0: F_frame_char = 8'd128;
                    1: F_frame_char = 8'd130;
                    2: F_frame_char = 0;
                    3: F_frame_char = ":";
                    4: F_frame_char = !valid ? "-" : ((fps_bcd[15:12] == 0) ? 8'd0 : 8'h30 + {4'd0,fps_bcd[15:12]});
                    5: F_frame_char = valid ? 8'h30 + {4'd0,fps_bcd[11:8]} : "-";
                    6: F_frame_char = valid ? 8'h30 + {4'd0,fps_bcd[7:4]} : "-";
                    7: F_frame_char = ".";
                    8: F_frame_char = valid ? 8'h30 + {4'd0,fps_bcd[3:0]} : "-";
                    default: begin end
                endcase
            end
        end
    endfunction

    function [4:0] F_panel_glyph;
        input [7:0] I_char;
        input [2:0] I_row;
        begin
            case(I_char)
                8'h41: begin case(I_row)   // 'A'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b11111;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h42: begin case(I_row)   // 'B'
                    3'd0: F_panel_glyph=5'b11110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b11110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h43: begin case(I_row)   // 'C'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b10000;
                    3'd4: F_panel_glyph=5'b10000; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h44: begin case(I_row)   // 'D'
                    3'd0: F_panel_glyph=5'b11110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b11110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h45: begin case(I_row)   // 'E'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b10000; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10000; 3'd5: F_panel_glyph=5'b10000; 3'd6: F_panel_glyph=5'b11111; default: F_panel_glyph=5'b00000;
                endcase end
                8'h46: begin case(I_row)   // 'F'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b10000; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10000; 3'd5: F_panel_glyph=5'b10000; 3'd6: F_panel_glyph=5'b10000; default: F_panel_glyph=5'b00000;
                endcase end
                8'h47: begin case(I_row)   // 'G'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b10111;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h48: begin case(I_row)   // 'H'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b11111;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h49: begin case(I_row)   // 'I'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b00100; 3'd2: F_panel_glyph=5'b00100; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4a: begin case(I_row)   // 'J'
                    3'd0: F_panel_glyph=5'b00111; 3'd1: F_panel_glyph=5'b00010; 3'd2: F_panel_glyph=5'b00010; 3'd3: F_panel_glyph=5'b00010;
                    3'd4: F_panel_glyph=5'b00010; 3'd5: F_panel_glyph=5'b10010; 3'd6: F_panel_glyph=5'b01100; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4b: begin case(I_row)   // 'K'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10010; 3'd2: F_panel_glyph=5'b10100; 3'd3: F_panel_glyph=5'b11000;
                    3'd4: F_panel_glyph=5'b10100; 3'd5: F_panel_glyph=5'b10010; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4c: begin case(I_row)   // 'L'
                    3'd0: F_panel_glyph=5'b10000; 3'd1: F_panel_glyph=5'b10000; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b10000;
                    3'd4: F_panel_glyph=5'b10000; 3'd5: F_panel_glyph=5'b10000; 3'd6: F_panel_glyph=5'b11111; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4d: begin case(I_row)   // 'M'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b11011; 3'd2: F_panel_glyph=5'b10101; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4e: begin case(I_row)   // 'N'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b11001; 3'd2: F_panel_glyph=5'b10101; 3'd3: F_panel_glyph=5'b10011;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h4f: begin case(I_row)   // 'O'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h50: begin case(I_row)   // 'P'
                    3'd0: F_panel_glyph=5'b11110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10000; 3'd5: F_panel_glyph=5'b10000; 3'd6: F_panel_glyph=5'b10000; default: F_panel_glyph=5'b00000;
                endcase end
                8'h51: begin case(I_row)   // 'Q'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10101; 3'd5: F_panel_glyph=5'b10010; 3'd6: F_panel_glyph=5'b01101; default: F_panel_glyph=5'b00000;
                endcase end
                8'h52: begin case(I_row)   // 'R'
                    3'd0: F_panel_glyph=5'b11110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10100; 3'd5: F_panel_glyph=5'b10010; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h53: begin case(I_row)   // 'S'
                    3'd0: F_panel_glyph=5'b01111; 3'd1: F_panel_glyph=5'b10000; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b01110;
                    3'd4: F_panel_glyph=5'b00001; 3'd5: F_panel_glyph=5'b00001; 3'd6: F_panel_glyph=5'b11110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h54: begin case(I_row)   // 'T'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b00100; 3'd2: F_panel_glyph=5'b00100; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b00100; default: F_panel_glyph=5'b00000;
                endcase end
                8'h55: begin case(I_row)   // 'U'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h56: begin case(I_row)   // 'V'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10001;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b01010; 3'd6: F_panel_glyph=5'b00100; default: F_panel_glyph=5'b00000;
                endcase end
                8'h57: begin case(I_row)   // 'W'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b10101;
                    3'd4: F_panel_glyph=5'b10101; 3'd5: F_panel_glyph=5'b11011; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h58: begin case(I_row)   // 'X'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b01010; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b01010; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b10001; default: F_panel_glyph=5'b00000;
                endcase end
                8'h59: begin case(I_row)   // 'Y'
                    3'd0: F_panel_glyph=5'b10001; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b01010; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b00100; default: F_panel_glyph=5'b00000;
                endcase end
                8'h5a: begin case(I_row)   // 'Z'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b00001; 3'd2: F_panel_glyph=5'b00010; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b01000; 3'd5: F_panel_glyph=5'b10000; 3'd6: F_panel_glyph=5'b11111; default: F_panel_glyph=5'b00000;
                endcase end
                8'h30: begin case(I_row)   // '0'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10011; 3'd3: F_panel_glyph=5'b10101;
                    3'd4: F_panel_glyph=5'b11001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h31: begin case(I_row)   // '1'
                    3'd0: F_panel_glyph=5'b00100; 3'd1: F_panel_glyph=5'b01100; 3'd2: F_panel_glyph=5'b00100; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h32: begin case(I_row)   // '2'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b00001; 3'd3: F_panel_glyph=5'b00010;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b01000; 3'd6: F_panel_glyph=5'b11111; default: F_panel_glyph=5'b00000;
                endcase end
                8'h33: begin case(I_row)   // '3'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b00010; 3'd2: F_panel_glyph=5'b00100; 3'd3: F_panel_glyph=5'b00010;
                    3'd4: F_panel_glyph=5'b00001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h34: begin case(I_row)   // '4'
                    3'd0: F_panel_glyph=5'b00010; 3'd1: F_panel_glyph=5'b00110; 3'd2: F_panel_glyph=5'b01010; 3'd3: F_panel_glyph=5'b10010;
                    3'd4: F_panel_glyph=5'b11111; 3'd5: F_panel_glyph=5'b00010; 3'd6: F_panel_glyph=5'b00010; default: F_panel_glyph=5'b00000;
                endcase end
                8'h35: begin case(I_row)   // '5'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b10000; 3'd2: F_panel_glyph=5'b11110; 3'd3: F_panel_glyph=5'b00001;
                    3'd4: F_panel_glyph=5'b00001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h36: begin case(I_row)   // '6'
                    3'd0: F_panel_glyph=5'b00110; 3'd1: F_panel_glyph=5'b01000; 3'd2: F_panel_glyph=5'b10000; 3'd3: F_panel_glyph=5'b11110;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h37: begin case(I_row)   // '7'
                    3'd0: F_panel_glyph=5'b11111; 3'd1: F_panel_glyph=5'b00001; 3'd2: F_panel_glyph=5'b00010; 3'd3: F_panel_glyph=5'b00100;
                    3'd4: F_panel_glyph=5'b01000; 3'd5: F_panel_glyph=5'b01000; 3'd6: F_panel_glyph=5'b01000; default: F_panel_glyph=5'b00000;
                endcase end
                8'h38: begin case(I_row)   // '8'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b01110;
                    3'd4: F_panel_glyph=5'b10001; 3'd5: F_panel_glyph=5'b10001; 3'd6: F_panel_glyph=5'b01110; default: F_panel_glyph=5'b00000;
                endcase end
                8'h39: begin case(I_row)   // '9'
                    3'd0: F_panel_glyph=5'b01110; 3'd1: F_panel_glyph=5'b10001; 3'd2: F_panel_glyph=5'b10001; 3'd3: F_panel_glyph=5'b01111;
                    3'd4: F_panel_glyph=5'b00001; 3'd5: F_panel_glyph=5'b00010; 3'd6: F_panel_glyph=5'b01100; default: F_panel_glyph=5'b00000;
                endcase end
                8'h3a: begin case(I_row)   // ':'
                    3'd0: F_panel_glyph=5'b00000; 3'd1: F_panel_glyph=5'b00100; 3'd2: F_panel_glyph=5'b00100; 3'd3: F_panel_glyph=5'b00000;
                    3'd4: F_panel_glyph=5'b00100; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b00000; default: F_panel_glyph=5'b00000;
                endcase end
                8'h65: begin case(I_row) // 'e'
                    0:F_panel_glyph=0;1:F_panel_glyph=0;2:F_panel_glyph=5'b01110;3:F_panel_glyph=5'b10001;
                    4:F_panel_glyph=5'b11111;5:F_panel_glyph=5'b10000;6:F_panel_glyph=5'b01111;default:F_panel_glyph=0;
                endcase end
                8'h73: begin case(I_row) // 's'
                    0:F_panel_glyph=0;1:F_panel_glyph=0;2:F_panel_glyph=5'b01111;3:F_panel_glyph=5'b10000;
                    4:F_panel_glyph=5'b01110;5:F_panel_glyph=5'b00001;6:F_panel_glyph=5'b11110;default:F_panel_glyph=0;
                endcase end
                8'h74: begin case(I_row) // 't'
                    0:F_panel_glyph=5'b00100;1:F_panel_glyph=5'b00100;2:F_panel_glyph=5'b11111;3:F_panel_glyph=5'b00100;
                    4:F_panel_glyph=5'b00100;5:F_panel_glyph=5'b00100;6:F_panel_glyph=5'b00011;default:F_panel_glyph=0;
                endcase end
                8'h2d: F_panel_glyph = (I_row == 3) ? 5'b11111 : 5'b00000; // '-'
                8'h2e: begin case(I_row)   // '.'  (v1.2 version string "1.2")
                    3'd0: F_panel_glyph=5'b00000; 3'd1: F_panel_glyph=5'b00000; 3'd2: F_panel_glyph=5'b00000; 3'd3: F_panel_glyph=5'b00000;
                    3'd4: F_panel_glyph=5'b00000; 3'd5: F_panel_glyph=5'b00100; 3'd6: F_panel_glyph=5'b00100; default: F_panel_glyph=5'b00000;
                endcase end
                default: F_panel_glyph = 5'b00000;
            endcase
        end
    endfunction
    // Numeric/punctuation paths remain the existing small combinational font.
    // All dynamic Chinese text shares one dual-port vendor ERAM below.
    function [15:0] F_screen_glyph;
        input [7:0] ch;
        input [3:0] row;
        reg [4:0] bits;
        begin
            bits=F_panel_glyph(ch,(row-1)>>1);
            F_screen_glyph=(row>=1&&row<15)?
                {3'd0,{2{bits[4]}},{2{bits[3]}},{2{bits[2]}},{2{bits[1]}},{2{bits[0]}},3'd0}:16'd0;
        end
    endfunction
    wire logo_win=(S_x_2d<160)&&(S_y_2d<160);
    // Two ROM stages begin at the existing coordinate stage 1.
    // The resulting pixel still meets a_logo at coordinate stage 3.
    wire [14:0] logo_address=({3'd0,S_y_1d}<<7)+({3'd0,S_y_1d}<<5)+{3'd0,S_x_1d};
    wire [24:0] logo_pixel;
    anlogic_logo_palette_rom_trim u_anlogic_logo_rom (
        .I_clk(I_clk),.I_addr(logo_address),.O_pixel(logo_pixel));
    wire brand_win=(S_x_2d<48)&&(S_y_2d>=170)&&(S_y_2d<192);
    wire [4:0] brand_x=(S_x_2d>=24)?S_x_2d-24:S_x_2d;
    wire [4:0] brand_y=S_y_2d-170;
    reg a_logo,a_brand,a_brand_lu;
    reg [3:0] a_brand_x,a_brand_y;
    reg a_global;
    reg [7:0] a_global_char;
    reg [3:0] a_global_x,a_global_y;
    wire [11:0] global_y=S_y_2d-200;
    wire [11:0] global_gx={8'd0,S_x_2d[3:0]}-12'd3;
    wire [11:0] global_gy={8'd0,global_y[3:0]}-12'd1;
    reg [7:0] global_char;
    always @(*) begin
        global_char=0;
        if(global_y[5:4]<2)
            global_char=F_frame_char(global_y[4],S_x_2d[7:4],
                {S_cnt_d5,S_cnt_d4,S_cnt_d3,S_cnt_d2,S_cnt_d1,S_cnt_d0},S_fps_bcd,S_frame_stats_valid);
        else if(global_y[5:4]==2)case(S_x_2d[7:4])
            0:global_char=8'd131;1:global_char=8'd132;2:global_char=0;3:global_char=":";
            4:global_char="2";5:global_char=".";6:global_char="7";
            default:global_char=0;
        endcase
        else case(S_x_2d[7:4])
            0:global_char=8'd133;1:global_char=8'd134;2:global_char=0;3:global_char=":";
            4,5,6,7:begin
                if(I_latency_status==2)case(S_x_2d[7:4])
                    4:global_char=8'd135;5:global_char=8'd136;6,7:global_char=0;
                endcase
                else if(I_latency_status==1)case(S_x_2d[7:4])
                    4:global_char=8'h30+{4'd0,I_latency_bcd[15:12]};
                    5:global_char=8'h30+{4'd0,I_latency_bcd[11:8]};
                    6:global_char=8'h30+{4'd0,I_latency_bcd[7:4]};
                    7:global_char=8'h30+{4'd0,I_latency_bcd[3:0]};
                endcase
                else global_char="-";
            end
            8:global_char=(I_latency_status==2)?0:8'd137;
            9:global_char=(I_latency_status==2)?0:8'd138;
            default:global_char=0;
        endcase
    end
    // One publication cache, shared by boxes and spotlight; SOF consumes the
    // previous cache on a simultaneous result pulse. No extra video stages.
    reg [159:0] class_frame;
    wire [1:0] class_inside;
    wire [11:0] spot_distance;
    reg spot_frame,class_flip;
    reg spot_mask_seen;
    reg S_b_hit;
    generate if(MCU_CLASS_DISPLAY)begin: g_class_frame
        localparam integer SPOT_CYCLES=(PIXEL_CLOCK_HZ/1000)*SPOT_TIMEOUT_MS;
        localparam integer AGE_WIDTH=$clog2(SPOT_CYCLES+1);
        reg [AGE_WIDTH-1:0] age;
        reg [159:0] latest_display;
        reg latest_fresh,latest_valid;
        reg [1:0] orientation;
        wire policy_change=orientation!={I_view_mir,I_view_flp};
        wire geometry_ok=latest_display[79]&&latest_display[10:0]<=latest_display[31:21]&&
            latest_display[20:11]<=latest_display[41:32]&&latest_display[10:0]<IMG_WIDTH&&latest_display[20:11]<IMG_HEIGHT;
        // Historical debug errors and servo-only action evidence must not
        // suppress a current accepted rectangle that is visible on screen.
        wire [3:0] reason=!I_spot_enable?4'd0:(!I_cnn_on?4'd2:(orig_sync[1]?4'd3:
            (policy_change?4'd7:(!latest_valid?4'd4:(age>=SPOT_CYCLES?4'd5:(!geometry_ok?4'd6:4'd1))))));
        always @(posedge I_clk or negedge I_rst_n)
            if(!I_rst_n)begin
                class_frame<=0;latest_display<=0;spot_frame<=0;O_spot_status<=0;
                latest_fresh<=0;latest_valid<=0;age<=SPOT_CYCLES;orientation<=0;class_flip<=0;
            end else begin
                orientation<={I_view_mir,I_view_flp};
                if(I_result_valid)begin
                    latest_display<=I_cnn_display;
                    latest_fresh<=I_spot_fresh;
                    latest_valid<=I_cnn_display[79]&&I_cnn_on&&!policy_change;
                    age<=0;
                end else if(age<SPOT_CYCLES)age<=age+1'b1;
                // A mode/orientation change poisons the cached ROI until a new
                // attributed publication arrives; toggling SPOT alone is safe.
                if(policy_change||!I_cnn_on)latest_valid<=0;
                if(S_frame_start)begin
                    class_frame<=latest_display;class_flip<=flip_sync[1];
                    spot_frame<=reason==4'd1;
                    O_spot_status<={spot_mask_seen,I_cnn_err,latest_fresh,latest_valid,reason};
                end
            end
    end else begin: g_legacy_frame
        always @*begin class_frame=160'd0;spot_frame=1'b0;class_flip=1'b0;O_spot_status=8'd0;end
    end endgenerate
    wire [1:0] class_border,class_label;
    wire [11:0] class_dx[0:1],class_dy[0:1];
    wire [36:0] class_bcd[0:1];
    genvar cb;
    generate for(cb=0;cb<2;cb=cb+1)begin: g_class_geometry
        wire [79:0] slot=class_frame[cb*80+:80];
        wire [11:0] x1=slot[10:0]>=IMG_WIDTH?12'd1279:{1'b0,slot[10:0]};
        wire [11:0] x2=slot[31:21]>=IMG_WIDTH?12'd1279:{1'b0,slot[31:21]};
        wire [11:0] y1=slot[20:11]>=IMG_HEIGHT?12'd719:{2'b0,slot[20:11]};
        wire [11:0] y2=slot[41:32]>=IMG_HEIGHT?12'd719:{2'b0,slot[41:32]};
        wire [11:0] py=class_flip?(12'd719-S_y_2d):S_y_2d;
        wire good=slot[79]&&slot[10:0]<=slot[31:21]&&slot[20:11]<=slot[41:32]&&x1<=x2&&y1<=y2;
        wire inside_box=S_x_2d>=x1&&S_x_2d<=x2&&py>=y1&&py<=y2;
        // Compare against inset endpoints. Narrow boxes have no interior.
        wire inner_box=S_x_2d>=x1+12'd2&&S_x_2d+12'd2<=x2&&
            py>=y1+12'd2&&py+12'd2<=y2;
        localparam [11:0] LABEL_WIDTH=cb==0?272:288;
        localparam [11:0] LABEL_RIGHT=IMG_WIDTH-LABEL_WIDTH;
        wire [11:0] left=(x1>LABEL_RIGHT)?LABEL_RIGHT:x1;
        wire [11:0] top=class_flip?(12'd719-y2):y1;
        wire [11:0] label_top=top>=16?top-12'd16:top+12'd2;
        if(cb==0)begin: g_spot_distance
            // Reuse the exact clipped rectangle and vertical orientation.
            // Max-axis distance gives an even rectangular halo; no square root.
            wire [11:0] dx=S_x_2d<x1?x1-S_x_2d:(S_x_2d>x2?S_x_2d-x2:12'd0);
            wire [11:0] dy=py<y1?y1-py:(py>y2?py-y2:12'd0);
            assign spot_distance=dx>dy?dx:dy;
        end
        assign class_inside[cb]=good&&inside_box;
        assign class_dx[cb]=S_x_2d-left;
        assign class_dy[cb]=S_y_2d-label_top;
        assign class_border[cb]=good&&inside_box&&!inner_box;
        assign class_label[cb]=good&&class_dx[cb]<LABEL_WIDTH&&class_dy[cb]<16;
        assign class_bcd[cb]=slot[78:42];
    end endgenerate
    // Class 0 wins at overlap; both slots share one font and output pipeline.
    wire class_pick=class_label[0]?1'b0:(class_label[1]?1'b1:!class_border[0]);
    wire [11:0] selected_dx=class_dx[class_pick],selected_dy=class_dy[class_pick];
    wire [36:0] selected_bcd=class_bcd[class_pick];
    wire [11:0] box_y=flip_sync[1]?(12'd719-S_y_2d):S_y_2d;
    wire [11:0] box_x1={1'b0,I_cnn_boxes[33+:11]},box_y1={1'b0,I_cnn_boxes[22+:11]};
    wire [11:0] box_x2={1'b0,I_cnn_boxes[11+:11]},box_y2={1'b0,I_cnn_boxes[0+:11]};
    wire box_inside=S_x_2d>=box_x1&&S_x_2d<=box_x2&&box_y>=box_y1&&box_y<=box_y2;
    wire box_inner=S_x_2d>=box_x1+2&&S_x_2d<=((box_x2>2)?box_x2-2:0)&&
        box_y>=box_y1+2&&box_y<=((box_y2>2)?box_y2-2:0);
    // Class 0 uses the same name as tools/voice_assets.json: "starve".
    // A tiny combinational 5x7 font needs no additional ERAM or DDR traffic.
    // Both classes share this font lookup and the existing five-clock latency.
    function [4:0] F_cnn_label_glyph;
        input [4:0] col;
        input [2:0] row;
        input [3:0] digit;
        input genshin;
        reg [34:0] bits;
        reg [4:0] font_col;
        begin
            font_col=col;
            case(font_col)
                0:bits={5'b00000,5'b00000,5'b01111,5'b10000,5'b01110,5'b00001,5'b11110}; // s
                1:bits={5'b00100,5'b00100,5'b11111,5'b00100,5'b00100,5'b00101,5'b00010}; // t
                2:bits={5'b00000,5'b00000,5'b01110,5'b00001,5'b01111,5'b10001,5'b01111}; // a
                3:bits={5'b00000,5'b00000,5'b10110,5'b11001,5'b10000,5'b10000,5'b10000}; // r
                4:bits={5'b00000,5'b00000,5'b10001,5'b10001,5'b10001,5'b01010,5'b00100}; // v
                5:bits={5'b00000,5'b00000,5'b01110,5'b10001,5'b11111,5'b10000,5'b01110}; // e
                7:bits={5'b00010,5'b00100,5'b01000,5'b01000,5'b01000,5'b00100,5'b00010}; // (
                12:bits={5'b00000,5'b00000,5'b00000,5'b00000,5'b00000,5'b00100,5'b01000}; // ,
                16:bits={5'b01000,5'b00100,5'b00010,5'b00010,5'b00010,5'b00100,5'b01000}; // )
                default:bits=0;
            endcase
            if(genshin&&col<7)case(col)
                0:bits={5'b00000,5'b01111,5'b10001,5'b10001,5'b01111,5'b00001,5'b01110}; // g
                1:bits={5'b00000,5'b00000,5'b01110,5'b10001,5'b11111,5'b10000,5'b01110}; // e
                2,6:bits={5'b00000,5'b00000,5'b10110,5'b11001,5'b10001,5'b10001,5'b10001}; // n
                3:bits={5'b00000,5'b00000,5'b01111,5'b10000,5'b01110,5'b00001,5'b11110}; // s
                4:bits={5'b10000,5'b10000,5'b10110,5'b11001,5'b10001,5'b10001,5'b10001}; // h
                5:bits={5'b00100,5'b00000,5'b01100,5'b00100,5'b00100,5'b00100,5'b01110}; // i
                default:bits=0;
            endcase
            case(row)
                0:F_cnn_label_glyph=bits[34:30];1:F_cnn_label_glyph=bits[29:25];
                2:F_cnn_label_glyph=bits[24:20];3:F_cnn_label_glyph=bits[19:15];
                4:F_cnn_label_glyph=bits[14:10];5:F_cnn_label_glyph=bits[9:5];
                6:F_cnn_label_glyph=bits[4:0];default:F_cnn_label_glyph=0;
            endcase
            if ((font_col>=8&&font_col<=11)||(font_col>=13&&font_col<=15))
                F_cnn_label_glyph=F_panel_glyph({4'h3,digit},row);
        end
    endfunction
    localparam [11:0] CNN_LABEL_WIDTH=272;
    localparam [11:0] CNN_LABEL_RIGHT=IMG_WIDTH-CNN_LABEL_WIDTH;
    wire [11:0] label_left=(box_x1>CNN_LABEL_RIGHT)?CNN_LABEL_RIGHT:box_x1;
    wire [11:0] box_top=flip_sync[1]?(12'd719-box_y2):box_y1;
    // Prefer above the box; a box at the top gets an inset, upright label.
    wire [11:0] label_top=(box_top>=16)?box_top-12'd16:box_top+12'd2;
    wire [11:0] label_dx=MCU_CLASS_DISPLAY?selected_dx:S_x_2d-label_left;
    wire [11:0] label_dy=MCU_CLASS_DISPLAY?selected_dy:S_y_2d-label_top;
    wire label_genshin=MCU_CLASS_DISPLAY&&class_pick;
    wire [4:0] digit_col=label_dx[8:4];
    wire [15:0] label_x_bcd=MCU_CLASS_DISPLAY?{3'd0,selected_bcd[12:0]}:I_cnn_label_bcd[15:0];
    wire label_window=label_dx<CNN_LABEL_WIDTH&&label_dy<16&&box_x1<IMG_WIDTH&&
        box_x1<=box_x2&&box_y1<=box_y2&&box_y2<720;
    wire [11:0] label_y_bcd=MCU_CLASS_DISPLAY?
        (flip_sync[1]?selected_bcd[36:25]:selected_bcd[24:13]):
        (flip_sync[1]?I_cnn_label_bcd[39:28]:I_cnn_label_bcd[27:16]);
    reg [3:0] label_digit;
    always @* begin
        case(digit_col)
            8:label_digit=label_x_bcd[15:12];
            9:label_digit=label_x_bcd[11:8];
            10:label_digit=label_x_bcd[7:4];
            11:label_digit=label_x_bcd[3:0];
            13:label_digit=label_y_bcd[11:8];
            14:label_digit=label_y_bcd[7:4];
            15:label_digit=label_y_bcd[3:0];
            default:label_digit=0;
        endcase
    end
    reg a_label,a_label_cell,a_label_genshin;
    reg [4:0] a_label_col;
    reg [3:0] a_label_digit;
    reg [2:0] a_label_x,a_label_y;
    reg [3:0] a_label_raw_x,a_label_raw_y;
    reg a_box;
    reg a_motion_fill,a_motion_box,a_motion_text;
    reg [7:0] a_motion_char;
    reg [3:0] a_motion_x,a_motion_y;
    wire [11:0] motion_x=S_x_2d-12'd560;
    wire [11:0] motion_y=S_y_2d-12'd8;
    wire motion_enabled=RUNTIME_MOTION?I_motion_enable:1'b0;
    reg [7:0] motion_char;
    always @*begin
        motion_char=0;
        case(motion_x[7:4])
            0:motion_char=8'd139;1:motion_char=8'd140;2:motion_char=8'd141;3:motion_char=8'd142;
            4:motion_char=":";5,6:motion_char=0;
            7:motion_char=8'd48+{4'd0,I_motion_count_bcd[7:4]};
            8:motion_char=8'd48+{4'd0,I_motion_count_bcd[3:0]};
            10:motion_char=I_motion_camera?8'd143:0;
            11:motion_char=I_motion_camera?8'd144:0;
            12:motion_char=I_motion_camera?8'd145:0;
            default:begin end
        endcase
    end
    reg [23:0] a_box_color;
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)begin
            a_logo<=0;a_brand<=0;a_brand_lu<=0;a_brand_x<=0;a_brand_y<=0;
            a_global<=0;a_global_char<=0;a_global_x<=0;a_global_y<=0;a_box<=0;a_box_color<=0;
            a_label<=0;a_label_cell<=0;a_label_genshin<=0;a_label_col<=0;a_label_digit<=0;a_label_x<=0;a_label_y<=0;a_label_raw_x<=0;a_label_raw_y<=0;
            a_motion_fill<=0;a_motion_box<=0;a_motion_text<=0;a_motion_char<=0;a_motion_x<=0;a_motion_y<=0;
        end else begin
            a_logo<=S_video_de_2d&&logo_win;
            a_brand<=S_video_de_2d&&brand_win;
            a_brand_lu<=S_x_2d>=24;a_brand_x<=F_brand_coord(brand_x);a_brand_y<=F_brand_coord(brand_y);
            // Frame/FPS/version/latency are persistent; KEY2 only hides other UI.
            a_global<=S_video_de_2d&&
                (S_x_2d<160||(global_y[5:4]==2&&S_x_2d<208))&&S_y_2d>=200&&S_y_2d<264&&
                1'b1;
            a_global_char<=global_char;a_global_x<=S_x_2d[3:0];a_global_y<=global_y[3:0];
            a_motion_fill<=S_video_de_2d&&motion_enabled&&I_motion_fill;
            a_motion_box<=S_video_de_2d&&motion_enabled&&I_motion_box;
            a_motion_text<=S_video_de_2d&&motion_enabled&&
                S_x_2d>=560&&S_x_2d<768&&S_y_2d>=8&&S_y_2d<24&&
                1'b1;
            a_motion_char<=motion_char;a_motion_x<=motion_x[3:0];
            a_motion_y<=motion_y[3:0];
            a_box<=S_video_de_2d&&I_cnn_on&&(MCU_CLASS_DISPLAY?
                (|class_border):((I_cnn_nbox!=0)&&box_inside&&!box_inner));
            a_label<=S_video_de_2d&&I_cnn_on&&(MCU_CLASS_DISPLAY?
                (|class_label):((I_cnn_nbox!=0)&&I_cnn_boxes[45:44]==0&&label_window));
            a_label_genshin<=label_genshin;
            a_label_raw_x<=label_dx[3:0];a_label_raw_y<=label_dy[3:0];
            a_label_cell<=label_dx[3:0]>=3&&label_dx[3:0]<13&&label_dy>=1&&label_dy<15;
            a_label_col<=label_dx[8:4];a_label_digit<=label_digit;
            a_label_x<=(label_dx[3:0]-4'd3)>>1;
            a_label_y<=(label_dy-12'd1)>>1;
            if(MCU_CLASS_DISPLAY)a_box_color<=class_pick?24'h4040ff:24'hff3030;
            else case(I_cnn_boxes[45:44])
                0:a_box_color<=24'hff3030;1:a_box_color<=24'h30ff30;
                2:a_box_color<=24'h4040ff;default:a_box_color<=24'hffff30;
            endcase
        end
    end
    // Launch at coordinate stage 2. Synchronous NOREG reads meet the
    // existing stage-3 flags/coordinates, preserving the five-clock mixer.
    // Motion (y=8..23) and global status (y=200..263) cannot overlap, so
    // they share port A; either class label uses port B, even over status.
    wire font_motion=S_y_2d<32;
    wire [8:0] status_font_address=font_motion?
        {motion_char[4:0],motion_y[3:0]}:{global_char[4:0],global_y[3:0]};
    wire [4:0] class_font_index=label_genshin?
        (label_dx[4]?5'd21:5'd20):(label_dx[4]?5'd19:5'd18);
    wire [15:0] status_font_q,class_font_q;
    PH1P_LOGIC_ERAM #(
        .DATA_WIDTH_A(16),.DATA_WIDTH_B(16),.ADDR_WIDTH_A(9),.ADDR_WIDTH_B(9),
        .DATA_DEPTH_A(512),.DATA_DEPTH_B(512),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
        .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),
        .OREGSET_A("RESET"),.OREGSET_B("RESET"),
        .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
        .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
        .INIT_FILE(SCREEN_FONT_FILE),.FILL_ALL("NONE")
    ) u_screen_chinese_font (
        .dia(16'd0),.dib(16'd0),.addra(status_font_address),
        .addrb({class_font_index,label_dy[3:0]}),
        .cea(1'b1),.ceb(1'b1),.ocea(1'b0),.oceb(1'b0),
        .clka(I_clk),.clkb(I_clk),.wea(1'b0),.web(1'b0),
        .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
        .doa(status_font_q),.dob(class_font_q),.ecc_sbiterr(),.ecc_dbiterr(),
        .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0)
    );
    wire [15:0] brand_bits=F_brand_glyph(a_brand_lu,a_brand_y);
    wire [15:0] global_bits=a_global_char[7]?status_font_q:F_screen_glyph(a_global_char,a_global_y);
    wire brand_hit=a_brand&&brand_bits[15-a_brand_x];
    wire logo_hit=a_logo&&logo_pixel[24];
    wire global_hit=a_global&&global_bits[15-a_global_x];
    wire [15:0] motion_bits=a_motion_char[7]?status_font_q:F_screen_glyph(a_motion_char,a_motion_y);
    wire motion_hit=a_motion_text&&motion_bits[15-a_motion_x];
    wire [4:0] label_bits=F_cnn_label_glyph(a_label_col,a_label_y,a_label_digit,a_label_genshin);
    wire [7:0] label_ch=a_label_genshin?(a_label_col[0]?8'd149:8'd148):(a_label_col[0]?8'd147:8'd146);
    wire [15:0] label_ch_bits=class_font_q;
    wire label_ink=a_label_col<2?label_ch_bits[15-a_label_raw_x]:
        (a_label_col>=7&&a_label_cell&&label_bits[4-a_label_x]);
    reg spot_dark_a,spot_dark_b;
    reg [5:0] spot_distance_a;
    reg [5:0] spot_gain_b;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)begin
            spot_dark_a<=0;spot_dark_b<=0;spot_distance_a<=0;spot_gain_b<=6'd32;
        end else begin
            spot_dark_a<=spot_frame&&class_frame[79]&&!class_inside[0];
            spot_dark_b<=spot_dark_a;
            // Saturate before registering. Distance -> gain uses the existing
            // two coordinate alignment stages; no added pixel latency.
            spot_distance_a<=spot_distance>=12'd60 ? 6'd60 : spot_distance[5:0];
            spot_gain_b<=6'd32-{1'b0,spot_distance_a[5:1]};
        end
    // Q5 gain: 1 at the border, 1/2 at 32 px, 1/16 at >=60 px.
    // Five gated shift terms plus the unity bypass, balanced carry trees.
    // No DSP, ROM, frame buffer or sensor exposure/white-balance feedback.
    function [7:0] F_spot_scale;
        input [7:0] value;
        input [5:0] gain;
        reg [12:0] pair01,pair23,low4,product;
        begin
            pair01=(gain[0]?{5'd0,value}:13'd0)+(gain[1]?{4'd0,value,1'b0}:13'd0);
            pair23=(gain[2]?{3'd0,value,2'd0}:13'd0)+(gain[3]?{2'd0,value,3'd0}:13'd0);
            low4=pair01+pair23;
            product=low4+(gain[4]?{1'b0,value,4'd0}:13'd0);
            F_spot_scale=gain[5]?value:product[12:5];
        end
    endfunction
    // Read-only observation of actual attenuated-video eligibility. Hidden
    // diagnostics cannot affect the video/control paths.
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)spot_mask_seen<=0;
        else if(S_frame_start)spot_mask_seen<=0;
        else if(S_video_de_4d&&spot_dark_b&&!spot_gain_b[5]&&!S_b_hit)spot_mask_seen<=1;
    wire [23:0] spot_image=MCU_CLASS_DISPLAY&&spot_dark_b?
        {F_spot_scale(S_video_data_4d[23:16],spot_gain_b),
         F_spot_scale(S_video_data_4d[15:8],spot_gain_b),
         F_spot_scale(S_video_data_4d[7:0],spot_gain_b)}:S_video_data_4d;
    reg [23:0] S_b_color;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)begin S_b_hit<=0;S_b_color<=0;end
        else begin
            S_b_hit<=logo_hit||brand_hit||global_hit||I_ui_hit||a_box||a_label||a_motion_fill||a_motion_box||motion_hit;
            S_b_color<=logo_hit?logo_pixel[23:0]:(brand_hit?24'hfff200:
                (global_hit?24'hffffff:(I_ui_hit?I_ui_color:
                ((motion_hit||a_motion_box)?24'hff0000:(a_motion_fill?24'hc02020:
                ((a_label&&!label_ink)?24'h182028:a_box_color))))));
        end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)begin
            S_video_vsync_1d<=0;S_video_vsync_2d<=0;S_video_vsync_3d<=0;S_video_vsync_4d<=0;O_hdmi_vsync<=0;
            S_video_hsync_1d<=0;S_video_hsync_2d<=0;S_video_hsync_3d<=0;S_video_hsync_4d<=0;O_hdmi_hsync<=0;
            S_video_de_1d<=0;S_video_de_2d<=0;S_video_de_3d<=0;S_video_de_4d<=0;O_hdmi_de<=0;
            O_hdmi_data<=0;O_image_rgb<=0;O_osd_hit<=0;
        end else begin
            S_video_vsync_1d<=I_video_vsync;S_video_vsync_2d<=S_video_vsync_1d;
            S_video_vsync_3d<=S_video_vsync_2d;S_video_vsync_4d<=S_video_vsync_3d;O_hdmi_vsync<=S_video_vsync_4d;
            S_video_hsync_1d<=I_video_hsync;S_video_hsync_2d<=S_video_hsync_1d;
            S_video_hsync_3d<=S_video_hsync_2d;S_video_hsync_4d<=S_video_hsync_3d;O_hdmi_hsync<=S_video_hsync_4d;
            S_video_de_1d<=I_video_de;S_video_de_2d<=S_video_de_1d;
            S_video_de_3d<=S_video_de_2d;S_video_de_4d<=S_video_de_3d;O_hdmi_de<=S_video_de_4d;
            O_image_rgb<=spot_image;O_osd_hit<=S_b_hit;
            O_hdmi_data<=S_b_hit?S_b_color:spot_image;
        end
    end
endmodule

// Four clocks, one RGB888 pixel/clock; no multiplier, divider or RAM.
// Y=floor((R+2G+B)/4); C'=clip(C+floor((C-Y)/4),0,255).
// The 1.25 chroma gain preserves neutral greys exactly. Signed widths cover
// delta [-255,255] and output [-64,318], including negative right shifts.
module saturation_rgb_pipeline #(parameter integer OUTPUT_REGISTER=1) (
    input wire I_clk, I_rst_n,
    input wire [23:0] I_rgb,
    input wire I_enable,
    output wire [23:0] O_rgb
);
    reg [23:0] rgb1,rgb2,rgb3;
    reg [9:0] y1;
    reg signed [8:0] dr2,dg2,db2;
    reg signed [9:0] r3,g3,b3;
    reg [2:0] enable_pipe;
    function [7:0] clip;
        input signed [9:0] value;
        begin clip=value[9]?8'd0:(value[8]?8'd255:value[7:0]); end
    endfunction
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            rgb1<=0;rgb2<=0;rgb3<=0;y1<=0;
            dr2<=0;dg2<=0;db2<=0;r3<=0;g3<=0;b3<=0;
            enable_pipe<=0;
        end else begin
            rgb1<=I_rgb;rgb2<=rgb1;rgb3<=rgb2;
            y1<={2'd0,I_rgb[23:16]}+{1'b0,I_rgb[15:8],1'b0}+{2'd0,I_rgb[7:0]};
            dr2<=$signed({1'b0,rgb1[23:16]})-$signed({1'b0,y1[9:2]});
            dg2<=$signed({1'b0,rgb1[15:8]})-$signed({1'b0,y1[9:2]});
            db2<=$signed({1'b0,rgb1[7:0]})-$signed({1'b0,y1[9:2]});
            r3<=$signed({2'b0,rgb2[23:16]})+($signed({dr2[8],dr2})>>>2);
            g3<=$signed({2'b0,rgb2[15:8]})+($signed({dg2[8],dg2})>>>2);
            b3<=$signed({2'b0,rgb2[7:0]})+($signed({db2[8],db2})>>>2);
            enable_pipe<={enable_pipe[1:0],I_enable};

        end
    end
    wire [23:0] final_rgb=enable_pipe[2]?{clip(r3),clip(g3),clip(b3)}:rgb3;
    generate if(OUTPUT_REGISTER)begin:g_output_register
        reg [23:0] result;
        always @(posedge I_clk or negedge I_rst_n)
            if(!I_rst_n)result<=0;else result<=final_rgb;
        assign O_rgb=result;
    end else begin:g_three_clock
        assign O_rgb=final_rgb;
    end endgenerate
endmodule
