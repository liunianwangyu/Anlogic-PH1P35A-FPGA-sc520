`timescale 1ns/1ps
// HDMI-domain histogram + colour-preserving luminance equalization.
// One 512x16 counter RAM packs input/output histograms; two table RAMs hold
// LUT and paired input/output heights. No frame RAM/divider/DSP.
// Every fourth pixel of every fourth row is sampled: 57,600 at 720p.
// The single counter RAM freezes while the MCU reads it; busy MCU skips
// statistics frames, never video. Tables are published only in vertical blank.
module histogram_video #(
    parameter integer WIDTH=1280, HEIGHT=720,
    parameter integer PANEL_X=1008, PANEL_Y=32,
    parameter integer BAR_HEIGHT=112,
    parameter integer RUNTIME_UI=0,
    parameter integer HIDE_FRAME_CONTROLLED=0,
    parameter integer PANEL_ONLY=0
)(
    input wire I_clk,I_rst_n,
    input wire I_vsync,I_hsync,I_de,
    input wire [23:0] I_rgb,I_image_rgb,
    input wire I_osd_hit,
    input wire I_equalize,I_original,
    input wire I_show,I_hide,
    input wire [9:0] I_paddr,
    input wire I_psel,I_penable,I_pwrite,
    input wire [31:0] I_pwdata,
    output reg [31:0] O_prdata,
    output wire O_pready,O_pslverr,
    output wire O_vsync,O_hsync,O_de,
    output reg [23:0] O_rgb,
    input wire I_bar_clk,I_bar_write,
    input wire [8:0] I_bar_address,
    input wire [13:0] I_bar_data,
    input wire I_table_bank,I_table_valid,I_table_equalized,
    output wire O_panel_bank,O_panel_valid
);
    localparam CLEAR=3'd0,IDLE=3'd1,CAPTURE=3'd2,DRAIN=3'd3,
               PENDING=3'd4,SWAP=3'd5;
    reg [2:0] state;
    reg [8:0] clear_index,read_index;
    reg [7:0] write_index;
    reg [8:0] written;
    reg [15:0] sample_count;
    reg [31:0] token;
    reg bank,table_valid;
    reg capture_equalized,display_equalized;
    reg [11:0] x,y;
    reg vsync_d;
    wire frame_blank=I_vsync&&!vsync_d;
    (* async_reg="true" *) reg [1:0] eq_sync,original_sync;
    reg equalize_frame;
    (* async_reg="true" *) reg [1:0] show_sync,hide_sync;
    reg show_frame,hide_frame;
    wire hide_for_frame=HIDE_FRAME_CONTROLLED?I_hide:hide_frame;
    wire access=I_psel&&I_penable;
    wire [5:0] addr=I_paddr[5:0]; // 0x040..0x07f, indirect stream ports
    assign O_pready=1'b1;
    assign O_pslverr=access && (I_paddr[1:0]!=0 ||
        (I_pwrite && !((addr==6'h0c && state==PENDING) ||
                       (addr==6'h14 && state==PENDING && written<256) ||
                       (addr==6'h18 && state==PENDING && written==256 && I_pwdata==token))));
    wire accept_write=access&&I_pwrite&&!O_pslverr;
    wire commit=accept_write&&(addr==6'h18);

    (* ram_style="block" *) reg [15:0] counts [0:511];
    (* ram_style="block" *) reg [7:0] lut [0:511];
    (* ram_style="block" *) reg [13:0] bars [0:511];
    reg [15:0] count_q;
    reg sample_d;
    reg [8:0] sample_bin;
    reg [1:0] post_sample_pipe;
    reg [23:0] processed3;
    reg [7:0] luma1,luma2,map2;
    reg [23:0] rgb1,rgb2,composite1,composite2;
    reg legacy1,legacy2;
    reg [11:0] x1,y1;
    reg [2:0] vs_pipe,hs_pipe,de_pipe;
    reg [13:0] bar1;
    reg panel2;
    reg [23:0] panel_color2;
    // Approximate luminance (R+2G+B)/4: bounded, monotonic, shift/add only.
    wire [9:0] luma_sum={2'd0,I_image_rgb[23:16]}+
        {1'd0,I_image_rgb[15:8],1'b0}+{2'd0,I_image_rgb[7:0]};
    wire sample=(state==CAPTURE)&&de_pipe[0]&&(x1[1:0]==0)&&(y1[1:0]==0);
    // Input reads occur every four clocks. The actual processed pixel is
    // available two clocks later, in the unused slot of the same RAM port.
    // Each read-modify-write completes before the following RAM read.
    wire post_sample=post_sample_pipe[1];
    wire ram_sample=sample||post_sample;
    wire [9:0] post_luma_sum={2'd0,processed3[23:16]}+
        {1'd0,processed3[15:8],1'b0}+{2'd0,processed3[7:0]};
    wire [8:0] ram_sample_bin=post_sample?{1'b1,post_luma_sum[9:2]}:{1'b0,luma1};
    wire last_pixel=de_pipe[0]&&(x1==WIDTH-1)&&(y1==HEIGHT-1);
    wire [11:0] panel_col=x-PANEL_X;
    wire [11:0] px=x1-PANEL_X,py=y1-PANEL_Y;
    wire panel_inside=(x1>=PANEL_X-1)&&(x1<=PANEL_X+256)&&
        (y1>=PANEL_Y-1)&&(y1<=PANEL_Y+BAR_HEIGHT);
    wire border=(x1==PANEL_X-1)||(x1==PANEL_X+256)||
        (y1==PANEL_Y-1)||(y1==PANEL_Y+BAR_HEIGHT);
    wire plot=(x1>=PANEL_X)&&(x1<PANEL_X+256)&&
        (y1>=PANEL_Y)&&(y1<PANEL_Y+BAR_HEIGHT);
    wire equalize_active=equalize_frame&&table_valid;
    wire [6:0] bar_height=equalize_active?bar1[13:7]:bar1[6:0];
    // Do not label an old bypass snapshot as equalized during mode entry.
    // Input bars remain immediately available when EQ/SW4 bypasses processing.
    wire bars_ready=table_valid&&(!equalize_active||display_equalized);
    wire bar_on=plot&&bars_ready&&(py>=BAR_HEIGHT-bar_height);
    wire grid_on=plot&&((px[5:0]==0)||(py==28)||(py==56)||(py==84));

    // Histogram selection is already stated in the Chinese mode summary.
    // Remove the redundant English header and its reserved background strip.

    function [7:0] adjust;
        input [7:0] channel;
        input signed [8:0] delta;
        reg signed [10:0] value;
        begin
            value=$signed({1'b0,channel})+delta;
            adjust=(value<0)?8'd0:((value>255)?8'd255:value[7:0]);
        end
    endfunction
    wire signed [8:0] delta=$signed({1'b0,map2})-$signed({1'b0,luma2});
    wire [23:0] equalized_rgb2={adjust(rgb2[23:16],delta),adjust(rgb2[15:8],delta),adjust(rgb2[7:0],delta)};
    assign O_vsync=vs_pipe[2];
    assign O_hsync=hs_pipe[2];
    assign O_de=de_pipe[2];

    assign O_panel_bank=bank;
    assign O_panel_valid=table_valid;
    generate if(PANEL_ONLY)begin:g_panel_only
        // One dual-clock RAM; producer holds the published bank/descriptor
        // until this frame-boundary acknowledgement returns to the CSI side.
        (* async_reg="true" *) reg [2:0] bank_request;
        (* async_reg="true" *) reg [1:0] descriptor_meta,descriptor_sync;
        always @(posedge I_bar_clk)
            if(I_bar_write)bars[I_bar_address]<=I_bar_data;
        always @(posedge I_clk)bar1<=bars[{bank,panel_col[7:0]}];
        always @(posedge I_clk or negedge I_rst_n)begin
            if(!I_rst_n)begin
                bank_request<=0;descriptor_meta<=0;descriptor_sync<=0;
                bank<=0;table_valid<=0;display_equalized<=0;O_prdata<=0;
                x<=0;y<=0;x1<=0;y1<=0;vsync_d<=0;
                eq_sync<=0;original_sync<=0;equalize_frame<=0;
                show_sync<=0;hide_sync<=0;show_frame<=0;hide_frame<=0;
                vs_pipe<=0;hs_pipe<=0;de_pipe<=0;
                composite1<=0;composite2<=0;panel2<=0;panel_color2<=0;O_rgb<=0;
            end else begin
                bank_request<={bank_request[1:0],I_table_bank};
                descriptor_meta<={I_table_valid,I_table_equalized};descriptor_sync<=descriptor_meta;
                vsync_d<=I_vsync;
                eq_sync<={eq_sync[0],I_equalize};original_sync<={original_sync[0],I_original};
                show_sync<={show_sync[0],I_show};hide_sync<={hide_sync[0],I_hide};
                if(frame_blank)begin
                    x<=0;y<=0;equalize_frame<=eq_sync[1]&&!original_sync[1];
                    show_frame<=show_sync[1];hide_frame<=hide_sync[1];
                    if(!descriptor_sync[1])table_valid<=0;
                    else if(bank_request[2]==bank_request[1])begin
                        bank<=bank_request[2];table_valid<=1;
                        display_equalized<=descriptor_sync[0];
                    end
                end else if(I_de)begin
                    if(x==WIDTH-1)begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
                end
                vs_pipe<={vs_pipe[1:0],I_vsync};hs_pipe<={hs_pipe[1:0],I_hsync};de_pipe<={de_pipe[1:0],I_de};
                composite1<=I_rgb;composite2<=composite1;x1<=x;y1<=y;
                panel2<=de_pipe[0]&&panel_inside&&(!RUNTIME_UI||(show_frame&&!hide_for_frame));
                panel_color2<=border?24'hc0d8e0:
                    (bar_on?(equalize_active?24'hffcc40:24'h30d8f0):(grid_on?24'h304050:24'h101820));
                O_rgb<=panel2?panel_color2:composite2;
            end
        end
    end else begin:g_legacy
    // No resets on RAM or RAM read registers, preserving block RAM inference.
    // Counter reads and the MCU's indirect reads share one synchronous port.
    always @(posedge I_clk) begin
        count_q<=counts[ram_sample?ram_sample_bin:read_index];
        if(state==CLEAR) counts[clear_index]<=0;
        else if(sample_d) counts[sample_bin]<=count_q+16'd1;
        map2<=lut[{bank,luma1}];
        bar1<=bars[{bank,panel_col[7:0]}];
        if(accept_write&&addr==6'h14) begin
            lut[{!bank,write_index}]<=I_pwdata[7:0];
            bars[{!bank,write_index}]<=I_pwdata[21:8];
        end
    end
    always @(*) begin
        case(addr)
            6'h00:O_prdata=32'h48495332; // HIS2: input/output statistics + paired heights
            6'h04:O_prdata={25'd0,bars_ready,capture_equalized,(state==CAPTURE),equalize_frame,table_valid,(state==SWAP),(state==PENDING)};
            6'h08:O_prdata=token;
            6'h0c:O_prdata={23'd0,read_index};
            6'h10:O_prdata=(state==PENDING)?{16'd0,count_q}:32'd0;
            6'h14:O_prdata={1'b1,22'd0,written};
            6'h1c:O_prdata={16'd0,sample_count};
            6'h20:O_prdata={16'd256,9'd0,7'd112};
            default:O_prdata=0;
        endcase
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            state<=CLEAR;clear_index<=0;read_index<=0;write_index<=0;written<=0;
            sample_count<=0;token<=0;bank<=0;table_valid<=0;
            capture_equalized<=0;display_equalized<=0;
            x<=0;y<=0;vsync_d<=0;eq_sync<=0;original_sync<=0;equalize_frame<=0;
            show_sync<=0;hide_sync<=0;show_frame<=0;hide_frame<=0;
            sample_d<=0;sample_bin<=0;
            post_sample_pipe<=0;processed3<=0;
            luma1<=0;luma2<=0;rgb1<=0;rgb2<=0;composite1<=0;composite2<=0;
            legacy1<=0;legacy2<=0;x1<=0;y1<=0;
            vs_pipe<=0;hs_pipe<=0;de_pipe<=0;panel2<=0;panel_color2<=0;O_rgb<=0;
        end else begin
            vsync_d<=I_vsync;
            eq_sync<={eq_sync[0],I_equalize};original_sync<={original_sync[0],I_original};
            show_sync<={show_sync[0],I_show};hide_sync<={hide_sync[0],I_hide};
            if(frame_blank) begin
                x<=0;y<=0;
                equalize_frame<=eq_sync[1]&&!original_sync[1];
                show_frame<=show_sync[1];
                hide_frame<=hide_sync[1];
            end else if(I_de) begin
                if(x==WIDTH-1) begin x<=0;y<=y+1'b1;end
                else x<=x+1'b1;
            end
            sample_d<=ram_sample;sample_bin<=ram_sample_bin;
            post_sample_pipe<={post_sample_pipe[0],sample};
            // Statistics observe the same saturated image as the output mux,
            // before legacy OSD and the histogram panel are composited.
            processed3<=equalize_active?equalized_rgb2:rgb2;
            case(state)
                CLEAR:begin
                    clear_index<=clear_index+1'b1;
                    if(clear_index==511) state<=IDLE;
                end
                IDLE:if(frame_blank) begin
                    state<=CAPTURE;sample_count<=0;
                    capture_equalized<=eq_sync[1]&&!original_sync[1]&&table_valid;
                end
                CAPTURE:begin
                    if(sample) sample_count<=sample_count+1'b1;
                    if(last_pixel) state<=DRAIN;
                    // Truncated video is discarded instead of published.
                    else if(frame_blank) begin state<=CLEAR;clear_index<=0;end
                end
                DRAIN:if(!(post_sample_pipe[0]||post_sample_pipe[1]||sample_d)) begin
                    state<=PENDING;token<=token+1'b1;written<=0;write_index<=0;
                end
                PENDING:if(commit) state<=SWAP;
                SWAP:if(frame_blank) begin
                    bank<=!bank;table_valid<=1;state<=CLEAR;clear_index<=0;
                    display_equalized<=capture_equalized;
                end
                default:state<=CLEAR;
            endcase
            if(accept_write&&addr==6'h0c) read_index<=I_pwdata[8:0];
            if(accept_write&&addr==6'h14) begin
                write_index<=write_index+1'b1;written<=written+1'b1;
            end
            // Three clocks added to the complete HDMI stream; DDR read
            // requests and the original mixer pipeline are untouched.
            vs_pipe<={vs_pipe[1:0],I_vsync};hs_pipe<={hs_pipe[1:0],I_hsync};
            de_pipe<={de_pipe[1:0],I_de};
            luma1<=luma_sum[9:2];luma2<=luma1;
            rgb1<=I_image_rgb;rgb2<=rgb1;
            composite1<=I_rgb;composite2<=composite1;
            legacy1<=I_osd_hit;legacy2<=legacy1;
            x1<=x;y1<=y;
            panel2<=de_pipe[0]&&panel_inside&&(!RUNTIME_UI||(show_frame&&!hide_for_frame));
            panel_color2<=border?24'hc0d8e0:
                (bar_on?(equalize_active?24'hffcc40:24'h30d8f0):
                (grid_on?24'h304050:24'h101820));
            if(panel2) O_rgb<=panel_color2;
            else if(equalize_active&&!legacy2)
                O_rgb<=equalized_rgb2;
            else O_rgb<=composite2;
        end
    end
    end endgenerate
endmodule
