`timescale 1ns/1ps
// AWB -> four-pixel luminance equalizer -> effects. MCU HIS2 ABI is unchanged.
// Four read replicas share table writes; all arithmetic is shift/add/clamp.
// Statistics sample pixel 0 of every four-pixel beat, on every fourth row:
// still exactly 57,600 samples per 720p frame, before and after RGB clipping.
module histogram_equalize4 #(parameter integer WIDTH=1280,HEIGHT=720)(
    input wire I_clk,I_rst_n,I_valid,I_user,I_last,I_equalize,
    input wire [95:0] I_rgb,
    output reg O_valid,O_user,O_last,
    output reg [95:0] O_rgb,
    input wire [9:0] I_paddr,
    input wire I_psel,I_penable,I_pwrite,
    input wire [31:0] I_pwdata,
    output reg [31:0] O_prdata,
    output wire O_pready,O_pslverr,
    output wire O_bar_write,
    output wire [8:0] O_bar_address,
    output wire [13:0] O_bar_data,
    output reg O_table_bank,O_table_valid,O_table_equalized,
    input wire I_panel_bank,I_panel_valid
);
    localparam CLEAR=0,IDLE=1,CAPTURE=2,DRAIN=3,PENDING=4,SWAP=5,WAIT_PANEL=6;
    reg [2:0] state;
    reg [7:0] clear_index,write_index;
    reg [8:0] read_index,written;
    reg [15:0] sample_count;
    reg [31:0] token;
    reg [10:0] x,y;
    wire [10:0] bx=I_user?11'd0:x,by=I_user?11'd0:y;
    reg equalize_frame,capture_equalized;
    wire swapping=state==SWAP&&I_user;
    wire valid_for_beat=O_table_valid||swapping;
    wire bank_for_beat=swapping?!O_table_bank:O_table_bank;
    wire eq_for_beat=I_user?I_equalize:equalize_frame;
    wire capturing=(state==CAPTURE)||(state==IDLE&&I_user);
    wire sample=capturing&&I_valid&&(by[1:0]==0);
    wire last_pixel=I_valid&&bx==WIDTH/4-1&&by==HEIGHT-1;
    reg [2:0] sample_pipe;
    reg [1:0] valid_pipe,user_pipe,last_pipe,eq_pipe;
    reg [95:0] rgb1,rgb2;
    reg [7:0] luma1[0:3],luma2[0:3];
    reg bank1;
    wire [7:0] mapped[0:3];
    function [7:0] luminance(input [23:0] p);
        reg [9:0] sum;
        begin sum={2'd0,p[23:16]}+{1'd0,p[15:8],1'b0}+{2'd0,p[7:0]};luminance=sum[9:2];end
    endfunction
    function [7:0] adjust(input [7:0] c,input signed [8:0] d);
        reg signed [10:0] v;
        begin v=$signed({1'b0,c})+d;adjust=v<0?0:(v>255?255:v[7:0]);end
    endfunction
    wire access=I_psel&&I_penable;
    wire [5:0] addr=I_paddr[5:0];
    assign O_pready=1'b1;
    assign O_pslverr=access&&(I_paddr[1:0]!=0 || (I_pwrite&&
        !((addr==6'h0c&&state==PENDING)||(addr==6'h14&&state==PENDING&&written<256)||
          (addr==6'h18&&state==PENDING&&written==256&&I_pwdata==token))));
    wire accept=access&&I_pwrite&&!O_pslverr;
    assign O_bar_write=accept&&addr==6'h14;
    assign O_bar_address={!O_table_bank,write_index};
    assign O_bar_data=I_pwdata[21:8];
    genvar lane;
    generate for(lane=0;lane<4;lane=lane+1)begin:g_lut
        (* ram_style="block" *) reg [7:0] table_ram[0:511];
        reg [7:0] q;
        assign mapped[lane]=q;
        always @(posedge I_clk)begin
            q<=table_ram[{bank1,luma1[lane]}];
            if(O_bar_write)table_ram[{!O_table_bank,write_index}]<=I_pwdata[7:0];
        end
        wire signed [8:0] delta=$signed({1'b0,mapped[lane]})-$signed({1'b0,luma2[lane]});
        wire [23:0] pixel=rgb2[95-lane*24-:24];
        always @(posedge I_clk or negedge I_rst_n)
            if(!I_rst_n)begin luma1[lane]<=0;luma2[lane]<=0;O_rgb[95-lane*24-:24]<=0;end
            else begin
                luma1[lane]<=luminance(I_rgb[95-lane*24-:24]);luma2[lane]<=luma1[lane];
                O_rgb[95-lane*24-:24]<=eq_pipe[1]?
                    {adjust(pixel[23:16],delta),adjust(pixel[15:8],delta),adjust(pixel[7:0],delta)}:pixel;
            end
    end endgenerate
    wire [15:0] input_count,output_count;
    wire in_busy,out_busy;
    histogram_counter256 u_input_counts(.I_clk(I_clk),.I_rst_n(I_rst_n),
        .I_clear(state==CLEAR),.I_clear_index(clear_index),.I_sample(sample),
        .I_bin(luminance(I_rgb[95:72])),.I_read_index(read_index[7:0]),.O_count(input_count),.O_busy(in_busy));
    histogram_counter256 u_output_counts(.I_clk(I_clk),.I_rst_n(I_rst_n),
        .I_clear(state==CLEAR),.I_clear_index(clear_index),.I_sample(sample_pipe[2]),
        .I_bin(luminance(O_rgb[95:72])),.I_read_index(read_index[7:0]),.O_count(output_count),.O_busy(out_busy));
    (* async_reg="true" *) reg [1:0] panel_bank_sync,panel_valid_sync;
    always @* begin
        case(addr)
            6'h00:O_prdata=32'h48495332;
            6'h04:O_prdata={25'd0,O_table_valid&&(!equalize_frame||O_table_equalized),capture_equalized,
                state==CAPTURE,equalize_frame,O_table_valid,state==SWAP||state==WAIT_PANEL,state==PENDING};
            6'h08:O_prdata=token;
            6'h0c:O_prdata={23'd0,read_index};
            6'h10:O_prdata=state==PENDING?{16'd0,read_index[8]?output_count:input_count}:32'd0;
            // The MCU must distinguish a real zero count from the CDC's
            // all-zero timeout reply before retrying an unacknowledged write.
            6'h14:O_prdata={1'b1,22'd0,written};
            6'h1c:O_prdata={16'd0,sample_count};
            6'h20:O_prdata={16'd256,9'd0,7'd112};
            default:O_prdata=0;
        endcase
    end
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            state<=CLEAR;clear_index<=0;write_index<=0;read_index<=0;written<=0;
            sample_count<=0;token<=0;x<=0;y<=0;equalize_frame<=0;capture_equalized<=0;
            O_table_bank<=0;O_table_valid<=0;O_table_equalized<=0;
            sample_pipe<=0;valid_pipe<=0;user_pipe<=0;last_pipe<=0;eq_pipe<=0;
            rgb1<=0;rgb2<=0;bank1<=0;O_valid<=0;O_user<=0;O_last<=0;
            panel_bank_sync<=0;panel_valid_sync<=0;
        end else begin
            panel_bank_sync<={panel_bank_sync[0],I_panel_bank};
            panel_valid_sync<={panel_valid_sync[0],I_panel_valid};
            valid_pipe<={valid_pipe[0],I_valid};user_pipe<={user_pipe[0],I_user};last_pipe<={last_pipe[0],I_last};
            O_valid<=valid_pipe[1];O_user<=user_pipe[1];O_last<=last_pipe[1];
            rgb1<=I_rgb;rgb2<=rgb1;bank1<=bank_for_beat;
            eq_pipe<={eq_pipe[0],eq_for_beat&&valid_for_beat};
            sample_pipe<={sample_pipe[1:0],sample};
            if(I_user)equalize_frame<=I_equalize;
            if(I_user)begin x<=I_valid?11'd1:11'd0;y<=0;end
            else if(I_valid)begin
                if(x==WIDTH/4-1)begin x<=0;y<=y==HEIGHT-1?11'd0:y+11'd1;end
                else x<=x+11'd1;
            end
            case(state)
                CLEAR:begin clear_index<=clear_index+1'b1;if(clear_index==255)state<=IDLE;end
                IDLE:if(I_user)begin
                    state<=CAPTURE;sample_count<=sample?16'd1:16'd0;
                    capture_equalized<=I_equalize&&O_table_valid;
                end
                CAPTURE:begin
                    if(sample)sample_count<=sample_count+1'b1;
                    if(last_pixel)state<=DRAIN;
                    else if(I_user)begin state<=CLEAR;clear_index<=0;end
                end
                DRAIN:if(!(in_busy||out_busy||(|sample_pipe)))begin
                    state<=PENDING;token<=token+1'b1;written<=0;write_index<=0;
                end
                PENDING:if(accept&&addr==6'h18)state<=SWAP;
                SWAP:if(I_user)begin
                    O_table_bank<=!O_table_bank;O_table_valid<=1;
                    O_table_equalized<=capture_equalized;state<=WAIT_PANEL;
                end
                // An inactive table bank cannot be reused until HDMI has
                // atomically adopted the new bank at its own frame boundary.
                WAIT_PANEL:if(panel_valid_sync[1]&&panel_bank_sync[1]==O_table_bank)begin
                    state<=CLEAR;clear_index<=0;
                end
                default:state<=CLEAR;
            endcase
            if(accept&&addr==6'h0c)read_index<=I_pwdata[8:0];
            if(O_bar_write)begin write_index<=write_index+1'b1;written<=written+1'b1;end
        end
    end
endmodule

// One synchronous read + one write port. Forward the last update on a
// read/write collision, including arbitrarily long runs of the same bin.
module histogram_counter256(
    input wire I_clk,I_rst_n,I_clear,I_sample,
    input wire [7:0] I_clear_index,I_bin,I_read_index,
    output wire [15:0] O_count,output wire O_busy
);
    (* ram_style="block" *) reg [15:0] counts[0:255];
    reg [15:0] q,last_value;
    reg [7:0] bin_d,last_bin;
    reg sample_d,last_valid;
    wire [15:0] updated=(last_valid&&last_bin==bin_d?last_value:q)+16'd1;
    assign O_count=q;assign O_busy=sample_d;
    always @(posedge I_clk)begin
        q<=counts[I_sample?I_bin:I_read_index];
        if(I_clear)counts[I_clear_index]<=0;
        else if(sample_d)counts[bin_d]<=updated;
    end
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)begin sample_d<=0;bin_d<=0;last_valid<=0;last_bin<=0;last_value<=0;end
        else begin
            sample_d<=I_sample&&!I_clear;bin_d<=I_bin;last_valid<=sample_d&&!I_clear;
            if(sample_d)begin last_bin<=bin_d;last_value<=updated;end
        end
endmodule
