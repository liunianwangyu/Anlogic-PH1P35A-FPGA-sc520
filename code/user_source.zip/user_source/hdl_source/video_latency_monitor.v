`timescale 1ns/1ps
// A held-payload req/ack mailbox. The receiver consumes on O_valid's edge;
// payload was held before the two request synchronizers and stays held until
// the acknowledgement has returned through two source synchronizers.
module video_latency_mailbox #(parameter WIDTH=8)(
 input I_src_clk,I_dst_clk,I_rst_n,I_valid,input [WIDTH-1:0] I_data,
 output O_ready,output O_valid,output [WIDTH-1:0] O_data
);
 reg [WIDTH-1:0] hold_data;
 reg req,ack;
 (* async_reg="true" *) reg am,asyn,rm,rsyn;
 assign O_ready=req==asyn;
 assign O_valid=rsyn!=ack;
 assign O_data=hold_data;
 always @(posedge I_src_clk or negedge I_rst_n)
  if(!I_rst_n)begin hold_data<=0;req<=0;am<=0;asyn<=0;end
  else begin
   am<=ack;asyn<=am;
   if(I_valid&&O_ready)begin hold_data<=I_data;req<=!req;end
  end
 always @(posedge I_dst_clk or negedge I_rst_n)
  if(!I_rst_n)begin rm<=0;rsyn<=0;ack<=0;end
  else begin rm<=req;rsyn<=rm;if(O_valid)ack<=rsyn;end
endmodule

// Observational only: no ready/request/pixel output. Time is the existing
// audio Gray-CDC millisecond clock, never a second millisecond divider.
module video_latency_monitor #(
 parameter integer FRAME_WORDS=172800,
 parameter integer ROW_WORDS=240,
 parameter integer STALL_BITS=20,
 parameter integer UPDATE_MS=500,
 parameter integer MIN_CAPTURE_MS=4
)(
 input I_raw_clk,I_raw_rst_n,I_raw_sof,I_raw_valid,I_isp_sof,
 input I_clk,I_rst_n,input [15:0] I_time_ms,
 input I_write_start,input [1:0] I_write_slot,input I_write_flip,
 input I_write_accept,input [24:0] I_write_addr,
 input I_read_start,input [1:0] I_read_slot,
 input I_read_request,input [24:0] I_read_addr,
 input I_pixel_clk,I_pixel_rst_n,I_vsync,I_de,I_underflow,
 output reg [15:0] O_bcd,output reg [1:0] O_status,
 // One event per confirmed display lifecycle, before the OSD rate limiter.
 // Reason bits: timebase/timeout, identity, write, address, underflow, age.
 output reg O_sample_valid,output reg [9:0] O_sample_ms,
 output reg O_sample_hold,output reg [7:0] O_sample_bad_reason
);
 localparam [1:0] INVALID=0,VALID=1,HOLD=2;
 // All relevant domain resets revoke the *whole* statistics subsystem.
 // This reset is never fanned into the existing video/audio domains.
 wire reset_n=I_rst_n&&I_raw_rst_n&&I_pixel_rst_n;
 reg raw_sof_d,raw_armed,raw_identity,isp_wait,raw_loss;
 reg [7:0] raw_tag;
 wire new_raw=I_raw_sof&&!raw_sof_d;
 wire capture=I_raw_valid&&(raw_armed||new_raw);
 wire [7:0] capture_tag=new_raw?raw_tag+8'd1:raw_tag;
 wire raw_ready,cap_event,isp_ready,isp_event;
 wire [8:0] cap_data,isp_data;
 wire isp_identity=new_raw?!isp_wait:(isp_wait&&raw_identity);
 video_latency_mailbox #(.WIDTH(9)) u_capture(
  .I_src_clk(I_raw_clk),.I_dst_clk(I_clk),.I_rst_n(reset_n),
  .I_valid(capture),.I_data({raw_loss,capture_tag}),.O_ready(raw_ready),
  .O_valid(cap_event),.O_data(cap_data));
 // These synchronizers launch on the SAME ISP SOF and consume on the SAME
 // DDR edge as video_in's original 2-FF stretched-SOF edge detector. The
 // condition is checked at runtime: a skew/lost event invalidates the sample.
 video_latency_mailbox #(.WIDTH(9)) u_isp_tag(
  .I_src_clk(I_raw_clk),.I_dst_clk(I_clk),.I_rst_n(reset_n),
  .I_valid(I_isp_sof),.I_data({isp_identity,capture_tag}),
  .O_ready(isp_ready),.O_valid(isp_event),.O_data(isp_data));
 always @(posedge I_raw_clk or negedge reset_n)
  if(!reset_n)begin raw_sof_d<=0;raw_armed<=0;raw_identity<=0;
   isp_wait<=0;raw_loss<=0;raw_tag<=0;end
  else begin
   raw_sof_d<=I_raw_sof;
   if(new_raw)begin
    raw_tag<=raw_tag+8'd1;raw_armed<=1;isp_wait<=1;
    raw_identity<=!isp_wait;
   end
   if(capture)begin raw_armed<=0;raw_loss<=!raw_ready;end
   if(I_isp_sof)begin isp_wait<=0;raw_identity<=0;end
  end

 reg vs_d,pixel_armed,pixel_seen,pixel_bad,pixel_loss;
 wire pixel_first=pixel_armed&&I_de;
 wire pixel_end=I_vsync&&!vs_d;
 wire pixel_event=pixel_first||pixel_end;
 wire endpoint_ready,endpoint_event;
 wire [3:0] endpoint;
 video_latency_mailbox #(.WIDTH(4)) u_endpoint(
  .I_src_clk(I_pixel_clk),.I_dst_clk(I_clk),.I_rst_n(reset_n),
  .I_valid(pixel_event),.I_data({pixel_loss,pixel_bad||I_underflow,pixel_seen,pixel_first}),
  .O_ready(endpoint_ready),.O_valid(endpoint_event),.O_data(endpoint));
 always @(posedge I_pixel_clk or negedge reset_n)
  if(!reset_n)begin vs_d<=0;pixel_armed<=0;pixel_seen<=0;
   pixel_bad<=0;pixel_loss<=0;end
  else begin
   vs_d<=I_vsync;
   // Falling VS starts the same read lifecycle as video_out's inverted VS.
   if(!I_vsync&&vs_d)begin pixel_armed<=1;pixel_seen<=0;pixel_bad<=0;end
   if(I_underflow)pixel_bad<=1;
   if(pixel_first)begin pixel_armed<=0;pixel_seen<=1;end
   if(pixel_event)pixel_loss<=!endpoint_ready;
  end

 function [24:0] slot_base(input [1:0] s);
  case(s)0:slot_base=0;1:slot_base=7000000;
   2:slot_base=14000000;3:slot_base=21000000;endcase
 endfunction
 // The complete payload and <=512-word tail fit in one 4M-address page.
 // Pages are disjoint even though image-slot strides are not powers of two.
 // Sequential request checking below rejects skipped/backwards addresses;
 // the page guard rejects excessive reads before crossing a slot boundary.
 function [2:0] slot_page(input [1:0] s);
  case(s)0:slot_page=0;1:slot_page=1;2:slot_page=3;3:slot_page=5;endcase
 endfunction
 localparam integer FRAME_ROWS=FRAME_WORDS/ROW_WORDS;
 localparam integer LAST_ROW=(FRAME_ROWS-1)*ROW_WORDS*8;
 localparam integer ROW_BACK=(2*ROW_WORDS-1)*8;
 (* syn_ramstyle="registers" *) reg [15:0] slot_time[0:3];
 (* syn_ramstyle="registers" *) reg [7:0] slot_tag[0:3];
 reg [3:0] slot_valid,slot_complete,slot_counted;
 reg [1:0] expire_slot;
 wire [15:0] slot_age=I_time_ms-slot_time[expire_slot];
 reg cap_pending,write_pending,have_input,expired;
 reg [7:0] cap_tag,write_tag,last_cap_tag;
 reg [15:0] cap_time,last_input;
 reg [1:0] pending_slot;
 wire tagged_write=I_write_start&&isp_event&&isp_data[8];
 wire [15:0] input_age=I_time_ms-last_input;
 wire duplicate_cap=have_input&&cap_data[7:0]==last_cap_tag;
 wire cap_fast=have_input&&!duplicate_cap&&input_age<MIN_CAPTURE_MS;
 wire stalled;
 // RAW may remain live while the shared timebase is stopped. Such captures
 // must not rearm the same timeout every frame; recover after time moves.
 wire good_cap=cap_event&&!cap_data[8]&&!duplicate_cap&&!cap_fast&&!stalled;
 // A DDR-clock liveness watchdog detects a frozen shared pixel timebase.
 // It is a saturating cycle counter, not another calibrated time source.
 reg [STALL_BITS-1:0] time_stall;
 reg [15:0] previous_ms;
 assign stalled=&time_stall;
 wire timeout=(have_input&&input_age>=1000)||stalled;
 reg announced,announced_flip,write_active,active_flip;
 reg [1:0] announced_slot,active_slot;
 reg [24:0] expected_write;
 reg [9:0] write_row;
 reg [7:0] write_col;
 reg [24:0] announced_first;
 always @*case({announced_slot,announced_flip})
  0:announced_first=0;1:announced_first=LAST_ROW;
  2:announced_first=7000000;3:announced_first=7000000+LAST_ROW;
  4:announced_first=14000000;5:announced_first=14000000+LAST_ROW;
  6:announced_first=21000000;7:announced_first=21000000+LAST_ROW;
 endcase
 wire restart_write=I_write_accept&&announced&&I_write_addr==announced_first;
 reg read_active,read_ok,candidate_ok,candidate_hold,seen_display;
 reg [1:0] read_slot;
 reg [7:0] read_tag,last_display_tag;
 reg [15:0] read_time,last_update,last_display_time;
 reg [9:0] candidate_ms;
 wire [15:0] delta_ms=I_time_ms-read_time;
 wire [2:0] read_page=slot_page(read_slot);
 // The user-approved original tail prefetch stays inside the same slot.
 // video_out's request address is sequential; test it on every user request.
 wire read_in_bounds=I_read_addr[24:22]==read_page;
 reg [24:0] expected_read;
 wire read_fault=read_active&&!I_read_start&&I_read_request&&(!read_in_bounds||I_read_addr!=expected_read);
 wire overwrite=read_active&&((I_write_start&&I_write_slot==read_slot)||
   (I_write_accept&&I_write_addr[24:22]==read_page));
 reg [7:0] read_reason;
 wire identity_fault=(cap_event&&(cap_data[8]||cap_fast))||
     (I_write_start&&!tagged_write)||(isp_event&&!I_write_start)||
     (endpoint_event&&endpoint[3]);
 wire [7:0] end_reason=read_reason|
     (read_fault?8'h08:8'h00)|(overwrite?8'h04:8'h00)|
     (endpoint[2]?8'h10:8'h00)|(endpoint[3]?8'h02:8'h00)|
     (timeout?8'h01:8'h00);
 reg [9:0] binary_shift;
 reg [11:0] bcd_shift;
 reg [3:0] bcd_step;
 reg bcd_busy,send_result;
 reg [17:0] result_data;
 wire result_ready,result_event;
 wire [17:0] result_pixel;
 reg [17:0] pending_pixel;
 reg pending_pixel_valid;
 reg [11:0] bcd_correct;
 integer k;
 always @*begin
  bcd_correct=bcd_shift;
  for(integer j=0;j<3;j=j+1)
   if(bcd_shift[j*4+:4]>=5)bcd_correct[j*4+:4]=bcd_shift[j*4+:4]+4'd3;
 end
 video_latency_mailbox #(.WIDTH(18)) u_result(
  .I_src_clk(I_clk),.I_dst_clk(I_pixel_clk),.I_rst_n(reset_n),
  .I_valid(send_result),.I_data(result_data),.O_ready(result_ready),
  .O_valid(result_event),.O_data(result_pixel));
 always @(posedge I_pixel_clk or negedge reset_n)
  if(!reset_n)begin O_bcd<=0;O_status<=INVALID;pending_pixel<=0;pending_pixel_valid<=0;end
  else begin
   if(result_event)begin pending_pixel<=result_pixel;pending_pixel_valid<=1;end
   // Falling VS, long before first DE: all characters change atomically.
   if(!I_vsync&&vs_d&&(pending_pixel_valid||result_event))begin
    {O_status,O_bcd}<=result_event?result_pixel:pending_pixel;
    pending_pixel_valid<=0;
   end
  end

 always @(posedge I_clk or negedge reset_n)
  if(!reset_n)begin
   slot_valid<=0;slot_complete<=0;slot_counted<=0;expire_slot<=0;cap_pending<=0;write_pending<=0;
   have_input<=0;expired<=1;cap_tag<=0;write_tag<=0;last_cap_tag<=0;
   cap_time<=0;last_input<=0;pending_slot<=0;time_stall<=0;previous_ms<=0;
   announced<=0;announced_flip<=0;announced_slot<=0;write_active<=0;active_flip<=0;
   active_slot<=0;expected_write<=0;write_row<=0;write_col<=0;
   read_active<=0;read_ok<=0;read_slot<=0;read_tag<=0;read_time<=0;expected_read<=0;
   candidate_ok<=0;candidate_hold<=0;candidate_ms<=0;seen_display<=0;last_display_tag<=0;last_display_time<=0;
   last_update<=0;binary_shift<=0;bcd_shift<=0;bcd_step<=0;bcd_busy<=0;
   send_result<=0;result_data<=0;read_reason<=0;
   O_sample_valid<=0;O_sample_ms<=0;O_sample_hold<=0;O_sample_bad_reason<=0;
   for(k=0;k<4;k=k+1)begin slot_time[k]<=0;slot_tag[k]<=0;end
  end else begin
   send_result<=0;O_sample_valid<=0;O_sample_hold<=0;O_sample_bad_reason<=0;
   // Scan one slot per DDR clock, sharing a single narrow age subtraction.
   // Saturating validity bits prevent a stale slot reviving after 65.536 s,
   // even if RAW events continue while no new ISP frame reaches the writer.
   expire_slot<=expire_slot+2'd1;
   if(slot_valid[expire_slot]&&slot_age>=1000)begin
    slot_valid[expire_slot]<=0;slot_complete[expire_slot]<=0;
    if(read_active&&read_slot==expire_slot)begin read_ok<=0;candidate_ok<=0;read_reason<=read_reason|8'h20;end
   end
   previous_ms<=I_time_ms;
   if(previous_ms!=I_time_ms)time_stall<=0;
   else if(!stalled)time_stall<=time_stall+1'b1;
   if(good_cap)begin
    have_input<=1;expired<=0;last_input<=I_time_ms;last_cap_tag<=cap_data[7:0];
    cap_pending<=1;cap_tag<=cap_data[7:0];cap_time<=I_time_ms;
    if(write_pending&&write_tag!=cap_data[7:0])write_pending<=0;
    if(write_pending&&write_tag==cap_data[7:0])begin
     slot_time[pending_slot]<=I_time_ms;slot_tag[pending_slot]<=cap_data[7:0];
     slot_valid[pending_slot]<=1;write_pending<=0;cap_pending<=0;
    end
   end
   if(I_write_start)begin
    slot_valid[I_write_slot]<=0;slot_complete[I_write_slot]<=0;slot_counted[I_write_slot]<=0;
    announced<=1;announced_slot<=I_write_slot;announced_flip<=I_write_flip;
    write_pending<=tagged_write;write_tag<=isp_data[7:0];pending_slot<=I_write_slot;
    if(cap_pending&&cap_tag!=isp_data[7:0])cap_pending<=0;
    if(tagged_write&&((good_cap&&cap_data[7:0]==isp_data[7:0])||
       (cap_pending&&cap_tag==isp_data[7:0])))begin
     slot_time[I_write_slot]<=good_cap&&cap_data[7:0]==isp_data[7:0]?I_time_ms:cap_time;
     slot_tag[I_write_slot]<=isp_data[7:0];slot_valid[I_write_slot]<=1;
     cap_pending<=0;write_pending<=0;
    end
    if(write_active&&active_slot==I_write_slot)begin
     write_active<=0;slot_valid[I_write_slot]<=0;
    end
   end
   if(I_write_accept)begin
    if(write_active&&I_write_addr==expected_write)begin
     expected_write<=expected_write+((active_flip&&write_col==ROW_WORDS-1)?-ROW_BACK:25'd8);
     if(write_col==ROW_WORDS-1)begin
      write_col<=0;write_row<=write_row+1'b1;
      if(write_row==FRAME_ROWS-1)begin
       slot_complete[active_slot]<=1;write_active<=0;
      end
     end else write_col<=write_col+1'b1;
    end else begin
     if(write_active)slot_valid[active_slot]<=0;
     write_active<=0;
     // Starts are attributable only to the latest announced frame. On an
     // ambiguous command sequence discard measurement, never stall video.
     if(restart_write)begin
      write_active<=1;active_slot<=announced_slot;active_flip<=announced_flip;
      expected_write<=announced_first+25'd8;write_row<=0;write_col<=1;
      announced<=0;
     end else begin slot_valid<=0;slot_complete<=0;end
    end
   end
   if(I_read_start)begin
    read_active<=1;read_slot<=I_read_slot;read_tag<=slot_tag[I_read_slot];
    read_time<=slot_time[I_read_slot];read_ok<=slot_valid[I_read_slot]&&slot_complete[I_read_slot]&&!expired;
    candidate_ok<=0;expected_read<=slot_base(I_read_slot);
    read_reason<=(slot_valid[I_read_slot]&&slot_complete[I_read_slot]&&!expired)?8'd0:8'h04;
   end else if(I_read_request)expected_read<=expected_read+25'd8;
   if(read_fault||overwrite)begin
    read_ok<=0;candidate_ok<=0;
    read_reason<=read_reason|(read_fault?8'h08:8'h00)|(overwrite?8'h04:8'h00);
   end
   if(endpoint_event)begin
    if(endpoint[0])begin
     candidate_ms<=delta_ms[9:0];
     candidate_ok<=read_active&&read_ok&&!read_fault&&!overwrite&&delta_ms<1000&&!endpoint[2]&&!endpoint[3];
     candidate_hold<=slot_counted[read_slot]||
         (seen_display&&read_tag==last_display_tag&&read_time==last_display_time);
     if(delta_ms>=1000)read_reason<=read_reason|8'h20;
    end else begin
     read_active<=0;
     if(candidate_ok&&read_ok&&!read_fault&&!overwrite&&endpoint[1]&&!endpoint[2]&&!endpoint[3]&&!timeout)begin
      O_sample_valid<=1;O_sample_ms<=candidate_ms;O_sample_hold<=candidate_hold;
      slot_counted[read_slot]<=1;
      seen_display<=1;last_display_tag<=read_tag;last_display_time<=read_time;
      if(candidate_hold)begin result_data<={HOLD,16'd0};send_result<=1;bcd_busy<=0;end
      else if((I_time_ms-last_update)>=UPDATE_MS||result_data[17:16]!=VALID)begin
       binary_shift<=candidate_ms;bcd_shift<=0;bcd_step<=0;bcd_busy<=1;
       last_update<=I_time_ms;
      end
     end else begin
      result_data<=0;send_result<=1;bcd_busy<=0;seen_display<=0;
      if(!expired&&read_active)begin
       O_sample_valid<=1;O_sample_bad_reason<=end_reason!=0?end_reason:8'h02;
      end
     end
     candidate_ok<=0;
    end
   end
   if(bcd_busy&&!endpoint_event)begin
    bcd_shift<={bcd_correct[10:0],binary_shift[9]};binary_shift<=binary_shift<<1;
    bcd_step<=bcd_step+1'b1;
    if(bcd_step==9)begin
     result_data<={VALID,4'd0,bcd_correct[10:0],binary_shift[9]};send_result<=1;bcd_busy<=0;
    end
   end
   // Retain unsent result until mailbox is free; never overwrite a flight.
   if(send_result&&!result_ready)send_result<=1;
   if((timeout&&!expired)||identity_fault)begin
    slot_valid<=0;slot_complete<=0;cap_pending<=0;write_pending<=0;
    read_ok<=0;candidate_ok<=0;announced<=0;write_active<=0;
    expired<=1;have_input<=0;seen_display<=0;bcd_busy<=0;
    result_data<=0;send_result<=1;
    // A persistent disconnect or clock stop counts once on state entry.
    // Do not count every subsequent empty display while expired remains set.
    if(!expired)begin
     O_sample_valid<=1;O_sample_hold<=0;
     O_sample_bad_reason<=(timeout?8'h01:8'h00)|(identity_fault?8'h02:8'h00);
    end
   end
  end
endmodule
