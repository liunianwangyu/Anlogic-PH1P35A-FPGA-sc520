`include "../audio/audio_abi.vh"
`timescale 1ns/1ps
// One mono stream; all writes/reads are bounded to the private PCM partition.
// FIFO carries first/last markers. Zero samples continue while idle/underflow.
module pcm_cache_player (
 input I_clk,I_rst_n,input [7:0] I_addr,input I_sel,I_enable,I_write,
 input [31:0] I_wdata,output reg [31:0] O_rdata,output O_error,
 output O_req,output O_write,output [24:0] O_addr,output [127:0] O_wdata,
 input I_done,I_error,input [127:0] I_rdata,
 input I_pixel_clk,I_pixel_rst_n,
 output reg O_audio_valid,output reg [23:0] O_audio_data,
 output [15:0] O_time_ms,output [15:0] O_pixel_time_ms
);
 localparam [24:0] PCM_BEGIN=1600000,PCM_END=5794304;
 reg [24:0] base,position,write_addr;
 reg [31:0] length,token,last_token,ack_token,first_ms,events,error_code,done_token;
 reg [127:0] write_data,line_data;
 // Starts are limited to 480000 samples; this private counter needs 19 bits.
 reg [18:0] left_to_fetch;
 reg busy,started,write_pending,write_seen,stop_toggle,stopping;
 reg [2:0] state,sample_index;
 reg [12:0] timeout_count;
 wire access=I_sel&&I_enable;
 wire readable=I_addr<=8'h2c||I_addr==8'h60||I_addr==8'h74||I_addr==8'h78||I_addr==8'h7c;
 wire writable=I_addr==8'h0c||I_addr==8'h10||I_addr==8'h14||I_addr==8'h18||I_addr==8'h20||
    (I_addr>=8'h60&&I_addr<=8'h74);
 assign O_error=access&&(I_addr[1:0]!=0||(I_write?!writable:!readable));
 wire fifo_full,fifo_empty,fifo_valid;
 wire [9:0] fifo_wr_level,fifo_rd_level;
 wire [10:0] wr_level={1'b0,fifo_wr_level},rd_level={1'b0,fifo_rd_level};
 wire [17:0] fifo_data;
 wire fifo_we=(state==2)&&!fifo_full&&left_to_fetch!=0;
 // During a transfer length is immutable and left_to_fetch only decreases.
 // Equality therefore identifies exactly the first accepted sample, without
 // the former subtract/add datapath used only to test samples_sent for zero.
 wire [17:0] fifo_input={left_to_fetch==length[18:0],left_to_fetch==1,line_data[15:0]};
 reg fifo_re;
 soft_fifo_al_4057d6b76aa6 #(.DATA_WIDTH_W(18),.DATA_WIDTH_R(18),
  .ADDR_WIDTH_W(10),.ADDR_WIDTH_R(10),.AL_FULL_NUM(768),.AL_EMPTY_NUM(256),
  .SHOW_AHEAD_EN(0),.OUTREG_EN("NOREG")) pcm_fifo (
  .rst(!I_rst_n),.clkw(I_clk),.clkr(I_pixel_clk),.we(fifo_we),.di(fifo_input),
  .re(fifo_re),.dout(fifo_data),.valid(fifo_valid),.full_flag(fifo_full),
  .empty_flag(fifo_empty),.afull(),.aempty(),.wrusedw(fifo_wr_level),.rdusedw(fifo_rd_level));
 // First/last acknowledgements are immutable until the next first/last sample.
 reg first_toggle,finish_toggle,underflow_toggle;
 reg [31:0] pixel_token,pixel_first_ms,pixel_underflows;
 (* async_reg="true" *)reg first_meta,first_sync,finish_meta,finish_sync;
 (* async_reg="true" *)reg underflow_meta,underflow_sync;
 reg underflow_seen;
 reg [31:0] underflows;
 reg first_seen,finish_seen;
 (* async_reg="true" *)reg stop_meta,stop_sync;
 reg stop_seen,draining;
 reg [17:0] hold_sample;
 reg have_sample,read_pending;
 reg [16:0] ms_phase;
 reg [31:0] pixel_ms;
 // TIME_MS and FIRST_SAMPLE_MS share this pixel-clock timebase, independent
 // of MCU startup DPLL reset/frequency changes. Register Gray before crossing;
 // only one source bit changes per millisecond, then use two DDR-domain FFs.
 reg [31:0] pixel_time_gray;
 (* async_reg="true" *)reg [31:0] time_meta,time_sync;
 wire [31:0] next_pixel_ms=pixel_ms+1'b1;
 wire [31:0] time_ms;
 assign O_time_ms=time_ms[15:0];
 assign O_pixel_time_ms=pixel_ms[15:0];
 genvar time_bit;
 generate for(time_bit=0;time_bit<32;time_bit=time_bit+1)begin : g_time_decode
  assign time_ms[time_bit]=^time_sync[31:time_bit];
 end endgenerate
 // PLL/Design.xml CLK4_ACTUAL_FREQ_DISP is 75 MHz (requested 74.25 MHz).
 // 2 / 3125 gives exactly 48 kHz without changing the existing video PLL.
 reg [11:0] phase;
 wire tick=phase>=12'd3123;
 reg pixel_playing;
 always @(posedge I_pixel_clk or negedge I_pixel_rst_n)begin
  if(!I_pixel_rst_n)begin phase<=0;ms_phase<=0;pixel_ms<=0;pixel_time_gray<=0;O_audio_valid<=0;O_audio_data<=0;
   fifo_re<=0;read_pending<=0;have_sample<=0;hold_sample<=0;first_toggle<=0;finish_toggle<=0;
   pixel_token<=0;pixel_first_ms<=0;pixel_underflows<=0;pixel_playing<=0;
   stop_meta<=0;stop_sync<=0;stop_seen<=0;draining<=0;underflow_toggle<=0;end
  else begin
   if(ms_phase==74999)begin ms_phase<=0;pixel_ms<=next_pixel_ms;
    pixel_time_gray<=next_pixel_ms^(next_pixel_ms>>1);end else ms_phase<=ms_phase+1'b1;
   phase<=tick?phase-12'd3123:phase+12'd2;
   O_audio_valid<=tick;O_audio_data<=0;fifo_re<=0;
   stop_meta<=stop_toggle;stop_sync<=stop_meta;
   if(stop_sync!=stop_seen)begin stop_seen<=stop_sync;draining<=1;have_sample<=0;pixel_playing<=0;end
   if(!read_pending&&!have_sample&&!fifo_empty)begin fifo_re<=1;read_pending<=1;end
   if(fifo_valid)begin read_pending<=0;hold_sample<=fifo_data;have_sample<=!draining;end
   if(draining)begin
    have_sample<=0;
    if(!read_pending&&fifo_empty)begin draining<=0;finish_toggle<=!finish_toggle;end
   end else if(tick)begin
    if(have_sample)begin
     O_audio_data<={hold_sample[15:0],8'd0};have_sample<=0;
     if(hold_sample[17])begin pixel_token<=token;pixel_first_ms<=pixel_ms;
      first_toggle<=!first_toggle;pixel_playing<=1;end
     if(hold_sample[16])begin finish_toggle<=!finish_toggle;pixel_playing<=0;end
    end else if(pixel_playing)begin pixel_underflows<=pixel_underflows+1'b1;underflow_toggle<=!underflow_toggle;end
   end
  end
 end
 assign O_req=state==1||state==3;
 assign O_write=state==3;
 assign O_addr=state==3?write_addr:position;
 assign O_wdata=write_data;
 always @*begin
  O_rdata=0;
  case(I_addr)
   `AA_ID:O_rdata=`AA_INTERFACE_ID;
   `AA_STATUS:O_rdata={27'd0,write_pending,(error_code!=0),(wr_level<256),busy,(!busy&&state==0&&!write_pending&&wr_level==0)};
   `AA_TIME_MS:O_rdata=time_ms;
   `AA_EVENTS:O_rdata=events;
   `AA_PCM_BASE:O_rdata={7'd0,base};
   `AA_SAMPLE_COUNT:O_rdata=length;
   `AA_START_TOKEN:O_rdata=token;
   `AA_ACK_TOKEN:O_rdata=ack_token;
   `AA_FIFO_LEVEL:O_rdata={21'd0,wr_level};
   `AA_ERROR_CODE:O_rdata=error_code;
   `AA_FIRST_SAMPLE_MS:O_rdata=first_ms;
   `AA_CACHE_ADDRESS:O_rdata={7'd0,write_addr};
   `AA_CACHE_TOKEN:O_rdata=last_token;
   `AA_DONE_TOKEN:O_rdata=done_token;
   `AA_UNDERFLOWS:O_rdata=underflows;
   default:begin end
  endcase
 end
 always @(posedge I_clk or negedge I_rst_n)begin
  if(!I_rst_n)begin base<=PCM_BEGIN;position<=PCM_BEGIN;length<=0;token<=0;last_token<=0;
   ack_token<=0;first_ms<=0;events<=0;error_code<=0;done_token<=0;
   busy<=0;started<=0;write_pending<=0;write_seen<=0;write_addr<=PCM_BEGIN;write_data<=0;
   line_data<=0;left_to_fetch<=0;state<=0;sample_index<=0;timeout_count<=0;stop_toggle<=0;stopping<=0;
   underflow_meta<=0;underflow_sync<=0;underflow_seen<=0;underflows<=0;
   first_meta<=0;first_sync<=0;first_seen<=0;finish_meta<=0;finish_sync<=0;finish_seen<=0;
   time_meta<=0;time_sync<=0;end
  else begin
   time_meta<=pixel_time_gray;time_sync<=time_meta;
   first_meta<=first_toggle;first_sync<=first_meta;finish_meta<=finish_toggle;finish_sync<=finish_meta;
   underflow_meta<=underflow_toggle;underflow_sync<=underflow_meta;
   if(underflow_sync!=underflow_seen)begin underflow_seen<=underflow_sync;underflows<=underflows+1'b1;events[2]<=1;end
   if(first_sync!=first_seen)begin first_seen<=first_sync;ack_token<=pixel_token;
    first_ms<=pixel_first_ms;events[0]<=1;started<=1;end
   if(finish_sync!=finish_seen)begin finish_seen<=finish_sync;busy<=0;events[1]<=1;done_token<=token;end
   if(access&&I_write&&!O_error)case(I_addr)
    `AA_EVENTS:events<=events&~I_wdata;
    `AA_PCM_BASE:if(!busy)base<=(I_wdata[31:25]!=0) ? 25'd0:I_wdata[24:0];else events[3]<=1;
    `AA_SAMPLE_COUNT:if(!busy)length<=I_wdata;else events[3]<=1;
    `AA_START_TOKEN:if(!busy&&state==0&&!write_pending&&wr_level==0&&I_wdata!=token&&I_wdata!=0&&
      base>=PCM_BEGIN&&base[2:0]==0&&length!=0&&length<=480000&&
      ({1'b0,base}+((length+7)>>3)*8)<=PCM_END)begin
      token<=I_wdata;busy<=1;started<=0;position<=base;left_to_fetch<=length[18:0];error_code<=0;
     end else begin events[3]<=1;end
    `AA_STOP_TOKEN:if(busy&&I_wdata==token)stopping<=1;
    `AA_CACHE_ADDRESS:if(!write_pending)write_addr<=(I_wdata[31:25]!=0) ? 25'd0:I_wdata[24:0];
    `AA_CACHE_DATA0:if(!write_pending)write_data[31:0]<=I_wdata;
    `AA_CACHE_DATA1:if(!write_pending)write_data[63:32]<=I_wdata;
    `AA_CACHE_DATA2:if(!write_pending)write_data[95:64]<=I_wdata;
    `AA_CACHE_DATA3:if(!write_pending)write_data[127:96]<=I_wdata;
    `AA_CACHE_TOKEN:if(!write_pending&&I_wdata!=last_token&&I_wdata!=0&&write_addr>=PCM_BEGIN&&
      write_addr<PCM_END&&write_addr[2:0]==0&&(!busy||write_addr<base||write_addr>=base+((length+7)>>3)*8))begin
      last_token<=I_wdata;write_pending<=1;
     end else events[3]<=1;
    default:begin end
   endcase
   case(state)
    0:begin timeout_count<=0;
     if(stopping)begin left_to_fetch<=0;stop_toggle<=!stop_toggle;stopping<=0;end
     else if(busy&&left_to_fetch!=0&&wr_level<768)state<=1;
     else if(write_pending)state<=3;
    end
    1:if(I_done)begin
      if(I_error)begin error_code<=1;events[2]<=1;stopping<=1;state<=0;end
      else if(stopping)state<=0;
      else begin line_data<=I_rdata;sample_index<=0;state<=2;end
     end
    2:if(stopping)state<=0;else if(fifo_we)begin
      line_data<=line_data>>16;left_to_fetch<=left_to_fetch-1'b1;sample_index<=sample_index+1'b1;
      if(sample_index==7||left_to_fetch==1)begin position<=position+8;state<=0;end
     end
    3:if(I_done)begin write_pending<=0;write_seen<=!write_seen;state<=0;if(I_error)error_code<=2;end
    default:state<=0;
   endcase
  end
 end
endmodule
