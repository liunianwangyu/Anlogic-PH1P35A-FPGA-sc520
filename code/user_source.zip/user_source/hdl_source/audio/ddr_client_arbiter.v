`timescale 1ns/1ps
// Interpose AFTER the old command FIFO. Each actually accepted DDR read is
// tagged; delayed audio replies can never leak into the video return FIFO.
module ddr_client_arbiter #(parameter integer CNN_ENABLE=0) (
 input I_clk,I_rst_n,I_video_busy,I_video_empty,I_calibrated,
 input I_v_en,input [24:0] I_v_addr,input [2:0] I_v_cmd,
 input I_v_wren,input [127:0] I_v_wdata,input [31:0] I_v_mask,
 output O_v_ready,O_v_wready,output O_v_valid,
 input I_a_req,I_a_write,input [24:0] I_a_addr,input [127:0] I_a_wdata,
 output reg O_a_done,output reg [127:0] O_a_rdata,output reg O_a_error,
 output O_en,output [24:0] O_addr,output [2:0] O_cmd,
 output O_wren,output [127:0] O_wdata,output [31:0] O_mask,
 input I_c_req,I_c_write,input [24:0] I_c_addr,input [127:0] I_c_wdata,
 output O_c_accept,O_c_valid,
 input I_ready,I_wready,I_rd_valid,input [127:0] I_rdata
);
 (* syn_ramstyle="distributed_ram" *) reg [1:0] tags[0:511];
 reg [8:0] wp,rp;
 reg [9:0] count;
 reg audio_inflight,a_seen;
 wire grant=I_a_req&&!a_seen&&!audio_inflight&&I_video_empty&&!I_video_busy&&
            I_calibrated&&count<510;
 wire c_grant=CNN_ENABLE && I_c_req && !I_a_req &&
             I_video_empty && !I_video_busy && I_calibrated && count<510;
 wire private_grant=grant||c_grant;
 assign O_c_accept=c_grant&&I_ready&&I_wready;
 assign O_v_ready=I_ready&&!private_grant&&count<510;
 assign O_v_wready=I_wready&&!private_grant&&count<510;
 wire a_accept=grant&&I_ready&&I_wready;
 assign O_en=private_grant?(I_ready&&I_wready):I_v_en;
 assign O_addr=grant?I_a_addr:(c_grant?I_c_addr:I_v_addr);
 assign O_cmd=grant?(I_a_write?3'd0:3'd1):
              (c_grant?(I_c_write?3'd0:3'd1):I_v_cmd);
 assign O_wren=grant?(a_accept&&I_a_write):
               (c_grant?(O_c_accept&&I_c_write):I_v_wren);
 assign O_wdata=grant?I_a_wdata:(c_grant?I_c_wdata:I_v_wdata);
 assign O_mask=private_grant?32'd0:I_v_mask;
 wire push=O_en&&I_ready&&(O_cmd==1);
 wire pop=I_rd_valid&&count!=0;
 assign O_c_valid=pop&&tags[rp]==2'd2;
 assign O_v_valid=pop&&tags[rp]==2'd0;
 always @(posedge I_clk or negedge I_rst_n)begin
  if(!I_rst_n)begin wp<=0;rp<=0;count<=0;audio_inflight<=0;a_seen<=0;
   O_a_done<=0;O_a_rdata<=0;O_a_error<=0;end
  else begin
   O_a_done<=0;O_a_error<=0;
   if(!I_a_req)a_seen<=0;
   if(push)begin tags[wp]<=grant?2'd1:(c_grant?2'd2:2'd0);wp<=wp+1'b1;end
   if(pop)begin
    rp<=rp+1'b1;
    if(tags[rp]==2'd1)begin O_a_done<=1;O_a_rdata<=I_rdata;audio_inflight<=0;end
   end
   case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
   if(a_accept)begin a_seen<=1;
    if(I_a_write)O_a_done<=1;else audio_inflight<=1;
   end
  end
 end
endmodule
