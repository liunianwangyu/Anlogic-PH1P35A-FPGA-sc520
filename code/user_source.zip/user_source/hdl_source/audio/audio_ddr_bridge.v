`timescale 1ns/1ps
// Immutable request/response CDC, bounded CPU wait, one cached 16-byte line.
// Writes use a full-line read/modify/write; no DDR mask interpretation assumed.
module audio_ddr_bridge #(parameter WAIT_CYCLES=5000)(
 input I_bus_clk,I_bus_rst_n,input I_req,I_write,input [15:0] I_addr,
 input [2:0] I_size,input [31:0] I_wdata,
 output O_done,O_error,output [31:0] O_rdata,output reg O_fault,output reg [12:0] O_max_wait,
 input I_ddr_clk,I_ddr_rst_n,
 output O_req,output O_write,output [24:0] O_addr,output [127:0] O_wdata,
 input I_done,I_error,input [127:0] I_rdata
);
 reg req_toggle,ack_toggle;
 (* async_reg="true" *)reg ack_meta,ack_sync,req_meta,req_sync;
 reg [51:0] request_data;
 reg [31:0] response_data;
 reg response_error;
 reg pending,complete;
 reg [31:0] reply_data;
 reg reply_error;
 reg [$clog2(WAIT_CYCLES)-1:0] wait_count;
 assign O_done=complete||(I_req&&O_fault);
 assign O_error=reply_error||O_fault;
 assign O_rdata=reply_data;
 always @(posedge I_bus_clk or negedge I_bus_rst_n)begin
  if(!I_bus_rst_n)begin req_toggle<=0;ack_meta<=0;ack_sync<=0;request_data<=0;
   pending<=0;complete<=0;reply_data<=0;reply_error<=0;wait_count<=0;O_fault<=0;O_max_wait<=0;end
  else begin
   ack_meta<=ack_toggle;ack_sync<=ack_meta;
   if(!I_req)complete<=0;
   if(I_req&&!pending&&!complete&&!O_fault)begin
    request_data<={I_write,I_size,I_addr,I_wdata};req_toggle<=!req_toggle;
    pending<=1;wait_count<=0;
   end else if(pending)begin
    if(ack_sync==req_toggle)begin
     if(wait_count>O_max_wait)O_max_wait<=wait_count;
     reply_data<=response_data;reply_error<=response_error;pending<=0;complete<=1;
     if(response_error)O_fault<=1;
    end else if(wait_count==WAIT_CYCLES-1)begin
     if(wait_count>O_max_wait)O_max_wait<=wait_count;
     O_fault<=1;pending<=0;complete<=1;reply_error<=1;
    end else wait_count<=wait_count+1'b1;
   end
  end
 end
 reg [51:0] dst_data;
 reg [2:0] state;
 reg [127:0] cache_data;
 reg [11:0] cache_tag;
 reg cache_valid;
 wire wr=dst_data[51];
 wire [2:0] sz=dst_data[50:48];
 wire [15:0] addr=dst_data[47:32];
 wire [31:0] wd=dst_data[31:0];
 assign O_req=(state==2)||(state==3);
 assign O_write=state==3;
 assign O_addr=25'd1500000+{10'd0,addr[15:4],3'b000};
 assign O_wdata=cache_data;
 reg [127:0] modified;
 integer i;
 wire [3:0] byte_enable=(sz==2)?4'b1111:
                          ((sz==1)?(addr[1]?4'b1100:4'b0011):
                           ((sz==0)?(4'b0001<<addr[1:0]):4'b0000));
 always @*begin
  modified=cache_data;
  // Decode the word and byte lanes once. Static byte destinations avoid
  // synthesizing a variable-position 128-bit insertion network.
  for(i=0;i<16;i=i+1)
   if(addr[3:2]==i/4&&byte_enable[i%4])
    modified[i*8 +: 8]=wd[(i%4)*8+:8];
 end
 always @(posedge I_ddr_clk or negedge I_ddr_rst_n)begin
  if(!I_ddr_rst_n)begin req_meta<=0;req_sync<=0;ack_toggle<=0;state<=0;dst_data<=0;
   response_data<=0;response_error<=0;cache_data<=0;cache_tag<=0;cache_valid<=0;end
  else begin
   req_meta<=req_toggle;req_sync<=req_meta;
   case(state)
    0:if(req_sync!=ack_toggle)begin dst_data<=request_data;state<=1;response_error<=0;end
    1:if(cache_valid&&cache_tag==addr[15:4])begin
       if(wr)begin cache_data<=modified;state<=3;end
       else begin response_data<=cache_data[addr[3:2]*32+:32];ack_toggle<=req_sync;state<=0;end
      end else state<=2;
    2:if(I_done)begin
       if(I_error)begin response_error<=1;ack_toggle<=req_sync;cache_valid<=0;state<=0;end
       else begin cache_data<=I_rdata;cache_tag<=addr[15:4];cache_valid<=1;state<=1;end
      end
    3:if(I_done)begin response_error<=I_error;ack_toggle<=req_sync;state<=0;if(I_error)cache_valid<=0;end
    default:state<=0;
   endcase
  end
 end
endmodule
