`timescale 1ns/1ps
// One outstanding AHB transfer. Old APB ABI and its two-cycle ERROR response
// are retained. Audio SRAM has four official ERAM byte lanes (8 KiB total).
// Decode once in the address phase. Successful reads retire from a registered
// response one clock after the peripheral handshake; writes keep their timing.
module audio_ahb_fabric (
 input I_clk,I_rst_n,input [1:0] I_htrans,input I_hwrite,
 input [30:0] I_haddr,input [2:0] I_hsize,input [31:0] I_hwdata,
 output reg [31:0] O_hrdata,output [1:0] O_hresp,output O_hready,
 output reg [19:0] O_paddr,output O_psel,O_audio_sel,O_penable,
 output reg O_pwrite,output [31:0] O_pwdata,
 input [31:0] I_prdata,I_audio_rdata,input I_pready,I_pslverr,I_audio_ready,I_audio_error,
 output O_mem_req,output O_mem_write,output [15:0] O_mem_addr,
 output [2:0] O_mem_size,output [31:0] O_mem_wdata,
 input I_mem_done,I_mem_error,input [31:0] I_mem_rdata
);
 localparam IDLE=0,SETUP=1,ACCESS=2,ERROR_END=3,RESPONSE=4;
 reg [2:0] state;
 reg [3:0] target;
 reg bad;
 reg [2:0] size;
 wire access=state==ACCESS;
 wire ready=(target[0]&&I_pready)||(target[1]&&I_audio_ready)||
            target[2]||(target[3]&&I_mem_done);
 wire error_now=access&&(bad||(target[0]&&I_pslverr)||
                    (target[1]&&I_audio_ready&&I_audio_error)||(target[3]&&I_mem_done&&I_mem_error));
 assign O_hready=state==IDLE||state==ERROR_END||state==RESPONSE||
                 (access&&O_pwrite&&ready&&!error_now);
 assign O_hresp=(error_now||state==ERROR_END)?2'b01:2'b00;
 assign O_psel=(state==SETUP||access)&&!bad&&target[0];
 assign O_audio_sel=(state==SETUP||access)&&!bad&&target[1];
 assign O_penable=access;
 assign O_pwdata=I_hwdata;
 assign O_mem_req=access&&!bad&&target[3];
 assign O_mem_write=O_pwrite;
 assign O_mem_addr=O_paddr[15:0];
 assign O_mem_size=size;
 assign O_mem_wdata=I_hwdata;
 wire [31:0] ram_data;
 wire [31:0] read_data=({32{target[0]}}&I_prdata)|
                     ({32{target[1]}}&I_audio_rdata)|
                     ({32{target[2]}}&ram_data)|
                     ({32{target[3]}}&I_mem_rdata);
 wire [3:0] byte_enable=(size==0)?(4'b0001<<O_paddr[1:0]):
                             ((size==1)?(4'b0011<<O_paddr[1:0]):4'b1111);
 genvar lane;
 generate for(lane=0;lane<4;lane=lane+1)begin: sram
   PH1P_LOGIC_ERAM #(.DATA_WIDTH_A(8),.DATA_WIDTH_B(8),
    .ADDR_WIDTH_A(11),.ADDR_WIDTH_B(11),.DATA_DEPTH_A(2048),.DATA_DEPTH_B(2048),
    .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
    .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.IMPLEMENT("20K(FAST)"),
    .ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),.CLKMODE("SYNC"),
    .INIT_FILE("NONE"),.FILL_ALL("NONE")) mem (
    .dia(I_hwdata[lane*8+:8]),.dib(8'd0),.addra(O_paddr[12:2]),.addrb(11'd0),
    .cea(1'b1),.ceb(1'b0),.ocea(1'b0),.oceb(1'b0),.clka(I_clk),.clkb(I_clk),
    .wea(access&&!bad&&target[2]&&O_pwrite&&byte_enable[lane]),.web(1'b0),
    .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
    .doa(ram_data[lane*8+:8]),.dob(),.ecc_sbiterr(),.ecc_dbiterr(),
    .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
 end endgenerate
 // Exact existing windows: 00000000..000003ff, 00000400..000004ff,
 // 00001000..00002fff, 01000000..0100ffff. Bit fields avoid wide magnitude
 // comparators, and the mutually exclusive selects remove a priority mux.
 wire hit_apb=I_haddr[30:10]==0;
 wire hit_audio=I_haddr[30:8]==23'h4;
 wire hit_ram=I_haddr[30:14]==0&&(I_haddr[13:12]==1||I_haddr[13:12]==2);
 wire hit_mem=I_haddr[30:16]==15'h100;
 task capture;
 begin
   O_paddr<={4'd0,I_haddr[15:0]};O_pwrite<=I_hwrite;size<=I_hsize;
   target<={hit_mem,hit_ram,hit_audio,hit_apb};
   bad<=!(hit_apb||hit_audio||hit_ram||hit_mem)||I_hsize>2||
        ((hit_apb||hit_audio)&&I_hsize!=2)||
        ((I_hsize==1)&&I_haddr[0])||((I_hsize==2)&&I_haddr[1:0]!=0);
   state<=SETUP;
 end endtask
 always @(posedge I_clk or negedge I_rst_n)begin
   if(!I_rst_n)begin state<=IDLE;target<=0;bad<=0;size<=0;O_paddr<=0;O_pwrite<=0;O_hrdata<=0;end
   else case(state)
     IDLE,ERROR_END,RESPONSE:if(I_htrans[1])capture;else state<=IDLE;
     SETUP:state<=ACCESS;
     ACCESS:if(error_now)state<=ERROR_END;else if(ready)begin
       if(!O_pwrite)begin O_hrdata<=read_data;state<=RESPONSE;end
       else if(I_htrans[1])capture;else state<=IDLE;
     end
     default:state<=IDLE;
   endcase
 end
endmodule
