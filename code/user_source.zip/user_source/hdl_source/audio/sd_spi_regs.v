`include "../audio/audio_abi.vh"
`timescale 1ns/1ps
// SD SPI mode 0, 200 kHz initial / 12.5 MHz transfer at 100 MHz AHB.
// CPU commands are asynchronous. BLOCK clocks 512 bytes + CRC16 into one
// official ERAM; waiting for a card never stalls HREADY or existing tasks.
module sd_spi_regs (
 input I_clk,I_rst_n,input [7:0] I_addr,input I_sel,I_enable,I_write,
 input [31:0] I_wdata,output reg [31:0] O_rdata,output O_error,
 output reg O_cs_n,output reg O_sclk,output O_mosi,input I_miso
);
 reg fast,busy,block_mode;
 reg [7:0] tx,rx,result;
 reg [2:0] bit_index;
 reg [7:0] divider;
 reg [9:0] byte_count;
 reg [31:0] seq,pack_word;
 reg [15:0] crc,received_crc;
 reg crc_error;
 reg [6:0] read_index;
 wire access=I_sel&&I_enable;
 wire known=I_addr==8'h30||I_addr==8'h34||I_addr==8'h38||I_addr==8'h3c||I_addr==8'h40||I_addr==8'h44||I_addr==8'h48;
 assign O_error=access&&(!known||(I_write&&(busy||I_addr==8'h38||I_addr==8'h40||I_addr==8'h48)));
 assign O_mosi=busy?tx[7]:1'b1;
 wire [31:0] block_word;
 reg ram_we;
 reg [6:0] ram_addr;
 reg [31:0] ram_data;
 PH1P_LOGIC_ERAM #(.DATA_WIDTH_A(32),.DATA_WIDTH_B(32),.ADDR_WIDTH_A(7),.ADDR_WIDTH_B(7),
  .DATA_DEPTH_A(128),.DATA_DEPTH_B(128),.MODE("SP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
  .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.IMPLEMENT("20K(FAST)"),
  .ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),.CLKMODE("ASYNC"),.INIT_FILE("NONE"),.FILL_ALL("NONE")) buffer (
  .dia(ram_data),.dib(32'd0),.addra((busy||ram_we)?ram_addr:read_index),.addrb(7'd0),.cea(1'b1),.ceb(1'b0),
  .ocea(1'b0),.oceb(1'b0),.clka(I_clk),.clkb(I_clk),.wea(ram_we),.web(1'b0),
  .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),.doa(block_word),.dob(),
  .ecc_sbiterr(),.ecc_dbiterr(),.ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
 function [15:0] crc_byte;
 input [15:0] c;input [7:0] b;reg [15:0] v;integer n;
 begin v=c^{b,8'd0};for(n=0;n<8;n=n+1)v=v[15]?(v<<1)^16'h1021:(v<<1);crc_byte=v;end
 endfunction
 always @*begin
  O_rdata=0;
  case(I_addr)
   `AA_SD_CONTROL:O_rdata={30'd0,fast,O_cs_n};
   `AA_SD_BYTE:O_rdata={24'd0,result};
   `AA_SD_STATUS:O_rdata={29'd0,block_mode,crc_error,busy};
   `AA_SD_READ_INDEX:O_rdata={25'd0,read_index};
   `AA_SD_SEQUENCE:O_rdata=seq;
   `AA_SD_DATA:O_rdata=block_word;
   default:begin end
  endcase
 end
 always @(posedge I_clk or negedge I_rst_n)begin
  if(!I_rst_n)begin O_cs_n<=1;O_sclk<=0;fast<=0;busy<=0;block_mode<=0;
   tx<=255;rx<=0;result<=0;bit_index<=0;divider<=0;byte_count<=0;seq<=0;
   crc<=0;received_crc<=0;crc_error<=0;read_index<=0;pack_word<=0;ram_we<=0;ram_addr<=0;ram_data<=0;end
  else begin
   ram_we<=0;
   if(access&&!I_write&&I_addr==8'h48&&!busy)read_index<=read_index+1'b1;
   if(access&&I_write&&!O_error)case(I_addr)
    `AA_SD_CONTROL:begin O_cs_n<=I_wdata[0];fast<=I_wdata[1];end
    8'h34,`AA_SD_READ_BLOCK:begin busy<=1;block_mode<=I_addr==8'h44;tx<=I_addr==8'h44 ? 8'hff:I_wdata[7:0];
     rx<=0;bit_index<=0;divider<=0;byte_count<=0;crc<=0;received_crc<=0;crc_error<=0;O_sclk<=0;end
    `AA_SD_READ_INDEX:read_index<=I_wdata[6:0];
    default:begin end
   endcase
   if(busy)begin
    if(divider==(fast?8'd3:8'd249))begin
     divider<=0;O_sclk<=!O_sclk;
     if(!O_sclk)rx<={rx[6:0],I_miso};
     else begin
      tx<={tx[6:0],1'b1};
      if(bit_index==7)begin
       bit_index<=0;result<=rx;
       if(!block_mode)begin busy<=0;seq<=seq+1'b1;end
       else begin
        if(byte_count<512)begin
         crc<=crc_byte(crc,rx);pack_word<={rx,pack_word[31:8]};
         if(byte_count[1:0]==3)begin ram_we<=1;ram_addr<=byte_count[8:2];ram_data<={rx,pack_word[31:8]};end
        end else received_crc<={received_crc[7:0],rx};
        if(byte_count==513)begin busy<=0;seq<=seq+1'b1;crc_error<=crc!={received_crc[7:0],rx};end
        else byte_count<=byte_count+1'b1;
       end
      end else bit_index<=bit_index+1'b1;
     end
    end else divider<=divider+1'b1;
   end
  end
 end
endmodule
