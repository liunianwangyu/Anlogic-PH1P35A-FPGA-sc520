`timescale 1ns/1ps
module audio_subsystem (
 input I_bus_clk,I_bus_rst_n,input [7:0] I_paddr,input I_psel,I_penable,I_pwrite,
 input [31:0] I_pwdata,output [31:0] O_prdata,output O_pready,O_pslverr,
 input I_mem_req,I_mem_write,input [15:0] I_mem_addr,input [2:0] I_mem_size,
 input [31:0] I_mem_wdata,output O_mem_done,O_mem_error,output [31:0] O_mem_rdata,
 input I_ddr_clk,I_ddr_rst_n,I_calibrated,input I_pixel_clk,I_pixel_rst_n,
 output O_ddr_req,O_ddr_write,output [24:0] O_ddr_addr,output [127:0] O_ddr_wdata,
 input I_ddr_done,I_ddr_error,input [127:0] I_ddr_rdata,
 output O_audio_valid,output [23:0] O_audio_data,output [15:0] O_time_ms,output [15:0] O_pixel_time_ms,
 output O_sd_cs_n,O_sd_clk,O_sd_mosi,input I_sd_miso
);
 wire sd_select=I_paddr>=8'h30&&I_paddr<=8'h48;
 wire memory_select=I_paddr==8'h50||I_paddr==8'h54;
 wire cpu_fault;
 (* async_reg="true" *)reg calibrated_meta,calibrated_sync;
 wire [12:0] max_memory_wait;
 always @(posedge I_bus_clk or negedge I_bus_rst_n)
  if(!I_bus_rst_n)begin calibrated_meta<=0;calibrated_sync<=0;end
  else begin calibrated_meta<=I_calibrated;calibrated_sync<=calibrated_meta;end
 wire [31:0] sd_data,link_data;
 wire sd_error,link_ready,link_error;
 sd_spi_regs u_sd(.I_clk(I_bus_clk),.I_rst_n(I_bus_rst_n),.I_addr(I_paddr),
  .I_sel(I_psel&&sd_select),.I_enable(I_penable),.I_write(I_pwrite),.I_wdata(I_pwdata),
  .O_rdata(sd_data),.O_error(sd_error),.O_cs_n(O_sd_cs_n),.O_sclk(O_sd_clk),
  .O_mosi(O_sd_mosi),.I_miso(I_sd_miso));
 wire [9:0] dst_addr;
 wire dst_sel,dst_enable,dst_write;
 wire [31:0] dst_wdata,dst_rdata;
 wire dst_error;
 mcu_apb_cdc u_register_cdc(
  .I_bus_clk(I_bus_clk),.I_dst_clk(I_ddr_clk),.I_rst_n(I_bus_rst_n),
  .I_paddr({2'd0,I_paddr}),.I_psel(I_psel&&!sd_select&&!memory_select),.I_penable(I_penable),
  .I_pwrite(I_pwrite),.I_pwdata(I_pwdata),.O_prdata(link_data),.O_pready(link_ready),.O_pslverr(link_error),
  .O_paddr(dst_addr),.O_psel(dst_sel),.O_penable(dst_enable),.O_pwrite(dst_write),.O_pwdata(dst_wdata),
  .I_prdata(dst_rdata),.I_pready(1'b1),.I_pslverr(dst_error));
 assign O_prdata=sd_select?sd_data:(memory_select?
    (I_paddr==8'h50 ? {30'd0,cpu_fault,calibrated_sync}:{19'd0,max_memory_wait}):link_data);
 assign O_pready=sd_select||memory_select||link_ready;
 assign O_pslverr=sd_select?sd_error:(memory_select?(I_psel&&I_penable&&I_pwrite):link_error);
 wire cpu_req,cpu_write,cpu_done,cpu_error;
 wire [24:0] cpu_addr;
 wire [127:0] cpu_wdata;
 wire pcm_req,pcm_write,pcm_done,pcm_error;
 wire [24:0] pcm_addr;
 wire [127:0] pcm_wdata;
 reg active,owner;
 assign O_ddr_req=active;
 // Both clients already latch their complete request and keep it unchanged
 // until their done edge. Retain only ownership here, avoiding a second copy
 // of the 154-bit payload. Client state changes on completion occur after
 // active is cleared at that same edge, when the request is no longer valid.
 assign O_ddr_write=owner?pcm_write:cpu_write;
 assign O_ddr_addr=owner?pcm_addr:cpu_addr;
 assign O_ddr_wdata=owner?pcm_wdata:cpu_wdata;
 assign cpu_done=active&&!owner&&I_ddr_done;
 assign pcm_done=active&&owner&&I_ddr_done;
 assign cpu_error=I_ddr_error;
 assign pcm_error=I_ddr_error;
 always @(posedge I_ddr_clk or negedge I_ddr_rst_n)begin
  if(!I_ddr_rst_n)begin active<=0;owner<=0;end
  else if(active)begin if(I_ddr_done)active<=0;end
  else if(pcm_req||cpu_req)begin
   active<=1;owner<=pcm_req;
  end
 end
 audio_ddr_bridge u_work_ram (
  .I_bus_clk(I_bus_clk),.I_bus_rst_n(I_bus_rst_n),.I_req(I_mem_req),.I_write(I_mem_write),
  .I_addr(I_mem_addr),.I_size(I_mem_size),.I_wdata(I_mem_wdata),.O_done(O_mem_done),
  .O_error(O_mem_error),.O_rdata(O_mem_rdata),.O_fault(cpu_fault),.O_max_wait(max_memory_wait),
  .I_ddr_clk(I_ddr_clk),.I_ddr_rst_n(I_ddr_rst_n),.O_req(cpu_req),.O_write(cpu_write),
  .O_addr(cpu_addr),.O_wdata(cpu_wdata),.I_done(cpu_done),.I_error(cpu_error),.I_rdata(I_ddr_rdata));
 pcm_cache_player u_player(
  .I_clk(I_ddr_clk),.I_rst_n(I_ddr_rst_n),.I_addr(dst_addr[7:0]),.I_sel(dst_sel),
  .I_enable(dst_enable),.I_write(dst_write),.I_wdata(dst_wdata),.O_rdata(dst_rdata),.O_error(dst_error),
  .O_req(pcm_req),.O_write(pcm_write),.O_addr(pcm_addr),.O_wdata(pcm_wdata),
  .I_done(pcm_done),.I_error(pcm_error),.I_rdata(I_ddr_rdata),
  .I_pixel_clk(I_pixel_clk),.I_pixel_rst_n(I_pixel_rst_n),.O_audio_valid(O_audio_valid),.O_audio_data(O_audio_data),
  .O_time_ms(O_time_ms),.O_pixel_time_ms(O_pixel_time_ms));
endmodule
