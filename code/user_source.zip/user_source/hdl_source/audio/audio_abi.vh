// Generated from tools/audio_abi.json.
`ifndef AUDIO_ABI_VH
`define AUDIO_ABI_VH
`define AA_INTERFACE_ID 32'h41550202
`define AA_ID 8'h00
`define AA_STATUS 8'h04
`define AA_TIME_MS 8'h08
`define AA_EVENTS 8'h0c
`define AA_PCM_BASE 8'h10
`define AA_SAMPLE_COUNT 8'h14
`define AA_START_TOKEN 8'h18
`define AA_ACK_TOKEN 8'h1c
`define AA_STOP_TOKEN 8'h20
`define AA_FIFO_LEVEL 8'h24
`define AA_ERROR_CODE 8'h28
`define AA_FIRST_SAMPLE_MS 8'h2c
`define AA_SD_CONTROL 8'h30
`define AA_SD_BYTE 8'h34
`define AA_SD_STATUS 8'h38
`define AA_SD_READ_INDEX 8'h3c
`define AA_SD_SEQUENCE 8'h40
`define AA_SD_READ_BLOCK 8'h44
`define AA_SD_DATA 8'h48
`define AA_DDR_STATUS 8'h50
`define AA_DDR_MAX_WAIT 8'h54
`define AA_CACHE_ADDRESS 8'h60
`define AA_CACHE_DATA0 8'h64
`define AA_CACHE_DATA1 8'h68
`define AA_CACHE_DATA2 8'h6c
`define AA_CACHE_DATA3 8'h70
`define AA_CACHE_TOKEN 8'h74
`define AA_DONE_TOKEN 8'h78
`define AA_UNDERFLOWS 8'h7c
`endif
