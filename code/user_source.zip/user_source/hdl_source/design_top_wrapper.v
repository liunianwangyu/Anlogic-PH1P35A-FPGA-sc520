

// v1.6: frame-coherent AVERAGE/CENTER metering; AUTO calculation stays in FD.
module design_top_wrapper #(parameter AE_USE_MCU = 1) (
    input wire        I_sys_clk,
      
    output wire       O_cam_scl,
    inout  wire       IO_cam_sda,
    output wire       O_cam_24m,
    output wire       O_cam_rst,
      
    input  wire [3:0]  I_button,
    input  wire [3:0]  I_switch,
    output wire [3:0]  LED,
    output wire [7:0] O_segment,O_digit_select,
    output wire O_servo_pan,O_servo_tilt,

    output wire O_sd_cs_n,O_sd_clk,O_sd_mosi,
    input wire I_sd_miso,
    output wire       O_screen_pwm,
    output wire       O_tmds_ch0_p,
    output wire       O_tmds_ch1_p,
    output wire       O_tmds_ch2_p,
    output wire       O_tmds_clk_p,

    inout wire        IO_rx_clk_pad_n, 
    inout wire        IO_rx_clk_pad_p, 
    inout wire[3:0]   IO_rx_data_pad_n,
    inout wire[3:0]   IO_rx_data_pad_p,

    output wire[12:0] ddr_addr,
    output wire[ 1:0] ddr_ba,
    output wire[ 0:0] ddr_cke,
    output wire[ 0:0] ddr_odt,
    output wire[ 0:0] ddr_cs_n,
    output wire       ddr_ras_n,
    output wire       ddr_cas_n,
    output wire       ddr_we_n,
    output wire[ 0:0] ddr_ck_p,
    output wire[ 0:0] ddr_ck_n,
    inout wire[1:0]   ddr_dm,
    inout wire[15:0]  ddr_dq,
    inout wire[1:0]   ddr_dqs_p,
    inout wire[1:0]   ddr_dqs_n   
);


    wire        	S_100m_clk;
    wire        	S_24m_clk;
    wire        	S_aux_50m_clk;
	wire        	S_10m_clk;
		
	wire        	S_pll_lock;
    wire        	S_rst_n;
    wire        	S_csi_rx_clk;
    wire            S_hdmi_pixel_clk;
    wire            S_ddr_clk;
    wire            S_init_calib_complete;
    wire [95:0] S_motion_pix;
    wire S_motion_valid,S_motion_user,S_motion_last;
    // Shared MCU-to-CSI APB path; AE stays on its original local window.
    wire S_mcu_bus_clk,S_mcu_bus_rst_n;
    wire [7:0] S_audio_addr;
    wire S_audio_sel,S_audio_enable,S_audio_write,S_audio_ready,S_audio_error;
    wire [31:0] S_audio_wdata,S_audio_rdata;
    wire S_mem_req,S_mem_write,S_mem_done,S_mem_error;
    wire [15:0] S_mem_addr;
    wire [2:0] S_mem_size;
    wire [31:0] S_mem_wdata,S_mem_rdata;
    wire S_audio_valid;wire [23:0] S_audio_sample;
    wire S_audio_ddr_req,S_audio_ddr_write,S_audio_ddr_done,S_audio_ddr_error;
    wire [24:0] S_audio_ddr_addr;wire [127:0] S_audio_ddr_wdata,S_audio_ddr_rdata;
    wire [15:0] S_video_time_ms;
    wire [15:0] S_video_pixel_time_ms;
    wire [15:0] S_latency_bcd;
    wire [1:0] S_latency_status;
    audio_subsystem u_audio (
      .I_bus_clk(S_mcu_bus_clk),.I_bus_rst_n(S_mcu_bus_rst_n),
      .I_paddr(S_audio_addr),.I_psel(S_audio_sel),.I_penable(S_audio_enable),.I_pwrite(S_audio_write),
      .I_pwdata(S_audio_wdata),.O_prdata(S_audio_rdata),.O_pready(S_audio_ready),.O_pslverr(S_audio_error),
      .I_mem_req(S_mem_req),.I_mem_write(S_mem_write),.I_mem_addr(S_mem_addr),.I_mem_size(S_mem_size),
      .I_mem_wdata(S_mem_wdata),.O_mem_done(S_mem_done),.O_mem_error(S_mem_error),.O_mem_rdata(S_mem_rdata),
      .I_ddr_clk(S_ddr_clk),.I_ddr_rst_n(S_rst_n),.I_calibrated(S_init_calib_complete),.I_pixel_clk(S_hdmi_pixel_clk),.I_pixel_rst_n(S_rst_n),
      .O_ddr_req(S_audio_ddr_req),.O_ddr_write(S_audio_ddr_write),.O_ddr_addr(S_audio_ddr_addr),
      .O_ddr_wdata(S_audio_ddr_wdata),.I_ddr_done(S_audio_ddr_done),.I_ddr_error(S_audio_ddr_error),
      .I_ddr_rdata(S_audio_ddr_rdata),.O_audio_valid(S_audio_valid),.O_audio_data(S_audio_sample),.O_time_ms(S_video_time_ms),
      .O_pixel_time_ms(S_video_pixel_time_ms),
      .O_sd_cs_n(O_sd_cs_n),.O_sd_clk(O_sd_clk),.O_sd_mosi(O_sd_mosi),.I_sd_miso(I_sd_miso));
    wire[9:0] S_mcu_addr,S_csi_paddr;
    wire S_mcu_sel,S_mcu_enable,S_mcu_write,S_mcu_ready,S_mcu_error;
    wire S_csi_psel,S_csi_penable,S_csi_pwrite;
    wire[31:0] S_mcu_wdata,S_mcu_rdata,S_csi_pwdata,S_csi_prdata;
    wire[31:0] S_cnn_prdata,S_awb_prdata;
    wire S_cnn_pready,S_cnn_pslverr,S_awb_pready,S_awb_pslverr;
    wire S_cnn_psel=S_csi_psel&&(S_csi_paddr[9:8]==2'd1);
    wire S_awb_psel=S_csi_psel&&S_csi_paddr[9];
    wire S_ext_video=(S_mcu_addr[9:8]!=0)||(S_mcu_addr[9:6]==4'd1);
    wire S_ui_selected=(S_mcu_addr[9:7]==3'b001);
    wire [31:0] S_ui_prdata;
    wire S_ui_pready,S_ui_pslverr;
    wire S_hist_selected=(S_mcu_addr[9:6]==4'd1);
    wire S_motion_selected=(S_mcu_addr[9:6]==4'd6);
    wire S_motion_psel=S_hist_psel&&(S_hist_paddr[9:6]==4'd6);
    wire [31:0] S_motion_prdata,S_hist_only_prdata;
    wire S_motion_pready,S_motion_pslverr,S_hist_only_pready,S_hist_only_pslverr;
    wire S_hdmi_peripheral_selected=S_motion_selected;
    wire [31:0] S_hist_bus_data;
    wire S_hist_bus_ready,S_hist_bus_error;
    wire [9:0] S_hist_paddr;
    wire S_hist_psel,S_hist_penable,S_hist_pwrite;
    wire [31:0] S_hist_pwdata,S_hist_prdata;
    wire S_hist_pready,S_hist_pslverr;
    mcu_apb_cdc u_mcu_histogram_bus(
        .I_bus_clk(S_mcu_bus_clk),.I_dst_clk(S_hdmi_pixel_clk),.I_rst_n(S_mcu_bus_rst_n),
        .I_paddr(S_mcu_addr),.I_psel(S_mcu_sel&&S_hdmi_peripheral_selected),.I_penable(S_mcu_enable),
        .I_pwrite(S_mcu_write),.I_pwdata(S_mcu_wdata),.O_prdata(S_hist_bus_data),
        .O_pready(S_hist_bus_ready),.O_pslverr(S_hist_bus_error),
        .O_paddr(S_hist_paddr),.O_psel(S_hist_psel),.O_penable(S_hist_penable),
        .O_pwrite(S_hist_pwrite),.O_pwdata(S_hist_pwdata),.I_prdata(S_hist_prdata),
        .I_pready(S_hist_pready),.I_pslverr(S_hist_pslverr));
    wire S_link_ready,S_link_error;
    wire[31:0] S_link_data;
    assign S_mcu_rdata=S_ui_selected?S_ui_prdata:(S_hdmi_peripheral_selected?S_hist_bus_data:(S_ext_video?S_link_data:32'd0));
    assign S_mcu_ready=S_ui_selected?S_ui_pready:(S_hdmi_peripheral_selected?S_hist_bus_ready:(S_ext_video?S_link_ready:1'b1));
    assign S_mcu_error=S_ui_selected?S_ui_pslverr:(S_hdmi_peripheral_selected?S_hist_bus_error:(S_ext_video?S_link_error:(S_mcu_sel&&S_mcu_enable)));
    wire S_latency_diag_selected=S_hist_paddr[5:0]>=6'h24;
    wire [31:0] S_latency_diag_prdata;
    wire S_latency_diag_pready,S_latency_diag_pslverr;
    assign S_hist_prdata=S_latency_diag_selected?S_latency_diag_prdata:S_motion_prdata;
    assign S_hist_pready=S_latency_diag_selected?S_latency_diag_pready:S_motion_pready;
    assign S_hist_pslverr=S_latency_diag_selected?S_latency_diag_pslverr:S_motion_pslverr;
    wire S_csi_hist_selected=(S_csi_paddr[9:6]==4'd1);
    wire S_csi_hist_psel=S_csi_psel&&S_csi_hist_selected;
    wire S_hist_bar_write,S_hist_table_bank,S_hist_table_valid,S_hist_table_equalized;
    wire [8:0] S_hist_bar_address;
    wire [13:0] S_hist_bar_data;
    wire S_hist_panel_bank,S_hist_panel_valid;
    // Capture each peripheral's readback locally before the shared return
    // mux. The bridge retires one clock after the actual APB transfer.
    // Address/readback decode no longer spans the entire CSI peripheral area.
    reg [31:0] S_hist_read_q,S_cnn_read_q,S_awb_read_q;
    reg S_hist_error_q,S_cnn_error_q,S_awb_error_q;
    always @(posedge S_csi_rx_clk)begin
        S_hist_read_q<=S_hist_only_prdata;S_hist_error_q<=S_hist_only_pslverr;
        S_cnn_read_q<=S_cnn_prdata;S_cnn_error_q<=S_cnn_pslverr;
        S_awb_read_q<=S_awb_prdata;S_awb_error_q<=S_awb_pslverr;
    end
    // Select by the held address, including the retirement cycle with PSEL=0.
    assign S_csi_prdata=S_csi_hist_selected?S_hist_read_q:((S_csi_paddr[9:8]==2'd1)?S_cnn_read_q:S_awb_read_q);
    wire S_csi_pready=S_csi_hist_selected?S_hist_only_pready:(S_cnn_psel?S_cnn_pready:S_awb_pready);
    wire S_csi_pslverr=S_csi_hist_selected?S_hist_error_q:((S_csi_paddr[9:8]==2'd1)?S_cnn_error_q:S_awb_error_q);
    mcu_apb_cdc #(.REGISTER_RESPONSE(1)) u_mcu_csi_bus(
        .I_bus_clk(S_mcu_bus_clk),.I_dst_clk(S_csi_rx_clk),.I_rst_n(S_mcu_bus_rst_n),
        .I_paddr(S_mcu_addr),.I_psel(S_mcu_sel&&S_ext_video&&!S_motion_selected),.I_penable(S_mcu_enable),
        .I_pwrite(S_mcu_write),.I_pwdata(S_mcu_wdata),.O_prdata(S_link_data),
        .O_pready(S_link_ready),.O_pslverr(S_link_error),
        .O_paddr(S_csi_paddr),.O_psel(S_csi_psel),.O_penable(S_csi_penable),
        .O_pwrite(S_csi_pwrite),.O_pwdata(S_csi_pwdata),.I_prdata(S_csi_prdata),
        .I_pready(S_csi_pready),.I_pslverr(S_csi_pslverr));

	reg  [17:0] 	S_cam_power_cnt;
	reg         	S_cam_pwdnb;
	reg         	S_cam_i2c_ready;
	(* keep = "true" *) wire [15:0] S_cam_sensor_id;
	(* keep = "true" *) wire        S_cam_sensor_id_ok;
	(* keep = "true" *) wire        S_cam_i2c_error;
    wire S_cam_i2c_retry_seen;
	localparam integer CAM_PWDNB_LOW_CYCLES = 23810;  // >= 1 ms at 23.809524 MHz
	localparam integer CAM_I2C_START_CYCLES = 142859; // release + >= 5 ms
	
	wire [15:0] 	S_ae;
    wire [15:0] 	S_ag;
    wire 			S_cam_cfg_done;
    wire 			S_ae_cfg_done;
    wire 			S_ae_req; 
	
    wire        	S_hs_rx_valid;  
    wire[15:0]  	S_hs_rx_data;   
	wire[1:0]   	S_lane_error;
	
	wire        	S_csi_frame_start;       
	wire        	S_csi_frame_end;         
	wire        	S_csi_valid;             
	wire[31:0]  	S_csi_data;  
		
	wire        	S_raw10_frame_start; 
	wire        	S_raw10_frame_end;   
	wire        	S_raw10_valid;       
	wire [39:0] 	S_raw10_data;
		
	wire 			S_axis_tlast;  
	wire 			S_axis_tuser;  
	wire [39:0]		S_axis_tdata;  
	wire 			S_axis_tvalid; 
	
	wire [39:0]		S_raw_tdata ;
	wire			S_raw_tlast ;
	wire 			S_raw_tvalid;
	wire 			S_raw_tuser ;
	
	wire			S_ISP_O_tready;
	wire [127:0]	S_ISP_O_tdata ;
	wire 			S_ISP_O_tlast ;
	wire 			S_ISP_O_tuser ;
	wire 			S_ISP_O_tvalid; 

    // ---------------------------------------------------------------------
    // v1.7 CNN 目标检测子系统（被动监听 ISP 输出，不干预视频通路）
    // 状态线用 keep 保住，否则整块会被综合剪掉（真正消费它的是下一步的 OSD 叠加）
    // ---------------------------------------------------------------------
    wire        S_isp_mon_valid;
    wire        S_isp_mon_tuser;
    wire [95:0] S_isp_mon_pix;
    (* keep = "true" *) wire [2:0]  S_cnn_state;
    (* keep = "true" *) wire        S_cnn_box_valid;
    (* keep = "true" *) wire [15:0] S_cnn_frame_cnt;
    (* keep = "true" *) wire [14:0] S_cnn_wr_cnt;
    (* keep = "true" *) wire        S_cnn_err;
    (* keep = "true" *) wire [3:0]  S_cnn_nbox;
    (* keep = "true" *) wire [63:0] S_cnn_box0;
    wire [383:0] S_cnn_box_all;   // 8 框 x 48 位（cnn_post 5b 打包）
    wire         S_cnn_pub;       // S_PUB 那一拍的发布脉冲
	

    wire        S_hdmi_serial_clk;
    wire        S_hdmi_rst_n;
    wire        S_video_out_rst_n;


    wire        S_vi_128b_frame_start;
    wire        S_vi_128b_valid;      
    wire[127:0] S_vi_128b_data;    
    
    wire        S_video_out_rd_busy;
    wire        S_video_in_wr_busy; 
    wire[1:0]   S_video_out_rp;     

    wire        S_ddr_user_wr_en;       
    wire        S_ddr_user_rd_en;       
    wire[24:0]  S_ddr_user_addr;        
    wire[127:0] S_ddr_user_wr_data;     
    wire        S_ddr_user_ready;       
    wire        S_ddr_user_rd_valid;    
    wire[127:0] S_ddr_user_rd_data;     

    wire        S_vi_ddr_wr_en;   
    wire[24:0]  S_vi_ddr_wr_addr; 
    wire[127:0] S_vi_ddr_wr_data;
    wire        S_vi_ddr_wr_ready;

    wire        S_vo_ddr_rd_en;   
    wire[24:0]  S_vo_ddr_rd_addr; 
    wire        S_vo_ddr_rd_ready;
    wire        S_vo_dbg_fifo_rst;
    wire        S_vo_dbg_ddr_rd_valid;
    wire        S_vo_dbg_fifo_rd_en;
    wire        S_vo_dbg_fifo_empty;

    wire[24:0]  S_mc_app_addr;          
    wire[2:0]   S_mc_app_cmd;           
    wire        S_mc_app_en;            
    wire[127:0] S_mc_app_wdf_data;      
    wire        S_mc_app_wdf_end;       
    wire[15:0]  S_mc_app_wdf_mask;      
    wire        S_mc_app_wdf_wren;      
    wire[127:0] S_mc_app_rd_data;       
    wire        S_mc_app_rd_data_end;   
    wire        S_mc_app_rd_data_valid; 
    wire        S_mc_app_rdy;           
    wire        S_mc_app_wdf_rdy;       
    wire        S_mc_dbg_fifo_afull;
    wire        S_mc_dbg_app_rdy;
    wire        S_mc_dbg_wdf_rdy;
    wire        S_mc_dbg_cmd_pop;

    wire        S_hdmi_vsync;
    wire        S_hdmi_hsync;
    wire        S_hdmi_de;
    wire        S_hdmi_user;
    wire        S_hdmi_last;
    wire        S_video_out_vsync;
    wire        S_hdmi_window_rd_en;
    wire        S_hdmi_out_vsync;
    wire        S_hdmi_out_hsync;
    wire        S_hdmi_out_de;
    wire[23:0]  S_hdmi_out_data;

    wire[23:0]  S_video_rd_data;
    reg         S_dbg_raw_seen;
    reg         S_dbg_isp_seen;
    reg         S_dbg_ddr_wr_seen;
    reg         S_dbg_ddr_rd_seen;
    reg         S_dbg_cam_cfg_seen;
    reg         S_dbg_hs_seen;
    reg         S_dbg_csi_seen;
    reg         S_dbg_raw10_seen;
    reg         S_dbg_isp_fs_seen;
    reg         S_dbg_isp_valid_seen;
    reg         S_dbg_ddr_req_seen;
    reg         S_dbg_ddr_ready_seen;
    reg [1:0]   S_dbg_raw_seen_sync;
    reg [1:0]   S_dbg_isp_seen_sync;
    reg [1:0]   S_dbg_ddr_wr_seen_sync;
    reg [1:0]   S_dbg_ddr_rd_seen_sync;
    reg [1:0]   S_dbg_cam_cfg_seen_sync;
    reg [1:0]   S_dbg_hs_seen_sync;
    reg [1:0]   S_dbg_csi_seen_sync;
    reg [1:0]   S_dbg_raw10_seen_sync;
    reg [1:0]   S_dbg_isp_fs_seen_sync;
    reg [1:0]   S_dbg_isp_valid_seen_sync;
    reg [1:0]   S_dbg_ddr_req_seen_sync;
    reg [1:0]   S_dbg_ddr_ready_seen_sync;
    reg         S_dbg_video_nonzero_seen;
    reg         S_dbg_rd_req_seen;
    reg         S_dbg_rd_valid_seen;
    reg         S_dbg_rd_nonzero_seen;
    reg [1:0]   S_dbg_rd_req_seen_sync;
    reg [1:0]   S_dbg_rd_valid_seen_sync;
    reg [1:0]   S_dbg_rd_nonzero_seen_sync;
    reg         S_dbg_mc_init_seen;
    reg         S_dbg_mc_app_rdy_seen;
    reg         S_dbg_mc_wdf_rdy_seen;
    reg         S_dbg_mc_cmd_pop_seen;
    reg [1:0]   S_dbg_mc_init_seen_sync;
    reg [1:0]   S_dbg_mc_app_rdy_seen_sync;
    reg [1:0]   S_dbg_mc_wdf_rdy_seen_sync;
    reg [1:0]   S_dbg_mc_cmd_pop_seen_sync;
    wire[3:0]   S_hdmi_debug_status;
    wire        S_lane_error_any;


    assign O_screen_pwm = 1'b1;
    assign S_video_out_vsync = ~S_hdmi_vsync;
	
	
    wire S_reset_request,S_system_reset;
    // The always-on reference clock sequences the main PLL reset. Reuse the
    // original lock-driven power-on reset tree instead of adding a clocked
    // 50 MHz reset source to every unrelated consumer domain. The sequencer
    // must not wait for the PLL that it is holding in reset.
    proc_sys_reset #(
        .EXTERNAL_RESET_PULSE_WIDTH(1),.AUXILIARY_RESET_PULSE_WIDTH(1)
    ) u_system_reset (
        .clk(I_sys_clk),.external_reset(S_reset_request),.aux_rst(1'b0),
        .system_rst(1'b0),.pll_locked(1'b1),.soc_reset(S_system_reset),
        .bus_reset(),.peripheral_reset(),.interconnect_aresetn(),.peripheral_aresetn());
    assign S_rst_n = S_pll_lock;
    assign S_hdmi_rst_n = S_rst_n;

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_raw_seen <= 1'b0;
        else if(S_raw10_frame_start | S_axis_tvalid)
            S_dbg_raw_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_seen <= 1'b0;
        else if(S_ISP_O_tuser | S_ISP_O_tvalid)
            S_dbg_isp_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_wr_seen <= 1'b0;
        else if(S_vi_ddr_wr_en)
            S_dbg_ddr_wr_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_rd_seen <= 1'b0;
        else if(S_ddr_user_rd_valid)
            S_dbg_ddr_rd_seen <= 1'b1;
    end

    always @(posedge S_24m_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_cam_cfg_seen <= 1'b0;
        else if(S_cam_cfg_done)
            S_dbg_cam_cfg_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_hs_seen <= 1'b0;
        else if(S_hs_rx_valid)
            S_dbg_hs_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_csi_seen <= 1'b0;
        else if(S_csi_frame_start | S_csi_valid)
            S_dbg_csi_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_raw10_seen <= 1'b0;
        else if(S_raw10_frame_start | S_raw10_valid)
            S_dbg_raw10_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_fs_seen <= 1'b0;
        else if(S_ISP_O_tuser)
            S_dbg_isp_fs_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_valid_seen <= 1'b0;
        else if(S_ISP_O_tvalid)
            S_dbg_isp_valid_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_req_seen <= 1'b0;
        else if(S_vi_ddr_wr_en)
            S_dbg_ddr_req_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_ready_seen <= 1'b0;
        else if(S_ddr_user_ready)
            S_dbg_ddr_ready_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_req_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_req_seen <= 1'b0;
        else if(S_vo_ddr_rd_en)
            S_dbg_rd_req_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_valid_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_valid_seen <= 1'b0;
        else if(S_ddr_user_rd_valid)
            S_dbg_rd_valid_seen <= 1'b1;
    end

    always @(posedge S_hdmi_pixel_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_nonzero_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_nonzero_seen <= 1'b0;
        else if(S_hdmi_window_rd_en && (S_video_rd_data != 24'd0))
            S_dbg_rd_nonzero_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_init_seen <= 1'b0;
        else if(S_init_calib_complete)
            S_dbg_mc_init_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_app_rdy_seen <= 1'b0;
        else if(S_mc_dbg_app_rdy)
            S_dbg_mc_app_rdy_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_wdf_rdy_seen <= 1'b0;
        else if(S_mc_dbg_wdf_rdy)
            S_dbg_mc_wdf_rdy_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_cmd_pop_seen <= 1'b0;
        else if(S_mc_dbg_cmd_pop)
            S_dbg_mc_cmd_pop_seen <= 1'b1;
    end

    always @(posedge S_hdmi_pixel_clk or negedge S_hdmi_rst_n) begin
        if(!S_hdmi_rst_n) begin
            S_dbg_cam_cfg_seen_sync <= 2'b00;
            S_dbg_hs_seen_sync      <= 2'b00;
            S_dbg_csi_seen_sync     <= 2'b00;
            S_dbg_raw10_seen_sync   <= 2'b00;
            S_dbg_raw_seen_sync    <= 2'b00;
            S_dbg_isp_seen_sync    <= 2'b00;
            S_dbg_ddr_wr_seen_sync <= 2'b00;
            S_dbg_ddr_rd_seen_sync <= 2'b00;
            S_dbg_isp_fs_seen_sync  <= 2'b00;
            S_dbg_isp_valid_seen_sync <= 2'b00;
            S_dbg_ddr_req_seen_sync <= 2'b00;
            S_dbg_ddr_ready_seen_sync <= 2'b00;
            S_dbg_video_nonzero_seen <= 1'b0;
            S_dbg_rd_req_seen_sync <= 2'b00;
            S_dbg_rd_valid_seen_sync <= 2'b00;
            S_dbg_rd_nonzero_seen_sync <= 2'b00;
            S_dbg_mc_init_seen_sync <= 2'b00;
            S_dbg_mc_app_rdy_seen_sync <= 2'b00;
            S_dbg_mc_wdf_rdy_seen_sync <= 2'b00;
            S_dbg_mc_cmd_pop_seen_sync <= 2'b00;
        end
        else begin
            S_dbg_cam_cfg_seen_sync <= {S_dbg_cam_cfg_seen_sync[0], S_dbg_cam_cfg_seen};
            S_dbg_hs_seen_sync      <= {S_dbg_hs_seen_sync[0],      S_dbg_hs_seen};
            S_dbg_csi_seen_sync     <= {S_dbg_csi_seen_sync[0],     S_dbg_csi_seen};
            S_dbg_raw10_seen_sync   <= {S_dbg_raw10_seen_sync[0],   S_dbg_raw10_seen};
            S_dbg_raw_seen_sync    <= {S_dbg_raw_seen_sync[0],    S_dbg_raw_seen};
            S_dbg_isp_seen_sync    <= {S_dbg_isp_seen_sync[0],    S_dbg_isp_seen};
            S_dbg_ddr_wr_seen_sync <= {S_dbg_ddr_wr_seen_sync[0], S_dbg_ddr_wr_seen};
            S_dbg_ddr_rd_seen_sync <= {S_dbg_ddr_rd_seen_sync[0], S_dbg_ddr_rd_seen};
            S_dbg_isp_fs_seen_sync  <= {S_dbg_isp_fs_seen_sync[0],  S_dbg_isp_fs_seen};
            S_dbg_isp_valid_seen_sync <= {S_dbg_isp_valid_seen_sync[0], S_dbg_isp_valid_seen};
            S_dbg_ddr_req_seen_sync <= {S_dbg_ddr_req_seen_sync[0], S_dbg_ddr_req_seen};
            S_dbg_ddr_ready_seen_sync <= {S_dbg_ddr_ready_seen_sync[0], S_dbg_ddr_ready_seen};
            S_dbg_rd_req_seen_sync <= {S_dbg_rd_req_seen_sync[0], S_dbg_rd_req_seen};
            S_dbg_rd_valid_seen_sync <= {S_dbg_rd_valid_seen_sync[0], S_dbg_rd_valid_seen};
            S_dbg_rd_nonzero_seen_sync <= {S_dbg_rd_nonzero_seen_sync[0], S_dbg_rd_nonzero_seen};
            S_dbg_mc_init_seen_sync <= {S_dbg_mc_init_seen_sync[0], S_dbg_mc_init_seen};
            S_dbg_mc_app_rdy_seen_sync <= {S_dbg_mc_app_rdy_seen_sync[0], S_dbg_mc_app_rdy_seen};
            S_dbg_mc_wdf_rdy_seen_sync <= {S_dbg_mc_wdf_rdy_seen_sync[0], S_dbg_mc_wdf_rdy_seen};
            S_dbg_mc_cmd_pop_seen_sync <= {S_dbg_mc_cmd_pop_seen_sync[0], S_dbg_mc_cmd_pop_seen};
            if(S_hdmi_window_rd_en && (S_video_rd_data != 24'd0))
                S_dbg_video_nonzero_seen <= 1'b1;
        end
    end

    assign S_lane_error_any = |S_lane_error;

    assign S_vo_dbg_fifo_rst = 1'b0;
    assign S_vo_dbg_ddr_rd_valid = 1'b0;
    assign S_vo_dbg_fifo_rd_en = 1'b0;
    assign S_vo_dbg_fifo_empty = 1'b0;
    assign S_mc_dbg_fifo_afull = 1'b0;
    assign S_mc_dbg_app_rdy = 1'b0;
    assign S_mc_dbg_wdf_rdy = 1'b0;
    assign S_mc_dbg_cmd_pop = 1'b0;

    assign S_hdmi_debug_status = {
        (|S_ddr_user_rd_data),
        S_ddr_user_rd_valid,
        S_vo_ddr_rd_en,
        S_vi_ddr_wr_en
    };
	
	// SC520CS上电后先保持PWDNB/XSHUTDN为低，再释放并等待内部上电完成，
	// 避免PLL刚锁定就开始I2C初始化而造成寄存器偶发写入失败。
	always @(posedge S_24m_clk or negedge S_rst_n) begin
		if (!S_rst_n) begin
			S_cam_power_cnt <= 18'd0;
			S_cam_pwdnb <= 1'b0;
			S_cam_i2c_ready <= 1'b0;
		end else begin
			if (S_cam_power_cnt < CAM_I2C_START_CYCLES)
				S_cam_power_cnt <= S_cam_power_cnt + 1'b1;
			if (S_cam_power_cnt >= CAM_PWDNB_LOW_CYCLES)
				S_cam_pwdnb <= 1'b1;
			if (S_cam_power_cnt >= CAM_I2C_START_CYCLES - 1)
				S_cam_i2c_ready <= 1'b1;
		end
	end

	assign O_cam_rst 	= S_cam_pwdnb;
    // Forward the control clock through the dedicated output DDR cell.
    // Constants on D0/D1 keep every fabric clock sink on clock pins only.
    PH1P_LOGIC_HD_ODDR u_camera_clock_forward (
        .clk(S_24m_clk), .rst(!S_rst_n),
        .d0(1'b1), .d1(1'b0), .q(O_cam_24m)
    );
	
	
	
	
    PLL u_PLL(
        .refclk      ( I_sys_clk         ),
        // Official sequencer runs on I_sys_clk, independent of PLL outputs.
        // PLL lock then restarts the existing complete power-on reset tree.
        .reset       ( S_system_reset    ),
        
        .clk0_out    ( S_100m_clk        ),
        .clk1_out    ( S_24m_clk         ),

        .clk4_out    ( S_hdmi_pixel_clk  ),
        .clk5_out    ( S_hdmi_serial_clk ),

        .lock        ( S_pll_lock        )

    );


	

  /////////////////////////////////////////////////////////////////////////////

    // v1.8 MCU menu replaces switch-context key interpreters. Board switches
    // remain active-low: SW1 menu, SW2 hide overlays, SW3 original compare.
    reg [3:0] S_switch_meta,S_switch_sync;
    always @(posedge S_24m_clk or negedge S_rst_n)
        if(!S_rst_n) begin S_switch_meta<=0;S_switch_sync<=0;end
        else begin S_switch_meta<=~I_switch;S_switch_sync<=S_switch_meta;end
    wire S_orig_view=S_switch_sync[2];
    // MCU debounces SW2 independently of keys and configuration previews.
    // All display consumers receive one stable level in vertical blank.
    wire S_hide_request;
    wire S_hide_osd;
    wire [127:0] S_ui_config,S_ui_control,S_ui_pixel_config;
    localparam [127:0] UI_DEFAULT={32'h050087c7,32'h8010a0ff,32'h00820082,32'h00000000};
    effect_config_cdc #(.WIDTH(128),.DEFAULT_CONFIG(UI_DEFAULT)) u_ui_control_cdc (
        .I_src_clk(S_mcu_bus_clk),.I_dst_clk(S_24m_clk),.I_rst_n(S_rst_n),
        .I_src_config(S_ui_config),.I_dst_frame(1'b1),
        .O_dst_active(S_ui_control),.O_dst_for_beat());
    effect_config_cdc #(.WIDTH(128),.DEFAULT_CONFIG(UI_DEFAULT)) u_ui_pixel_cdc (
        .I_src_clk(S_mcu_bus_clk),.I_dst_clk(S_hdmi_pixel_clk),.I_rst_n(S_rst_n),
        .I_src_config(S_ui_config),.I_dst_frame(S_hdmi_user),
        .O_dst_active(S_ui_pixel_config),.O_dst_for_beat());
    wire S_ae_auto=S_ui_control[0],S_wb_auto=S_ui_control[1];
    wire S_ae_center=S_ui_control[2],S_view_mir=S_ui_control[3],S_view_flp=S_ui_control[4];
    wire S_hist_equalize=S_ui_control[6],S_saturation_24m=S_ui_control[7];
    wire S_cnn_en_24m=S_ui_control[8]|S_ui_control[13];
    wire [2:0] S_mode_request_24m=S_ui_control[12:10];
    wire [47:0] S_effect_limits={S_ui_control[79:64],S_ui_control[63:32]};
    wire [23:0] S_paint_color=(S_ui_control[81:80]==0)?24'h00ff00:
        ((S_ui_control[81:80]==1)?24'h0000ff:((S_ui_control[81:80]==2)?24'hffff00:24'hffffff));
    localparam [47:0] EFFECT_LIMITS=48'hA0FF00820082;
    localparam [23:0] EFFECT_PAINT=24'h00ff00;
    wire [3:0] S_ae_ag_button=4'hf;
    reg S_manual_toggle_d;
    always @(posedge S_24m_clk or negedge S_rst_n)
        if(!S_rst_n)S_manual_toggle_d<=0;
        else S_manual_toggle_d<=S_ui_control[115];
    wire S_manual_set=S_ui_control[115]!=S_manual_toggle_d;
    reg [15:0] S_ae_hold,S_ag_hold;
    reg S_disp_toggle,S_disp_pending;
    wire [2:0] S_mode_active_csi;
    wire [3:0] S_segment_mask;
    wire S_segment_valid,S_segment_frame;
    wire [10:0] S_segment_x,S_segment_y;
    wire [1:0] S_wb_status_csi;
    wire [7:0] S_ae_mean,S_ae_clip_ratio,S_ae_near_ratio;
    reg [3:0] S_ae_frame_seq,S_ae_write_seq;
    wire [18:0] S_ui_ae_ag;
    ae_stats_cdc #(.WIDTH(19)) u_ui_ae_status_cdc (
        .I_src_clk(S_24m_clk),.I_dst_clk(S_mcu_bus_clk),.I_rst_n(S_rst_n),
        .I_valid(1'b1),.I_mean({S_ag[7:0],S_ae[10:0]}),.O_valid(),.O_mean(S_ui_ae_ag));
    wire [11:0] S_ui_x,S_ui_y;
    wire S_ui_de,S_ui_hit;
    wire [23:0] S_ui_color;
    wire [7:0] S_spot_status_pixel,S_spot_status_bus;
    // Reuse the existing bundled handshake for a coherent read-only report.
    effect_config_cdc #(.WIDTH(8),.DEFAULT_CONFIG(8'd0)) u_spot_status_cdc (
        .I_src_clk(S_hdmi_pixel_clk),.I_dst_clk(S_mcu_bus_clk),.I_rst_n(S_rst_n),
        .I_src_config(S_spot_status_pixel),.I_dst_frame(1'b1),
        .O_dst_active(S_spot_status_bus),.O_dst_for_beat());
    ui_osd u_ui_osd (
        .I_bus_clk(S_mcu_bus_clk),.I_bus_rst_n(S_mcu_bus_rst_n),
        .I_paddr(S_mcu_addr[6:0]),.I_psel(S_mcu_sel&&S_ui_selected),
        .I_penable(S_mcu_enable),.I_pwrite(S_mcu_write),.I_pwdata(S_mcu_wdata),
        .O_prdata(S_ui_prdata),.O_pready(S_ui_pready),.O_pslverr(S_ui_pslverr),
        .I_button(I_button),.I_switch(I_switch),.I_ae_ag(S_ui_ae_ag),.I_spot_status(S_spot_status_bus),.O_config(S_ui_config),
        .O_servo_pan(O_servo_pan),.O_servo_tilt(O_servo_tilt),
        .O_hide_request(S_hide_request),.O_hide_active(S_hide_osd),.O_reset_request(S_reset_request),
        .I_pixel_clk(S_hdmi_pixel_clk),.I_pixel_rst_n(S_hdmi_rst_n),.I_vsync(S_hdmi_vsync),
        .I_x(S_ui_x),.I_y(S_ui_y),.I_de(S_ui_de),.I_hide(S_hide_request),
        .O_hit(S_ui_hit),.O_color(S_ui_color));

//////////////////////////////////
  // AE observes native RAW10 without changing ISP latency or data. The
  // completed frame's mode travels in the existing held-data CDC mailbox.
  // Discard old-mode readings while the new mode waits for a frame boundary.
  wire S_ae_stats_valid_csi, S_ae_stats_valid_ctrl, S_ae_stats_valid;
  wire S_ae_center_csi, S_ae_stats_center;
  assign S_ae_stats_valid = S_ae_stats_valid_ctrl && (S_ae_stats_center == S_ae_center);
  wire [7:0] S_ae_mean_csi, S_ae_clip_csi, S_ae_near_csi;
  raw10_ae_stats u_ae_stats (
      .I_clk(S_csi_rx_clk), .I_rst_n(S_rst_n),
      .I_frame_start(S_raw10_frame_start),
      .I_valid(S_raw10_valid), .I_raw(S_raw10_data),
      .I_center(S_ae_center), .O_center(S_ae_center_csi),
      .O_valid(S_ae_stats_valid_csi), .O_mean(S_ae_mean_csi),
      .O_clip_ratio(S_ae_clip_csi), .O_near_ratio(S_ae_near_csi)
  );
  ae_stats_cdc #(.WIDTH(25)) u_ae_stats_cdc (
      .I_src_clk(S_csi_rx_clk), .I_dst_clk(S_24m_clk), .I_rst_n(S_rst_n),
      .I_valid(S_ae_stats_valid_csi), .I_mean({S_ae_center_csi,S_ae_near_csi,S_ae_clip_csi,S_ae_mean_csi}),
      .O_valid(S_ae_stats_valid_ctrl), .O_mean({S_ae_stats_center,S_ae_near_ratio,S_ae_clip_ratio,S_ae_mean})
  );
  generate if (AE_USE_MCU) begin : g_ae_fd
    sc520_ae_mcu_system #(.MCU_TASKS(63)) u_ae_mcu (
        .O_audio_addr(S_audio_addr),.O_audio_sel(S_audio_sel),.O_audio_enable(S_audio_enable),
          .O_audio_write(S_audio_write),.O_audio_wdata(S_audio_wdata),.I_audio_rdata(S_audio_rdata),
          .I_audio_ready(S_audio_ready),.I_audio_error(S_audio_error),
          .O_mem_req(S_mem_req),.O_mem_write(S_mem_write),.O_mem_addr(S_mem_addr),.O_mem_size(S_mem_size),
          .O_mem_wdata(S_mem_wdata),.I_mem_done(S_mem_done),.I_mem_error(S_mem_error),.I_mem_rdata(S_mem_rdata),
          .I_core_clk(S_100m_clk), .I_pll_lock(S_rst_n),
        .I_ctrl_clk(S_24m_clk), .I_ctrl_rst_n(S_rst_n),
        .I_manual(!S_ae_auto), .I_key_n(S_ae_ag_button),
        .I_manual_set(S_manual_set),.I_manual_exposure(S_ui_control[106:96]),.I_manual_gain(S_ui_control[114:107]),
        .I_cam_cfg_done(S_cam_cfg_done), .I_ae_cfg_done(S_ae_cfg_done),
        .I_iic_error(S_cam_i2c_error), .I_retry(S_cam_i2c_retry_seen),
        .I_stats_valid(S_ae_stats_valid), .I_mean(S_ae_mean),
        .I_clip(S_ae_clip_ratio), .I_near(S_ae_near_ratio),
        .O_ae_req(S_ae_req), .O_ae(S_ae), .O_ag(S_ag),
        .O_bus_clk(S_mcu_bus_clk),.O_bus_rst_n(S_mcu_bus_rst_n),
        .O_ext_addr(S_mcu_addr),.O_ext_sel(S_mcu_sel),.O_ext_enable(S_mcu_enable),
        .O_ext_write(S_mcu_write),.O_ext_wdata(S_mcu_wdata),
        .I_ext_rdata(S_mcu_rdata),.I_ext_ready(S_mcu_ready),.I_ext_error(S_mcu_error)
    );
  end else begin : g_ae_rtl
    assign S_mcu_bus_clk=S_100m_clk;
    assign S_mcu_bus_rst_n=S_rst_n;
    assign S_audio_addr=0;
    assign S_audio_sel=0;
    assign S_audio_enable=0;
    assign S_audio_write=0;
    assign S_audio_wdata=0;
    assign S_mem_req=0;
    assign S_mem_write=0;
    assign S_mem_addr=0;
    assign S_mem_size=0;
    assign S_mem_wdata=0;
    assign S_mcu_addr=0;
    assign S_mcu_sel=0;
    assign S_mcu_enable=0;
    assign S_mcu_write=0;
    assign S_mcu_wdata=0;
  sc520_ae_control u_ae_control (
      .I_clk(S_24m_clk), .I_rst_n(S_rst_n),
      .I_manual(!S_ae_auto), .I_key_n(S_ae_ag_button),
      .I_cam_cfg_done(S_cam_cfg_done), .I_ae_cfg_done(S_ae_cfg_done),
      .I_iic_error(S_cam_i2c_error),
      .I_stats_valid(S_ae_stats_valid), .I_mean(S_ae_mean),
      .O_ae_req(S_ae_req), .O_ae(S_ae), .O_ag(S_ag),
      .I_clip_ratio(S_ae_clip_ratio), .I_near_ratio(S_ae_near_ratio)
  );
  end endgenerate
  
    // SC520CS原厂真实HD模式：1280x720@60、RAW10、2-Lane、828 Mbps/Lane。
    // 当前寄存器表已关闭Slave/FSIN等待，Sensor以free-run方式连续输出。
    uicfgcs520 #(
      .CLK_DIV(23809524 / 100000 - 1)
  ) u_uicfgcs520 (
      .I_clk(S_24m_clk),  //系统时钟输入
      .I_rst_n(S_cam_i2c_ready), // SC520CS power-up delay completed
      .I_ae_req(S_ae_req),
      .I_ae(S_ae),
      .I_ag(S_ag),
      .O_cam_scl(O_cam_scl),  //I2C总线，SCL时钟
      .IO_cam_sda(IO_cam_sda),  //I2C总线，SDA数据
      .O_cfg_done(S_cam_cfg_done),  //摄像头寄存器初始化完成
      .O_ae_cfg_done(S_ae_cfg_done),  //AE配置完成
      .O_sensor_id(S_cam_sensor_id),
      .O_sensor_id_ok(S_cam_sensor_id_ok),
        .O_iic_error(S_cam_i2c_error),
        .O_iic_retry_seen(S_cam_i2c_retry_seen)
    );

    // Small modulo-16 activity counters distinguish metering and write faults.
    always @(posedge S_24m_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin S_ae_frame_seq <= 4'd0;S_ae_write_seq <= 4'd0;end
        else begin
            if (S_ae_stats_valid) S_ae_frame_seq <= S_ae_frame_seq + 1'b1;
            if (S_ae_req) S_ae_write_seq <= S_ae_write_seq + 1'b1;
        end
    end

    // Exposure / gain readout handshake (24 MHz -> HDMI pixel domain).
    // AE/AG values change at most once per completed I2C sequence; they are
    // registered here first and the toggle flips one 24 MHz clock later, so
    // the display side can capture the bus with a two stage synchroniser.
    always @(posedge S_24m_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin
            S_ae_hold      <= 16'd0;
            S_ag_hold      <= 16'd0;
            S_disp_toggle  <= 1'b0;
            S_disp_pending <= 1'b0;
        end
        else begin
            if ((S_ae != S_ae_hold) || (S_ag != S_ag_hold)) begin
                S_ae_hold      <= S_ae;
                S_ag_hold      <= S_ag;
                S_disp_pending <= 1'b1;
            end
            else if (S_disp_pending) begin
                S_disp_pending <= 1'b0;
                S_disp_toggle  <= ~S_disp_toggle;
            end
        end
    end

    mipi_dphy_rx_ph1p_mipiio_wrapper#(
        .DPHY_RX_LOCATION      ( "DPHY0" ),
        .HS_EQUALIZER          ( "3dB"   ),// 828 Mbps/Lane接收均衡
        .HS_VGA_GAIN           ( "8dB" ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .LANE_NUM              ( 2       ),
        .BYTE_NUM              ( 1       )
    )u_mipi_dphy_rx_ph1p_mipiio_wrapper(
        .I_lp_clk              ( S_100m_clk       ),
        .I_rst                 ( ~S_rst_n         ),

        .I_clk_lane_in_delay   ( 6'd0             ),
        .I_data_lane0_in_delay ( 6'd0             ),
        .I_data_lane1_in_delay ( 6'd0             ),
        .I_data_lane2_in_delay ( 6'd0             ),
        .I_data_lane3_in_delay ( 6'd0             ),

        .I_lane_invert         ( 4'b0000          ),
     
        .O_hs_rx_clk           ( S_csi_rx_clk     ),
        .O_hs_rx_valid         ( S_hs_rx_valid    ),
        .O_hs_rx_data          ( S_hs_rx_data     ),
      
        .O_lp_rx_lane0_p       (  ),
        .O_lp_rx_lane0_n       (  ),
      
        .I_lp_tx_en            ( 1'b0             ),
        .I_lp_tx_lane0_p       ( 1'b1             ),
        .I_lp_tx_lane0_n       ( 1'b1             ),
      
        .O_lane_match_error    (                  ),
        .O_lane_error          ( S_lane_error     ),
      
        .IO_rx_clk_pad_n       ( IO_rx_clk_pad_n  ),
        .IO_rx_clk_pad_p       ( IO_rx_clk_pad_p  ),
        .IO_rx_data_pad_n      ( IO_rx_data_pad_n ),
        .IO_rx_data_pad_p      ( IO_rx_data_pad_p )
    );
	
	
 //  cwc cwc_inst
 //(
 //    .probe0(S_hs_rx_valid),
 //    .probe1(S_hs_rx_data),
 //    .probe2(S_lane_error),
 //    .clk(S_csi_rx_clk)
 //);

 //csi 解码为RAW数据
csi_unpacket_2lane u_csi_unpacket(
.I_clk                 ( S_csi_rx_clk       ),
.I_rst_n               ( S_rst_n        	),
.I_hs_valid            ( S_hs_rx_valid     ),
.I_hs_data             ( S_hs_rx_data      ),

.O_csi_frame_start     ( S_csi_frame_start ),
.O_csi_frame_end       ( S_csi_frame_end   ),
.O_csi_valid           ( S_csi_valid       ),
.O_csi_data            ( S_csi_data        )
);


//解码为RAW8
raw10_unpacket_2lane u_raw10_unpacket (
.I_clk  (S_csi_rx_clk),
.I_rst_n(S_rst_n),

.I_csi_frame_start(S_csi_frame_start),
.I_csi_frame_end  (S_csi_frame_end),
.I_csi_valid      (S_csi_valid),
.I_csi_data       (S_csi_data),

.O_raw10_frame_start(S_raw10_frame_start),
.O_raw10_frame_end  (S_raw10_frame_end),
.O_raw10_valid      (S_raw10_valid),
.O_raw10_data       (S_raw10_data)
  );


//将数据转为stream流
uial2axis #(
.IMG_WIDTH(1280),
.IMG_HEIGHT(720),
.INPUT_DATA_WIDTH(40)
) 
u_uial2axis (
.I_native_clk(S_csi_rx_clk),
.I_rst_n     (S_rst_n),
.I_data      (S_raw10_data       ),
.I_data_valid(S_raw10_valid      ),
.I_data_start(S_raw10_frame_start),
.I_data_end  (S_raw10_frame_end  ),
.axis_tvalid (S_axis_tvalid),
.axis_tdata  (S_axis_tdata ),
.axis_tuser  (S_axis_tuser ),
.axis_tlast  (S_axis_tlast )
);
	

// 原厂HD模式直接输出1280x720 RAW10，不再进行FPGA固定窗口裁剪。
assign S_raw_tdata  = S_axis_tdata;
assign S_raw_tlast  = S_axis_tlast;
assign S_raw_tvalid = S_axis_tvalid;
assign S_raw_tuser  = S_axis_tuser;


//cwc1 cwc1_Inst
//  (
//      .probe0(S_axis_tuser),
//      .probe1(S_axis_tvalid),
//      .probe2(S_axis_tlast),
//      .probe3(S_axis_tdata),
//      .probe4(S_ISP_O_tuser),
//      .probe5(S_ISP_O_tvalid),
//      .probe6(S_ISP_O_tlast),
//      .probe7(S_ISP_O_tdata),
//      .probe8 (S_raw_tdata ),
//      .probe9 (S_raw_tlast ),
//      .probe10(S_raw_tvalid),
//      .probe11(S_raw_tuser ),
//      .clk(S_csi_rx_clk)
//  );


//ISP算法顶层模块
wire S_isp_mon_mirror,S_isp_mon_tracking,S_cnn_result_tracking,S_cnn_spot_fresh;
wire [1:0] S_isp_mon_edge;
isp_top #(
.TRACKING_ENABLE(1),
    .AWB_USE_MCU(AE_USE_MCU),.RUNTIME_UI(1),.HISTOGRAM_PRE_EFFECTS(1),
    .DEFAULT_LIMITS(EFFECT_LIMITS), .DEFAULT_PAINT(EFFECT_PAINT)
) u_isp_top (
    .I_equalize(S_hist_equalize),.I_original(S_orig_view),
    .I_hist_paddr(S_csi_paddr),.I_hist_psel(S_csi_hist_psel),.I_hist_penable(S_csi_penable),
    .I_hist_pwrite(S_csi_pwrite),.I_hist_pwdata(S_csi_pwdata),
    .O_hist_prdata(S_hist_only_prdata),.O_hist_pready(S_hist_only_pready),.O_hist_pslverr(S_hist_only_pslverr),
    .O_hist_bar_write(S_hist_bar_write),.O_hist_bar_address(S_hist_bar_address),.O_hist_bar_data(S_hist_bar_data),
    .O_hist_table_bank(S_hist_table_bank),.O_hist_table_valid(S_hist_table_valid),.O_hist_table_equalized(S_hist_table_equalized),
    .I_hist_panel_bank(S_hist_panel_bank),.I_hist_panel_valid(S_hist_panel_valid),
    .I_mcu_paddr(S_csi_paddr[8:0]),.I_mcu_psel(S_awb_psel),.I_mcu_penable(S_csi_penable),
    .I_mcu_pwrite(S_csi_pwrite),.I_mcu_pwdata(S_csi_pwdata),
    .O_mcu_prdata(S_awb_prdata),.O_mcu_pready(S_awb_pready),.O_mcu_pslverr(S_awb_pslverr),
    .O_wb_status(S_wb_status_csi),
.I_control_clk   (S_24m_clk),
.I_saturation(S_saturation_24m),.I_tracking(S_ui_control[13]),.O_mon_tracking(S_isp_mon_tracking),
.I_wb_auto(S_wb_auto),.I_binary_threshold(S_ui_control[95:88]),.I_edge_threshold(S_ui_control[126:116]),
.I_mode_request  (S_orig_view ? 3'd0 : S_mode_request_24m),
.I_color_limits  (S_effect_limits),
.I_color_target(S_ui_control[83:82]),.I_color_sensitivity(S_ui_control[85:84]),
.I_custom_rgb(S_ui_control[86]),
.I_paint_color   (S_paint_color),
.I_mirror        (S_view_mir),
.O_mode_active   (S_mode_active_csi),
.O_segment_mask  (S_segment_mask),
.O_segment_valid (S_segment_valid),
.O_segment_frame (S_segment_frame),
.O_segment_x     (S_segment_x),
.O_segment_y     (S_segment_y),
.axi4s_video_aclk(S_csi_rx_clk),
.I_rst_n         (S_rst_n),
.I_tlast         (S_raw_tlast	),
.I_tuser         (S_raw_tuser	),
.I_tdata         (S_raw_tdata	),
.I_tvalid        (S_raw_tvalid	),
.I_tdest         (),
.O_tready        (1'b1),
.O_tdata         (S_ISP_O_tdata ),
.O_tlast         (S_ISP_O_tlast ),
.O_tuser         (S_ISP_O_tuser ),
.O_tvalid        (S_ISP_O_tvalid),
.O_mon_edge(S_isp_mon_edge),.O_mon_mirror(S_isp_mon_mirror),.O_mon_pix       ( S_isp_mon_pix   ),
.O_mon_valid     ( S_isp_mon_valid ),
.O_mon_tuser     ( S_isp_mon_tuser ),
.O_mon_tlast     (                 ),
.O_motion_pix(S_motion_pix),.O_motion_valid(S_motion_valid),
.O_motion_user(S_motion_user),.O_motion_last(S_motion_last),
.I_tready        (S_ISP_O_tready)
  );


    wire S_latency_write_start,S_latency_write_flip,S_latency_read_start,S_latency_underflow;
    wire [1:0] S_latency_write_slot,S_latency_read_slot;
    video_in u_video_in(
        .I_rst_n              (  S_rst_n             ),

        .O_latency_start(S_latency_write_start),.O_latency_slot(S_latency_write_slot),
        .O_latency_flip(S_latency_write_flip),
        .I_camera_clk         ( S_csi_rx_clk          ),
        .I_camera_frame_start ( S_ISP_O_tuser  ),
        .I_camera_valid       ( S_ISP_O_tvalid ),
        .I_camera_data        ( S_ISP_O_tdata  ),
        .I_mipi_rx_error      ( 1'b0			      ),
        .I_flip_y             ( S_view_flp            ),

        .I_ddr_clk            ( S_ddr_clk             ),
		.I_display_pause      ( 1'b0                  ),
        .I_video_out_rd_busy  ( S_video_out_rd_busy   ),
        .O_video_in_wr_busy   ( S_video_in_wr_busy    ),
        .O_video_out_rp       ( S_video_out_rp        ),

        .O_ddr_user_wr_en     ( S_vi_ddr_wr_en        ),
        .O_ddr_user_addr      ( S_vi_ddr_wr_addr      ),
        .O_ddr_user_wr_data   ( S_vi_ddr_wr_data      ),
        .I_ddr_user_ready     ( S_ddr_user_ready      )
    );

    // 单比特电平 -> csi 域 / hdmi 域（各两级同步；复位值给 1，与默认 ON 一致）
    reg [1:0] S_cnn_en_csi_sync;
    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if (!S_rst_n) S_cnn_en_csi_sync <= 2'b00;
        else          S_cnn_en_csi_sync <= {S_cnn_en_csi_sync[0], S_cnn_en_24m};
    end
    wire S_cnn_on = S_cnn_en_csi_sync[1];

    // Use the same atomic, frame-latched selection as the motion overlay.
    wire S_cnn_on_hdmi = S_ui_pixel_config[8]|S_ui_pixel_config[13];

    // ---------------------------------------------------------------------
    // v1.7 CNN 目标检测子系统（单时钟域 = S_csi_rx_clk = axi4s_video_aclk）
    //   被动监听：不驱动 tready、不干涉 DDR/HDMI 通路；结果留给 OSD 叠加消费。
    //   I_en 先常开（检测各隔帧跑一次）；后续可由 UI 开关控制。
    // ---------------------------------------------------------------------
    wire [159:0] S_cnn_display;
    // The display FIFO first resets at its initial frame boundary. Defer CNN
    // capture until then so boot-time video initialization cannot fill its FIFO.
    reg S_cnn_video_ready;
    always @(posedge S_ddr_clk or negedge S_rst_n)
        if(!S_rst_n)S_cnn_video_ready<=1'b0;
        else if(S_latency_read_start)S_cnn_video_ready<=1'b1;
    wire S_cnn_ddr_req,S_cnn_ddr_write,S_cnn_ddr_accept,S_cnn_ddr_valid;
    wire [24:0] S_cnn_ddr_addr;wire [127:0] S_cnn_ddr_wdata;
    cnn_subsystem #(.TRACKING_ENABLE(1),.DDR_INPUT(1),.POST_USE_MCU(AE_USE_MCU)) u_cnn_subsystem (
        .I_ddr_clk(S_ddr_clk),.I_ddr_calibrated(S_init_calib_complete&&S_cnn_video_ready),
        .O_ddr_req(S_cnn_ddr_req),.O_ddr_write(S_cnn_ddr_write),
        .O_ddr_addr(S_cnn_ddr_addr),.O_ddr_wdata(S_cnn_ddr_wdata),
        .I_ddr_accept(S_cnn_ddr_accept),.I_ddr_valid(S_cnn_ddr_valid),.I_ddr_rdata(S_mc_app_rd_data),
        .I_paddr(S_csi_paddr[7:0]),.I_psel(S_cnn_psel),.I_penable(S_csi_penable),
        .I_pwrite(S_csi_pwrite),.I_pwdata(S_csi_pwdata),.O_prdata(S_cnn_prdata),
        .O_pready(S_cnn_pready),.O_pslverr(S_cnn_pslverr),
        .I_clk          ( S_csi_rx_clk      ),
        .I_rst_n        ( S_rst_n           ),
        .I_en           ( S_cnn_on          ),
        .I_pix_valid    ( S_isp_mon_valid   ),
        .I_pix_tuser    ( S_isp_mon_tuser   ),
        .I_pix_data     ( S_isp_mon_pix     ),.I_edge_hits(S_isp_mon_edge),
        .O_result_tracking(S_cnn_result_tracking),.I_tracking(S_isp_mon_tracking),.I_pix_mirror(S_isp_mon_mirror),
        .O_state        ( S_cnn_state       ),
        .O_box_valid    ( S_cnn_box_valid   ),
        .O_frame_cnt    ( S_cnn_frame_cnt   ),
        .O_dbg_wr_cnt   ( S_cnn_wr_cnt      ),
        .O_dbg_err      ( S_cnn_err         ),
        .I_rd_idx       ( 3'd0              ),
        .O_rd_data      ( S_cnn_box0        ),
        .O_nbox         ( S_cnn_nbox        ),
        .I_dbg_addr     ( 15'd0             ),
        .O_dbg_data     (                  ),
        .O_box_all      ( S_cnn_box_all      ),
        .O_label_bcd    (                     ),
        .O_display      ( S_cnn_display      ),.O_spot_fresh(S_cnn_spot_fresh),
        .O_pub          ( S_cnn_pub          )
    );

    // v1.7：LED 用来指示检测状态（原来 LED[3:0] 没有任何驱动）
    //   LED[3] = 至少完成过一帧检测；LED[2:0] = 最近一帧检出的框数
    //   注意：这也让整条 CNN 通路真正"被消费"，否则综合会把内部逻辑全部剪掉
    //   （实测：只连到 (* keep *) 的悬空线上时，u_mem/u_post 被剪成只剩 10 LUT）。
    //   框坐标 O_rd_data 尚未被消费，留给下一步 OSD 叠加。

    // ---------------------------------------------------------------------
    // v1.7 P3-a：把 CNN 结果包搬到 HDMI 像素域（画框/上屏的前置步骤）
    //   包 = { frame_cnt[15:0], wr_cnt[14:0], err, nbox[3:0], 8x48 框 }  = 420 位
    //   只在 S_PUB 那一拍发布；cnn_post 的 res/O_nbox 在那拍是稳定的，
    //   整包因此同帧一致（不会出现"框是这帧、计数是上帧"的混搭）。
    //   csi 域与 HDMI 域已在同一组 set_clock_groups -asynchronous 内，
    //   所以不需要改 SDC，只需保证 cnn_result_cdc 的结构正确。
    // ---------------------------------------------------------------------
    // Only display winners cross into HDMI. Numerical top-8/debug/audio
    // results stay in the CSI/MCU domain. Same atomic req/ack CDC, 198 bits including capture policy and fresh class-0 evidence.
    wire [197:0] S_cnn_packet = {S_cnn_spot_fresh,S_cnn_result_tracking,S_cnn_frame_cnt,S_cnn_wr_cnt,S_cnn_err,S_cnn_nbox,S_cnn_display};
    wire [197:0] S_cnn_packet_hdmi;
    wire S_cnn_packet_hdmi_valid;
    cnn_result_cdc #(.WIDTH(198)) u_cnn_result_cdc (
        .I_src_clk(S_csi_rx_clk),.I_dst_clk(S_hdmi_pixel_clk),.I_rst_n(S_rst_n),
        .I_src_data(S_cnn_packet),.I_src_valid(S_cnn_pub),
        .O_dst_data(S_cnn_packet_hdmi),.O_dst_valid(S_cnn_packet_hdmi_valid));
    wire S_cnn_policy_matches=(S_cnn_packet_hdmi[196]==S_ui_pixel_config[13]);
    wire [3:0] S_cnn_nbox_hdmi=S_cnn_packet_hdmi[163:160];
    (* keep = "true" *) wire S_cnn_pkt_parity=^S_cnn_packet_hdmi;

    // v1.7 P6：LED 简化 —— 只用 LED3 表示"当前帧有目标"，LED1/2 空闲
    assign LED = { (S_cnn_on_hdmi & S_cnn_policy_matches & (S_cnn_nbox_hdmi != 4'd0)), 3'b000 };



    assign S_ddr_user_wr_en    = S_vi_ddr_wr_en;

    assign S_ddr_user_rd_en    = S_vo_ddr_rd_en;

    assign S_ddr_user_addr     = S_vi_ddr_wr_en ? S_vi_ddr_wr_addr :
                                 S_vo_ddr_rd_en ? S_vo_ddr_rd_addr : 'd0;

    assign S_ddr_user_wr_data  = S_vi_ddr_wr_data;


    assign S_video_out_rst_n = S_hdmi_rst_n;

    video_out u_video_out(
        .O_latency_start(S_latency_read_start),.O_latency_slot(S_latency_read_slot),
        .O_latency_underflow(S_latency_underflow),
        .I_rst_n             ( S_video_out_rst_n    ),
        .I_ddr_clk           ( S_ddr_clk            ),
 
        .O_video_out_rd_busy ( S_video_out_rd_busy  ),
        .I_video_in_wr_busy  ( S_video_in_wr_busy   ),
        .I_video_out_rp      ( S_video_out_rp       ),
 
        .O_ddr_user_rd_en    ( S_vo_ddr_rd_en       ),
        .O_ddr_user_addr     ( S_vo_ddr_rd_addr     ),
        .I_ddr_user_ready    ( S_ddr_user_ready     ),
        .I_ddr_user_rd_valid ( S_ddr_user_rd_valid  ),
        .I_ddr_user_rd_data  ( S_ddr_user_rd_data   ),

        .I_dsi_clk           ( S_hdmi_pixel_clk     ),
        .I_video_vsync       ( S_video_out_vsync    ),
        .I_video_rd_en       ( S_hdmi_window_rd_en  ),
        .O_vdieo_data        ( S_video_rd_data      )
    );



    wire S_video_app_en,S_video_app_wdf_wren,S_video_app_wdf_end;
    wire S_video_app_rdy,S_video_app_wdf_rdy,S_video_command_empty,S_video_read_valid;
    wire [24:0] S_video_app_addr;wire [2:0] S_video_app_cmd;
    wire [127:0] S_video_app_wdf_data;wire [31:0] S_video_app_wdf_mask;
    // Passive metadata path, observing FIFO-after-arbitration video acceptance.
    wire S_latency_sample,S_latency_hold,S_latency_clear;
    wire [9:0] S_latency_ms;
    wire [7:0] S_latency_bad;
    wire [143:0] S_latency_snapshot;
    video_latency_monitor u_video_latency (
        .I_raw_clk(S_csi_rx_clk),.I_raw_rst_n(S_rst_n),
        .I_raw_sof(S_raw10_frame_start),.I_raw_valid(S_raw10_valid),.I_isp_sof(S_ISP_O_tuser),
        .I_clk(S_ddr_clk),.I_rst_n(S_rst_n),.I_time_ms(S_video_time_ms),
        .I_write_start(S_latency_write_start),.I_write_slot(S_latency_write_slot),.I_write_flip(S_latency_write_flip),
        .I_write_accept(S_video_app_en&&S_video_app_rdy&&S_video_app_wdf_wren&&S_video_app_wdf_rdy&&S_video_app_cmd==3'd0),
        .I_write_addr(S_video_app_addr),.I_read_start(S_latency_read_start),.I_read_slot(S_latency_read_slot),
        .I_read_request(S_vo_ddr_rd_en),.I_read_addr(S_vo_ddr_rd_addr),
        .I_pixel_clk(S_hdmi_pixel_clk),.I_pixel_rst_n(S_hdmi_rst_n),
        .I_vsync(S_hdmi_out_vsync),.I_de(S_hdmi_out_de),.I_underflow(S_latency_underflow),
        .O_bcd(S_latency_bcd),.O_status(S_latency_status),
        .O_sample_valid(S_latency_sample),.O_sample_ms(S_latency_ms),
        .O_sample_hold(S_latency_hold),.O_sample_bad_reason(S_latency_bad));
    video_latency_stats u_latency_stats (
        .I_clk(S_ddr_clk),.I_rst_n(S_rst_n&&S_hdmi_rst_n),.I_time_ms(S_video_time_ms),
        .I_sample_valid(S_latency_sample),.I_sample_ms(S_latency_ms),
        .I_sample_hold(S_latency_hold),.I_sample_bad_reason(S_latency_bad),
        .I_clear(S_latency_clear),.O_snapshot(S_latency_snapshot));
    video_latency_diagnostics u_latency_diagnostics (
        .I_clk(S_hdmi_pixel_clk),.I_rst_n(S_hdmi_rst_n),.I_frame(S_hdmi_user),
        .I_stats_clk(S_ddr_clk),.I_stats_rst_n(S_rst_n),
        .I_snapshot(S_latency_snapshot),.O_clear(S_latency_clear),
        .I_paddr(S_hist_paddr[5:0]),.I_psel(S_motion_psel&&S_latency_diag_selected),
        .I_penable(S_hist_penable),.I_pwrite(S_hist_pwrite),.I_pwdata(S_hist_pwdata),
        .O_prdata(S_latency_diag_prdata),.O_pready(S_latency_diag_pready),.O_pslverr(S_latency_diag_pslverr));
    ddr_client_arbiter #(.CNN_ENABLE(1)) u_audio_ddr_arbiter (
      .I_c_req(S_cnn_ddr_req),.I_c_write(S_cnn_ddr_write),.I_c_addr(S_cnn_ddr_addr),.I_c_wdata(S_cnn_ddr_wdata),
      .O_c_accept(S_cnn_ddr_accept),.O_c_valid(S_cnn_ddr_valid),
      .I_clk(S_ddr_clk),.I_rst_n(S_rst_n),.I_video_busy(S_video_in_wr_busy||S_video_out_rd_busy||S_vi_ddr_wr_en),
      .I_video_empty(S_video_command_empty),.I_calibrated(S_init_calib_complete),
      .I_v_en(S_video_app_en),.I_v_addr(S_video_app_addr),.I_v_cmd(S_video_app_cmd),
      .I_v_wren(S_video_app_wdf_wren),.I_v_wdata(S_video_app_wdf_data),.I_v_mask(S_video_app_wdf_mask),
      .O_v_ready(S_video_app_rdy),.O_v_wready(S_video_app_wdf_rdy),.O_v_valid(S_video_read_valid),
      .I_a_req(S_audio_ddr_req),.I_a_write(S_audio_ddr_write),.I_a_addr(S_audio_ddr_addr),.I_a_wdata(S_audio_ddr_wdata),
      .O_a_done(S_audio_ddr_done),.O_a_rdata(S_audio_ddr_rdata),.O_a_error(S_audio_ddr_error),
      .O_en(S_mc_app_en),.O_addr(S_mc_app_addr),.O_cmd(S_mc_app_cmd),.O_wren(S_mc_app_wdf_wren),
      .O_wdata(S_mc_app_wdf_data),.O_mask(S_mc_app_wdf_mask),.I_ready(S_mc_app_rdy),
      .I_wready(S_mc_app_wdf_rdy),.I_rd_valid(S_mc_app_rd_data_valid),.I_rdata(S_mc_app_rd_data));
    assign S_mc_app_wdf_end=S_mc_app_wdf_wren;
    mc_to_user_interface u_mc_to_user_interface(
        .O_command_empty(S_video_command_empty),
        .I_clk                   ( S_ddr_clk               ),
        .I_rst_n                 ( S_rst_n                 ),

        .I_ddr_user_wr_en        ( S_ddr_user_wr_en        ),
        .I_ddr_user_rd_en        ( S_ddr_user_rd_en        ),
        .I_ddr_user_addr         ( S_ddr_user_addr         ),
        .I_ddr_user_wr_data      ( S_ddr_user_wr_data      ),
        .O_ddr_user_ready        ( S_ddr_user_ready        ),
        .O_ddr_user_rd_valid     ( S_ddr_user_rd_valid     ),
        .O_ddr_user_rd_data      ( S_ddr_user_rd_data      ),
            
        .O_mc_app_en             ( S_video_app_en             ),
        .O_mc_app_addr           ( S_video_app_addr           ),
        .O_mc_app_cmd            ( S_video_app_cmd            ),
        .I_mc_app_rdy            ( S_video_app_rdy            ),
        .O_mc_app_wdf_wren       ( S_video_app_wdf_wren       ),
        .O_mc_app_wdf_data       ( S_video_app_wdf_data       ),
        .O_mc_app_wdf_end        ( S_video_app_wdf_end        ),
        .O_mc_app_wdf_mask       ( S_video_app_wdf_mask       ),
        .I_mc_app_wdf_rdy        ( S_video_app_wdf_rdy        ),
        .I_mc_app_rd_data        ( S_mc_app_rd_data        ),
        .I_mc_app_rd_data_end    ( S_mc_app_rd_data_end    ),
        .I_mc_app_rd_data_valid  ( S_video_read_valid     )
    );



    ph1p35_324_ddr_wrapper u_ph1p35_324_ddr_wrapper(
        .I_sys_clk              ( I_sys_clk              ),
        .I_sys_rst_n            ( S_rst_n                ),

        .O_ddr_clk              ( S_ddr_clk              ),
        .O_init_calib_complete  ( S_init_calib_complete  ),
        .I_mc_app_addr          ( S_mc_app_addr          ),
        .I_mc_app_cmd           ( S_mc_app_cmd           ),
        .I_mc_app_en            ( S_mc_app_en            ),
        .I_mc_app_wdf_data      ( S_mc_app_wdf_data      ),
        .I_mc_app_wdf_end       ( S_mc_app_wdf_end       ),
        .I_mc_app_wdf_mask      ( S_mc_app_wdf_mask      ),
        .I_mc_app_wdf_wren      ( S_mc_app_wdf_wren      ),
        .O_mc_app_rd_data       ( S_mc_app_rd_data       ),
        .O_mc_app_rd_data_end   ( S_mc_app_rd_data_end   ),
        .O_mc_app_rd_data_valid ( S_mc_app_rd_data_valid ),
        .O_mc_app_rdy           ( S_mc_app_rdy           ),
        .O_mc_app_wdf_rdy       ( S_mc_app_wdf_rdy       ),

        .ddr_addr               ( ddr_addr               ),
        .ddr_ba                 ( ddr_ba                 ),
        .ddr_cke                ( ddr_cke                ),
        .ddr_odt                ( ddr_odt                ),
        .ddr_cs_n               ( ddr_cs_n               ),
        .ddr_ras_n              ( ddr_ras_n              ),
        .ddr_cas_n              ( ddr_cas_n              ),
        .ddr_we_n               ( ddr_we_n               ),
        .ddr_ck_p               ( ddr_ck_p               ),
        .ddr_ck_n               ( ddr_ck_n               ),
        .ddr_dm                 ( ddr_dm                 ),
        .ddr_dq                 ( ddr_dq                 ),
        .ddr_dqs_p              ( ddr_dqs_p              ),
        .ddr_dqs_n              ( ddr_dqs_n              )
    );



    uivtc #(
        .H_ActiveSize ( 1280 ),
        .H_FrameSize  ( 1650 ),
        .H_SyncStart  ( 1390 ),
        .H_SyncEnd    ( 1430 ),
        .V_ActiveSize ( 720  ),
        .V_FrameSize  ( 750  ),
        .V_SyncStart  ( 725  ),
        .V_SyncEnd    ( 730  )
    )u_hdmi_vtc(
        .I_vtc_rstn    ( S_hdmi_rst_n    ),
        .I_vtc_clk     ( S_hdmi_pixel_clk ),
        .O_vtc_vs      ( S_hdmi_vsync     ),
        .O_vtc_hs      ( S_hdmi_hsync     ),
        .O_vtc_de_valid( S_hdmi_de        ),
        .O_vtc_user    ( S_hdmi_user      ),
        .O_vtc_last    ( S_hdmi_last      )
    );

    wire S_hist_in_vsync,S_hist_in_hsync,S_hist_in_de,S_hist_in_osd;
    wire S_motion_fill,S_motion_box,S_motion_camera;
    wire [6:0] S_motion_count;
    wire [7:0] S_motion_count_bcd;
    motion_seven_segment u_motion_digits (
        .I_clk(S_hdmi_pixel_clk),.I_rst_n(S_hdmi_rst_n),.I_count_bcd(S_motion_count_bcd),
        .O_segment(O_segment),.O_select(O_digit_select));
    motion_video #(.REGISTRATION_HW(1)) u_motion (
        .I_clk(S_hdmi_pixel_clk),.I_rst_n(S_hdmi_rst_n),
        .I_capture_clk(S_csi_rx_clk),.I_capture_rst_n(S_rst_n),
        .I_capture_rgb(S_motion_pix),.I_capture_valid(S_motion_valid),
        .I_capture_user(S_motion_user),.I_capture_last(S_motion_last),
        .I_enable(S_ui_pixel_config[9]),.I_mirror(S_ui_pixel_config[3]),.I_flip(S_ui_pixel_config[4]),
        .I_frame(S_hdmi_user),.I_x(S_ui_x),.I_y(S_ui_y),.I_de(S_ui_de),.I_time_ms(S_video_pixel_time_ms),
        .O_fill(S_motion_fill),.O_box(S_motion_box),.O_count(S_motion_count),.O_count_bcd(S_motion_count_bcd),.O_camera(S_motion_camera),
        .I_paddr(S_hist_paddr[5:0]),.I_psel(S_motion_psel&&!S_latency_diag_selected),.I_penable(S_hist_penable),
        .I_pwrite(S_hist_pwrite),.I_pwdata(S_hist_pwdata),.O_prdata(S_motion_prdata),
        .O_pready(S_motion_pready),.O_pslverr(S_motion_pslverr));
    wire [23:0] S_hist_in_rgb,S_hist_in_image;
    histogram_video #(.RUNTIME_UI(1),.HIDE_FRAME_CONTROLLED(1),.PANEL_ONLY(1)) u_histogram (
        .I_clk(S_hdmi_pixel_clk),.I_rst_n(S_hdmi_rst_n),
        .I_vsync(S_hist_in_vsync),.I_hsync(S_hist_in_hsync),.I_de(S_hist_in_de),
        .I_rgb(S_hist_in_rgb),.I_image_rgb(S_hist_in_image),.I_osd_hit(S_hist_in_osd),
        .I_equalize(S_hist_equalize),.I_original(S_orig_view),
        .I_show(S_ui_pixel_config[5]),.I_hide(S_hide_osd),
         .I_bar_clk(S_csi_rx_clk),.I_bar_write(S_hist_bar_write),
        .I_bar_address(S_hist_bar_address),.I_bar_data(S_hist_bar_data),
        .I_table_bank(S_hist_table_bank),.I_table_valid(S_hist_table_valid),.I_table_equalized(S_hist_table_equalized),
        .O_panel_bank(S_hist_panel_bank),.O_panel_valid(S_hist_panel_valid),
        .I_paddr(10'd0),.I_psel(1'b0),.I_penable(1'b0),.I_pwrite(1'b0),.I_pwdata(32'd0),
        .O_prdata(),.O_pready(),.O_pslverr(),
        .O_vsync(S_hdmi_out_vsync),.O_hsync(S_hdmi_out_hsync),
        .O_de(S_hdmi_out_de),.O_rgb(S_hdmi_out_data));

    hdmi_mixer #(
        .HIDE_FRAME_CONTROLLED(1),.MCU_CLASS_DISPLAY(1),
        .H_OFFSET   ( 0    ),
        .V_OFFSET   ( 0    ),
        .IMG_WIDTH  ( 1280 ),
        .IMG_HEIGHT ( 720  ),
        .PIXEL_CLOCK_HZ( 75000000 ), // u_PLL C4 = 75 MHz
        .DEBUG_MODE ( 4    ),.RUNTIME_MOTION(1)
    )u_hdmi_mixer(
        .I_clk           ( S_hdmi_pixel_clk   ),
        .I_rst_n         ( S_hdmi_rst_n       ),
        .I_spot_enable(S_ui_pixel_config[15]&&S_ui_pixel_config[13]),
        .I_spot_fresh(S_cnn_packet_hdmi[197]),.I_result_valid(S_cnn_packet_hdmi_valid),
        .I_latency_bcd(S_latency_bcd),.I_latency_status(S_latency_status),
        .I_video_vsync   ( S_hdmi_vsync       ),
        .I_video_hsync   ( S_hdmi_hsync       ),
        .I_video_de      ( S_hdmi_de          ),
        .I_video_user    ( S_hdmi_user        ),
        .I_video_last    ( S_hdmi_last        ),
        .I_debug_status  ( S_hdmi_debug_status),
        .I_diag_button   ( I_button           ),
        .I_diag_switch   ( I_switch           ),
        .I_diag_mode     ( S_mode_request_24m ),
        .I_diag_active   ( S_mode_active_csi  ),
        .I_ae_value      ( S_ae_hold          ),
        .I_ag_value      ( S_ag_hold          ),
        .I_disp_toggle   ( S_disp_toggle      ),
        .I_view_mir      ( S_view_mir         ),
        .I_view_flp      ( S_view_flp         ),
        .I_orig_view     ( S_orig_view        ),
        .I_hide(S_hide_osd),.I_ui_hit(S_ui_hit),.I_ui_color(S_ui_color),
        .I_motion_enable(S_ui_pixel_config[9]),.I_motion_fill(S_motion_fill),.I_motion_box(S_motion_box),
        .I_motion_count(S_motion_count),.I_motion_count_bcd(S_motion_count_bcd),.I_motion_camera(S_motion_camera),
        .O_ui_x(S_ui_x),.O_ui_y(S_ui_y),.O_ui_de(S_ui_de),
        .I_v11_status(10'd0),.I_auto_modes(4'd0),.I_ae_diag(20'd0),.I_wb_status(2'd0),
        .I_saturation(S_ui_pixel_config[7]),.I_threshold_data(51'd0),.I_threshold_toggle(1'b0),
        .I_cnn_display      ( {S_ui_pixel_config[13]?80'd0:S_cnn_packet_hdmi[159:80],S_cnn_packet_hdmi[79:0]} ),
        .I_cnn_boxes        ( 384'd0 ),.I_cnn_label_bcd(40'd0),
        .I_cnn_nbox         ( S_cnn_packet_hdmi[163:160] ),
        // v1.7 P3-c：诊断行数据（整包因此被完全消费，不再依赖 LED 奇偶位防剪枝）
        .I_cnn_frame_cnt    ( S_cnn_packet_hdmi[195:180]  ),
        .I_cnn_wr_cnt       ( S_cnn_packet_hdmi[179:165]  ),
        .I_cnn_err          ( S_cnn_packet_hdmi[164]      ),
        .I_cnn_on           ( S_cnn_on_hdmi && S_cnn_policy_matches ),
        .O_video_rd_en   ( S_hdmi_window_rd_en),
        .I_video_rd_data ( S_video_rd_data    ),
        .O_hdmi_vsync    ( S_hist_in_vsync    ),
        .O_hdmi_hsync    ( S_hist_in_hsync    ),
        .O_hdmi_de       ( S_hist_in_de       ),
        .O_hdmi_data     ( S_hist_in_rgb      ),
        .O_image_rgb     ( S_hist_in_image    ),
        .O_osd_hit       ( S_hist_in_osd      ),
        .O_spot_status(S_spot_status_pixel)
    );

    hdmi_tx u_hdmi_tx(
        .I_pixel_clk        ( S_hdmi_pixel_clk  ),
        .I_serial_clk       ( S_hdmi_serial_clk ),
        .I_rst              ( ~S_hdmi_rst_n     ),
        .I_key_in           ( 1'b0              ),
        .I_edid_read_trig   ( 1'b0              ),
        .O_edid_read_valid  (                   ),
        .O_edid_read_data   (                   ),
        .I_video_rgb_enable ( 1'b1              ),
        .I_video_in_vs      ( S_hdmi_out_vsync  ),
        .I_video_in_de      ( S_hdmi_out_de     ),
        .I_video_in_user    ( 1'b0              ),
        .I_video_in_valid   ( 1'b0              ),
        .I_video_in_last    ( 1'b0              ),
        .O_video_in_ready   (                   ),
        .I_video_in_data    ( S_hdmi_out_data   ),
        .I_audio_valid      ( S_audio_valid      ),
        .I_audio_left_data  ( S_audio_sample     ),
        .I_audio_right_data ( S_audio_sample     ),
        .I_i2s_BCLK         ( 1'b0              ),
        .I_i2s_LRCK         ( 1'b0              ),
        .I_i2s_DOUT         ( 1'b0              ),
        .O_ddc_scl          (                   ),
        .O_hdmi_clk_p       (                   ),
        .O_hdmi_tx_p        (                   ),
        .O_tmds_ch0_p       ( O_tmds_ch0_p      ),
        .O_tmds_ch1_p       ( O_tmds_ch1_p      ),
        .O_tmds_ch2_p       ( O_tmds_ch2_p      ),
        .O_tmds_clk_p       ( O_tmds_clk_p      )
    );


    
endmodule
