// HDMI frame interval monitor. All logic stays in the pixel clock domain.
// A bit-serial divider and double-dabble datapath format FPS only.
// No frame-time datapath, DSP, RAM, MCU bus or generated clock is required.
module hdmi_frame_stats #(
    parameter integer CLOCK_HZ = 75000000
)(
    input wire I_clk,
    input wire I_rst_n,
    input wire I_frame_start,
    output reg [15:0] O_fps_bcd, // ddd.d FPS, rounded to nearest 0.1
    output reg O_valid
);
    localparam integer CW = $clog2(CLOCK_HZ);
    // CLOCK_HZ is the actual pixel clock (75 MHz in this design).
    localparam [2:0] IDLE = 0, DIVIDE = 1, BCD = 2;
    reg [CW-1:0] age, divisor, remainder;
    reg seen;
    reg [2:0] state;
    reg [31:0] quotient;
    reg [5:0] bits_left;
    reg [13:0] binary_value;
    reg [15:0] decimal_value, pending_fps;
    reg pending_ready;
    wire [CW:0] shifted = {remainder, quotient[31]};
    wire take = shifted >= {1'b0, divisor};
    wire [CW:0] reduced = take ? shifted - {1'b0, divisor} : shifted;
    wire [31:0] next_quotient = {quotient[30:0], take};
    wire [31:0] interval_cycles = age + 32'd1;

    function [15:0] F_adjust;
        input [15:0] value;
        integer n;
        begin
            F_adjust = value;
            for (n = 0; n < 4; n = n + 1)
                if (value[n*4 +: 4] >= 4'd5)
                    F_adjust[n*4 +: 4] = value[n*4 +: 4] + 4'd3;
        end
    endfunction
    wire [15:0] adjusted = F_adjust(decimal_value);
    wire [15:0] next_decimal = {adjusted[14:0], binary_value[13]};

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            age <= 0; divisor <= 0; remainder <= 0;
            seen <= 0; state <= IDLE; quotient <= 0;
            bits_left <= 0; binary_value <= 0; decimal_value <= 0;
            pending_fps <= 0;
            pending_ready <= 0; O_fps_bcd <= 0; O_valid <= 0;
        end else begin
            // Results are published only at SOF, never halfway
            // through a displayed frame. They describe the last complete
            // interval; startup needs two intervals before publication.
            if (I_frame_start) begin
                age <= 0;
                seen <= 1;
                if (pending_ready) begin
                    O_fps_bcd <= pending_fps;
                    O_valid <= 1;
                end
                if (seen && state == IDLE) begin
                    divisor <= interval_cycles[CW-1:0];
                    quotient <= CLOCK_HZ * 10 + (interval_cycles >> 1);
                    remainder <= 0; bits_left <= 31;
                    state <= DIVIDE; pending_ready <= 0;
                end
            end else if (seen) begin
                if (age == CLOCK_HZ - 1) begin
                    // No SOF for one second: discard stale readings and
                    // reacquire a complete interval on recovery.
                    age <= 0; seen <= 0; state <= IDLE;
                    pending_ready <= 0; O_valid <= 0;
                end else age <= age + 1'b1;
            end

            case (state)
                DIVIDE: begin
                    quotient <= next_quotient;
                    remainder <= reduced[CW-1:0];
                    if (bits_left == 0) begin
                        binary_value <= (next_quotient > 9999) ? 14'd9999 : next_quotient[13:0];
                        decimal_value <= 0; bits_left <= 13; state <= BCD;
                    end else bits_left <= bits_left - 1'b1;
                end
                BCD: begin
                    decimal_value <= next_decimal;
                    binary_value <= {binary_value[12:0], 1'b0};
                    if (bits_left == 0) begin
                        pending_fps <= next_decimal;
                        pending_ready <= 1; state <= IDLE;
                    end else bits_left <= bits_left - 1'b1;
                end
                default: begin end
            endcase
        end
    end
endmodule
