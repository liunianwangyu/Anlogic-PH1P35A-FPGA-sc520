`timescale 1ns / 1ps

// One-entry held-data mailbox. The complete bus is stable from request until
// acknowledge returns through two flops. A busy mailbox drops a NEW reading;
// it never overwrites an in-flight reading. Normal 60fps operation has ample
// time for the handshake, including at the 23.809524MHz control clock.
module ae_stats_cdc #(parameter integer WIDTH = 8) (
    input wire I_src_clk, I_dst_clk, I_rst_n,
    input wire I_valid,
    input wire [WIDTH-1:0] I_mean,
    output reg O_valid,
    output reg [WIDTH-1:0] O_mean
);
    reg [WIDTH-1:0] mean_hold;
    reg req, ack;
    (* async_reg = "true" *) reg ack_meta, ack_sync;
    (* async_reg = "true" *) reg req_meta, req_sync;
    always @(posedge I_src_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            mean_hold <= {WIDTH{1'b0}}; req <= 1'b0;
            ack_meta <= 1'b0; ack_sync <= 1'b0;
        end else begin
            ack_meta <= ack; ack_sync <= ack_meta;
            if (I_valid && (req == ack_sync)) begin
                mean_hold <= I_mean;
                req <= ~req;
            end
        end
    end
    always @(posedge I_dst_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            req_meta <= 1'b0; req_sync <= 1'b0; ack <= 1'b0;
            O_valid <= 1'b0; O_mean <= {WIDTH{1'b0}};
        end else begin
            req_meta <= req; req_sync <= req_meta;
            O_valid <= 1'b0;
            if (req_sync != ack) begin
                O_mean <= mean_hold;
                O_valid <= 1'b1;
                ack <= req_sync;
            end
        end
    end
endmodule
