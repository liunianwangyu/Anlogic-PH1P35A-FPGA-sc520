`timescale 1ns / 1ps
module sc520_ae_mcu_system #(parameter integer MCU_TASKS=3) (
    input wire I_core_clk, I_pll_lock, I_ctrl_clk, I_ctrl_rst_n,
    input wire I_manual,
    input wire [3:0] I_key_n,
    input wire I_manual_set,
    input wire [10:0] I_manual_exposure,
    input wire [7:0] I_manual_gain,
    input wire I_cam_cfg_done, I_ae_cfg_done, I_iic_error, I_retry,
    input wire I_stats_valid,
    input wire [7:0] I_mean, I_clip, I_near,
    output wire O_ae_req,
    output wire [15:0] O_ae, O_ag,
    output wire O_bus_clk,O_bus_rst_n,
    output wire [9:0] O_ext_addr,
    output wire O_ext_sel,O_ext_enable,O_ext_write,
    output wire [31:0] O_ext_wdata,
    input wire [31:0] I_ext_rdata,
    input wire I_ext_ready,I_ext_error,
    output wire [7:0] O_audio_addr,output wire O_audio_sel,O_audio_enable,O_audio_write,
    output wire [31:0] O_audio_wdata,input wire [31:0] I_audio_rdata,
    input wire I_audio_ready,I_audio_error,
    output wire O_mem_req,O_mem_write,output wire [15:0] O_mem_addr,
    output wire [2:0] O_mem_size,output wire [31:0] O_mem_wdata,
    input wire I_mem_done,I_mem_error,input wire [31:0] I_mem_rdata
);
    wire bus_clk;
    (* async_reg="true" *) reg [1:0] core_reset_release, bus_reset_release;
    always @(posedge I_core_clk or negedge I_pll_lock)
        if (!I_pll_lock) core_reset_release<=0;
        else core_reset_release<={core_reset_release[0],1'b1};
    always @(posedge bus_clk or negedge I_pll_lock)
        if (!I_pll_lock) bus_reset_release<=0;
        else bus_reset_release<={bus_reset_release[0],1'b1};
    wire [1:0] htrans, hresp;
    wire hwrite, hready;
    wire [30:0] haddr;
    wire [2:0] hsize;
    wire [31:0] hwdata, hrdata;
    // Hard MCU; no soft CPU, instruction BRAM or additional video PLL.
    // JTAG uses the board PAD path (MCU_JTAG_SEL=0), with no new external pins.
    MCU u_MCU (
        .core_clk(I_core_clk), .timer_clk(I_core_clk),
        .core_reset(!core_reset_release[1]), .por_reset(!core_reset_release[1]),
        .nmi(1'b0), .clic_irq(23'd0),
        .ahb_clk(bus_clk), .htrans(htrans), .hwrite(hwrite), .haddr(haddr),
        .hsize(hsize), .hburst(), .hprot(), .hmastlock(), .hwdata(hwdata),
        .hrdata(hrdata), .hresp(hresp), .hready(hready)
    );
    wire [19:0] paddr;
    wire psel, penable, pwrite, pready, pslverr;
    wire [31:0] pwdata, prdata;
    wire [31:0] ae_rdata;
    wire ae_ready,ae_error;
    wire ae_selected=(paddr[19:6]==0);
    assign O_bus_clk=bus_clk;
    assign O_bus_rst_n=bus_reset_release[1];
    assign O_ext_addr=paddr[9:0];
    assign O_ext_sel=psel&&!ae_selected;
    assign O_ext_enable=penable;
    assign O_ext_write=pwrite;
    assign O_ext_wdata=pwdata;
    assign prdata=ae_selected?ae_rdata:I_ext_rdata;
    assign pready=ae_selected?ae_ready:I_ext_ready;
    assign pslverr=ae_selected?ae_error:I_ext_error;
    assign O_audio_addr=paddr[7:0];
    assign O_audio_enable=penable;
    assign O_audio_write=pwrite;
    assign O_audio_wdata=pwdata;
    audio_ahb_fabric u_bridge (
        .I_clk(bus_clk), .I_rst_n(bus_reset_release[1]),
        .I_htrans(htrans), .I_hwrite(hwrite), .I_haddr(haddr),
        .I_hsize(hsize), .I_hwdata(hwdata),
        .O_hrdata(hrdata), .O_hresp(hresp), .O_hready(hready),
        .O_paddr(paddr), .O_psel(psel), .O_penable(penable),
        .O_pwrite(pwrite), .O_pwdata(pwdata),
        .I_prdata(prdata), .I_pready(pready), .I_pslverr(pslverr),
        .O_audio_sel(O_audio_sel),.I_audio_rdata(I_audio_rdata),.I_audio_error(I_audio_error),.I_audio_ready(I_audio_ready),
        .O_mem_req(O_mem_req),.O_mem_write(O_mem_write),.O_mem_addr(O_mem_addr),
        .O_mem_size(O_mem_size),.O_mem_wdata(O_mem_wdata),
        .I_mem_done(I_mem_done),.I_mem_error(I_mem_error),.I_mem_rdata(I_mem_rdata)
    );
    wire start, cancel, ready, done, update, write_done, timeout_seen;
    wire [10:0] next_exposure;
    wire [7:0] next_gain;
    wire [23:0] stats_snapshot;
    sc520_ae_scheduler u_scheduler (
        .I_clk(I_ctrl_clk), .I_rst_n(I_ctrl_rst_n), .I_manual(I_manual), .I_key_n(I_key_n),
        .I_manual_set(I_manual_set),.I_manual_exposure(I_manual_exposure),.I_manual_gain(I_manual_gain),
        .I_cam_cfg_done(I_cam_cfg_done), .I_ae_cfg_done(I_ae_cfg_done), .I_iic_error(I_iic_error),
        .I_stats_valid(I_stats_valid), .I_mean(I_mean), .I_clip_ratio(I_clip), .I_near_ratio(I_near),
        .O_ae_req(O_ae_req), .O_ae(O_ae), .O_ag(O_ag),
        .I_calc_ready(ready), .I_calc_done(done), .I_calc_update(update),
        .I_calc_exposure(next_exposure), .I_calc_gain(next_gain),
        .O_calc_start(start), .O_calc_cancel(cancel), .O_calc_stats(stats_snapshot),
        .O_write_done(write_done), .O_timeout(timeout_seen)
    );
    ae_mailbox #(.MCU_TASKS(MCU_TASKS)) u_mailbox (
        .I_ctrl_clk(I_ctrl_clk), .I_ctrl_rst_n(I_ctrl_rst_n), .I_start(start), .I_cancel(cancel),
        .I_exposure(O_ae[10:0]), .I_gain(O_ag[7:0]),
        .I_mean(stats_snapshot[7:0]), .I_clip(stats_snapshot[15:8]), .I_near(stats_snapshot[23:16]),
        .I_manual(I_manual), .I_cam_done(I_cam_cfg_done), .I_cfg_done(I_ae_cfg_done),
        .I_error(I_iic_error), .I_retry(I_retry), .I_write_done(write_done), .I_timeout(timeout_seen),
        .O_ready(ready), .O_done(done), .O_update(update), .O_exposure(next_exposure), .O_gain(next_gain),
        .I_bus_clk(bus_clk), .I_bus_rst_n(bus_reset_release[1]),
        .I_paddr(paddr), .I_psel(psel&&ae_selected), .I_penable(penable), .I_pwrite(pwrite), .I_pwdata(pwdata),
        .O_prdata(ae_rdata), .O_pready(ae_ready), .O_pslverr(ae_error)
    );
endmodule
