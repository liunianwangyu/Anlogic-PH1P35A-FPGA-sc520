`timescale 1ns / 1ps
// AHB-Lite single slave. Holds the address through APB SETUP/ACCESS and
// AHB holds write data while HREADY is low, so APB uses it without a 32-bit copy.
// Supports back-to-back transfers.
module ae_ahb_apb_bridge #(parameter integer ADDR_BITS=6) (
    input wire I_clk, I_rst_n,
    input wire [1:0] I_htrans,
    input wire I_hwrite,
    input wire [30:0] I_haddr,
    input wire [2:0] I_hsize,
    input wire [31:0] I_hwdata,
    output wire [31:0] O_hrdata,
    output wire [1:0] O_hresp,
    output wire O_hready,
    output reg [19:0] O_paddr,
    output wire O_psel, O_penable,
    output reg O_pwrite,
    output wire [31:0] O_pwdata,
    input wire [31:0] I_prdata,
    input wire I_pready, I_pslverr
);
    localparam [1:0] IDLE=0, SETUP=1, ACCESS=2, ERROR_END=3;
    reg [1:0] state;
    reg bad_address;
    assign O_psel = (state==SETUP || state==ACCESS) && !bad_address;
    assign O_penable = state==ACCESS;
    wire error_now = state==ACCESS && (bad_address || I_pslverr);
    assign O_hready = state==IDLE || state==ERROR_END ||
                      (state==ACCESS && I_pready && !error_now);
    assign O_hresp = (error_now || state==ERROR_END) ? 2'b01 : 2'b00;
    assign O_hrdata = I_prdata;
    assign O_pwdata = I_hwdata;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state<=IDLE; O_paddr<=0; O_pwrite<=0; bad_address<=0;
        end else begin
            case (state)
                IDLE, ERROR_END: if (I_htrans[1]) begin
                    O_paddr<={{(20-ADDR_BITS){1'b0}},I_haddr[ADDR_BITS-1:0]}; O_pwrite<=I_hwrite;
                    bad_address<=(I_haddr[30:ADDR_BITS]!=0 || I_haddr[1:0]!=0 || I_hsize!=3'd2);
                    state<=SETUP;
                end else state<=IDLE;
                SETUP: state<=ACCESS;
                ACCESS: if (error_now) state<=ERROR_END;
                        else if (I_pready) begin
                            if (I_htrans[1]) begin
                                O_paddr<={{(20-ADDR_BITS){1'b0}},I_haddr[ADDR_BITS-1:0]}; O_pwrite<=I_hwrite;
                                bad_address<=(I_haddr[30:ADDR_BITS]!=0 || I_haddr[1:0]!=0 || I_hsize!=3'd2);
                                state<=SETUP;
                            end else state<=IDLE;
                        end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
