`timescale 1ns/1ps

// Normalized SW1..SW3. SW4 is independent and deliberately not an input.
// SW1+SW2 (011): KEY1 selects a persistent global exposure mode.
// In AUTO, KEY2 selects AVERAGE (reset default) / CENTER metering.
// KEY3 is a persistent guarded selector, routed to histogram EQ in v1.8.
// The factory AWB calibration/continuous tracking remains independent.
// SW1 only (001): the four exposure keys are available only in MANUAL.
module ae_mode_ui #(
    parameter integer HOLD_CYCLES = 476190
) (
    input wire I_clk, I_rst_n,
    input wire [2:0] I_switch_on,
    input wire [3:0] I_key_n,
    output wire O_auto,
    output wire O_center,
    output wire O_wb_cal_toggle,
    output wire [3:0] O_manual_key_n
);
    wire manual_keys_enabled = !O_auto && (I_switch_on == 3'b001);
    reg [3:0] manual_armed;
    auto_manual_mode_ui #(.MODE_COUNT(1), .HOLD_CYCLES(HOLD_CYCLES)) u_modes (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_enable(I_switch_on == 3'b011), .I_key_n(I_key_n[0]), .O_auto(O_auto)
    );
    auto_manual_mode_ui #(.MODE_COUNT(1), .HOLD_CYCLES(HOLD_CYCLES),
                         .DEFAULT_AUTO(1'b0)) u_wb_cal_key (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_enable(I_switch_on == 3'b011),
        .I_key_n(I_key_n[2]), .O_auto(O_wb_cal_toggle)
    );
    auto_manual_mode_ui #(.MODE_COUNT(1), .HOLD_CYCLES(HOLD_CYCLES),
                         .DEFAULT_AUTO(1'b0)) u_meter_mode (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_enable((I_switch_on == 3'b011) && O_auto),
        .I_key_n(I_key_n[1]), .O_auto(O_center)
    );
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) manual_armed <= 4'd0;
        else if (!manual_keys_enabled) manual_armed <= 4'd0;
        else manual_armed <= manual_armed | I_key_n;
    end
    // A held menu key must be released before it can become a manual key.
    assign O_manual_key_n = manual_keys_enabled ? (I_key_n | ~manual_armed) : 4'hf;
endmodule

// Share the existing CNN long-press timer with the saturation short press.
// Short press commits on release, so a CNN long press never changes colour.
// SW4 is intentionally absent: it remains an independent original view.
module saturation_key_control #(
    parameter integer DEBOUNCE_CYCLES = 476190,
    parameter integer LONG_CYCLES = 36000000
)(
    input wire I_clk, I_rst_n,
    input wire [2:0] I_switch_on,
    input wire [3:0] I_key_n,
    output reg O_saturation,
    output reg O_cnn
);
    localparam integer CW = (LONG_CYCLES < 2) ? 1 : $clog2(LONG_CYCLES+1);
    reg [CW-1:0] count;
    reg long_armed, short_armed;
    reg [2:0] context_d;
    wire short_context = (I_switch_on == 3'b011) &&
                         (context_d == I_switch_on) && (&I_key_n[2:0]);
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            count <= 0;
            long_armed <= 1'b1;
            short_armed <= 1'b0;
            context_d <= 0;
            O_saturation <= 1'b0;
            O_cnn <= 1'b1;
        end else begin
            context_d <= I_switch_on;
            if (I_key_n[3]) begin
                if (short_context && short_armed && long_armed &&
                    count >= DEBOUNCE_CYCLES && count < LONG_CYCLES)
                    O_saturation <= ~O_saturation;
                count <= 0;
                long_armed <= 1'b1;
                short_armed <= short_context;
            end else begin
                if (!short_context) short_armed <= 1'b0;
                if (long_armed) begin
                    if (count == LONG_CYCLES-1) begin
                        long_armed <= 1'b0;
                        short_armed <= 1'b0;
                        O_cnn <= ~O_cnn;
                    end else count <= count + 1'b1;
                end
            end
        end
    end
endmodule
