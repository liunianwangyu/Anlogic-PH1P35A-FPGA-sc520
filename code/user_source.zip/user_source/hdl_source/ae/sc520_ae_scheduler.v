`timescale 1ns / 1ps
// FPGA owns manual controls, I2C scheduling and settling; FD owns AUTO arithmetic.
module sc520_ae_scheduler #(
    parameter [2:0] SETTLE_FRAMES = 3'd3,
    parameter integer MANUAL_TICK_CYCLES = 100000,
    parameter integer CALC_TIMEOUT_CYCLES = 23810
) (
    input wire I_clk, I_rst_n, I_manual,
    input wire [3:0] I_key_n,
    input wire I_manual_set,
    input wire [10:0] I_manual_exposure,
    input wire [7:0] I_manual_gain,
    input wire I_cam_cfg_done, I_ae_cfg_done, I_iic_error,
    input wire I_stats_valid,
    input wire [7:0] I_mean, I_clip_ratio, I_near_ratio,
    output reg O_ae_req,
    output wire [15:0] O_ae, O_ag,
    input wire I_calc_ready, I_calc_done, I_calc_update,
    input wire [10:0] I_calc_exposure,
    input wire [7:0] I_calc_gain,
    output wire O_calc_start,
    output reg O_calc_cancel,
    output wire [23:0] O_calc_stats,
    output reg O_write_done, O_timeout
);
    localparam [1:0] IDLE=0, WAIT_BUSY=1, WAIT_DONE=2, WAIT_CALC=3;
    reg [1:0] state;
    reg [10:0] exposure, manual_exposure;
    reg [7:0] gain, manual_gain;
    reg initialized, manual_d;
    reg [2:0] settle;
    reg [16:0] tick_count;
    reg [4:0] gain_tick_count;
    // Exact-width counter: no 32-bit divider, multiplier or free-running timer.
    reg [$clog2(CALC_TIMEOUT_CYCLES)-1:0] calc_count;
    wire tick = (tick_count == MANUAL_TICK_CYCLES-1);
    wire gain_tick = tick && (&gain_tick_count);
    assign O_ae = {5'd0,exposure};
    assign O_ag = {8'd0,gain};
    // Capture directly on the decision edge, avoiding a second 24-bit snapshot.
    assign O_calc_stats = {I_near_ratio,I_clip_ratio,I_mean};
    assign O_calc_start = state==IDLE && initialized && I_cam_cfg_done && I_ae_cfg_done &&
                          !I_iic_error && !I_manual && !manual_d && I_stats_valid && settle==0 && I_calc_ready;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            tick_count<=0; gain_tick_count<=0;
            manual_exposure<=1991; manual_gain<=144;
        end else begin
            if (tick) begin
                tick_count<=0; gain_tick_count<=gain_tick_count+1'b1;
            end else tick_count<=tick_count+1'b1;
            if (I_manual && I_manual_set) begin
                if(I_manual_exposure>=4&&I_manual_exposure<=1991&&I_manual_gain>=16&&I_manual_gain<=208) begin
                    manual_exposure<=I_manual_exposure;manual_gain<=I_manual_gain;
                end
            end else if (I_manual && !manual_d) begin
                manual_exposure<=exposure; manual_gain<=gain;
            end else if (I_manual) begin
                if (tick) begin
                    if (!I_key_n[0] && manual_exposure>4)
                        manual_exposure<=manual_exposure-1'b1;
                    else if (I_key_n[0] && !I_key_n[1] && manual_exposure<1991)
                        manual_exposure<=manual_exposure+1'b1;
                end
                if (gain_tick) begin
                    if (!I_key_n[2] && manual_gain>16) manual_gain<=manual_gain-1'b1;
                    else if (I_key_n[2] && !I_key_n[3] && manual_gain<208)
                        manual_gain<=manual_gain+1'b1;
                end
            end
        end
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state<=IDLE; exposure<=1991; gain<=16;
            initialized<=0; manual_d<=0; settle<=SETTLE_FRAMES;
            O_ae_req<=0; O_calc_cancel<=0;
            O_write_done<=0; O_timeout<=0; calc_count<=0;
        end else begin
            O_ae_req<=0; O_calc_cancel<=0; O_write_done<=0;
            manual_d<=I_manual;
            if (manual_d != I_manual) settle<=SETTLE_FRAMES;
            // Cancellation cannot edit an I2C transaction already in flight.
            if (state==WAIT_CALC && ((manual_d!=I_manual) || I_manual || I_iic_error)) begin
                O_calc_cancel<=1; state<=IDLE;
            end else if (!I_iic_error) begin
                case (state)
                    IDLE: if (I_cam_cfg_done && I_ae_cfg_done) begin
                        if (!initialized) begin
                            exposure<=I_manual ? manual_exposure : 11'd1991;
                            gain<=I_manual ? manual_gain : 8'd16;
                            initialized<=1; O_ae_req<=1; state<=WAIT_BUSY;
                        end else if (I_manual && manual_d) begin
                            if (exposure!=manual_exposure || gain!=manual_gain) begin
                                exposure<=manual_exposure; gain<=manual_gain;
                                O_ae_req<=1; state<=WAIT_BUSY;
                            end
                        end else if (!I_manual && I_stats_valid && manual_d==I_manual) begin
                            if (settle!=0) settle<=settle-1'b1;
                            else if (I_calc_ready) begin
                                calc_count<=0; state<=WAIT_CALC;
                            end
                        end
                    end
                    WAIT_CALC: begin
                        if (I_calc_done) begin
                            state<=IDLE;
                            if (I_calc_update && I_calc_exposure>=4 && I_calc_exposure<=1991 &&
                                I_calc_gain>=16 && I_calc_gain<=208) begin
                                exposure<=I_calc_exposure; gain<=I_calc_gain;
                                O_ae_req<=1; state<=WAIT_BUSY;
                            end
                        end else if (calc_count==CALC_TIMEOUT_CYCLES-1) begin
                            // Hold the last issued parameters, keep MANUAL usable and
                            // permit a fresh request. Late replies are drained, never used.
                            O_timeout<=1; O_calc_cancel<=1; state<=IDLE;
                        end else calc_count<=calc_count+1'b1;
                    end
                    WAIT_BUSY: if (!I_ae_cfg_done) state<=WAIT_DONE;
                    WAIT_DONE: if (I_ae_cfg_done) begin
                        state<=IDLE; settle<=SETTLE_FRAMES; O_write_done<=1;
                    end
                    default: state<=IDLE;
                endcase
            end
        end
    end
endmodule
