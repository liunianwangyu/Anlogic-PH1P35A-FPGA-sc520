`timescale 1ns / 1ps
// Coherent four-phase CDC mailbox. Bundled data is held until acknowledged;
// only handshake bits cross synchronizers. Both sides share the power reset.
module ae_mailbox #(parameter integer MCU_TASKS=0) (
    input wire I_ctrl_clk, I_ctrl_rst_n,
    input wire I_start, I_cancel,
    input wire [10:0] I_exposure,
    input wire [7:0] I_gain, I_mean, I_clip, I_near,
    input wire I_manual, I_cam_done, I_cfg_done, I_error, I_retry, I_write_done, I_timeout,
    output wire O_ready,
    output reg O_done,
    output wire O_update,
    output wire [10:0] O_exposure,
    output wire [7:0] O_gain,
    input wire I_bus_clk, I_bus_rst_n,
    input wire [19:0] I_paddr,
    input wire I_psel, I_penable, I_pwrite,
    input wire [31:0] I_pwdata,
    output reg [31:0] O_prdata,
    output wire O_pready, O_pslverr
);
    localparam [1:0] FREE=0, ACK=1, RESULT=2, DRAIN=3;
    reg [1:0] ctrl_state;
    reg request, cancel_pending;
    reg [58:0] request_bundle; // token16 + near8 + clip8 + mean8 + gain8 + exp11
    (* async_reg="true" *) reg ack_meta, ack_sync, done_meta, done_sync;
    reg bus_ack, bus_done;
    reg [18:0] result_params;
    reg result_update;
    // The staging bank itself stays immutable from COMMIT through CDC drain.
    // The scheduler samples it only on O_done; no redundant result bank is needed.
    assign O_exposure = result_params[10:0];
    assign O_gain = result_params[18:11];
    assign O_update = result_update;
    assign O_ready = ctrl_state==FREE;
    always @(posedge I_ctrl_clk or negedge I_ctrl_rst_n) begin
        if (!I_ctrl_rst_n) begin
            ack_meta<=0; ack_sync<=0; done_meta<=0; done_sync<=0;
            ctrl_state<=FREE; request<=0; cancel_pending<=0;
            request_bundle<=0; O_done<=0;
        end else begin
            ack_meta<=bus_ack; ack_sync<=ack_meta;
            done_meta<=bus_done; done_sync<=done_meta; O_done<=0;
            case (ctrl_state)
                FREE: if (I_start) begin
                    request_bundle<={request_bundle[58:43]+16'd1,I_near,I_clip,I_mean,I_gain,I_exposure};
                    request<=1; cancel_pending<=I_cancel;
                    ctrl_state<=ACK;
                end
                ACK: begin
                    if (I_cancel) cancel_pending<=1;
                    if (ack_sync) begin
                        if (cancel_pending || I_cancel) begin request<=0; ctrl_state<=DRAIN; end
                        else ctrl_state<=RESULT;
                    end
                end
                RESULT: if (I_cancel || done_sync) begin
                    request<=0; ctrl_state<=DRAIN;
                    if (!I_cancel && done_sync) begin
                        O_done<=1;
                    end
                end
                DRAIN: if (!ack_sync && !done_sync) ctrl_state<=FREE;
                default: ctrl_state<=FREE;
            endcase
        end
    end
    (* async_reg="true" *) reg req_meta, req_sync;
    (* async_reg="true" *) reg [6:0] status_meta, status_sync;
    reg [58:0] snapshot;
    reg claimed, staged;
    reg event_toggle;
    (* async_reg="true" *) reg event_meta, event_sync;
    reg event_seen, completion_event, reject_event;
    always @(posedge I_ctrl_clk or negedge I_ctrl_rst_n)
        if (!I_ctrl_rst_n) event_toggle<=0;
        else if (I_write_done) event_toggle<=!event_toggle;
    wire access = I_psel && I_penable;
    wire address_ok = I_paddr[19:6]==0 && I_paddr[1:0]==0;
    wire write_ok = I_paddr[5:0]==6'h18 || I_paddr[5:0]==6'h1c ||
                    I_paddr[5:0]==6'h20 || I_paddr[5:0]==6'h24;
    wire read_ok = I_paddr[5:0]<=6'h14 || I_paddr[5:0]==6'h28;
    assign O_pready=1'b1;
    assign O_pslverr=access && (!address_ok || (I_pwrite ? !write_ok : !read_ok));
    always @* begin
        O_prdata=0;
        if (address_ok) case (I_paddr[5:0])
            6'h00: O_prdata=32'hAE150001; // hardware1.5 / interface1
            6'h04: O_prdata={19'd0,reject_event,completion_event,status_sync,staged,claimed,bus_done,bus_ack};
            6'h08: O_prdata={16'd0,snapshot[58:43]};
            6'h0c: O_prdata={13'd0,snapshot[18:0]};
            6'h10: O_prdata={8'd0,snapshot[42:19]};
            6'h14: O_prdata=32'd100000000;
            6'h28: O_prdata=MCU_TASKS; // bit0 CNN, bit1 AWB; additive capability word
            default: O_prdata=0;
        endcase
    end
    always @(posedge I_bus_clk or negedge I_bus_rst_n) begin
        if (!I_bus_rst_n) begin
            req_meta<=0; req_sync<=0; status_meta<=0; status_sync<=0;
            bus_ack<=0; bus_done<=0; snapshot<=0; claimed<=0; staged<=0;
            result_params<=0; result_update<=0;
            event_meta<=0; event_sync<=0; event_seen<=0; completion_event<=0; reject_event<=0;
        end else begin
            req_meta<=request; req_sync<=req_meta;
            status_meta<={I_timeout,I_retry,I_error,I_cfg_done,I_cam_done,I_manual,1'b1};
            status_sync<=status_meta;
            event_meta<=event_toggle; event_sync<=event_meta;
            if (event_sync!=event_seen) begin completion_event<=1; event_seen<=event_sync; end
            if (!req_sync) begin bus_ack<=0; bus_done<=0; claimed<=0; staged<=0; end
            else if (!bus_ack) begin
                snapshot<=request_bundle; bus_ack<=1; bus_done<=0; claimed<=0; staged<=0;
            end
            if (access && I_pwrite && !O_pslverr) begin
                case (I_paddr[5:0])
                    6'h18: if (req_sync && bus_ack && !bus_done &&
                               I_pwdata=={16'd0,snapshot[58:43]}) claimed<=1;
                            else reject_event<=1;
                    6'h1c: if (req_sync && bus_ack && claimed && !bus_done) begin
                                result_params<=I_pwdata[18:0]; result_update<=I_pwdata[19];
                                staged<= (I_pwdata[31:20]==0 && I_pwdata[10:0]>=4 &&
                                          I_pwdata[10:0]<=1991 && I_pwdata[18:11]>=16 && I_pwdata[18:11]<=208);
                            end else reject_event<=1;
                    6'h20: if (req_sync && bus_ack && claimed && staged && !bus_done &&
                               I_pwdata=={16'd0,snapshot[58:43]}) begin
                                bus_done<=1;
                            end else reject_event<=1;
                    6'h24: begin
                        if (I_pwdata[0] && event_sync==event_seen) completion_event<=0;
                        if (I_pwdata[1]) reject_event<=0;
                    end
                    default: begin end
                endcase
            end
        end
    end
endmodule
