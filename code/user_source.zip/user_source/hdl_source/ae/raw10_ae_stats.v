`timescale 1ns / 1ps

// Passive meter: 16 four-pixel beats on 512 distributed lines = 32768 pixels.
// A 32/45 line accumulator keeps 256 lines of each Bayer phase. AVERAGE is
// bit-identical to v1.5. CENTER weights are 8 in the central 320x180 window,
// 4 in the surrounding 640x360 window, and 1 elsewhere. The grid contains
// 512 inner, 1536 surrounding and 6144 outer beats: total weight = 16384.
// Mean and highlight ratios therefore still use only adds and bit slices.
// One accumulator bank and the original two-stage statistics pipeline are
// shared by both modes; the video path is untouched.
module raw10_ae_stats (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_frame_start,
    input  wire        I_valid,
    input  wire [39:0] I_raw,
    input  wire        I_center,
    output reg         O_valid,
    output reg  [7:0]  O_mean,
    output reg  [7:0]  O_clip_ratio, O_near_ratio,
    output reg         O_center
);
    reg [8:0] x;
    reg [9:0] y;
    reg [4:0] column_phase;
    reg [5:0] row_error;
    reg sample_line;
    reg frame_seen, frame_bad;
    reg sample_d0, sample_d1;
    (* async_reg = "true" *) reg center_meta, center_sync;
    reg center_frame;
    reg [1:0] weight_d0;
    reg [8:0] pair01, pair23;
    reg [1:0] clip01, clip23, near01, near23;
    reg [5:0] beat_clip, beat_near;
    reg [10:0] beat_mean;
    reg [21:0] sum;
    reg [16:0] clip_count, near_count;
    wire [6:0] next_row_error = {1'b0,row_error} + 7'd32;
    wire sample_now = frame_seen && !I_frame_start && I_valid &&
                      (y < 10'd720) && sample_line && (column_phase == 5'd9);
    wire [9:0] four_sum = {1'b0, pair01} + {1'b0, pair23};
    wire [2:0] four_clip = {1'b0,clip01} + {1'b0,clip23};
    wire [2:0] four_near = {1'b0,near01} + {1'b0,near23};
    wire in_middle = (x >= 9'd80) && (x < 9'd240) &&
                     (y >= 10'd180) && (y < 10'd540);
    wire in_inner = (x >= 9'd120) && (x < 9'd200) &&
                    (y >= 10'd270) && (y < 10'd450);
    wire [7:0] p0=I_raw[9:2], p1=I_raw[19:12], p2=I_raw[29:22], p3=I_raw[39:32];

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            x <= 9'd0; y <= 10'd0;
            column_phase <= 0; row_error <= 32; sample_line <= 0;
            frame_seen <= 1'b0; frame_bad <= 1'b0;
            sample_d0 <= 1'b0; sample_d1 <= 1'b0;
            center_meta <= 0; center_sync <= 0; center_frame <= 0;
            weight_d0 <= 0; O_center <= 0;
            pair01 <= 9'd0; pair23 <= 9'd0; beat_mean <= 11'd0;
            clip01 <= 0; clip23 <= 0; near01 <= 0; near23 <= 0;
            beat_clip <= 0; beat_near <= 0;
            sum <= 22'd0; clip_count <= 0; near_count <= 0;
            O_valid <= 1'b0; O_mean <= 8'd0; O_clip_ratio <= 0; O_near_ratio <= 0;
        end else begin
            O_valid <= 1'b0;
            center_meta <= I_center;
            center_sync <= center_meta;
            sample_d0 <= sample_now;
            sample_d1 <= sample_d0;
            if (sample_now) begin
                weight_d0 <= {center_frame && in_inner, center_frame && in_middle};
                pair01 <= {1'b0, I_raw[9:2]} + {1'b0, I_raw[19:12]};
                pair23 <= {1'b0, I_raw[29:22]} + {1'b0, I_raw[39:32]};
                clip01 <= {1'b0,(p0>=8'd240)} + {1'b0,(p1>=8'd240)};
                clip23 <= {1'b0,(p2>=8'd240)} + {1'b0,(p3>=8'd240)};
                near01 <= {1'b0,(p0>=8'd192)} + {1'b0,(p1>=8'd192)};
                near23 <= {1'b0,(p2>=8'd192)} + {1'b0,(p3>=8'd192)};
            end
            if (sample_d0) begin
                // Constant shifts are wiring, not a variable barrel shifter.
                // Round each four-pixel beat exactly as in AVERAGE first.
                case (weight_d0)
                    2'b11: begin
                        beat_mean <= {four_sum[9:2],3'b000};
                        beat_clip <= {four_clip,3'b000};
                        beat_near <= {four_near,3'b000};
                    end
                    2'b01: begin
                        beat_mean <= {1'b0,four_sum[9:2],2'b00};
                        beat_clip <= {1'b0,four_clip,2'b00};
                        beat_near <= {1'b0,four_near,2'b00};
                    end
                    default: begin
                        beat_mean <= {3'b000,four_sum[9:2]};
                        beat_clip <= {3'b000,four_clip};
                        beat_near <= {3'b000,four_near};
                    end
                endcase
            end
            if (sample_d1) begin
                sum <= sum + {11'd0, beat_mean};
                clip_count <= clip_count + {11'd0,beat_clip};
                near_count <= near_count + {11'd0,beat_near};
            end

            if (I_frame_start) begin
                // Exactly 320*720 valid beats, and an empty meter pipeline.
                // Short/long frames are discarded instead of biasing AE.
                if (frame_seen && !frame_bad && (x == 9'd0) &&
                    (y == 10'd720) && !sample_d0 && !sample_d1) begin
                    O_mean <= center_frame ? sum[21:14] : sum[20:13];
                    O_clip_ratio <= center_frame ?
                        (clip_count[16] ? 8'hff : clip_count[15:8]) :
                        (clip_count[15] ? 8'hff : clip_count[14:7]);
                    O_near_ratio <= center_frame ?
                        (near_count[16] ? 8'hff : near_count[15:8]) :
                        (near_count[15] ? 8'hff : near_count[14:7]);
                    O_center <= center_frame;
                    O_valid <= 1'b1;
                end
                x <= I_valid ? 9'd1 : 9'd0;
                y <= 10'd0;
                column_phase <= I_valid ? 5'd1 : 5'd0;
                row_error <= 32; sample_line <= 0;
                frame_seen <= 1'b1; frame_bad <= 1'b0;
                center_frame <= center_sync;
                sample_d0 <= 1'b0; sample_d1 <= 1'b0;
                sum <= 22'd0; clip_count <= 0; near_count <= 0;
            end else if (frame_seen && I_valid) begin
                if (y == 10'd720) frame_bad <= 1'b1;
                else begin
                    column_phase <= (column_phase == 19) ? 5'd0 : column_phase + 5'd1;
                    if (x == 9'd319) begin
                        x <= 9'd0; y <= y + 10'd1;
                        sample_line <= (next_row_error >= 45);
                        row_error <= (next_row_error >= 45) ? next_row_error - 7'd45 : next_row_error[5:0];
                    end else x <= x + 9'd1;
                end
            end
        end
    end
endmodule
