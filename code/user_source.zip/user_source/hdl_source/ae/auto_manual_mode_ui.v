`timescale 1ns/1ps

// Reusable persistent AUTO/MANUAL selector. Key k toggles mode k only in the
// enabled menu. Context changes disarm keys until release; bounce/long holds
// cannot toggle twice. Unused modes generate no counters when MODE_COUNT=1.
module auto_manual_mode_ui #(
    parameter integer MODE_COUNT = 1,
    parameter integer HOLD_CYCLES = 476190,
    parameter [MODE_COUNT-1:0] DEFAULT_AUTO = {MODE_COUNT{1'b1}}
) (
    input wire I_clk, I_rst_n,
    input wire I_enable,
    input wire [MODE_COUNT-1:0] I_key_n,
    output reg [MODE_COUNT-1:0] O_auto
);
    localparam integer COUNT_WIDTH = (HOLD_CYCLES < 2) ? 1 : $clog2(HOLD_CYCLES);
    reg enabled_d;
    reg [MODE_COUNT-1:0] armed;
    reg [COUNT_WIDTH-1:0] count [0:MODE_COUNT-1];
    integer k;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_auto <= DEFAULT_AUTO;
            enabled_d <= 1'b0;
            armed <= {MODE_COUNT{1'b0}};
            for (k=0; k<MODE_COUNT; k=k+1) count[k] <= {COUNT_WIDTH{1'b0}};
        end else begin
            enabled_d <= I_enable;
            for (k=0; k<MODE_COUNT; k=k+1) begin
                if (!I_enable || !enabled_d) begin
                    count[k] <= {COUNT_WIDTH{1'b0}};
                    armed[k] <= 1'b0;
                end else if (I_key_n[k]) begin
                    count[k] <= {COUNT_WIDTH{1'b0}};
                    armed[k] <= 1'b1;
                end else if (armed[k]) begin
                    if (count[k] == HOLD_CYCLES-1) begin
                        count[k] <= {COUNT_WIDTH{1'b0}};
                        armed[k] <= 1'b0;
                        O_auto[k] <= ~O_auto[k];
                    end else count[k] <= count[k] + 1'b1;
                end
            end
        end
    end
endmodule
