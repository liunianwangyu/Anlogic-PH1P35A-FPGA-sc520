`timescale 1ns / 1ps

// SC520CS-03 factory 720p60: VTS=1000, exposure=4..1991 half-lines.
// I_manual is a persistent GLOBAL mode. I_key_n is routed by ae_mode_ui.
// Manual bank, button direction and repeat cadence match ae_set.v; the gain
// ceiling is extended consistently so AUTO->MANUAL can inherit any setting.
// Auto starts at maximum exposure/unity gain and changes only sensor settings.
module sc520_ae_control #(
    parameter [7:0] TARGET_LOW = 8'd112,
    parameter [7:0] TARGET_HIGH = 8'd128,
    parameter [7:0] FAST_LOW = 8'd64,
    parameter [7:0] FAST_HIGH = 8'd160,
    parameter [7:0] AUTO_GAIN_MAX = 8'd208,
    parameter [7:0] MANUAL_GAIN_MAX = 8'd208,
    parameter [7:0] CLIP_LIMIT = 8'd16,
    parameter [7:0] NEAR_LIMIT = 8'd12,
    parameter [7:0] GAIN_STEP = 8'd4,
    // Six SC520 fine codes increase gain by at most 18.75%, leaving noise
    // margin in the 192..239 hold band (16 codes could jump across it).
    parameter [7:0] FAST_GAIN_STEP = 8'd6,
    parameter [2:0] SETTLE_FRAMES = 3'd3,
    parameter integer MANUAL_TICK_CYCLES = 100000
) (
    input wire I_clk, I_rst_n,
    input wire I_manual,
    input wire [3:0] I_key_n,
    input wire I_cam_cfg_done, I_ae_cfg_done, I_iic_error,
    input wire I_stats_valid,
    input wire [7:0] I_mean,
    output reg O_ae_req,
    output wire [15:0] O_ae,
    output wire [15:0] O_ag,
    input wire [7:0] I_clip_ratio, I_near_ratio
);
    localparam [1:0] IDLE = 2'd0, WAIT_BUSY = 2'd1, WAIT_DONE = 2'd2;
    reg [1:0] state;
    reg [10:0] exposure;
    reg [7:0] gain;
    reg initialized, manual_d;
    reg [2:0] settle;
    reg [16:0] tick_count;
    reg [4:0] gain_tick_count;
    reg [10:0] manual_exposure;
    reg [7:0] manual_gain;
    wire tick = (tick_count == MANUAL_TICK_CYCLES - 1);
    wire gain_tick = tick && (&gain_tick_count);
    // Fractions of 256 pixels. Protect broad highlights even if a dark
    // background keeps the mean inside the target band. A separate >=192
    // bin inhibits brightening before those same highlights clip again.
    // NEAR_LIMIT < CLIP_LIMIT also absorbs highlight-area sampling noise;
    // this avoids a clipped/unclipped frame oscillation. Small glints pass.
    wire clipped = (I_clip_ratio >= CLIP_LIMIT);
    wire dark = (I_mean < TARGET_LOW) && !clipped && (I_near_ratio < NEAR_LIMIT);
    wire bright = (I_mean > TARGET_HIGH) || clipped;
    wire fast = (I_mean < FAST_LOW) || (I_mean > FAST_HIGH) || (I_clip_ratio >= 8'd32);
    wire [10:0] step_shift = fast ? {2'd0, exposure[10:2]} : {4'd0, exposure[10:4]};
    wire [10:0] exposure_step = (step_shift == 11'd0) ? 11'd1 : step_shift;
    wire [11:0] exposure_up = {1'b0, exposure} + {1'b0, exposure_step};
    wire [11:0] min_plus_step = 12'd4 + {1'b0, exposure_step};
    wire [7:0] gain_step = fast ? FAST_GAIN_STEP : GAIN_STEP;
    wire [8:0] gain_up = {1'b0, gain} + {1'b0, gain_step};
    wire [8:0] min_gain_plus_step = 9'd16 + {1'b0, gain_step};
    assign O_ae = {5'd0, exposure};
    assign O_ag = {8'd0, gain};

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            tick_count <= 17'd0; gain_tick_count <= 5'd0;
            manual_exposure <= 11'd1991; manual_gain <= 8'd144;
        end else begin
            if (tick) begin
                tick_count <= 17'd0;
                gain_tick_count <= gain_tick_count + 5'd1;
            end else tick_count <= tick_count + 17'd1;
            if (I_manual && !manual_d) begin
                // Inherit the latest issued (and atomically held) sensor
                // command even when a mode change occurs during I2C busy.
                // Manual entry does not jump back to an older manual bank.
                manual_exposure <= exposure;
                manual_gain <= gain;
            end else if (I_manual) begin
                if (tick) begin
                    if (!I_key_n[0] && (manual_exposure > 11'd4))
                        manual_exposure <= manual_exposure - 11'd1;
                    else if (I_key_n[0] && !I_key_n[1] && (manual_exposure < 11'd1991))
                        manual_exposure <= manual_exposure + 11'd1;
                end
                if (gain_tick) begin
                    if (!I_key_n[2] && (manual_gain > 8'd16))
                        manual_gain <= manual_gain - 8'd1;
                    else if (I_key_n[2] && !I_key_n[3] && (manual_gain < MANUAL_GAIN_MAX))
                        manual_gain <= manual_gain + 8'd1;
                end
            end
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= IDLE; O_ae_req <= 1'b0;
            exposure <= 11'd1991; gain <= 8'd16;
            initialized <= 1'b0; manual_d <= 1'b0; settle <= SETTLE_FRAMES;
        end else begin
            O_ae_req <= 1'b0;
            manual_d <= I_manual;
            // A mode change never edits the command currently being written.
            // Returning to auto inherits the sensor's current settings, then
            // skips old measurements before using a fresh completed frame.
            if (manual_d != I_manual) settle <= SETTLE_FRAMES;
            if (!I_iic_error) begin
                case (state)
                    IDLE: if (I_cam_cfg_done && I_ae_cfg_done) begin
                        if (!initialized) begin
                            exposure <= I_manual ? manual_exposure : 11'd1991;
                            gain <= I_manual ? manual_gain : 8'd16;
                            initialized <= 1'b1;
                            O_ae_req <= 1'b1; state <= WAIT_BUSY;
                        end else if (I_manual && manual_d) begin
                            if ((exposure != manual_exposure) || (gain != manual_gain)) begin
                                exposure <= manual_exposure; gain <= manual_gain;
                                O_ae_req <= 1'b1; state <= WAIT_BUSY;
                            end
                        end else if (!I_manual && I_stats_valid && (manual_d == I_manual)) begin
                            if (settle != 3'd0) settle <= settle - 3'd1;
                            else if (dark) begin
                                if (exposure < 11'd1991) begin
                                    exposure <= (exposure_up > 12'd1991) ? 11'd1991 : exposure_up[10:0];
                                    O_ae_req <= 1'b1; state <= WAIT_BUSY;
                                end else if (gain < AUTO_GAIN_MAX) begin
                                    gain <= (gain_up > {1'b0, AUTO_GAIN_MAX}) ? AUTO_GAIN_MAX : gain_up[7:0];
                                    O_ae_req <= 1'b1; state <= WAIT_BUSY;
                                end
                            end else if (bright) begin
                                if (gain > 8'd16) begin
                                    gain <= ({1'b0, gain} <= min_gain_plus_step) ? 8'd16 : gain - gain_step;
                                    O_ae_req <= 1'b1; state <= WAIT_BUSY;
                                end else if (exposure > 11'd4) begin
                                    exposure <= ({1'b0, exposure} <= min_plus_step) ? 11'd4 : exposure - exposure_step;
                                    O_ae_req <= 1'b1; state <= WAIT_BUSY;
                                end
                            end
                        end
                    end
                    WAIT_BUSY: if (!I_ae_cfg_done) state <= WAIT_DONE;
                    WAIT_DONE: if (I_ae_cfg_done) begin
                        state <= IDLE;
                        // The sensor applies writes at N+2. Three complete
                        // readings after DONE are discarded conservatively.
                        settle <= SETTLE_FRAMES;
                    end
                    default: state <= IDLE;
                endcase
            end
        end
    end
endmodule
