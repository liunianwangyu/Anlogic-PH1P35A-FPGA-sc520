// Observational five-second windows. Arithmetic and the existing UI renderer
// are shared with the MCU: no second divider, font ROM, pixel pipe or timebase.
module video_latency_stats #(parameter WINDOW_MS=5000)(
 input I_clk,I_rst_n,input [15:0] I_time_ms,
 input I_sample_valid,input [9:0] I_sample_ms,input I_sample_hold,
 input [7:0] I_sample_bad_reason,input I_clear,
 output reg [143:0] O_snapshot
);
 reg started;
 reg [15:0] start_ms,n,holds,bads,window_seq;
 reg [31:0] total;
 reg [9:0] low,high,latest;
 reg [7:0] reasons,generation;
 reg overflow;
 wire [15:0] age=I_time_ms-start_ms;
 wire close_window=started&&age>=WINDOW_MS;
 wire bad=I_sample_valid&&(I_sample_bad_reason!=0||I_sample_ms>999);
 wire hold_event=I_sample_valid&&!bad&&I_sample_hold;
 wire good=I_sample_valid&&!bad&&!I_sample_hold;
 always @(posedge I_clk or negedge I_rst_n)
  if(!I_rst_n)begin
   started<=0;start_ms<=0;n<=0;holds<=0;bads<=0;window_seq<=0;
   total<=0;low<=999;high<=0;latest<=0;reasons<=0;generation<=0;overflow<=0;O_snapshot<=0;
  end else if(I_clear)begin
   started<=1;start_ms<=I_time_ms;n<=0;holds<=0;bads<=0;total<=0;
   low<=999;high<=0;latest<=0;reasons<=0;overflow<=0;
   generation<=generation+1'b1;window_seq<=window_seq+1'b1;
   O_snapshot<={generation+8'd1,window_seq+16'd1,120'd0};
  end else begin
   if(!started)begin started<=1;start_ms<=I_time_ms;end
   if(close_window)begin
    // [start,end): the boundary event initializes the next window on this
    // very edge. No delayed clear can erase it. Saturated windows are marked.
    window_seq<=window_seq+1'b1;
    O_snapshot<={generation,window_seq+16'd1,1'b1,overflow,reasons,latest,high,low,bads,holds,n,total};
    start_ms<=I_time_ms;total<=good?{22'd0,I_sample_ms}:32'd0;
    n<=good?16'd1:16'd0;holds<=hold_event?16'd1:16'd0;bads<=bad?16'd1:16'd0;
    low<=good?I_sample_ms:10'd999;high<=good?I_sample_ms:10'd0;
    latest<=good?I_sample_ms:10'd0;
    reasons<=bad?(I_sample_bad_reason|(I_sample_ms>999?8'h20:8'h00)):8'd0;overflow<=0;
   end else if(I_sample_valid)begin
    if(bad)begin
     if(bads==65535)overflow<=1;else bads<=bads+1'b1;
     reasons<=reasons|I_sample_bad_reason|(I_sample_ms>999?8'h20:8'h00);
    end else if(hold_event)begin
     if(holds==65535)overflow<=1;else holds<=holds+1'b1;
    end else begin
     if(n==65535)overflow<=1;
     else begin
      total<=total+{22'd0,I_sample_ms};n<=n+1'b1;latest<=I_sample_ms;
      if(I_sample_ms<low)low<=I_sample_ms;
      if(I_sample_ms>high)high<=I_sample_ms;
     end
    end
   end
  end
endmodule

// The last seven words of the existing MOT2 window. Original snapshot/mask/
// COMMIT offsets are untouched. A command crosses only at a display frame
// boundary. Both mailboxes hold payloads until acknowledgement; reads have
// no side effects and a busy command is explicitly rejected.
module video_latency_diagnostics(
 input I_clk,I_rst_n,I_frame,
 input I_stats_clk,I_stats_rst_n,input [143:0] I_snapshot,
 output O_clear,
 input [5:0] I_paddr,input I_psel,I_penable,I_pwrite,input [31:0] I_pwdata,
 output reg [31:0] O_prdata,output O_pready,O_pslverr
);
 wire reset_n=I_rst_n&&I_stats_rst_n;
 reg busy,pending,clear_request;
 reg [143:0] snapshot;
 reg [15:0] snapshot_seq;
 wire command_ready,command_event,command_clear;
 wire reply_ready,reply_event;
 wire [143:0] reply;
 reg reply_pending,reply_send;
 wire access=I_psel&&I_penable;
 wire write_ok=I_paddr==6'h24&&!busy&&I_pwdata[0]&&I_pwdata[31:2]==0;
 wire read_ok=I_paddr>=6'h24&&I_paddr[1:0]==0;
 assign O_pready=1'b1;
 assign O_pslverr=access&&(I_pwrite?!write_ok:!read_ok);
 wire wr=access&&I_pwrite&&!O_pslverr;
 video_latency_mailbox #(.WIDTH(1)) u_command(
  .I_src_clk(I_clk),.I_dst_clk(I_stats_clk),.I_rst_n(reset_n),
  .I_valid(pending&&I_frame),.I_data(clear_request),.O_ready(command_ready),
  .O_valid(command_event),.O_data(command_clear));
 assign O_clear=command_event&&command_clear;
 // Wait a full stats clock after clear, so the returned generation and
 // empty-window flags belong to the new epoch rather than the old snapshot.
 always @(posedge I_stats_clk or negedge reset_n)
  if(!reset_n)begin reply_pending<=0;reply_send<=0;end
  else begin
   reply_send<=0;
   if(command_event)reply_pending<=1;
   else if(reply_pending&&reply_ready)begin reply_pending<=0;reply_send<=1;end
  end
 video_latency_mailbox #(.WIDTH(144)) u_reply(
  .I_src_clk(I_stats_clk),.I_dst_clk(I_clk),.I_rst_n(reset_n),
  .I_valid(reply_send),.I_data(I_snapshot),.O_ready(reply_ready),.O_valid(reply_event),.O_data(reply));
 always @(posedge I_clk or negedge reset_n)
  if(!reset_n)begin busy<=0;pending<=0;clear_request<=0;snapshot<=0;snapshot_seq<=0;end
  else begin
   if(wr)begin busy<=1;pending<=1;clear_request<=I_pwdata[1];end
   if(pending&&I_frame&&command_ready)pending<=0;
   if(reply_event)begin snapshot<=reply;snapshot_seq<=snapshot_seq+1'b1;busy<=0;end
  end
 always @*begin
  O_prdata=0;
  case(I_paddr)
   6'h24:O_prdata={snapshot_seq,14'd0,!busy,busy};
   6'h28:O_prdata=snapshot[31:0]; // SUM
   6'h2c:O_prdata=snapshot[63:32]; // HOLD,N
   6'h30:O_prdata={6'd0,snapshot[89:80],snapshot[79:64]}; // MIN,BAD
   6'h34:O_prdata={2'd0,snapshot[119:90]}; // closed,overflow,reason,last,MAX
   6'h38:O_prdata={8'd0,snapshot[143:120]}; // generation,window window_seq
   6'h3c:O_prdata=32'h4c415431; // LAT1. No claim of full MOT3 hardware.
   default:begin end
  endcase
 end
endmodule
