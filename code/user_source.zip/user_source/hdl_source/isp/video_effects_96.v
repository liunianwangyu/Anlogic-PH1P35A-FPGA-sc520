// Four pixels per beat, ordered from [95:72] (leftmost) to [23:0].
// RGB channels inside each pixel are R[23:16], G[15:8], B[7:0].
module rgb_quantize4 (
    input  wire [95:0] I_rgb,
    output wire [95:0] O_rgb
);
    function [7:0] q3;
        input [7:0] channel;
        begin q3 = {channel[7:5], channel[7:5], channel[7:6]}; end
    endfunction
    genvar p;
    generate for (p = 0; p < 4; p = p + 1) begin : pixel
        wire [23:0] rgb = I_rgb[95-p*24 -: 24];
        assign O_rgb[95-p*24 -: 24] =
            {q3(rgb[23:16]), q3(rgb[15:8]), q3(rgb[7:0])};
    end endgenerate
endmodule

// Inclusive RGB thresholds. Mask[3] belongs to the leftmost pixel.
module color_segment4 (
    input  wire [95:0] I_rgb,
    input  wire [47:0] I_limits, // {R_lo,R_hi,G_lo,G_hi,B_lo,B_hi}
    output wire [3:0]  O_mask
);
    genvar p;
    generate for (p = 0; p < 4; p = p + 1) begin : pixel
        wire [23:0] rgb = I_rgb[95-p*24 -: 24];
        assign O_mask[3-p] =
            (rgb[23:16] >= I_limits[47:40]) && (rgb[23:16] <= I_limits[39:32]) &&
            (rgb[15:8]  >= I_limits[31:24]) && (rgb[15:8]  <= I_limits[23:16]) &&
            (rgb[7:0]   >= I_limits[15:8])  && (rgb[7:0]   <= I_limits[7:0]);
    end endgenerate
endmodule

// v2.3 preset classifier, four RGB888 pixels/clock, exactly three clocks.
// Select the target first: when T dominates, M=T and m=min(A,B). This
// shares the colour features instead of building three complete classifiers.
// Only comparisons, subtraction and widened constant shifts/adds are used.
module color_classify4 (
    input wire I_clk,I_rst_n,I_valid,
    input wire [95:0] I_rgb,
    input wire [47:0] I_limits,
    input wire [1:0] I_target,I_sensitivity,
    input wire I_custom_rgb,
    output wire [3:0] O_mask
);
    wire [3:0] custom_hit;
    color_segment4 u_custom(.I_rgb(I_rgb),.I_limits(I_limits),.O_mask(custom_hit));
    reg [2:0] live;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)live<=0;
        else live<={live[1:0],I_valid&&(I_target!=2'd3)};
    genvar p;
    generate for(p=0;p<4;p=p+1)begin:g_classify
        wire [23:0] rgb=I_rgb[95-p*24-:24];
        reg [7:0] t,a,b;
        always @(*)begin
            case(I_target)
                2'd1:begin t=rgb[15:8];a=rgb[23:16];b=rgb[7:0];end
                2'd2:begin t=rgb[7:0];a=rgb[23:16];b=rgb[15:8];end
                default:begin t=rgb[23:16];a=rgb[15:8];b=rgb[7:0];end
            endcase
        end
        wire [7:0] lo=(a<b)?a:b,hi=(a<b)?b:a;
        reg [7:0] t1,lo1,hi1,t2,d2,u2;
        reg dominant1,dominant2,custom1,custom2,hit1,hit2,result3;
        reg [1:0] sensitivity1,sensitivity2;
        wire [10:0] dw={3'd0,d2},uw={3'd0,u2},mw={3'd0,t2};
        wire [7:0] vmin=(sensitivity2==0)?8'd32:((sensitivity2==2)?8'd48:8'd40);
        wire [10:0] ks_m=(sensitivity2==0)?mw:
            ((sensitivity2==2)?((mw<<1)+mw):(mw<<1));
        wire [10:0] kh_d=(sensitivity2==0)?((dw<<2)+dw):
            ((sensitivity2==2)?((dw<<1)+dw):(dw<<2));
        // Datapath registers need no reset: the three valid bits mask every
        // unfilled stage, including an asynchronous reset in a partial frame.
        always @(posedge I_clk)begin
            t1<=t;lo1<=lo;hi1<=hi;
            dominant1<=(t>=hi);
            sensitivity1<=I_sensitivity;
            custom1<=I_custom_rgb;hit1<=custom_hit[3-p];
            t2<=t1;
            // Widen before arithmetic. A non-dominant pixel is rejected;
            // only its unused negative chroma would be truncated here.
            d2<=({1'b0,t1}-{1'b0,lo1});
            u2<=({1'b0,hi1}-{1'b0,lo1});
            dominant2<=dominant1;sensitivity2<=sensitivity1;
            custom2<=custom1;hit2<=hit1;
            result3<=custom2?hit2:(dominant2&&(t2>=vmin)&&
                ((dw<<3)>=ks_m)&&((uw<<3)<=kh_d));
        end
        assign O_mask[3-p]=I_rst_n&&live[2]&&result3;
    end endgenerate
endmodule

module region_paint4 (
    input  wire [95:0] I_rgb,
    input  wire [3:0]  I_mask,
    input  wire [23:0] I_color,
    output wire [95:0] O_rgb
);
    genvar p;
    generate for (p = 0; p < 4; p = p + 1) begin : pixel
        assign O_rgb[95-p*24 -: 24] =
            I_mask[3-p] ? I_color : I_rgb[95-p*24 -: 24];
    end endgenerate
endmodule

// Four-clock separable 3x3 median for RGB333 and the binary decision.
// Quantization commutes with median, so RGB333 loses no displayed precision.
// Each row packs four RGB333 pixels plus four mask bits into 40 bits. Both
// 20-bit read-before-write ports address opposite halves of ONE ERAM20K;
// two rows therefore cost two blocks, shared by binary and cartoon modes.
// RGB maps to (previous row, x-2..x+1), retaining the historical cartoon crop.
// Binary uses the same interior mapping; its top/left border bypasses filtering.
module cartoon_mix4 #(
    parameter integer IMG_WIDTH = 1280,
    parameter integer IMG_HEIGHT = 720
)(
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_tuser,
    input  wire        I_tvalid,
    input  wire [95:0] I_rgb,
    input  wire [3:0]  I_binary_mask,
    input  wire [95:0] I_edge,
    input  wire [1:0]  I_strong_edge,
    output wire [95:0] O_rgb,
    output wire [3:0]  O_binary_mask
);
    localparam integer WORDS = IMG_WIDTH / 4;
    localparam integer ADDR_W = (WORDS > 1) ? $clog2(WORDS) : 1;
    reg [ADDR_W-1:0] x, addr_d;
    reg [10:0] y;
    wire [ADDR_W-1:0] addr = I_tuser ? {ADDR_W{1'b0}} : x;
    reg [29:0] tail;
    wire [39:0] packed_pixels;
    genvar p;
    generate for (p=0;p<4;p=p+1) begin : pack
        wire [23:0] rgb=I_rgb[95-p*24 -: 24];
        assign packed_pixels[39-p*10 -: 10] =
            {rgb[23:21],rgb[15:13],rgb[7:5],I_binary_mask[3-p]};
    end endgenerate
    wire [69:0] neighbours={tail,packed_pixels};
    function [2:0] median3;
        input [2:0] a,b,c;
        begin median3=(a<b)?((b<c)?b:((a<c)?c:a)):
                              ((a<c)?a:((b<c)?c:b)); end
    endfunction
    function [9:0] rank3;
        input [9:0] a,b,c;
        begin rank3={median3(a[9:7],b[9:7],c[9:7]),
                     median3(a[6:4],b[6:4],c[6:4]),
                     median3(a[3:1],b[3:1],c[3:1]),
                     ((a[0]&b[0])|(a[0]&c[0])|(b[0]&c[0]))}; end
    endfunction
    wire [39:0] horizontal;
    generate for (p=0;p<4;p=p+1) begin : horizontal_rank
        assign horizontal[39-p*10 -: 10]=rank3(
            neighbours[69-p*10 -: 10],neighbours[59-p*10 -: 10],
            neighbours[49-p*10 -: 10]);
    end endgenerate
    wire [39:0] row1,row2;
    wire [39:0] row_input[0:1];
    wire [ADDR_W-1:0] row_addr[0:1];
    wire [1:0] row_write;
    reg valid1,valid2,border1,border2,top1,top2;
    reg [39:0] current1,current2,middle2,base3,base4;
    reg [3:0] binary1,binary2;
    assign row_input[0]=horizontal;
    assign row_input[1]=row1;
    assign row_addr[0]=addr;
    assign row_addr[1]=addr_d;
    assign row_write={valid1,I_tvalid}&{2{I_rst_n}};
    genvar r;
    generate for (r=0;r<2;r=r+1) begin : lines
        wire [39:0] q;
        PH1P_LOGIC_ERAM #(
            .DATA_WIDTH_A(20),.DATA_WIDTH_B(20),
            .ADDR_WIDTH_A(ADDR_W+1),.ADDR_WIDTH_B(ADDR_W+1),
            .DATA_DEPTH_A(1 << (ADDR_W+1)),.DATA_DEPTH_B(1 << (ADDR_W+1)),
            .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
            .WRITEMODE_A("READBEFOREWRITE"),.WRITEMODE_B("READBEFOREWRITE"),
            .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
            .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),
            .OREGSET_A("RESET"),.OREGSET_B("RESET"),
            .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
            .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
            .INIT_FILE("NONE"),.FILL_ALL("NONE")
        ) u_line (
            .dia(row_input[r][39:20]),.dib(row_input[r][19:0]),
            .addra({row_addr[r],1'b0}),.addrb({row_addr[r],1'b1}),
            .cea(1'b1),.ceb(1'b1),.ocea(1'b0),.oceb(1'b0),
            .clka(I_clk),.clkb(I_clk),.wea(row_write[r]),.web(row_write[r]),
            .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
            .doa(q[39:20]),.dob(q[19:0]),.ecc_sbiterr(),.ecc_dbiterr(),
            .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0)
        );
        if(r==0)assign row1=q;
        else assign row2=q;
    end endgenerate
    wire [39:0] vertical;
    generate for (p=0;p<4;p=p+1) begin : vertical_rank
        // The first available source row is replicated at the top border.
        assign vertical[39-p*10 -: 10]=top2?middle2[39-p*10 -: 10]:
            rank3(row2[39-p*10 -: 10],middle2[39-p*10 -: 10],current2[39-p*10 -: 10]);
    end endgenerate
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)begin
            x<=0;y<=0;addr_d<=0;tail<=0;valid1<=0;valid2<=0;
            border1<=0;border2<=0;top1<=0;top2<=0;
            current1<=0;current2<=0;middle2<=0;base3<=0;base4<=0;
            binary1<=0;binary2<=0;
        end else begin
            valid1<=I_tvalid;valid2<=valid1;addr_d<=addr;
            border1<=I_tuser||(y==0)||(x==0);border2<=border1;
            top1<=I_tuser||(y<2);top2<=top1;
            current1<=horizontal;current2<=current1;middle2<=row1;
            binary1<=I_binary_mask;binary2<=binary1;
            if(I_tuser)begin
                x<=I_tvalid?1:0;y<=0;
                tail<=I_tvalid?packed_pixels[29:0]:30'd0;
            end else if(I_tvalid)begin
                tail<=packed_pixels[29:0];
                if(x==WORDS-1)begin x<=0;y<=(y==IMG_HEIGHT-1)?0:y+1'b1;end
                else x<=x+1'b1;
            end
            if(valid2)begin
                if(border2)base3<={9'd0,binary2[3],9'd0,binary2[2],9'd0,binary2[1],9'd0,binary2[0]};
                else base3<=vertical;
            end
            base4<=base3;
        end
    end
    generate for (p=0;p<4;p=p+1) begin : pixel
        wire [8:0] q=base4[39-p*10 -: 9];
        wire [23:0] rgb={q[8:6],q[8:6],q[8:7],q[5:3],q[5:3],q[5:4],q[2:0],q[2:0],q[2:1]};
        wire [23:0] shade={1'b0,rgb[23:17],1'b0,rgb[15:9],1'b0,rgb[7:1]};
        assign O_rgb[95-p*24 -: 24]=I_strong_edge[1-p/2]?24'd0:
            ((I_edge[95-p*24 -: 24]==24'hffffff)?shade:rgb);
        assign O_binary_mask[3-p]=base4[30-p*10];
    end endgenerate
endmodule

// Source holds the complete configuration until acknowledged. The CSI side
// receives one coherent bundle and applies it only at the AWB frame pulse.
// The source may change again while a transfer is in flight; its latest
// value is sent as soon as the previous transfer has completed.
module effect_config_cdc #(
    parameter integer WIDTH=75,
    parameter [WIDTH-1:0] DEFAULT_CONFIG = {3'd0,48'hA0FF00820082,24'h00ff00}
)(
    input  wire        I_src_clk,
    input  wire        I_dst_clk,
    input  wire        I_rst_n,
    input  wire [WIDTH-1:0] I_src_config,
    input  wire        I_dst_frame,
    output reg  [WIDTH-1:0] O_dst_active,
    output wire [WIDTH-1:0] O_dst_for_beat
);
    reg [WIDTH-1:0] src_hold, dst_pending;
    reg req_toggle, ack_toggle;
    reg ack_meta, ack_sync, req_meta, req_sync;
    always @(posedge I_src_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            src_hold <= DEFAULT_CONFIG;
            req_toggle <= 1'b0;
            ack_meta <= 1'b0;
            ack_sync <= 1'b0;
        end else begin
            ack_meta <= ack_toggle;
            ack_sync <= ack_meta;
            if ((req_toggle == ack_sync) && (src_hold != I_src_config)) begin
                src_hold <= I_src_config;
                req_toggle <= ~req_toggle;
            end
        end
    end
    always @(posedge I_dst_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            req_meta <= 1'b0;
            req_sync <= 1'b0;
            ack_toggle <= 1'b0;
            dst_pending <= DEFAULT_CONFIG;
            O_dst_active <= DEFAULT_CONFIG;
        end else begin
            req_meta <= req_toggle;
            req_sync <= req_meta;
            if (req_sync != ack_toggle) begin
                dst_pending <= src_hold;
                ack_toggle <= req_sync;
            end
            if (I_dst_frame)
                O_dst_active <= dst_pending;
        end
    end
    assign O_dst_for_beat = I_dst_frame ? dst_pending : O_dst_active;
endmodule

module effect_mux96 (
    input  wire [2:0]  I_mode,
    input  wire [95:0] I_original,
    input  wire [95:0] I_gray,
    input  wire [95:0] I_binary,
    input  wire [95:0] I_edge,
    input  wire [95:0] I_cartoon,
    input  wire [95:0] I_painted,
    input  wire [3:0]  I_mask,
    output reg  [95:0] O_rgb
);
    wire [95:0] mask_rgb = {{3{{8{I_mask[3]}}}},
                            {3{{8{I_mask[2]}}}},
                            {3{{8{I_mask[1]}}}},
                            {3{{8{I_mask[0]}}}}};
    always @* begin
        case (I_mode)
            3'd0: O_rgb = I_original;
            3'd1: O_rgb = I_gray;
            3'd2: O_rgb = I_binary;
            3'd3: O_rgb = I_edge;
            3'd4: O_rgb = I_cartoon;
            3'd5: O_rgb = I_painted;
            3'd6: O_rgb = mask_rgb;
            default: O_rgb = I_original;
        endcase
    end
endmodule

// Exact separable 3x3 Gaussian, four RGB888 pixels/clock.
// A shared horizontal median rejects impulses before Gaussian spreading.
// Kernel [1 2 1]'*[1 2 1]/16, one final rounding. Six native ERAM20K
// blocks hold both 120-bit horizontal-sum rows; no DSP or frame buffer.
// After the median the causal window is centred at (x-2,y-1). Top two rows and the first
// four-pixel beat bypass the window, never reading an uninitialised row.
module gaussian_rgb4 #(
    parameter integer IMG_WIDTH=1280, IMG_HEIGHT=720
)(
    input wire I_clk,I_rst_n,I_valid,I_user,I_last,
    input wire [95:0] I_rgb,
    output wire O_valid,O_user,O_last,
    output reg [95:0] O_rgb
);
    localparam integer WORDS=IMG_WIDTH/4;
    localparam integer AW=(WORDS>1)?$clog2(WORDS):1;
    reg [AW-1:0] x,addr_d;
    reg [10:0] y;
    wire [AW-1:0] addr=I_user?{AW{1'b0}}:x;
    reg [95:0] tail;
    wire [191:0] samples={tail,I_rgb};
    wire [143:0] ranked;
    function [7:0] median8;
        input [7:0] a,b,c;
        begin median8=(a<b)?((b<c)?b:((a<c)?c:a)):
                            ((a<c)?a:((b<c)?c:b));end
    endfunction
    wire [119:0] horizontal,row1,row2;
    reg [119:0] current1,current2,middle2;
    reg [95:0] raw1,raw2,filtered3;
    reg border1,border2;
    reg [3:0] vp,up,lp;
    genvar p,c,r,b,k,n;
    generate for(k=0;k<6;k=k+1)begin:g_rank
        for(n=0;n<3;n=n+1)begin:g_channel
            assign ranked[143-k*24-n*8-:8]=median8(
                samples[191-k*24-n*8-:8],samples[167-k*24-n*8-:8],samples[143-k*24-n*8-:8]);
        end
    end endgenerate
    generate for(p=0;p<4;p=p+1)begin:g_pixel
        for(c=0;c<3;c=c+1)begin:g_channel
            wire [7:0] a=ranked[143-p*24-c*8-:8];
            wire [7:0] m=ranked[119-p*24-c*8-:8];
            wire [7:0] z=ranked[95-p*24-c*8-:8];
            assign horizontal[119-p*30-c*10-:10]=
                {2'b0,a}+{1'b0,m,1'b0}+{2'b0,z};
            wire [9:0] top=row2[119-p*30-c*10-:10];
            wire [9:0] mid=middle2[119-p*30-c*10-:10];
            wire [9:0] bot=current2[119-p*30-c*10-:10];
            wire [11:0] total={2'b0,top}+{1'b0,mid,1'b0}+{2'b0,bot}+12'd8;
            always @(posedge I_clk or negedge I_rst_n)
                if(!I_rst_n)filtered3[95-p*24-c*8-:8]<=0;
                else filtered3[95-p*24-c*8-:8]<=border2?raw2[95-p*24-c*8-:8]:total[11:4];
        end
    end endgenerate
    generate for(r=0;r<2;r=r+1)begin:g_row
        wire [119:0] data_in=(r==0)?horizontal:row1;
        wire [AW-1:0] row_addr=(r==0)?addr:addr_d;
        wire write_row=I_rst_n&&((r==0)?I_valid:vp[0]);
        for(b=0;b<3;b=b+1)begin:g_bank
            wire [39:0] q;
            PH1P_LOGIC_ERAM #(
                .DATA_WIDTH_A(20),.DATA_WIDTH_B(20),
                .ADDR_WIDTH_A(AW+1),.ADDR_WIDTH_B(AW+1),
                .DATA_DEPTH_A(1 << (AW+1)),.DATA_DEPTH_B(1 << (AW+1)),
                .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
                .WRITEMODE_A("READBEFOREWRITE"),.WRITEMODE_B("READBEFOREWRITE"),
                .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
                .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),
                .OREGSET_A("RESET"),.OREGSET_B("RESET"),
                .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
                .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
                .INIT_FILE("NONE"),.FILL_ALL("NONE")
            ) u_ram (
                .dia(data_in[b*40+20+:20]),.dib(data_in[b*40+:20]),
                .addra({row_addr,1'b0}),.addrb({row_addr,1'b1}),
                .cea(1'b1),.ceb(1'b1),.ocea(1'b0),.oceb(1'b0),
                .clka(I_clk),.clkb(I_clk),.wea(write_row),.web(write_row),
                .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
                .doa(q[39:20]),.dob(q[19:0]),.ecc_sbiterr(),.ecc_dbiterr(),
                .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
            if(r==0)assign row1[b*40+:40]=q;
            else assign row2[b*40+:40]=q;
        end
    end endgenerate
    assign O_valid=vp[3];assign O_user=up[3];assign O_last=lp[3];
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            x<=0;y<=0;addr_d<=0;tail<=0;current1<=0;current2<=0;middle2<=0;
            raw1<=0;raw2<=0;border1<=0;border2<=0;vp<=0;up<=0;lp<=0;O_rgb<=0;
        end else begin
            vp<={vp[2:0],I_valid};up<={up[2:0],I_user};lp<={lp[2:0],I_last};
            addr_d<=addr;current1<=horizontal;current2<=current1;middle2<=row1;
            raw1<=I_rgb;raw2<=raw1;
            border1<=I_user||(y<2)||(x==0);border2<=border1;
            O_rgb<=filtered3;
            if(I_user)begin
                x<=I_valid?1:0;y<=0;tail<=I_valid?I_rgb:96'd0;
            end else if(I_valid)begin
                tail<=I_rgb;
                if(x==WORDS-1)begin x<=0;y<=(y==IMG_HEIGHT-1)?0:y+1'b1;end
                else x<=x+1'b1;
            end
        end
    end
endmodule
