module edge_detect_96 #(
    parameter IMG_WIDTH  = 1280,
    parameter IMG_HEIGHT = 720,
    parameter EDGE_TH    = 11'd80,
    parameter CARTOON_EDGE_TH = 11'd160,
    parameter integer RUNTIME_THRESHOLD=0
)(
    input               I_clk,
    input               I_rst_n,
    input               I_tlast,
    input               I_tuser,
    input      [95:0]   I_tdata,
    input               I_tvalid,
    input               I_tready,
    input      [10:0]   I_edge_threshold,
    output reg          O_tlast,
    output reg          O_tuser,
    output reg [95:0]   O_tdata,
    output reg          O_tvalid,
    output              O_tready,
    output reg [1:0]    O_cnn_edge,
    output reg [1:0]    O_cartoon_edge
);

// ---------------------------------------------------------------------
// Four-stage pipeline. EDGE_LATENCY=4; all ISP effect streams stay aligned.
//
//   S1 input/pair registers
//   S2 synchronous read of both packed rows and current-row alignment
//   S3 median-based gradients from the 3x3 neighbourhood
//   S4 magnitude, per-beat threshold and output
// No distributed row RAM or multiplier.
// ---------------------------------------------------------------------

assign O_tready = I_tready;

wire [23:0] pix0 = I_tdata[95:72];
wire [23:0] pix1 = I_tdata[71:48];
wire [23:0] pix2 = I_tdata[47:24];
wire [23:0] pix3 = I_tdata[23:0];

// Low-cost luminance approximation: R/4 + G/2 + B/4.  Its maximum is
// 253, so it cannot overflow an 8-bit result and requires no divider.
wire [7:0] gray0 = {2'b0,pix0[23:18]} + {1'b0,pix0[15:9]} + {2'b0,pix0[7:2]};
wire [7:0] gray1 = {2'b0,pix1[23:18]} + {1'b0,pix1[15:9]} + {2'b0,pix1[7:2]};
wire [7:0] gray2 = {2'b0,pix2[23:18]} + {1'b0,pix2[15:9]} + {2'b0,pix2[7:2]};
wire [7:0] gray3 = {2'b0,pix3[23:18]} + {1'b0,pix3[15:9]} + {2'b0,pix3[7:2]};

localparam IMG_WIDTH_GRP = (IMG_WIDTH >> 2);
localparam integer LINE_AW = (IMG_WIDTH_GRP > 1) ? $clog2(IMG_WIDTH_GRP) : 1;

// Two grayscale samples per 4-pixel beat, each representing a neighbouring
// pair of pixels: 640 horizontal edge samples per line.
wire [8:0] pair_sum0 = {1'b0,gray0} + {1'b0,gray1};
wire [8:0] pair_sum1 = {1'b0,gray2} + {1'b0,gray3};
wire [7:0] pair0 = pair_sum0[8:1];
wire [7:0] pair1 = pair_sum1[8:1];

// ---------------------------------------------------------------------
// S1: input register
// ---------------------------------------------------------------------
reg [7:0] pair0_d, pair1_d;
reg       valid_d, user_d, last_d;

always @(posedge I_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        pair0_d <= 8'd0;
        pair1_d <= 8'd0;
        valid_d <= 1'b0;
        user_d  <= 1'b0;
        last_d  <= 1'b0;
    end else begin
        pair0_d <= pair0;
        pair1_d <= pair1;
        valid_d <= I_tvalid;
        user_d  <= I_tuser;
        last_d  <= I_tlast;
    end
end

// ---------------------------------------------------------------------
// Line buffers.  The read address (x_grp) is a register and the read data
// is registered as well, so both memories infer block RAM instead of LUTRAM.
// ---------------------------------------------------------------------
wire [15:0] top_word,mid_word;      // S2 read data (one clock after address)
reg [7:0]  bot0_q,  bot1_q;         // current beat, aligned with top/mid
reg        valid_q, user_q, last_q;
reg [10:0] x_grp_q,y_pos_q;

// previous beat's two samples of each row (see window note below)
reg [7:0] top_prev2, top_prev1;
reg [7:0] mid_prev2, mid_prev1;
reg [7:0] bot_prev2, bot_prev1;

// ---------------------------------------------------------------------
// S3 registers: gradients, and the position / control of that beat
// ---------------------------------------------------------------------
reg [10:0] gx0_r, gy0_r, gx1_r, gy1_r;
reg        valid_q2, user_q2, last_q2;
reg [10:0] x_grp_q2,y_pos_q2;

// Two rows share addresses and enables. Explicit native simple-dual-port
// mode uses a 32-bit word in one 512x40 ERAM20K rather than splitting it
// across two 20-bit true-dual-port blocks. A writes only, B reads only;
// the same addresses and one-clock latency are retained. The read-only B
// port uses NORMAL, as required by the vendor's PDPW synthesis checker.
reg [10:0] x_grp,y_pos;
wire [10:0] read_x=user_d?11'd0:x_grp;
wire [10:0] read_y=user_d?11'd0:y_pos;
PH1P_LOGIC_ERAM #(
    .DATA_WIDTH_A(32), .DATA_WIDTH_B(32),
    .ADDR_WIDTH_A(LINE_AW), .ADDR_WIDTH_B(LINE_AW),
    .DATA_DEPTH_A(1 << LINE_AW), .DATA_DEPTH_B(1 << LINE_AW),
    .MODE("PDPW"), .REGMODE_A("NOREG"), .REGMODE_B("NOREG"),
    .WRITEMODE_A("NORMAL"), .WRITEMODE_B("NORMAL"),
    .IMPLEMENT("20K(FAST)"), .ECC_ENCODE("DISABLE"), .ECC_DECODE("DISABLE"),
    .CLKMODE("ASYNC"), .SSROVERCE("DISABLE"),
    .OREGSET_A("RESET"), .OREGSET_B("RESET"),
    .RESETMODE_A("ASYNC"), .RESETMODE_B("ASYNC"),
    .ASYNC_RESET_RELEASE_A("ASYNC"), .ASYNC_RESET_RELEASE_B("ASYNC"),
    .INIT_FILE("NONE"), .FILL_ALL("NONE")
) u_edge_lines (
    .dia({mid_word,bot0_q,bot1_q}), .dib(32'd0),
    .addra(x_grp_q[LINE_AW-1:0]), .addrb(read_x[LINE_AW-1:0]),
    .cea(1'b1), .ceb(1'b1), .ocea(1'b0), .oceb(1'b0),
    .clka(I_clk), .clkb(I_clk), .wea(I_rst_n && valid_q), .web(1'b0),
    .bea(1'b0), .beb(1'b0), .rsta(1'b0), .rstb(1'b0),
    .doa(), .dob({top_word,mid_word}), .ecc_sbiterr(), .ecc_dbiterr(),
    .ecc_sbiterrinj(1'b0), .ecc_dbiterrinj(1'b0)
);

wire [7:0] top0_w = top_word[15:8];
wire [7:0] top1_w = top_word[7:0];
wire [7:0] mid0_w = mid_word[15:8];
wire [7:0] mid1_w = mid_word[7:0];

// Robust 3x3 gradient: median down each outer column / across each
// outer row rejects an isolated outlier before taking a difference.
// Multiplication by four is wiring and preserves the Sobel step-edge scale
// (+/-1020). The existing two-row RAM and four-clock interface are reused.
function [7:0] median3;
    input [7:0] a,b,c;
    begin median3=(a<b)?((b<c)?b:((a<c)?c:a)):
                          ((a<c)?a:((b<c)?c:b)); end
endfunction
function [10:0] sob_gx;
    input [7:0] a00,a01,a02,a10,a11,a12,a20,a21,a22;
    reg signed [10:0] t;
    begin
        t=$signed({1'b0,median3(a02,a12,a22)})-$signed({1'b0,median3(a00,a10,a20)});
        sob_gx=t <<< 2;
    end
endfunction
function [10:0] sob_gy;
    input [7:0] a00,a01,a02,a10,a11,a12,a20,a21,a22;
    reg signed [10:0] t;
    begin
        t=$signed({1'b0,median3(a00,a01,a02)})-$signed({1'b0,median3(a20,a21,a22)});
        sob_gy=t <<< 2;
    end
endfunction

// ---- magnitude stage (S3): combinational, registered into O_tdata ----
wire signed [10:0] gx0_s = gx0_r;
wire signed [10:0] gy0_s = gy0_r;
wire signed [10:0] gx1_s = gx1_r;
wire signed [10:0] gy1_s = gy1_r;

wire [10:0] abs_gx0 = gx0_s[10] ? (~gx0_s + 11'd1) : gx0_s;
wire [10:0] abs_gy0 = gy0_s[10] ? (~gy0_s + 11'd1) : gy0_s;
wire [10:0] abs_gx1 = gx1_s[10] ? (~gx1_s + 11'd1) : gx1_s;
wire [10:0] abs_gy1 = gy1_s[10] ? (~gy1_s + 11'd1) : gy1_s;

wire [11:0] mag0 = {1'b0,abs_gx0} + {1'b0,abs_gy0};
wire [11:0] mag1 = {1'b0,abs_gx1} + {1'b0,abs_gy1};

wire window_valid = (y_pos_q2 >= 11'd2) && (x_grp_q2 != 11'd0) && !user_q2;
reg [10:0] threshold_d1,threshold_d2,threshold_d3;
always @(posedge I_clk or negedge I_rst_n) begin
    if(!I_rst_n)begin threshold_d1<=EDGE_TH;threshold_d2<=EDGE_TH;threshold_d3<=EDGE_TH;end
    else begin
        threshold_d1<=I_edge_threshold;threshold_d2<=threshold_d1;threshold_d3<=threshold_d2;
    end
end
wire [10:0] edge_threshold=RUNTIME_THRESHOLD?threshold_d3:EDGE_TH;
wire edge0 = window_valid && (mag0 >= {1'b0,edge_threshold});
wire edge1 = window_valid && (mag1 >= {1'b0,edge_threshold});

wire [23:0] out0 = edge0 ? 24'hffffff : 24'h000000;
wire [23:0] out1 = edge1 ? 24'hffffff : 24'h000000;

// ---------------------------------------------------------------------
// S2 / S3 / S4 pipeline
// ---------------------------------------------------------------------
always @(posedge I_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        bot0_q    <= 8'd0;
        bot1_q    <= 8'd0;
        valid_q   <= 1'b0;
        user_q    <= 1'b0;
        last_q    <= 1'b0;
        x_grp_q   <= 11'd0;
        y_pos_q   <= 11'd0;
        gx0_r     <= 11'd0;
        gy0_r     <= 11'd0;
        gx1_r     <= 11'd0;
        gy1_r     <= 11'd0;
        valid_q2  <= 1'b0;
        user_q2   <= 1'b0;
        last_q2   <= 1'b0;
        x_grp_q2  <= 11'd0;
        y_pos_q2  <= 11'd0;
        x_grp     <= 11'd0;
        y_pos     <= 11'd0;
        top_prev2 <= 8'd0; top_prev1 <= 8'd0;
        mid_prev2 <= 8'd0; mid_prev1 <= 8'd0;
        bot_prev2 <= 8'd0; bot_prev1 <= 8'd0;
        O_tlast   <= 1'b0;
        O_tuser   <= 1'b0;
        O_tdata   <= 96'd0;
        O_tvalid  <= 1'b0;
        O_cartoon_edge <= 2'b00;
        O_cnn_edge <= 2'b00;
    end else begin
        // ---- S2 data registers -------------------------------------
        bot0_q   <= pair0_d;
        bot1_q   <= pair1_d;
        valid_q  <= valid_d;
        user_q   <= user_d;
        last_q   <= last_d;
        x_grp_q  <= read_x;
        y_pos_q  <= read_y;

        // ---- S3 control registers ----------------------------------
        valid_q2 <= valid_q;
        user_q2  <= user_q;
        last_q2  <= last_q;
        x_grp_q2 <= x_grp_q;
        y_pos_q2 <= y_pos_q;

        // ---- address counters advance with the fetched beat ---------
        if (user_d) begin
            x_grp <= valid_d ? 11'd1 : 11'd0;
            y_pos <= 11'd0;
        end else if (valid_d) begin
            if (x_grp == IMG_WIDTH_GRP - 1) begin
                x_grp <= 11'd0;
                if (y_pos == IMG_HEIGHT - 1)
                    y_pos <= 11'd0;
                else
                    y_pos <= y_pos + 1'b1;
            end else begin
                x_grp <= x_grp + 1'b1;
            end
        end

        // ---- window, line commit and gradient stage (S2 cycle) ------
        if (valid_q) begin

            gx0_r <= sob_gx(top_prev2, top_prev1, top0_w,
                            mid_prev2, mid_prev1, mid0_w,
                            bot_prev2, bot_prev1, bot0_q);
            gy0_r <= sob_gy(top_prev2, top_prev1, top0_w,
                            mid_prev2, mid_prev1, mid0_w,
                            bot_prev2, bot_prev1, bot0_q);
            gx1_r <= sob_gx(top_prev1, top0_w, top1_w,
                            mid_prev1, mid0_w, mid1_w,
                            bot_prev1, bot0_q, bot1_q);
            gy1_r <= sob_gy(top_prev1, top0_w, top1_w,
                            mid_prev1, mid0_w, mid1_w,
                            bot_prev1, bot0_q, bot1_q);

            // The previous word holds the two samples immediately to the
            // left of the current word, in reverse order of arrival.
            top_prev2 <= top0_w; top_prev1 <= top1_w;
            mid_prev2 <= mid0_w; mid_prev1 <= mid1_w;
            bot_prev2 <= bot0_q; bot_prev1 <= bot1_q;

            if (x_grp_q == IMG_WIDTH_GRP - 1) begin
                top_prev2 <= 8'd0; top_prev1 <= 8'd0;
                mid_prev2 <= 8'd0; mid_prev1 <= 8'd0;
                bot_prev2 <= 8'd0; bot_prev1 <= 8'd0;
            end
        end

        // ---- magnitude, threshold and output (S3 cycle) -------------
        O_tlast  <= last_q2;
        O_tuser  <= user_q2;
        O_tvalid <= valid_q2;
        // Model feature threshold is independent of UI/cartoon settings.
        O_cnn_edge <= {2{valid_q2 && window_valid}} & {mag0 >= 12'd80, mag1 >= 12'd80};
        O_cartoon_edge <= {2{valid_q2 && window_valid}} &
                         {mag0 >= {1'b0,CARTOON_EDGE_TH},
                          mag1 >= {1'b0,CARTOON_EDGE_TH}};
        if (valid_q2)
            O_tdata <= {out0,out0,out1,out1};
        else
            O_tdata <= 96'd0;
    end
end

endmodule
