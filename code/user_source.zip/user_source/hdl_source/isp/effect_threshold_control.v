// Board-side threshold editor. Inputs are already synchronized to I_clk.
// When enabled, KEY4 selects Rlo,Rhi,Glo,Ghi,Blo,Bhi in that order;
// KEY2 decreases and KEY3 increases the selected bound by eight.
// A key must be released after entering the editor or changing selection.
module effect_threshold_control #(
    parameter [47:0] DEFAULT_LIMITS = 48'hA0FF00820082,
    parameter [18:0] HOLD_CYCLES = 19'd476190
)(
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_enable,
    input  wire [2:0]  I_context,
    input  wire        I_load,
    input  wire [47:0] I_load_limits,
    output reg         O_edited,
    input  wire        I_key2_n,
    input  wire        I_key3_n,
    input  wire        I_key4_n,
    output reg  [47:0] O_limits,
    output reg  [2:0]  O_target
);
    localparam [8:0] MIN_SPAN_FOR_STEP = 9'd16; // keep at least 8 levels
    reg enable_d;
    reg [2:0] context_d;
    reg [18:0] select_count, down_count, up_count;
    reg select_armed, down_armed, up_armed;
    wire select_press = I_enable && !I_key4_n && select_armed &&
                        (select_count == HOLD_CYCLES);
    wire down_press = I_enable && I_key4_n && !I_key2_n && down_armed &&
                      (down_count == HOLD_CYCLES);
    wire up_press = I_enable && I_key4_n && !I_key3_n && up_armed &&
                    (up_count == HOLD_CYCLES);

    function [7:0] lower_adjust;
        input [7:0] lower, upper;
        input increase;
        begin
            if (increase)
                lower_adjust = ({1'b0,upper} - {1'b0,lower} >= MIN_SPAN_FOR_STEP)
                             ? lower + 8'd8 : lower;
            else
                lower_adjust = (lower >= 8'd8) ? lower - 8'd8 : 8'd0;
        end
    endfunction
    function [7:0] upper_adjust;
        input [7:0] lower, upper;
        input increase;
        begin
            if (increase)
                upper_adjust = (upper <= 8'd247) ? upper + 8'd8 : 8'd255;
            else
                upper_adjust = ({1'b0,upper} - {1'b0,lower} >= MIN_SPAN_FOR_STEP)
                             ? upper - 8'd8 : upper;
        end
    endfunction

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_limits <= DEFAULT_LIMITS;
            O_target <= 3'd0;
            enable_d <= 1'b0;
            context_d <= 3'd0;
            O_edited <= 1'b0;
            select_count <= 19'd0;
            down_count <= 19'd0;
            up_count <= 19'd0;
            select_armed <= 1'b0;
            down_armed <= 1'b0;
            up_armed <= 1'b0;
        end else begin
            enable_d <= I_enable;
            context_d <= I_context;
            O_edited <= 1'b0;
            // Preset load has priority over all manual key activity.
            if (I_load) begin
                O_limits <= I_load_limits;
                O_target <= 3'd0;
                select_count <= 19'd0; down_count <= 19'd0; up_count <= 19'd0;
                select_armed <= 1'b0; down_armed <= 1'b0; up_armed <= 1'b0;
            end else if (!I_enable || !enable_d || (context_d != I_context)) begin
                // A new editing session always starts at R lower bound.
                // Hold keys cannot cross the SW/mode boundary as a press.
                O_target <= 3'd0;
                select_count <= 19'd0;
                down_count <= 19'd0;
                up_count <= 19'd0;
                select_armed <= 1'b0;
                down_armed <= 1'b0;
                up_armed <= 1'b0;
            end else begin
                if (I_key4_n) begin
                    select_count <= 19'd0;
                    select_armed <= 1'b1;
                end else if (select_count < HOLD_CYCLES)
                    select_count <= select_count + 19'd1;
                else if (select_armed) begin
                    O_target <= (O_target == 3'd5) ? 3'd0 : O_target + 3'd1;
                    select_armed <= 1'b0;
                end

                // A selector press suppresses edits until KEY2/3 are released.
                if (!I_key4_n || select_press) begin
                    down_count <= 19'd0;
                    up_count <= 19'd0;
                    down_armed <= 1'b0;
                    up_armed <= 1'b0;
                end else begin
                    if (I_key2_n) begin
                        down_count <= 19'd0;
                        down_armed <= 1'b1;
                    end else if (down_count < HOLD_CYCLES)
                        down_count <= down_count + 19'd1;
                    else if (down_armed)
                        down_armed <= 1'b0;

                    if (I_key3_n) begin
                        up_count <= 19'd0;
                        up_armed <= 1'b1;
                    end else if (up_count < HOLD_CYCLES)
                        up_count <= up_count + 19'd1;
                    else if (up_armed)
                        up_armed <= 1'b0;

                    // Simultaneous KEY2/KEY3 presses cancel one another.
                    if (down_press != up_press) begin
                        O_edited <= 1'b1;
                        case (O_target)
                            3'd0: O_limits[47:40] <= lower_adjust(O_limits[47:40], O_limits[39:32], up_press);
                            3'd1: O_limits[39:32] <= upper_adjust(O_limits[47:40], O_limits[39:32], up_press);
                            3'd2: O_limits[31:24] <= lower_adjust(O_limits[31:24], O_limits[23:16], up_press);
                            3'd3: O_limits[23:16] <= upper_adjust(O_limits[31:24], O_limits[23:16], up_press);
                            3'd4: O_limits[15:8]  <= lower_adjust(O_limits[15:8], O_limits[7:0], up_press);
                            3'd5: O_limits[7:0]   <= upper_adjust(O_limits[15:8], O_limits[7:0], up_press);
                            default: O_target <= 3'd0;
                        endcase
                    end
                end
            end
        end
    end
endmodule
