// v1.1 low-speed UI. Switches are normalized ON=1; keys are active-low.
// All keys require release after a switch/mode/menu context change.
module effect_ui_control #(
    parameter [18:0] HOLD_CYCLES = 19'd476190
)(
    input wire I_clk, I_rst_n,
    input wire [3:0] I_switch_on, I_key_n,
    input wire I_manual_edited,
    output reg [2:0] O_mode,
    output reg O_mirror, O_flip,
    output wire O_manual_enable,
    output reg O_load,
    output reg [47:0] O_load_limits,
    output reg [1:0] O_target, O_sensitivity, O_fill, O_menu,
    output reg O_custom,
    output wire O_extended,
    output reg [23:0] O_paint
);
    reg [18:0] count [0:3];
    reg [3:0] armed;
    reg [8:0] context_d;
    reg extended_d;
    wire enabled = (I_switch_on == 4'b0010) || (I_switch_on == 4'b0110);
    wire effect_mode = (O_mode == 3'd5) || (O_mode == 3'd6);
    assign O_extended = (I_switch_on == 4'b0110) && effect_mode;
    assign O_manual_enable = (I_switch_on == 4'b0010) && effect_mode && I_key_n[0];
    wire [8:0] context_now = {I_switch_on,O_mode,O_menu};
    wire context_ok = enabled && (context_now == context_d);
    wire [3:0] press;
    genvar k;
    generate for (k=0; k<4; k=k+1) begin: key_event
        assign press[k] = context_ok && !I_key_n[k] && armed[k] &&
                          (count[k] == HOLD_CYCLES);
    end endgenerate

    function [1:0] step3;
        input [1:0] value;
        input increase;
        begin
            if (increase) step3 = (value == 2'd2) ? 2'd0 : value + 2'd1;
            else step3 = (value == 2'd0) ? 2'd2 : value - 2'd1;
        end
    endfunction
    function [47:0] preset;
        input [1:0] target, sensitivity;
        reg [7:0] main_min, other_max;
        begin
            case(sensitivity)
                2'd0: begin main_min=8'd128; other_max=8'd160; end
                2'd2: begin main_min=8'd192; other_max=8'd100; end
                default: begin main_min=8'd160; other_max=8'd130; end
            endcase
            case(target)
                2'd1: preset={8'd0,other_max,main_min,8'd255,8'd0,other_max};
                2'd2: preset={8'd0,other_max,8'd0,other_max,main_min,8'd255};
                default: preset={main_min,8'd255,8'd0,other_max,8'd0,other_max};
            endcase
        end
    endfunction
    always @(*) begin
        case(O_fill)
            2'd1: O_paint=24'h0000ff;
            2'd2: O_paint=24'hffff00;
            2'd3: O_paint=24'hffffff;
            default: O_paint=24'h00ff00;
        endcase
    end
    integer i;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_mode<=3'd0; O_mirror<=1'b0; O_flip<=1'b0;
            O_load<=1'b0; O_load_limits<=48'hA0FF00820082;
            O_target<=2'd0; O_sensitivity<=2'd1; O_fill<=2'd0;
            O_menu<=2'd0; O_custom<=1'b0;
            context_d<=9'd0; extended_d<=1'b0; armed<=4'd0;
            for(i=0;i<4;i=i+1) count[i]<=19'd0;
        end else begin
            context_d<=context_now;
            extended_d<=O_extended;
            O_load<=1'b0;
            if(I_manual_edited) O_custom<=1'b1;
            if(O_extended && !extended_d) O_menu<=2'd0;
            for(i=0;i<4;i=i+1) begin
                if(!context_ok) begin count[i]<=19'd0; armed[i]<=1'b0; end
                else if(I_key_n[i]) begin count[i]<=19'd0; armed[i]<=1'b1; end
                else if(count[i]<HOLD_CYCLES) count[i]<=count[i]+19'd1;
                else armed[i]<=1'b0;
            end
            // Mode takes precedence; KEY4 suppresses value edits while held.
            if(press[0]) O_mode <= (O_mode==3'd6) ? 3'd0 : O_mode+3'd1;
            else if(O_extended) begin
                if(press[3]) O_menu<=O_menu+2'd1;
                else if(I_key_n[3]) begin
                    if(O_menu==2'd3) begin
                        if(press[1]) O_mirror<=~O_mirror;
                        if(press[2]) O_flip<=~O_flip;
                    end else if(press[1] != press[2]) begin
                        case(O_menu)
                            2'd0: begin
                                O_target<=step3(O_target,press[2]);
                                O_load_limits<=preset(step3(O_target,press[2]),O_sensitivity);
                                O_load<=1'b1; O_custom<=1'b0;
                            end
                            2'd1: begin
                                O_sensitivity<=step3(O_sensitivity,press[2]);
                                O_load_limits<=preset(O_target,step3(O_sensitivity,press[2]));
                                O_load<=1'b1; O_custom<=1'b0;
                            end
                            2'd2: O_fill<=press[2] ? O_fill+2'd1 : O_fill-2'd1;
                            default: begin end
                        endcase
                    end
                end
            end else if(enabled && !effect_mode) begin
                if(press[1]) O_mirror<=~O_mirror;
                if(press[2]) O_flip<=~O_flip;
            end
        end
    end
endmodule
