module isp_top #(
    parameter integer AWB_USE_MCU=0,
    parameter integer TRACKING_ENABLE=0,
    parameter integer RUNTIME_UI=0,
    parameter integer HISTOGRAM_PRE_EFFECTS=0,
    parameter [47:0] DEFAULT_LIMITS = 48'hA0FF00820082,
    parameter [23:0] DEFAULT_PAINT  = 24'h00ff00
) (
    input I_equalize,I_original,
    input I_tracking,
    input I_saturation,
    output O_mon_tracking,
    input [9:0] I_hist_paddr,
    input I_hist_psel,I_hist_penable,I_hist_pwrite,
    input [31:0] I_hist_pwdata,
    output [31:0] O_hist_prdata,
    output O_hist_pready,O_hist_pslverr,
    output O_hist_bar_write,
    output [8:0] O_hist_bar_address,
    output [13:0] O_hist_bar_data,
    output O_hist_table_bank,O_hist_table_valid,O_hist_table_equalized,
    input I_hist_panel_bank,I_hist_panel_valid,
    input [8:0] I_mcu_paddr,
    input I_mcu_psel,I_mcu_penable,I_mcu_pwrite,
    input [31:0] I_mcu_pwdata,
    output [31:0] O_mcu_prdata,
    output O_mcu_pready,O_mcu_pslverr,
    input           I_control_clk   ,
    input           I_wb_auto,
    input [7:0]     I_binary_threshold,
    input [10:0]    I_edge_threshold,
    output [1:0]    O_wb_status     ,
    input [2:0]     I_mode_request  ,
    input [47:0]    I_color_limits  ,
    input [1:0]     I_color_target,I_color_sensitivity,
    input           I_custom_rgb,
    input [23:0]    I_paint_color   ,
    input           I_mirror        ,   // v0.8 P4b: horizontal mirror
    output [2:0]    O_mode_active   ,
    output [3:0]    O_segment_mask  ,
    output          O_segment_valid ,
    output          O_segment_frame ,
    output [10:0]   O_segment_x     , // leftmost pixel coordinate / 4
    output [10:0]   O_segment_y     ,
    input 			axi4s_video_aclk,
    input 			I_rst_n			,
    input 			I_tlast			,
    input 			I_tuser			,
    input [39:0] 	I_tdata			,
    input 			I_tvalid		,
    input [9:0] 	I_tdest			,
    input 			O_tready		,
    output [127:0] 	O_tdata			,
    output 			O_tlast			,
    output 			O_tuser			,
    output 			O_tvalid		,
    output 			I_tready
  ,
  // v1.7 CNN 采集监听端口：只连线、不加逻辑。
  // mir_* 是 4:3 打包器之前那一路"拍内像素对齐"的 96 位流（1 拍 = 4 像素），
  // 也正是屏幕上真正显示的像素；顶层 S_ISP_O_tdata[127:0] 是 packing 之后的
  // 密集字节流，不能当 4 像素/拍用（详见 cnn/README_cnn.md 5.11.1）。
  output [1:0] O_mon_edge,
  output [95:0]  O_mon_pix   ,
  output         O_mon_valid ,
  output         O_mon_tuser ,
  output         O_mon_tlast,
  output         O_mon_mirror,
  output [95:0] O_motion_pix,
  output O_motion_valid,O_motion_user,O_motion_last
);
 
wire         m_aixs_tvalid;  //synthesis keep 
  wire [127:0] m_aixs_tdata;  //synthesis keep 
  wire         m_aixs_tuser;  //synthesis keep 
  wire         m_aixs_tlast;  //synthesis keep 
  wire         m_aixs_tready;  //synthesis keep 
  
  wire [ 95:0] m_aixs_tdata_96;  //synthesis keep 


  wire         awb_O_tlast;  //synthesis keep 
  wire         awb_O_tuser;  //synthesis keep 
  wire [ 95:0] awb_O_tdata;  //synthesis keep 
  wire         awb_O_tvalid;  //synthesis keep 
  wire         awb_O_tready;  //synthesis keep 
  // Passive pre-AWB RGB tap. Sensor AE/AG is shared by every consumer;
  // demosaic is reused, with no extra buffering or backpressure.
  assign O_motion_pix=m_aixs_tdata_96;
  assign O_motion_valid=m_aixs_tvalid;
  assign O_motion_user=m_aixs_tuser;
  assign O_motion_last=m_aixs_tlast;

  wire         awb_O_tuser_128;  //synthesis keep 
  wire         awb_O_tvalid_128;  //synthesis keep 
  wire [127:0] awb_O_tdata_128;  //synthesis keep 

  wire [98:0] config_active;
  wire [100:0] config_for_beat;
  wire [103:0] config_source_active,config_source_beat;
  wire [95:0] eq_O_tdata;
  wire eq_O_tvalid,eq_O_tuser,eq_O_tlast;
  assign config_active=config_source_active[98:0];
  generate if(HISTOGRAM_PRE_EFFECTS)begin:g_histogram_pre
      histogram_equalize4 u_equalizer(
          .I_clk(axi4s_video_aclk),.I_rst_n(I_rst_n),
          .I_valid(awb_O_tvalid),.I_user(awb_O_tuser),.I_last(awb_O_tlast),.I_rgb(awb_O_tdata),
          .I_equalize(config_source_beat[100]&&!config_source_beat[99]),
          .O_valid(eq_O_tvalid),.O_user(eq_O_tuser),.O_last(eq_O_tlast),.O_rgb(eq_O_tdata),
          .I_paddr(I_hist_paddr),.I_psel(I_hist_psel),.I_penable(I_hist_penable),
          .I_pwrite(I_hist_pwrite),.I_pwdata(I_hist_pwdata),
          .O_prdata(O_hist_prdata),.O_pready(O_hist_pready),.O_pslverr(O_hist_pslverr),
          .O_bar_write(O_hist_bar_write),.O_bar_address(O_hist_bar_address),.O_bar_data(O_hist_bar_data),
          .O_table_bank(O_hist_table_bank),.O_table_valid(O_hist_table_valid),.O_table_equalized(O_hist_table_equalized),
          .I_panel_bank(I_hist_panel_bank),.I_panel_valid(I_hist_panel_valid));
      reg [100:0] config_pipe[0:2];
      reg [2:0] config_live;
      integer hc;
      always @(posedge axi4s_video_aclk)begin
          config_pipe[0]<={config_source_beat[102:101],config_source_beat[98:0]};
          for(hc=1;hc<3;hc=hc+1)config_pipe[hc]<=config_pipe[hc-1];
      end
      always @(posedge axi4s_video_aclk or negedge I_rst_n)
          if(!I_rst_n)config_live<=0;else config_live<={config_live[1:0],1'b1};
      assign config_for_beat=config_live[2]?config_pipe[2]:
          {1'b0,2'd0,2'd1,11'd80,8'd128,3'd0,DEFAULT_LIMITS,DEFAULT_PAINT};
  end else begin:g_no_histogram_pre
      assign eq_O_tdata=awb_O_tdata;
      assign {eq_O_tvalid,eq_O_tuser,eq_O_tlast}={awb_O_tvalid,awb_O_tuser,awb_O_tlast};
      assign config_for_beat={config_source_beat[102:101],config_source_beat[98:0]};
      assign {O_hist_prdata,O_hist_pready,O_hist_pslverr}=34'd0;
      assign {O_hist_bar_write,O_hist_bar_address,O_hist_bar_data}=24'd0;
      assign {O_hist_table_bank,O_hist_table_valid,O_hist_table_equalized}=3'd0;
  end endgenerate

  // Tracking RGB: sensor AE -> existing AWB -> shared saturation arithmetic.
  // Three clocks match the existing histogram latency; nine native LUT shift
  // stages then match Gaussian/Sobel plus the existing effect output register.
  // Display keeps its equalizer/effects; tracking bypasses both and mirror RAM.
  wire [95:0] tracking_rgb;
  generate if(TRACKING_ENABLE)begin:g_tracking_rgb
      wire [95:0] sat_rgb;
      genvar lane;
      for(lane=0;lane<4;lane=lane+1)begin:g_sat
          saturation_rgb_pipeline #(.OUTPUT_REGISTER(0)) u_sat(
              .I_clk(axi4s_video_aclk),.I_rst_n(I_rst_n),
              .I_rgb(awb_O_tdata[95-lane*24-:24]),
              .I_enable(config_source_beat[103]),.O_rgb(sat_rgb[95-lane*24-:24]));
      end
      assign tracking_rgb=sat_rgb;
  end else begin:g_no_tracking_rgb
      assign tracking_rgb=eq_O_tdata;
  end endgenerate

  // One shared four-clock Gaussian feeds binary/edge/cartoon only. Keep
  // native RGB, paint, grayscale and segmentation aligned, delaying
  // their pixels and configuration by the same total eight clocks.
  localparam integer EDGE_LATENCY = 8;
  reg [EDGE_LATENCY-1:0] effect_delay_live;
  wire [95:0] gaussian_rgb;
  wire gaussian_valid,gaussian_user,gaussian_last;
  gaussian_rgb4 u_gaussian (
      .I_clk(axi4s_video_aclk),.I_rst_n(I_rst_n),
      .I_valid(eq_O_tvalid),.I_user(eq_O_tuser),.I_last(eq_O_tlast),
      .I_rgb(config_for_beat[100]?tracking_rgb:eq_O_tdata),.O_rgb(gaussian_rgb),
      .O_valid(gaussian_valid),.O_user(gaussian_user),.O_last(gaussian_last));

  wire [95:0] raw_tdata_d  [0:EDGE_LATENCY-1];
  wire        raw_tlast_d  [0:EDGE_LATENCY-1];
  wire        raw_tuser_d  [0:EDGE_LATENCY-1];
  wire        raw_tvalid_d [0:EDGE_LATENCY-1];

  wire [95:0] raw_tdata  = raw_tdata_d [EDGE_LATENCY-1];
  wire        raw_tlast  = raw_tlast_d [EDGE_LATENCY-1];
  wire        raw_tuser  = raw_tuser_d [EDGE_LATENCY-1];
  wire        raw_tvalid = raw_tvalid_d[EDGE_LATENCY-1];

  // The source clock holds mode, thresholds and paint colour as one bundle.
  // The CSI side applies a complete bundle at AWB tuser, including when that
  // pulse is earlier than the first valid pixel. Each beat carries its mode
  // through the four-stage effect pipeline.
  effect_config_cdc #(
      .WIDTH(104),.DEFAULT_CONFIG({5'b0,1'b0,2'd0,2'd1,11'd80,8'd128,3'd0,DEFAULT_LIMITS,DEFAULT_PAINT})
  ) u_effect_config_cdc (
      .I_src_clk(I_control_clk), .I_dst_clk(axi4s_video_aclk),
      .I_rst_n(I_rst_n),
      .I_src_config({TRACKING_ENABLE?I_saturation:1'b0,TRACKING_ENABLE?I_tracking:1'b0,TRACKING_ENABLE?I_mirror:1'b0,HISTOGRAM_PRE_EFFECTS?I_equalize:1'b0,HISTOGRAM_PRE_EFFECTS?I_original:1'b0,I_custom_rgb,I_color_target,I_color_sensitivity,(RUNTIME_UI?I_edge_threshold:11'd80),(RUNTIME_UI?I_binary_threshold:8'd128),I_mode_request,I_color_limits,I_paint_color}),
      .I_dst_frame(awb_O_tuser),
      .O_dst_active(config_source_active), .O_dst_for_beat(config_source_beat)
  );
  assign O_mode_active = config_active[74:72];

  wire [3:0] segment_mask_classified;
  color_classify4 u_color_classify4 (
      .I_clk(axi4s_video_aclk),.I_rst_n(I_rst_n),.I_valid(eq_O_tvalid),
      .I_rgb(eq_O_tdata), .I_limits(config_for_beat[71:24]),
      .I_custom_rgb(config_for_beat[98]),.I_target(config_for_beat[97:96]),
      .I_sensitivity(config_for_beat[95:94]),.O_mask(segment_mask_classified)
  );
  // Three classifier clocks plus five mask-only clocks meet the unchanged
  // eight-clock RGB/metadata pipeline. Never insert a late mask at stage 0.
  localparam integer MASK_DELAY=EDGE_LATENCY-3;
  reg [3:0] mask_delay[0:MASK_DELAY-1];
  integer md;
  always @(posedge axi4s_video_aclk)begin
      mask_delay[0]<=segment_mask_classified;
      for(md=1;md<MASK_DELAY;md=md+1)mask_delay[md]<=mask_delay[md-1];
  end
  wire [3:0] segment_mask_final=(effect_delay_live[EDGE_LATENCY-1]&&raw_tvalid)?mask_delay[MASK_DELAY-1]:4'd0;
  wire [2:0]  mode_d [0:EDGE_LATENCY-1];
  wire [7:0] binary_threshold_d [0:EDGE_LATENCY-1];
  // Delay only the shared fill colour; reuse the already aligned original
  // pixels and mask at the output. Avoid three 96-bit painted-pixel stages.
  wire [23:0] paint_color_d [0:EDGE_LATENCY-1];
  wire [10:0] segment_x_d [0:EDGE_LATENCY-1];
  wire [10:0] segment_y_d [0:EDGE_LATENCY-1];
  wire        segment_frame_d [0:EDGE_LATENCY-1];
  reg [10:0] segment_x, segment_y;
  reg        frame_pending;
  wire [95:0] painted_now;
  region_paint4 u_region_paint4 (
      .I_rgb(raw_tdata), .I_mask(segment_mask_final),
      .I_color(paint_color_d[EDGE_LATENCY-1]), .O_rgb(painted_now)
  );
  // Keep data and its per-beat metadata in one native LUT shift pipeline.
  // Only the eight occupancy bits require reset. Before a stage has filled,
  // its visible word is the exact original reset value (also during reset),
  // so uninitialised shifter contents can never escape. Latency is unchanged.
  wire [1:0] tracking_d[0:EDGE_LATENCY-1];
  localparam integer EFFECT_BEAT_W=159;
  localparam [EFFECT_BEAT_W-1:0] EFFECT_RESET_WORD=
      {2'b0,96'd0,3'b000,3'd0,8'd128,DEFAULT_PAINT,11'd0,11'd0,1'b0};
  reg [EFFECT_BEAT_W-1:0] effect_delay_words[0:EDGE_LATENCY-1];
  integer ef;
  always @(posedge axi4s_video_aclk)begin
      effect_delay_words[0]<={config_for_beat[100:99],eq_O_tdata,eq_O_tlast,eq_O_tuser,eq_O_tvalid,
          config_for_beat[74:72],config_for_beat[82:75],
          config_for_beat[23:0],eq_O_tuser?11'd0:segment_x,
          eq_O_tuser?11'd0:segment_y,eq_O_tvalid&&(eq_O_tuser||frame_pending)};
      for(ef=1;ef<EDGE_LATENCY;ef=ef+1)
          effect_delay_words[ef]<=effect_delay_words[ef-1];
  end
  always @(posedge axi4s_video_aclk or negedge I_rst_n)
      if(!I_rst_n)effect_delay_live<=0;
      else effect_delay_live<={effect_delay_live[EDGE_LATENCY-2:0],1'b1};
  genvar ed;
  generate for(ed=0;ed<EDGE_LATENCY;ed=ed+1)begin: effect_delay_outputs
      assign {tracking_d[ed],raw_tdata_d[ed],raw_tlast_d[ed],raw_tuser_d[ed],raw_tvalid_d[ed],
          mode_d[ed],binary_threshold_d[ed],paint_color_d[ed],
          segment_x_d[ed],segment_y_d[ed],segment_frame_d[ed]}=
          effect_delay_live[ed]?effect_delay_words[ed]:EFFECT_RESET_WORD;
  end endgenerate
  always @(posedge axi4s_video_aclk or negedge I_rst_n) begin
      if (!I_rst_n) begin
          segment_x <= 11'd0;
          segment_y <= 11'd0;
          frame_pending <= 1'b0;
      end else begin
          if (eq_O_tuser)
              frame_pending <= !eq_O_tvalid;
          else if (eq_O_tvalid && frame_pending)
              frame_pending <= 1'b0;
          if (eq_O_tuser) begin
              segment_x <= eq_O_tvalid ? 11'd1 : 11'd0;
              segment_y <= 11'd0;
          end else if (eq_O_tvalid) begin
              if (segment_x == 11'd319) begin
                  segment_x <= 11'd0;
                  segment_y <= (segment_y == 11'd719) ? 11'd0 : segment_y + 11'd1;
              end else segment_x <= segment_x + 11'd1;
          end
      end
  end
  assign O_segment_mask = segment_mask_final;
  assign O_segment_valid = raw_tvalid;
  assign O_segment_frame = segment_frame_d[EDGE_LATENCY-1];
  assign O_segment_x = segment_x_d[EDGE_LATENCY-1];
  assign O_segment_y = segment_y_d[EDGE_LATENCY-1];

  wire [95:0] edge_tdata;
  wire [1:0] cartoon_strong_edge,cnn_edge;
  wire edge_tlast, edge_tuser, edge_tvalid, edge_tready;
  wire [10:0] gaussian_edge_threshold;
  edge_detect_96 #(
      .IMG_WIDTH(1280), .IMG_HEIGHT(720), .EDGE_TH(11'd80),.RUNTIME_THRESHOLD(RUNTIME_UI)
  ) u_edge_detect_96 (
      .I_clk(axi4s_video_aclk), .I_rst_n(I_rst_n),
      .I_tlast(gaussian_last), .I_tuser(gaussian_user),
      .I_tdata(gaussian_rgb), .I_tvalid(gaussian_valid),
      .I_tready(O_tready),
      .I_edge_threshold((mode_d[3] == 3'd3) ? gaussian_edge_threshold : 11'd80),
      .O_tlast(edge_tlast), .O_tuser(edge_tuser),
      .O_tdata(edge_tdata), .O_tvalid(edge_tvalid),
      .O_tready(edge_tready), .O_cartoon_edge(cartoon_strong_edge),.O_cnn_edge(cnn_edge)
  );

  function [7:0] luminance;
      input [23:0] pixel;
      begin
          luminance = {2'b00,pixel[23:18]} + {1'b0,pixel[15:9]}
                    + {2'b00,pixel[7:2]};
      end
  endfunction
  wire [7:0] gray0 = luminance(raw_tdata[95:72]);
  wire [7:0] gray1 = luminance(raw_tdata[71:48]);
  wire [7:0] gray2 = luminance(raw_tdata[47:24]);
  wire [7:0] gray3 = luminance(raw_tdata[23:0]);
  wire [95:0] gray_tdata = {{3{gray0}}, {3{gray1}}, {3{gray2}}, {3{gray3}}};
  wire [7:0] binary_threshold=binary_threshold_d[EDGE_LATENCY-1];
  reg [10:0] gaussian_edge_threshold_d[0:3];
  integer gt;
  always @(posedge axi4s_video_aclk or negedge I_rst_n)
      if(!I_rst_n)begin
          for(gt=0;gt<4;gt=gt+1)gaussian_edge_threshold_d[gt]<=11'd80;
      end else begin
          gaussian_edge_threshold_d[0]<=config_for_beat[93:83];
          for(gt=1;gt<4;gt=gt+1)gaussian_edge_threshold_d[gt]<=gaussian_edge_threshold_d[gt-1];
      end
  assign gaussian_edge_threshold=gaussian_edge_threshold_d[3];
  wire [3:0] binary_mask_now;
  wire [3:0] binary_mask_filtered;
  genvar bp;
  generate for(bp=0;bp<4;bp=bp+1)begin : binary_input
      wire [7:0] g=luminance(gaussian_rgb[95-bp*24 -: 24]);
      assign binary_mask_now[3-bp]=(g>=binary_threshold_d[3]);
  end endgenerate
  wire [95:0] binary_tdata={{3{{8{binary_mask_filtered[3]}}}},
                              {3{{8{binary_mask_filtered[2]}}}},
                              {3{{8{binary_mask_filtered[1]}}}},
                              {3{{8{binary_mask_filtered[0]}}}}};
  wire [95:0] cartoon_tdata;
  cartoon_mix4 #(.IMG_WIDTH(1280), .IMG_HEIGHT(720)) u_cartoon_mix4 (
      .I_clk(axi4s_video_aclk), .I_rst_n(I_rst_n),
      .I_tuser(gaussian_user), .I_tvalid(gaussian_valid),
      .I_rgb(gaussian_rgb), .I_binary_mask(binary_mask_now), .I_edge(edge_tdata),
      .I_strong_edge(cartoon_strong_edge),
      .O_rgb(cartoon_tdata), .O_binary_mask(binary_mask_filtered)
  );
  wire [95:0] selected_tdata;
  effect_mux96 u_effect_mux96 (
      .I_mode(tracking_d[EDGE_LATENCY-1][1]?3'd0:mode_d[EDGE_LATENCY-1]),
      .I_original(raw_tdata), .I_gray(gray_tdata),
      .I_binary(binary_tdata), .I_edge(edge_tdata),
      .I_cartoon(cartoon_tdata), .I_painted(painted_now),
      .I_mask(segment_mask_final), .O_rgb(selected_tdata)
  );
  wire selected_tlast  = raw_tlast;
  wire selected_tuser  = raw_tuser;
  wire selected_tvalid = raw_tvalid;

  // Register the common mux result before the mirror/packer. All seven
  // paths gain exactly one clock and retain their per-beat metadata.
  reg [95:0] effect_tdata;
  wire [95:0] cnn_tracking_rgb;
  generate if(TRACKING_ENABLE)begin:g_tracking_delay
      reg [95:0] pixels[0:8];
      integer td;
      always @(posedge axi4s_video_aclk)begin
          pixels[0]<=tracking_rgb;
          for(td=1;td<9;td=td+1)pixels[td]<=pixels[td-1];
      end
      assign cnn_tracking_rgb=pixels[8];
  end else begin:g_no_tracking_delay
      assign cnn_tracking_rgb=96'd0;
  end endgenerate
  reg [1:0] cnn_edge_effect;
  reg [1:0] tracking_effect;
  always @(posedge axi4s_video_aclk or negedge I_rst_n)
    if(!I_rst_n)begin tracking_effect<=0;cnn_edge_effect<=0;end
    else begin cnn_edge_effect<=cnn_edge;tracking_effect<=tracking_d[EDGE_LATENCY-1];end
  reg        effect_tlast, effect_tuser, effect_tvalid;
  always @(posedge axi4s_video_aclk or negedge I_rst_n) begin
      if (!I_rst_n) begin
          effect_tdata  <= 96'd0;
          effect_tlast  <= 1'b0;
          effect_tuser  <= 1'b0;
          effect_tvalid <= 1'b0;
      end else begin
          effect_tdata  <= selected_tdata;
          effect_tlast  <= selected_tlast;
          effect_tuser  <= selected_tuser;
          effect_tvalid <= selected_tvalid;
      end
  end

  // v0.8 P4b: horizontal mirror, inserted between the mode mux and the
  // 96->128 bit packer.  At this point one beat is exactly four 24 bit
  // pixels, so reversing a line is "reverse the 320 beat order" plus
  // "reverse the four pixels inside every beat" (pure wiring).
  wire [95:0] mir_tdata;
  wire [1:0] mir_edge;
  wire display_mirror;
  wire        mir_tuser, mir_tvalid, mir_tlast;

  video_mirror u_video_mirror (
      .I_clk    (axi4s_video_aclk),
      .I_rst_n  (I_rst_n          ),
      .I_mirror (I_mirror         ),.O_mirror(display_mirror),
      .I_tuser  (effect_tuser     ),
      .I_tvalid (effect_tvalid    ),
      .I_tlast  (effect_tlast     ),
      .I_tdata  (effect_tdata     ),.I_edge_hits(cnn_edge_effect),.O_edge_hits(mir_edge),
      .O_tuser  (mir_tuser        ),
      .O_tvalid (mir_tvalid       ),
      .O_tlast  (mir_tlast        ),
      .O_tdata  (mir_tdata        )
  );

  // v1.7：把这一路引出给 CNN 采集模块（纯连线，不改变原有逻辑）
  // Tracking taps pre-equalizer, saturated AWB RGB before the display line RAM.
  // MCU reflects final box centres; no second mirror RAM is required.
  assign O_mon_tracking=tracking_effect[1];
  assign O_mon_mirror=tracking_effect[1]?tracking_effect[0]:display_mirror;
  assign O_mon_edge = tracking_effect[1]?cnn_edge_effect:mir_edge;
  assign O_mon_pix   = tracking_effect[1]?cnn_tracking_rgb:mir_tdata;
  assign O_mon_valid = tracking_effect[1]?effect_tvalid:mir_tvalid;
  assign O_mon_tuser = tracking_effect[1]?effect_tuser:mir_tuser;
  assign O_mon_tlast = tracking_effect[1]?effect_tlast:mir_tlast;

  assign awb_O_tready = edge_tready;
  assign O_tdata  = awb_O_tdata_128;
  assign O_tlast  = mir_tlast;
  assign O_tuser  = awb_O_tuser_128;
  assign O_tvalid = awb_O_tvalid_128;

demosaic #(
    .IMG_HEIGHT          (720 ), // 图像高度
    .IMG_WIDTH           (1280), // 图像宽度
    .data_complete_delay (50  ),
    .BAYER_MODE          ("BGGR")
)
u_demosaic
(
    .I_clk   			(axi4s_video_aclk)	,   // 时钟信号
    .I_rst_n 			(I_rst_n)	,   // 复位信号，低有效
    .axi4s_video_tdata 	(I_tdata)	,  // AXI4-Stream视频数据
    .axi4s_video_tdest 	(I_tdest)	,
    .axi4s_video_tlast 	(I_tlast)	,  // 行结束信号
    .axi4s_video_tvalid	(I_tvalid)	,  // 数据有效信号
    .axi4s_video_tuser 	(I_tuser)	,  // 帧开始信号
    .axi4s_video_tready	(I_tready)	,  // 从模块准备好接受数据
    .O_tlast  			(m_aixs_tlast)	,  // 输出行结束信号
    .O_tuser  			(m_aixs_tuser)	,  // 输出帧开始信号
    .O_tdata  			(m_aixs_tdata)	,  // 输出数据
    .O_tvalid 			(m_aixs_tvalid)	,  // 输出数据有效信号
    .O_tready   		(m_aixs_tready)	   // 输出数据准备好信号
);
 
data128_96 u_data128_96 (
    .I_tdata(m_aixs_tdata),
    .O_tdata(m_aixs_tdata_96)
);

awb #(
    .SOLVE_USE_MCU(AWB_USE_MCU),
    .CALIBRATION_ENABLE(0),
    .IMG_HEIGHT(720 ),
    .IMG_WIDTH (1280)
) u_awb (
    .I_paddr(I_mcu_paddr),.I_psel(I_mcu_psel),.I_penable(I_mcu_penable),.I_pwrite(I_mcu_pwrite),
    .I_pwdata(I_mcu_pwdata),.O_prdata(O_mcu_prdata),.O_pready(O_mcu_pready),.O_pslverr(O_mcu_pslverr),
    .I_clk   (axi4s_video_aclk),
    .I_rst_n (I_rst_n),
    .I_tlast (m_aixs_tlast),
    .I_tuser (m_aixs_tuser),
    .I_tdata (m_aixs_tdata_96),
    .I_tvalid(m_aixs_tvalid),
    .I_cal_toggle(1'b0), .O_cal_status(O_wb_status),
    .I_auto_enable(RUNTIME_UI?I_wb_auto:1'b1),.O_wb_telemetry(),
    .I_tready(m_aixs_tready),
    .O_tlast (awb_O_tlast ),
    .O_tuser (awb_O_tuser ),
    .O_tdata (awb_O_tdata ),
    .O_tvalid(awb_O_tvalid),
    .O_tready(awb_O_tready)
);

data_96bit_to_128bit u_data_96bit_to_128bit(
        .I_clk              ( axi4s_video_aclk  ),
        .I_rst_n            ( I_rst_n           ),
	
    .I_96b_frame_start  ( mir_tuser	        ),
    .I_96b_valid        ( mir_tvalid 		),
    .I_96b_data         ( mir_tdata		    ),
	
        .O_128b_frame_start ( awb_O_tuser_128  	),
        .O_128b_valid       ( awb_O_tvalid_128 	),
        .O_128b_data        ( awb_O_tdata_128  	)
    );



//data96_128 u_data96_128 (
//    .I_tdata(awb_O_tdata),
//    .O_tdata(awb_O_tdata_128)
//);
	
endmodule


//==========================================================================
// video_mirror (v0.8 P4b, deadlock fix)
//
// Horizontal mirror for the ISP output stream.  One beat is four 24 bit
// pixels (320 beats per 1280 pixel line), so mirroring a line is:
//   * output the beats of that line in reverse order (319 .. 0)
//   * reverse the four pixels inside every beat (pure wiring)
//
// Read as a whole the module has to behave as a fixed "one line delay": the
// output stream is the input stream delayed by one line, i.e. by 320 beats
// plus the single register stage of the memory read path = 321 clocks.  The
// output frame start is therefore produced by delaying I_tuser by the same
// 321 clocks.  It must NOT be rebuilt from whatever line the reader happens
// to be working on:
//
//   The previous version restarted the reader from the input frame start and
//   only when the reader was idle.  Whenever the last line of a frame was
//   still being read at the next frame start - which is exactly what happens
//   when the ISP stream has little or no idle time between the last line and
//   the frame start - the restart was skipped, the line counters of the two
//   sides drifted apart, the reader never started again, no further output
//   frame start was produced and the display froze on the last DDR buffer.
//   (Reproduced with ..\..\sim_frame: gapless stream -> 1 frame out, stall.)
//
// The reader is now free running: it starts the next line as soon as the
// writer has completed one, and both line counters simply count up for the
// whole session (they are only cleared while mirroring is switched off).
// With 320 beats per line the reader can always keep up, so the two counters
// never differ by more than one and the memory rotation of the two sides
// stays in step without any frame boundary special case.
//
// The three 320 beat line stores share one existing 96 bit wide block memory
// macro (blk_mem_gen_awb_delay_signal): port A writes, port B reads, and the
// rotation 0 -> 320 -> 640 -> 0 guarantees the buffer being read is never the
// one being written.  A project macro is used instead of an inferred array
// because inferred arrays were either mapped to distributed LUT RAM or
// scattered by the placer and created congestion.
//
// I_mirror is synchronised into this clock domain and latched at the frame
// start.  With I_mirror low the module is a pure wired bypass, so the
// non-mirrored behaviour is bit identical to before (no added latency).
//==========================================================================
module video_mirror (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_mirror,
    output wire        O_mirror,
    input  wire        I_tuser,
    input  wire        I_tvalid,
    input  wire        I_tlast,
    input wire [1:0] I_edge_hits,
    output wire [1:0] O_edge_hits,
    input  wire [95:0] I_tdata,
    output wire        O_tuser,
    output wire        O_tvalid,
    output wire        O_tlast,
    output wire [95:0] O_tdata
);
    localparam [8:0]  BEATS_LAST   = 9'd319;
    localparam [8:0]  BEATS_SECOND = 9'd318;
    localparam [8:0]  BEATS_ZERO   = 9'd0;
    localparam [9:0] ROW_LIMIT    = 10'd640;   // 2 * 320
    // Frame start pipeline: one line (320 beats) plus the single register
    // stage of the memory read path, i.e. exactly the data delay.
    localparam MKR_DELAY = 321;

    // ---- mirror state: two stage sync, latch at the frame start ----------
    reg [1:0] S_mir_sync;
    reg       S_mir_frame;

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_mir_sync <= 2'b00;
        else
            S_mir_sync <= {S_mir_sync[0], I_mirror};
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_mir_frame <= 1'b0;
        else if(I_tuser)
            S_mir_frame <= S_mir_sync[1];
    end

    // The frame start is the cycle in which the newly synchronised state must
    // already take effect: using the registered value there would let one
    // input beat through the bypass before mirroring starts (a one beat
    // shift of the whole line).
    wire S_mir_now = I_tuser ? S_mir_sync[1] : S_mir_frame;
    assign O_mirror = S_mir_now;
    wire S_off     = !S_mir_now;

    // ---- output frame start = input frame start delayed by one line ------
    // I_tuser is aligned with the first beat of line 0, so delaying it by the
    // same 321 clocks as the data puts it on the first output beat of line 0
    // of the mirrored frame.  This is independent of the reader state, which
    // is what makes the frame boundary immune to the reader still working on
    // the previous frame's last line.
    reg [320:0] S_usr_dly;
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_usr_dly <= {321{1'b0}};
        else
            S_usr_dly <= {S_usr_dly[319:0], I_tuser};
    end
    wire S_usr_dly_out = S_usr_dly[320];

    // ---- line stores ----------------------------------------------------
    wire [1:0] S_edge_q;
    wire [95:0] S_ram_q;
    wire [97:0] S_ram_doa_unused;

    reg [9:0] S_wr_base;       // S_wr_idx * 320
    reg [8:0]  S_wr_ptr;
    reg [11:0] S_wr_lines;      // complete lines stored since mirroring on

    reg [9:0] S_rd_base;       // S_rd_idx * 320
    reg [8:0]  S_rd_pres;
    reg [8:0]  S_rd_ptr;
    reg        S_rd_act;
    reg [11:0] S_rd_lines;      // lines already output since mirroring on
    reg        M_vld, M_last;

    wire [95:0] S_wr_rev = {I_tdata[23:0], I_tdata[47:24], I_tdata[71:48], I_tdata[95:72]};
    wire        S_wr_en  = S_mir_now && I_tvalid;

    // The frame start is also beat 0 of line 0 and must always land on the
    // base address, whatever the pointer held while mirroring was off.
    wire [8:0]  S_wr_addr = (I_tuser && I_tvalid && S_mir_now) ? BEATS_ZERO : S_wr_ptr;

    wire [9:0] S_wr_final = S_wr_base + {1'b0, S_wr_addr};

    // A line is ready as soon as the writer has completed one more line than
    // the reader has output.  Both counters are free running (they are only
    // cleared while mirroring is off) so the rotation of the two sides stays
    // in step across frame boundaries; the live comparison also avoids the
    // extra output line a registered "line ready" flag used to launch.
    wire        S_start_now = S_mir_now && (!S_rd_act) && (S_rd_lines != S_wr_lines);
    wire [8:0]  S_rd_addr   = S_start_now ? BEATS_LAST : S_rd_ptr;
    wire [9:0] S_rd_final  = S_rd_base + {1'b0, S_rd_addr};

    blk_mem_gen_awb_delay_signal #(.DATA_WIDTH(98)) u_video_mirror_line_store (
        .clka  (I_clk            ),
        .wea   (S_wr_en          ),
        .addra (S_wr_final       ),
        .dia   ({I_edge_hits[0],I_edge_hits[1],S_wr_rev}),
        .doa   (S_ram_doa_unused ),
        .clkb  (I_clk            ),
        .web   (1'b0             ),
        .addrb (S_rd_final       ),
        .dib   (98'd0            ),
        .dob   ({S_edge_q,S_ram_q})
    );

    // ---- write side: beat order reversed, one line per buffer -----------
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_wr_base  <= 10'd0;
            S_wr_ptr   <= 9'd0;
            S_wr_lines <= 12'd0;
        end
        else if(S_off) begin
            S_wr_base  <= 10'd0;
            S_wr_ptr   <= 9'd0;
            S_wr_lines <= 12'd0;
        end
        else if(I_tvalid) begin
            if(I_tuser) begin
                // Frame start: this beat is stored at the base address (see
                // S_wr_addr) and the pointer moves on to 1.
                S_wr_ptr <= 9'd1;
            end
            else if(S_wr_ptr == BEATS_LAST) begin
                // Line end taken from the beat count, NOT from I_tlast.
                // awb.v generates I_tlast as "valid fell" (valid_d1 == 0 &&
                // valid_d2 == 1), i.e. 1..2 clocks after the last beat and
                // while I_tvalid is low, so a valid gated line end would
                // never be seen.  1280 pixels / 4 pixels per beat = 320.
                S_wr_base  <= (S_wr_base == ROW_LIMIT) ? 10'd0 : (S_wr_base + 10'd320);
                S_wr_ptr   <= 9'd0;
                S_wr_lines <= S_wr_lines + 12'd1;
            end
            else begin
                S_wr_ptr <= S_wr_ptr + 9'd1;
            end
        end
    end

    // ---- read side: one line behind, beat order reversed ----------------
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_rd_base  <= 10'd0;
            S_rd_pres  <= 9'd0;
            S_rd_ptr   <= 9'd0;
            S_rd_act   <= 1'b0;
            S_rd_lines <= 12'd0;
            M_vld      <= 1'b0;
            M_last     <= 1'b0;
        end
        else if(S_off) begin
            S_rd_base  <= 10'd0;
            S_rd_pres  <= 9'd0;
            S_rd_ptr   <= 9'd0;
            S_rd_act   <= 1'b0;
            S_rd_lines <= 12'd0;
            M_vld      <= 1'b0;
            M_last     <= 1'b0;
        end
        else if(S_start_now) begin
            S_rd_act  <= 1'b1;
            S_rd_pres <= 9'd1;
            S_rd_ptr  <= BEATS_SECOND;
            M_vld     <= 1'b1;
            M_last    <= 1'b0;
        end
        else if(S_rd_act) begin
            M_vld  <= 1'b1;
            M_last <= (S_rd_pres == BEATS_LAST);
            if(S_rd_pres == BEATS_LAST) begin
                S_rd_act   <= 1'b0;
                S_rd_base  <= (S_rd_base == ROW_LIMIT) ? 10'd0 : (S_rd_base + 10'd320);
                S_rd_lines <= S_rd_lines + 12'd1;
            end
            else begin
                S_rd_pres <= S_rd_pres + 9'd1;
                S_rd_ptr  <= S_rd_ptr  - 9'd1;
            end
        end
        else begin
            M_vld  <= 1'b0;
            M_last <= 1'b0;
        end
    end

    // ---- output: bypass when mirroring is off (bit identical to before) --
    assign O_edge_hits = S_mir_now ? (M_vld ? S_edge_q : 2'b00) : I_edge_hits;
    assign O_tvalid = S_mir_now ? M_vld               : I_tvalid;
    assign O_tuser  = S_mir_now ? S_usr_dly_out       : I_tuser;
    assign O_tlast  = S_mir_now ? M_last              : I_tlast;
    assign O_tdata  = S_mir_now ? (M_vld ? S_ram_q : 96'd0) : I_tdata;

endmodule
