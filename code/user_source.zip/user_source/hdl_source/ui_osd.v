// MCU-owned menu and configuration. Pixel-side work is two synchronous RAM
// reads. Writes target the inactive text bank; publication occurs in blank.
module ui_osd #(
    parameter FONT_FILE = "G:/FPGAcompetition/test/lab_integrated_sc520_720p_v2.7-4/lab_integrated_sc520_720p_v2.7/user_source/hdl_source/ui_font_0.dat",
    parameter FONT_FILE1 = "G:/FPGAcompetition/test/lab_integrated_sc520_720p_v2.7-4/lab_integrated_sc520_720p_v2.7/user_source/hdl_source/ui_font_1.dat",
    parameter FONT_FILE3 = "G:/FPGAcompetition/test/lab_integrated_sc520_720p_v2.7-4/lab_integrated_sc520_720p_v2.7/user_source/hdl_source/ui_font_3.dat",
    parameter FONT_FILE2 = "G:/FPGAcompetition/test/lab_integrated_sc520_720p_v2.7-4/lab_integrated_sc520_720p_v2.7/user_source/hdl_source/ui_font_2.dat"
)(
    input wire I_bus_clk, I_bus_rst_n,
    input wire [6:0] I_paddr,
    input wire I_psel, I_penable, I_pwrite,
    input wire [31:0] I_pwdata,
    output reg [31:0] O_prdata,
    output wire O_pready, O_pslverr,
    input wire [3:0] I_button, I_switch,
    input wire [18:0] I_ae_ag,
    input wire [7:0] I_spot_status, // already coherent in the bus clock domain
    output reg [127:0] O_config,
    output reg O_hide_request,
    output wire O_hide_active,
    output reg O_reset_request,
    output wire O_servo_pan,O_servo_tilt,
    input wire I_pixel_clk, I_pixel_rst_n, I_vsync,
    input wire [11:0] I_x, I_y,
    input wire I_de, I_hide,
    output wire O_hit,
    output wire [23:0] O_color
);
    // Word 0: AE/WB,CENTER,MIR,FLP,HIST,EQ,SAT,CNN,MOTION; mode[12:10],
    // TRACK[13], reserved[14], SPOT[15], SEARCH[16].
    // Word 1: RGB lower 32 bits. Word 2: RGB upper16,fill,target,sensitivity,
    // custom RGB[22], reserved[23], binary threshold[31:24]. Word 3: manual exposure/gain,load toggle,
    // edge threshold[30:20]. Both bank contents and config are independent.
    localparam [127:0] DEFAULT_CONFIG = {32'h050087c7,32'h8010a0ff,32'h00820082,32'h00000000};
    reg [127:0] staging;
    (* async_reg="true" *) reg [3:0] key_meta,key_sync,sw_meta,sw_sync;
    reg [11:0] write_index;
    reg publish;
    (* async_reg="true" *) reg ack_meta,ack_sync;
    (* async_reg="true" *) reg valid_meta,valid_sync;
    reg acknowledged;
    reg vsync_d,front,valid_bank;
    wire busy=publish!=ack_sync;
    wire access=I_psel&&I_penable;
    wire write_allowed=(I_paddr==7'h10)||(I_paddr==7'h14)||
        (I_paddr==7'h18)||(I_paddr==7'h1c)||(I_paddr==7'h20)||(I_paddr==7'h34)||(I_paddr==7'h38)||(I_paddr==7'h3c)||
        ((I_paddr==7'h24||I_paddr==7'h28||I_paddr==7'h2c)&&!busy);
    assign O_pready=1'b1;
    assign O_pslverr=access&&((I_paddr[1:0]!=0)||
        (I_pwrite&&!write_allowed)||
        (I_pwrite&&I_paddr==7'h24&&I_pwdata>=3600)||
        (I_pwrite&&I_paddr==7'h28&&write_index>=3600));
    wire write_accept=access&&I_pwrite&&!O_pslverr;
    wire [31:0] servo_command;
    servo_pwm2 u_servo_pwm (
        .I_clk(I_bus_clk),.I_rst_n(I_bus_rst_n),
        .I_write(write_accept&&(I_paddr==7'h3c)),.I_command(I_pwdata),
        .O_pan(O_servo_pan),.O_tilt(O_servo_tilt),.O_command(servo_command));
    // Explicit vendor DP RAM avoids TD mapping the dual-clock text banks to
    // distributed LUT RAM. 4096 cells/bank, 3600 visible; no video frame RAM.
    wire [11:0] row80=({6'd0,I_y[9:4]}<<6)+({6'd0,I_y[9:4]}<<4);
    wire [11:0] cell_address=row80+{5'd0,I_x[10:4]};
    wire [9:0] cell_q;
    wire cell_write=write_accept&&(I_paddr==7'h28);
    // Separate 4K banks use four native 4096x5 ERAM blocks instead of
    // five 8192x2 blocks. Register the selected read bank with the memory
    // read, including the publication edge, so cell_q stays one clock late.
    wire [19:0] text_q;
    reg text_read_bank;
    always @(posedge I_pixel_clk) text_read_bank<=front;
    assign cell_q=text_read_bank?text_q[19:10]:text_q[9:0];
    genvar text_bank;
    generate for(text_bank=0;text_bank<2;text_bank=text_bank+1)begin:g_text
    wire bank_write=cell_write&&((!publish)==text_bank);
    PH1P_LOGIC_ERAM #(
        .DATA_WIDTH_A(10),.DATA_WIDTH_B(10),.ADDR_WIDTH_A(12),.ADDR_WIDTH_B(12),
        .DATA_DEPTH_A(4096),.DATA_DEPTH_B(4096),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
        .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),
        .OREGSET_A("RESET"),.OREGSET_B("RESET"),
        .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
        .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
        .INIT_FILE("NONE"),.FILL_ALL("NONE")
    ) u_text_ram (
        .dia(I_pwdata[9:0]),.dib(10'd0),
        .addra(write_index),.addrb(cell_address),
        .cea(bank_write),.ceb(1'b1),.ocea(1'b0),.oceb(1'b0),
        .clka(I_bus_clk),.clkb(I_pixel_clk),.wea(bank_write),.web(1'b0),
        .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
        .doa(),.dob(text_q[text_bank*10+:10]),.ecc_sbiterr(),.ecc_dbiterr(),
        .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
    end endgenerate
    always @(*) begin
        O_prdata=0;
        case(I_paddr)
            7'h00:O_prdata=32'h55493138;
            7'h04:O_prdata={24'd0,~sw_sync,~key_sync};
            7'h08:O_prdata={30'd0,valid_sync,busy};
            7'h10:O_prdata=staging[31:0];
            7'h14:O_prdata=staging[63:32];
            7'h18:O_prdata=staging[95:64];
            7'h1c:O_prdata=staging[127:96];
            7'h24:O_prdata={20'd0,write_index};
            7'h3c:O_prdata=servo_command;
            7'h30:O_prdata={13'd0,I_ae_ag};
            7'h34:O_prdata={31'd0,O_hide_request};
            7'h40:O_prdata={16'h5352,8'd0,I_spot_status}; // SR: display-side status ABI
            default:O_prdata=0;
        endcase
    end
    always @(posedge I_bus_clk or negedge I_bus_rst_n) begin
        if(!I_bus_rst_n) begin
            key_meta<=4'hf;key_sync<=4'hf;sw_meta<=4'hf;sw_sync<=4'hf;
            write_index<=0;publish<=0;ack_meta<=0;ack_sync<=0;valid_meta<=0;valid_sync<=0;
            staging<=DEFAULT_CONFIG;O_config<=DEFAULT_CONFIG;O_hide_request<=0;
            O_reset_request<=0;
        end else begin
            key_meta<=I_button;key_sync<=key_meta;
            sw_meta<=I_switch;sw_sync<=sw_meta;
            ack_meta<=acknowledged;ack_sync<=ack_meta;
            valid_meta<=valid_bank;valid_sync<=valid_meta;
            if(write_accept) case(I_paddr)
                // Reserved bits are hard zero. Keeping them as writable state
                // needlessly replicates flops/comparators in both 128-bit CDCs.
                7'h10:staging[31:0]<={15'd0,I_pwdata[16:15],1'b0,I_pwdata[13:0]};
                7'h14:staging[63:32]<=I_pwdata;
                7'h18:staging[95:64]<={I_pwdata[31:24],1'b0,I_pwdata[22:0]};
                7'h1c:staging[127:96]<={1'b0,I_pwdata[30:0]};
                7'h20:O_config<=staging;
                7'h24:write_index<=I_pwdata[11:0];
                7'h28:write_index<=write_index+1'b1;
                7'h2c:publish<=!publish;
                7'h34:O_hide_request<=I_pwdata[0];
                // Exact command, KEY4 alone, and all four switches OFF. The request is
                // sticky until system reset; no short self-clearing pulse.
                7'h38:if(I_pwdata==32'h52535431&&(&sw_sync)&&key_sync==4'b0111)O_reset_request<=1;
                default:begin end
            endcase
        end
    end
    (* async_reg="true" *) reg pub_meta,pub_sync;
    (* async_reg="true" *) reg [1:0] hide_sync;
    reg hide_frame;
    assign O_hide_active=hide_frame;
    always @(posedge I_pixel_clk or negedge I_pixel_rst_n) begin
        if(!I_pixel_rst_n) begin
            pub_meta<=0;pub_sync<=0;acknowledged<=0;
            vsync_d<=0;front<=0;valid_bank<=0;hide_sync<=0;hide_frame<=0;
        end else begin
            pub_meta<=publish;pub_sync<=pub_meta;vsync_d<=I_vsync;
            hide_sync<={hide_sync[0],I_hide};
            if(I_vsync&&!vsync_d)hide_frame<=hide_sync[1];
            if(I_vsync&&!vsync_d&&(pub_sync!=acknowledged)) begin
                front<=pub_sync;acknowledged<=pub_sync;valid_bank<=1;
            end
        end
    end
    reg [3:0] x1,x2,y1;
    reg active1,active2,selected2;
    reg [7:0] code2;
    // Four exact 1024x16 ROM banks hold the expanded Chinese font in
    // 4096 words. Register the bank alongside the synchronous RAM reads,
    // preserving the original one-clock lookup and every glyph bit.
    wire [15:0] glyph_q;
    wire [63:0] font_q;
    reg [1:0] font_bank;
    always @(posedge I_pixel_clk) font_bank<=cell_q[7:6];
    assign glyph_q=(font_bank==0)?font_q[15:0]:
                   (font_bank==1)?font_q[31:16]:
                   (font_bank==2)?font_q[47:32]:font_q[63:48];
    genvar font_part;
    generate for(font_part=0;font_part<4;font_part=font_part+1)begin:g_font
    PH1P_LOGIC_ERAM #(
        .DATA_WIDTH_A(16),.DATA_WIDTH_B(16),.ADDR_WIDTH_A(10),.ADDR_WIDTH_B(10),
        .DATA_DEPTH_A(1024),.DATA_DEPTH_B(1024),.MODE("SP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
        .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),
        .OREGSET_A("RESET"),.OREGSET_B("RESET"),
        .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
        .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
        .INIT_FILE(font_part==0?FONT_FILE:(font_part==1?FONT_FILE1:(font_part==2?FONT_FILE2:FONT_FILE3))),.FILL_ALL("NONE")
    ) u_font_rom (
        .dia(16'd0),.dib(16'd0),.addra({cell_q[5:0],y1}),.addrb(10'd0),
        .cea(1'b1),.ceb(1'b0),.ocea(1'b0),.oceb(1'b0),
        .clka(I_pixel_clk),.clkb(1'b0),.wea(1'b0),.web(1'b0),
        .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
        .doa(font_q[font_part*16+:16]),.dob(),.ecc_sbiterr(),.ecc_dbiterr(),
        .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
    end endgenerate
    always @(posedge I_pixel_clk) begin
        x1<=I_x[3:0];y1<=I_y[3:0];
        active1<=I_de&&I_x<1280&&I_y<720&&valid_bank;
        x2<=x1;code2<=cell_q[7:0];selected2<=cell_q[8];
        // Cell bit 9 bypasses KEY2 for MCU latency diagnostics only.
        // It fits the spare bit in the existing four 4096x5 ERAMs.
        active2<=active1&&(!hide_frame||cell_q[9]);
    end
    assign O_hit=active2&&(code2!=0);
    assign O_color=glyph_q[15-x2]?(selected2?24'hffff00:24'hffffff):24'h182028;
endmodule
