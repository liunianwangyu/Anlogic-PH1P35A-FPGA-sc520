`timescale 1ns/1ps
// Existing MCU AHB clock is 100 MHz. One shared 1-us enable and 20-ms phase.
// Atomic paired write; commands only take effect at the next frame boundary.
// No MCU polling dependency after a write, no new clock/PLL/RAM/DSP.
module servo_pwm2 #(
    parameter integer CLOCKS_PER_US=100,
    parameter integer PAN_MIN=1111,PAN_MAX=1889,TILT_MIN=1111,TILT_MAX=1889
)(
    input I_clk,I_rst_n,I_write,
    input [31:0] I_command,
    output reg O_pan,O_tilt,
    output [31:0] O_command
);
    localparam integer DIV_BITS=CLOCKS_PER_US>1?$clog2(CLOCKS_PER_US):1;
    reg [DIV_BITS-1:0] divider;
    reg [14:0] phase;
    reg [11:0] pan_pending,tilt_pending,pan_active,tilt_active;
    assign O_command={4'd0,tilt_pending,4'd0,pan_pending};
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            divider<=0;phase<=19999;O_pan<=0;O_tilt<=0;
            pan_pending<=1500;tilt_pending<=1500;pan_active<=1500;tilt_active<=1500;
        end else begin
            if(I_write)begin
                pan_pending<=I_command[11:0]<PAN_MIN?PAN_MIN:
                             (I_command[11:0]>PAN_MAX?PAN_MAX:I_command[11:0]);
                tilt_pending<=I_command[27:16]<TILT_MIN?TILT_MIN:
                              (I_command[27:16]>TILT_MAX?TILT_MAX:I_command[27:16]);
            end
            if(divider==CLOCKS_PER_US-1)begin
                divider<=0;
                if(phase==19999)begin
                    phase<=0;pan_active<=pan_pending;tilt_active<=tilt_pending;
                    O_pan<=1;O_tilt<=1;
                end else begin
                    phase<=phase+1'b1;
                    if(phase==pan_active-1'b1)O_pan<=0;
                    if(phase==tilt_active-1'b1)O_tilt<=0;
                end
            end else divider<=divider+1'b1;
        end
    end
endmodule
