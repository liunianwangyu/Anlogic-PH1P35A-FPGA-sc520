// v2.0: passive 64x36 luminance capture and MCU-owned motion results.
// 16x16 box averages inside 20x20 cells suppress sensor/texture noise.
// Snapshot RAM is frozen through the entire job. Neither port backpressures video.
module motion_video #(parameter REGISTRATION_HW=0)(
    input I_clk,I_rst_n,I_capture_clk,I_capture_rst_n,
    input [95:0] I_capture_rgb,
    input I_capture_valid,I_capture_user,I_capture_last,
    input I_enable,I_mirror,I_flip,I_frame,
    input [11:0] I_x,I_y,
    input I_de,input [15:0] I_time_ms,
    output O_fill,O_box,
    output [6:0] O_count,
    output [7:0] O_count_bcd,
    output O_camera,
    input [5:0] I_paddr,
    input I_psel,I_penable,I_pwrite,
    input [31:0] I_pwdata,
    output reg [31:0] O_prdata,
    output O_pready,O_pslverr
);
    wire reset_n=I_rst_n&&(REGISTRATION_HW?I_capture_rst_n:1'b1);
    wire capture_reset_n=I_capture_rst_n&&(REGISTRATION_HW?I_rst_n:1'b1);
    reg request;
    (* async_reg="true" *) reg req_meta,req_sync;
    reg completed,capturing,frame_pending,capture_bad;
    reg [8:0] line_beats;
    reg [9:0] capture_lines;
    reg [11:0] samples_written;
    reg capture_fault;
    // Accept either an early demosaic SOF or SOF on the first valid beat.
    // Retain an early marker through blanking and valid bubbles.
    wire frame_start=I_capture_user||frame_pending;
    reg [2:0] beat; // five groups of four pixels per grid cell
    reg [4:0] row;
    reg [5:0] col,grid_y;
    reg [11:0] sample_index;
    reg [11:0] line_sum;
    reg [15:0] column_sum [0:63];
    function [7:0] luma;
        input [23:0] rgb;
        reg [9:0] s;
        begin s={2'b0,rgb[23:16]}+{1'b0,rgb[15:8],1'b0}+{2'b0,rgb[7:0]};luma=s[9:2];end
    endfunction
    wire [9:0] four={2'b0,luma(I_capture_rgb[23:0])}+{2'b0,luma(I_capture_rgb[47:24])}+
        {2'b0,luma(I_capture_rgb[71:48])}+{2'b0,luma(I_capture_rgb[95:72])};
    wire [15:0] accumulated=(row==0?16'd0:column_sum[col])+line_sum+four;
    wire sample_write=capturing&&I_capture_valid&&!frame_start&&beat==3&&row==15;
    wire [7:0] snapshot_q;
    reg [11:0] read_index;
    reg [2:0] state;
    localparam IDLE=0,CAPTURE=1,PENDING=2,SWAP=3,PROCESS=4;
    wire [11:0] hw_read_index;
    wire hw_done,hw_reference_valid,hw_fault;
    wire signed [5:0] hw_dx,hw_dy;
    wire signed [6:0] hw_bias;
    wire [11:0] hw_score;
    wire [20:0] hw_cycles;
    reg hw_start,hw_invalidate,discard_capture;
    reg [2:0] configuration;
    reg [15:0] job_ms,published_ms;
    reg capture_expired;
    reg [9:0] fault_count;
    wire config_changed=configuration!={I_enable,I_mirror,I_flip};
    wire [15:0] capture_age=I_time_ms-job_ms,result_age=I_time_ms-published_ms;
    wire [31:0] registration_result={hw_reference_valid,hw_score,hw_bias,hw_dy,hw_dx};
    motion_ram #(.AW(12)) u_snapshot (
        .I_wclk(I_capture_clk),.I_we(sample_write),.I_waddr(sample_index),.I_data(accumulated[15:8]),
        .I_rclk(I_clk),.I_raddr(REGISTRATION_HW&&state==PROCESS?hw_read_index:read_index),.O_data(snapshot_q));
    always @(posedge I_capture_clk or negedge capture_reset_n) begin
        if(!capture_reset_n) begin
            req_meta<=0;req_sync<=0;completed<=0;capturing<=0;frame_pending<=0;
            beat<=0;row<=0;col<=0;grid_y<=0;sample_index<=0;line_sum<=0;
            capture_bad<=0;capture_fault<=0;line_beats<=0;capture_lines<=0;samples_written<=0;
        end else begin
            req_meta<=request;req_sync<=req_meta;
            if(I_capture_user)frame_pending<=1;
            if(I_capture_valid) begin
                if(frame_start) begin
                    frame_pending<=0;
                    if(req_sync!=completed) begin
                        capturing<=1;beat<=1;row<=0;col<=0;grid_y<=0;sample_index<=0;line_sum<=four;
                        capture_bad<=I_capture_last;line_beats<=1;capture_lines<=0;samples_written<=0;capture_fault<=0;
                    end else capturing<=0;
                end else if(capturing) begin
                    if(sample_write)samples_written<=samples_written+1'b1;
                    if(I_capture_last)begin
                        if(line_beats!=319)capture_bad<=1;
                        line_beats<=0;capture_lines<=capture_lines+1'b1;
                    end else begin
                        if(line_beats==319)capture_bad<=1;
                        if(line_beats<511)line_beats<=line_beats+1'b1;
                    end
                    if(beat<4&&row<16)line_sum<=beat==0?{2'b0,four}:line_sum+four;
                    if(beat==3&&row<16) begin
                        column_sum[col]<=accumulated;
                        if(row==15)sample_index<=sample_index+1'b1;
                    end
                    if(I_capture_last) begin
                        beat<=0;col<=0;line_sum<=0;
                        if(row==19)begin row<=0;grid_y<=grid_y+1'b1;end
                        else row<=row+1'b1;
                        if(grid_y==35&&row==19)begin
                            capturing<=0;completed<=req_sync;
                            capture_fault<=capture_bad||line_beats!=319||capture_lines!=719||samples_written!=2304;
                        end
                    end else if(beat==4)begin beat<=0;col<=col+1'b1;end
                    else beat<=beat+1'b1;
                    // A truncated frame restarts at the next SOF's first pixel.
                end
            end
        end
    end
    (* async_reg="true" *) reg done_meta,done_sync;
    reg [31:0] token;
    generate if(REGISTRATION_HW)begin:g_registration
        motion_hw_core u_core(
            .I_clk(I_clk),.I_rst_n(reset_n),.I_start(hw_start),
            .I_abort(config_changed||!I_enable||hw_invalidate),
            .O_snapshot_addr(hw_read_index),.I_snapshot_data(snapshot_q),
            .O_done(hw_done),.O_reference_valid(hw_reference_valid),.O_fault(hw_fault),
            .O_dx(hw_dx),.O_dy(hw_dy),.O_bias(hw_bias),.O_score(hw_score),.O_cycles(hw_cycles));
    end else begin:g_software
        assign hw_read_index=0;assign hw_done=0;assign hw_reference_valid=0;assign hw_fault=0;
        assign hw_dx=0;assign hw_dy=0;assign hw_bias=0;assign hw_score=0;assign hw_cycles=0;
    end endgenerate
    reg front,valid_result;
    reg [8:0] write_index;
    reg [3:0] box_index;
    reg [191:0] boxes0,boxes1;
    // [15:8] MCU decimal digits, [7] camera, [6:0] original binary count.
    reg [15:0] staged_status,front_status;
    reg [5:0] age;
    wire access=I_psel&&I_penable;
    wire read_ok=I_paddr==0||I_paddr==4||I_paddr==8||I_paddr==12||I_paddr==16;
    wire write_ok=(I_paddr==12&&I_pwdata<(REGISTRATION_HW?2306:2304)&&state==PENDING)||
        (I_paddr==20&&!REGISTRATION_HW&&write_index<288&&state==PENDING)||
        (I_paddr==24&&box_index<8&&state==PENDING)||
        (I_paddr==28&&I_pwdata[6:0]<=99&&state==PENDING)||
        (I_paddr==32&&state==PENDING&&I_pwdata==token&&write_index==288&&box_index==8);
    assign O_pready=1'b1;
    assign O_pslverr=access&&(I_paddr[1:0]!=0||(I_pwrite?!write_ok:!read_ok));
    wire wr=access&&I_pwrite&&!O_pslverr;
    wire [5:0] cell_x=I_x/20,cell_y=I_y/20;
    wire [5:0] view_x=I_mirror?(6'd63-cell_x):cell_x;
    wire [5:0] view_y=I_flip?(6'd35-cell_y):cell_y;
    // Keep the MOT2 transaction/count ABI. Legacy mask writes are checked
    // and counted, but no longer stored: the display shows rectangles only.
    reg [5:0] px,py;
    reg de_d;
    always @(posedge I_clk)begin px<=view_x;py<=view_y;de_d<=I_de;end
    reg [23:0] b;
    // Pixel precision for a 2-pixel border, including mirror/flip mapping.
    reg [4:0] sub_x,sub_y;
    always @(posedge I_clk)begin sub_x<=I_x%20;sub_y<=I_y%20;end
    reg edge_hit;
    always @*begin
        edge_hit=0;b=0;
        for(integer j=0;j<8;j=j+1)begin
            if(front) b=boxes1[j*24+:24];else b=boxes0[j*24+:24];
            if(b[23:18]<=b[11:6]&&b[17:12]<=b[5:0]&&px>=b[23:18]&&px<=b[11:6]&&py>=b[17:12]&&py<=b[5:0])
                if((px==b[23:18]&&(I_mirror?sub_x>=18:sub_x<2))||
                   (px==b[11:6]&&(I_mirror?sub_x<2:sub_x>=18))||
                   (py==b[17:12]&&(I_flip?sub_y>=18:sub_y<2))||
                   (py==b[5:0]&&(I_flip?sub_y<2:sub_y>=18)))edge_hit=1;
        end
    end
    assign O_fill=1'b0;
    assign O_box=I_enable&&valid_result&&de_d&&edge_hit;
    assign O_count=valid_result?front_status[6:0]:7'd0;
    assign O_count_bcd=valid_result?front_status[15:8]:8'd0;
    assign O_camera=valid_result&&front_status[7];
    always @*begin
        O_prdata=0;
        case(I_paddr)
            0:O_prdata=32'h4d4f5432;
            4:O_prdata={30'd0,I_enable,(state==PENDING)};
            8:O_prdata=token;
            12:O_prdata={REGISTRATION_HW?1'b1:1'b0,19'd0,read_index};
            16:O_prdata=REGISTRATION_HW&&read_index==2304?registration_result:
                (REGISTRATION_HW&&read_index==2305?{fault_count,hw_fault,hw_cycles}:{24'd0,snapshot_q});
            default:begin end
        endcase
    end
    always @(posedge I_clk or negedge reset_n)begin
        if(!reset_n)begin
            request<=0;done_meta<=0;done_sync<=0;token<=0;state<=IDLE;
            read_index<=0;write_index<=0;box_index<=0;front<=0;valid_result<=0;
            staged_status<=0;front_status<=0;boxes0<=0;boxes1<=0;age<=0;
            hw_start<=0;hw_invalidate<=0;discard_capture<=0;configuration<=0;
            job_ms<=0;published_ms<=0;capture_expired<=0;fault_count<=0;
        end else begin
            hw_start<=0;hw_invalidate<=0;
            configuration<={I_enable,I_mirror,I_flip};
            done_meta<=completed;done_sync<=done_meta;
            if(I_frame)begin
                if(age<63)age<=age+1'b1;
                if(REGISTRATION_HW?result_age>=500:age>=30)valid_result<=0;
                if(!I_enable)begin valid_result<=0;front_status<=0;end
                if(state==SWAP)begin
                    front<=!front;valid_result<=I_enable;front_status<=staged_status;age<=0;state<=IDLE;published_ms<=I_time_ms;
                end
            end
            if(state==IDLE&&I_enable&&done_sync==request&&(!REGISTRATION_HW||!config_changed))begin
                request<=!request;token<=token+1'b1;state<=CAPTURE;
                job_ms<=I_time_ms;capture_expired<=0;discard_capture<=0;
            end
            if(state==CAPTURE&&done_sync==request)begin
                read_index<=0;write_index<=REGISTRATION_HW?288:0;box_index<=0;
                if(REGISTRATION_HW)begin
                    if(capture_fault||discard_capture||capture_expired||!I_enable)begin
                        state<=IDLE;hw_invalidate<=1;valid_result<=0;
                        if(capture_fault&&fault_count!=1023)fault_count<=fault_count+1'b1;
                    end else begin state<=PROCESS;hw_start<=1;end
                end else state<=PENDING;
            end
            if(REGISTRATION_HW&&state==PROCESS&&hw_done)begin
                if(hw_fault)begin state<=IDLE;valid_result<=0;if(fault_count!=1023)fault_count<=fault_count+1'b1;end
                else state<=PENDING;
            end
            if(REGISTRATION_HW&&state==CAPTURE&&!capture_expired&&capture_age>=500)begin
                capture_expired<=1;valid_result<=0;hw_invalidate<=1;if(fault_count!=1023)fault_count<=fault_count+1'b1;
            end
            if(access&&!I_pwrite&&!O_pslverr&&I_paddr==16&&read_index<(REGISTRATION_HW?2305:2303))read_index<=read_index+1'b1;
            if(wr)case(I_paddr)
                12:read_index<=I_pwdata[11:0];
                20:write_index<=write_index+1'b1;
                24:begin
                    if(front)boxes0[box_index*24+:24]<=I_pwdata[23:0];else boxes1[box_index*24+:24]<=I_pwdata[23:0];
                    box_index<=box_index+1'b1;
                end
                28:staged_status<=I_pwdata[15:0];
                // A menu policy edge can arrive between the MCU's bounded
                // box/status writes. Drain that existing token without bus
                // errors, discard its result, then release the frozen RAM.
                32:state<=(REGISTRATION_HW&&(discard_capture||config_changed||!I_enable))?IDLE:SWAP;
                default:begin end
            endcase
            if(REGISTRATION_HW&&config_changed)begin
                valid_result<=0;front_status<=0;discard_capture<=1;
                if(state!=PENDING&&(state!=CAPTURE||done_sync==request))state<=IDLE;
            end
        end
    end
endmodule

// HX1P35A: PNP digit drivers and segments are both active LOW. Only the
// rightmost two positions are scanned; the other six and DP remain OFF.
// At 75 MHz, each digit refreshes at 1144 Hz. Blank for 256 clocks between
// digits, change segments halfway through blanking, then enable the digit.
// One BCD snapshot per complete scan prevents mixed old/new digit pairs.
module motion_seven_segment #(parameter SCAN_BITS=16, BLANK_BITS=8)(
    input I_clk,I_rst_n,
    input [7:0] I_count_bcd,
    output reg [7:0] O_segment,
    output wire [7:0] O_select
);
    reg [SCAN_BITS-1:0] scan;
    reg [7:0] digits;
    reg [1:0] select_n;
    wire tens=scan[SCAN_BITS-1];
    wire [3:0] digit=tens?digits[7:4]:digits[3:0];
    assign O_select={select_n,6'b111111};
    function [7:0] segments;
        input [3:0] value;
        begin case(value)
            0:segments=8'hc0;1:segments=8'hf9;2:segments=8'ha4;
            3:segments=8'hb0;4:segments=8'h99;5:segments=8'h92;
            6:segments=8'h82;7:segments=8'hf8;8:segments=8'h80;
            9:segments=8'h90;default:segments=8'hff;
        endcase end
    endfunction
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin scan<=0;digits<=0;select_n<=2'b11;O_segment<=8'hff;end
        else begin
            scan<=scan+1'b1;
            if(scan==0)digits<=I_count_bcd;
            if(scan[SCAN_BITS-2:0]==0)select_n<=2'b11;
            if(scan[SCAN_BITS-2:0]==(1<<(BLANK_BITS-1)))O_segment<=segments(digit);
            if(scan[SCAN_BITS-2:0]==(1<<BLANK_BITS))
                select_n<=tens?(digits[7:4]==0?2'b11:2'b10):2'b01;
        end
    end
endmodule

// Existing PH1P ERAM primitive: deterministic block-RAM mapping, no new IP license.
module motion_ram #(parameter AW=12)(
    input I_wclk,I_we,input [AW-1:0] I_waddr,input [7:0] I_data,
    input I_rclk,input [AW-1:0] I_raddr,output [7:0] O_data
);
    PH1P_LOGIC_ERAM #(
        .DATA_WIDTH_A(8),.DATA_WIDTH_B(8),.ADDR_WIDTH_A(AW),.ADDR_WIDTH_B(AW),
        .DATA_DEPTH_A(1<<AW),.DATA_DEPTH_B(1<<AW),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),.WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
        .CLKMODE("ASYNC"),.SSROVERCE("DISABLE"),.OREGSET_A("RESET"),.OREGSET_B("RESET"),
        .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),.ASYNC_RESET_RELEASE_A("ASYNC"),
        .ASYNC_RESET_RELEASE_B("ASYNC"),.INIT_FILE("NONE"),.FILL_ALL("NONE")
    ) u_ram (
        .dia(I_data),.dib(8'd0),.addra(I_waddr),.addrb(I_raddr),.cea(I_we),.ceb(1'b1),
        .ocea(1'b0),.oceb(1'b0),.clka(I_wclk),.clkb(I_rclk),.wea(I_we),.web(1'b0),
        .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),.doa(),.dob(O_data),
        .ecc_sbiterr(),.ecc_dbiterr(),.ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
endmodule
