//=============================================================================
// cnn_linebuf.v  --  3 行滑窗行缓存（参考实现，当前条带缓冲架构下不例化）
// 依据：条带缓冲是线性存储、PE 每位置要 2304 拍，行缓存不需要流式；
//       其"模 3 行旋转"功能已并入条带缓冲寻址，本文件保留作参考。
// 行映射：cur_row 在 I_row_done 时已推进为"下一个待写行"，故
//         最新行(rd_row=0) = (cur_row+2)%3，上一行 = (cur_row+1)%3，上两行 = cur_row。
//=============================================================================
`timescale 1ns / 1ps
module cnn_linebuf #(
    parameter integer IC = 4,
    parameter integer AW = 9
)(
    input  wire                I_clk,
    input  wire                I_rst_n,
    input  wire                I_wr_en,
    input  wire [IC*8-1:0]     I_wr_data,
    input  wire                I_row_done,
    input  wire [1:0]          I_rd_row,
    input  wire [AW-1:0]       I_rd_col,
    output reg  [IC*8-1:0]     O_rd_data,
    output reg  [1:0]          O_rows_ready
);
    localparam integer ROWWORDS = (1 << AW);
    (* ram_style = "block" *) reg [IC*8-1:0] mem [0:3*ROWWORDS-1];

    reg [1:0]    cur_row;
    reg [AW-1:0] wr_col;

    wire [2:0]    t_row = {1'b0, cur_row} + 3'd2 - {1'b0, I_rd_row} + 3'd3;
    wire [1:0]    phys  = t_row % 3'd3;
    wire [AW+1:0] rd_addr = {phys, I_rd_col};

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            cur_row      <= 2'd0;
            wr_col       <= {AW{1'b0}};
            O_rows_ready <= 2'd0;
        end else begin
            if (I_wr_en)
                mem[{cur_row, wr_col}] <= I_wr_data;
            if (I_row_done) begin
                cur_row <= (cur_row == 2'd2) ? 2'd0 : (cur_row + 1'b1);
                wr_col  <= {AW{1'b0}};
                if (O_rows_ready != 2'd3) O_rows_ready <= O_rows_ready + 1'b1;
            end else if (I_wr_en) begin
                wr_col <= wr_col + 1'b1;
            end
        end
    end

    always @(posedge I_clk) begin
        O_rd_data <= mem[rd_addr];
    end
endmodule
