//=============================================================================
// cnn_config.vh  --  v1.7 CNN 目标检测：顶层配置与 ERAM 分配表
// 所有数字的来源见同目录 README_cnn.md。
//=============================================================================
`ifndef CNN_CONFIG_VH
`define CNN_CONFIG_VH

//-----------------------------------------------------------------------------
// 1. 存储基本量（依据：DS1300_PH1P_Datasheet v1.2 §2.2.2 表 2-1）
//    ERAM20K 单块 20 Kbit = 2560 B；本项目按 512 字 x 32 bit 使用 => 每块 512 字
//-----------------------------------------------------------------------------
`define CNN_ERAM_BLK_WORDS    512
`define CNN_ERAM_BLK_BYTES    2560

//-----------------------------------------------------------------------------
// 2. 地址位宽
//    特征图按生命周期复用，36 块 = 18432 字；权重为四路独立 ERAM
//    => AWB = 15 (32768 字) 足够
//-----------------------------------------------------------------------------
`define CNN_AWB               15
`define CNN_AW                9          // 每行 2^9 = 512 字

//-----------------------------------------------------------------------------
// 3. PE 阵列（依据：DSP 9x9 拆分实测，见 _cnn_spike/RESULT_dsp_split.md）
//    默认综合 1 个 INT8 乘数 = 1 个 DSP，DSP 余量 20 => 阵列上限 20 个乘数
//    取 4x4 = 16 MAC/拍 = 16 个 DSP，留 4 个给 Otsu 等其他功能
//-----------------------------------------------------------------------------
`define CNN_PE_OC             4
`define CNN_PE_IC             4
`define CNN_PE_MAC_PER_CYCLE  16

//-----------------------------------------------------------------------------
// 4. 特征图存储格式：4 像素/字（与 ISP 4 像素/拍一致）
//    每通道每行字数 = ceil(W/4)；每面字数 = ceil(W/4) * H
//    每位置字数 = ceil(C/4)（C 个通道，每字 4 通道）
//-----------------------------------------------------------------------------
`define CNN_PX_PER_WORD       4

// Feature memory and native weight init paths are generated from cnn_contract.json.
// A=[0,14400): input/F2/Head; B=[14400,18000): F1/F3; pad to 18432.
// Four weight RAMs are independent and do not reserve feature-memory addresses.
`include "cnn_storage_params.vh"

//-----------------------------------------------------------------------------
// 6. 采集：ISP 输出 4 像素/拍，8x8 箱式平均 -> 160x90（1280/8=160, 720/8=90）
//-----------------------------------------------------------------------------
`define CNN_SRC_W             11'd1280
`define CNN_SRC_H             11'd720
`define CNN_SRC_PX_PER_BEAT   4
`define CNN_DOWNSCALE         4'd8
`define CNN_IN_W              11'd160
`define CNN_IN_H              11'd90
`define CNN_IN_CH             8'd4

// 采集侧常量（cnn_capture.v；依据见 README_cnn.md 5.11）
`define CNN_BEATS_PER_LINE   10'd320   // 1280 / 4 像素每拍
`define CNN_GRP_PER_LINE     8'd160    // 1280 / 8
`define CNN_LINES_PER_BAND   4'd8      // 垂直方向 8 行合一带
`define CNN_BANDS            7'd90     // 720 / 8
`define CNN_CAP_ZP           8'd128    // int8 零点：写入 (8x8 均值 + 128)

//-----------------------------------------------------------------------------
// 7. 层数
//-----------------------------------------------------------------------------
`define CNN_MAX_LAYERS        4'd8
`define CNN_NUM_LAYERS        4'd4

//-----------------------------------------------------------------------------
// 8. 检测后处理：网格 20x12 = 240 格；每格 8 通道 = obj(1)+box(4)+class(3)
//-----------------------------------------------------------------------------
`define CNN_GRID_W            11'd20
`define CNN_GRID_H            11'd12
`define CNN_HEAD_CH           8'd8
`define CNN_NUM_CLASS         8'd2
`define CNN_MAX_BOXES         4'd8
`define CNN_OBJ_THRESH        8'd131
`define CNN_IOU_THRESH        8'd128
`define CNN_COORD_SHIFT       4'd3

`endif // CNN_CONFIG_VH
