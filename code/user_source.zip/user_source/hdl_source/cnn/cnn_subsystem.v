//=============================================================================
// cnn_subsystem.v -- v1.7 CNN 目标检测子系统（采集 -> CNN -> 后处理 -> 结果）
//
// 组成：
//   cnn_capture   被动监听 ISP 的 96bit 像素对齐流 -> 写 160x90x4ch int8 输入帧
//   cnn_mem_top   层序列 + 引擎 + 特征图/权重 ERAM
//   cnn_post      阈值 + top-K(8) + 类内 NMS(IoU>0.5) + 坐标映射
//   权重初始化    官方 PH1P_LOGIC_ERAM INIT_FILE，随 BIT 配置
//   帧调度        采集一帧 -> 跑 CNN -> 跑后处理 -> 发布结果 -> 再采集
//
// 时钟：整条链**单时钟域**，用 ISP 的 axi4s_video_aclk（= S_csi_rx_clk，约
//   103.52 MHz，见 v1.6 的 sdc：mipi 时钟 414.08 MHz / 4）。
//   这样采集写输入帧不需要跨时钟域握手（写只有 1 拍脉冲，跨到 100 MHz 会丢）。
//   上板前必须在整机综合里确认这条链在 103.52 MHz 收得住；若收不住，
//   退路是把 mem_top/engine/post 挪到 pll_clk_100m，并在采集写口加一级
//   异步 FIFO（届时再加，现在不提前加）。
//
// 帧调度（关键：单缓冲，所以必须"隔帧"）：
//   采集帧 N（cap_on 在 tuser 锁存）-> frame_done -> 关采集 -> 跑 CNN（约 1.2 ms，
//   只占一帧的 7%）-> 跑后处理（约 8 us）-> 发布 -> 重新开采集。
//   开采集时 N+1 帧的 tuser 已经过去，于是 N+1 被整体丢弃、N+2 被采集 ——
//   结果约 30 fps。CNN 期间输入帧必须以不变状态被读，所以不能"每帧都跑"。
//
// 存储端口复用：cnn_mem_top 的预装端口（I_ld_en/I_ld_sel/I_ld_addr/I_ld_data）
//   协议与 cnn_capture 的写口完全一致（都是 1 拍写脉冲），所以：
//     I_ld_sel = 0 -> 输入帧区（采集写）
//     I_ld_sel = 1..4 -> 4 个权重实例（装载）
//   生产路径仅连接采集；权重测试预装口仍在 cnn_mem_top 保留。
//
// 读端口复用：cnn_mem_top 的读端口（I_rd_addr/O_rd_data，1 拍延迟）在 busy=1 时
//   被 mux 给引擎（cnn_mem_top.v L105），所以后处理必须在 CNN 完成之后启动；
//   非后处理期间该端口让给调试读（I_dbg_addr/O_dbg_data）。
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"
module cnn_subsystem #(parameter integer TRACKING_ENABLE=0, parameter integer DDR_INPUT=0, parameter integer POST_USE_MCU=0) (
    input wire I_ddr_clk,I_ddr_calibrated,
    output wire O_ddr_req,O_ddr_write,
    output wire [24:0] O_ddr_addr,
    output wire [127:0] O_ddr_wdata,
    input wire I_ddr_accept,I_ddr_valid,
    input wire [127:0] I_ddr_rdata,
    input  wire        I_clk,
    input  wire        I_rst_n,
    // 检测使能（可由用户开关控制；0 时不做检测，也不写输入帧）
    input  wire        I_en,
    // ISP 监听流（接 isp_top 的 O_mon_pix/O_mon_valid/O_mon_tuser）
    input  wire        I_pix_valid,
    input  wire        I_pix_tuser,
    input  wire [95:0] I_pix_data,
    input wire I_pix_mirror,
    input wire [1:0] I_edge_hits,
    input wire I_tracking,
    output wire O_result_tracking,
    // 状态与诊断
    output wire [2:0]  O_state,        // 0 装载 1 等帧 2 跑CNN 3 跑后处理 4 发布
    output wire        O_box_valid,    // 至少完成过一帧检测
    output wire [15:0] O_frame_cnt,    // 完成检测的帧数
    output wire [14:0] O_dbg_wr_cnt,   // 采集写字数（健康时恒为 14400）
    output wire        O_dbg_err,      // 采集异常粘滞
    // 结果读端口（OSD 用；O_nbox 个框，第 i 个由 I_rd_idx 读出）
    input  wire [2:0]  I_rd_idx,
    output wire [63:0] O_rd_data,
    output wire [3:0]  O_nbox,
    // 调试读端口（读存储字，1 拍延迟；上板可用来抓 head 原始数据）
    input  wire [14:0] I_dbg_addr,
    output wire [31:0] O_dbg_data,
    // 结果包原始输出（跨时钟域搬运到 HDMI 域画框/上屏用）
    output wire [383:0] O_box_all,   // 8 个框，每框 48 位，布局见 cnn_post.v 5b
    output wire O_spot_fresh,
    output wire [159:0] O_display, // two per-class 80-bit display slots
    output wire [39:0] O_label_bcd,  // box 0 screen-centre label, published with O_box_all
    input wire [7:0] I_paddr,
    input wire I_psel,I_penable,I_pwrite,
    input wire [31:0] I_pwdata,
    output wire [31:0] O_prdata,
    output wire O_pready,O_pslverr,
    output wire         O_pub        // S_PUB 那一拍：结果包已就绪（1 拍脉冲）
);
    localparam [2:0] S_LOAD=3'd0, S_WAIT=3'd1, S_CNN=3'd2, S_CNNW=3'd3,
                     S_POST=3'd4, S_POSTW=3'd5, S_PUB=3'd6;
    reg [2:0] st;
    // Model weights are configured directly into four ERAMs by the BIT.
    // Keep state encodings for diagnostics; S_LOAD is a one-cycle reset exit.
    //-------------------------------------------------------------------------
    // 2. 采集
    //-------------------------------------------------------------------------
    wire        cap_we;
    wire [14:0] cap_addr;
    wire [31:0] cap_data;
    wire        cap_done,cap_start;
    reg         cap_en;
    wire capture_error,post_fault;
    wire ddr_fault,ddr_available,ddr_stored;
    assign O_dbg_err=capture_error|post_fault|ddr_fault;
    cnn_capture u_cap (
        .I_edge_hits(I_edge_hits),
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_pix_valid(I_pix_valid), .I_pix_tuser(I_pix_tuser), .I_pix_data(I_pix_data),
        .I_en(cap_en),
        .O_wr_en(cap_we), .O_wr_addr(cap_addr), .O_wr_data(cap_data),
        .O_frame_start(cap_start),.O_frame_done(cap_done),
        .O_dbg_wr_cnt(O_dbg_wr_cnt), .O_dbg_err(capture_error)
    );
    //-------------------------------------------------------------------------
    // 3. CNN 主体（层序列 + 引擎 + 存储）
    //-------------------------------------------------------------------------
    wire        ld_en;
    wire [2:0]  ld_sel;
    wire [14:0] ld_addr;
    wire [31:0] ld_data;
    reg         mem_start;
    wire        mem_done;
    wire [14:0] mem_rd_addr;
    wire [31:0] mem_rd_data;
    assign ld_en   = cap_we;
    assign ld_sel  = 3'd0;
    assign ld_addr = cap_addr;
    assign ld_data = cap_data;
    wire [14:0] first_addr,first_base;
    wire first_active,first_ready;
    wire [31:0] first_data;
    cnn_mem_top #(.DDR_INPUT(DDR_INPUT)) u_mem (
        .I_first_ready(first_ready),.I_first_data(first_data),
        .O_first_addr(first_addr),.O_first_base(first_base),.O_first_active(first_active),
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_start(mem_start), .O_done(mem_done),
        .I_ld_en(ld_en), .I_ld_sel(ld_sel), .I_ld_addr(ld_addr), .I_ld_data(ld_data),
        .I_rd_addr(mem_rd_addr), .O_rd_data(mem_rd_data)
    );
    generate if(DDR_INPUT)begin:g_ddr_input
        cnn_ddr_input u_input (
            .I_clk(I_clk),.I_rst_n(I_rst_n),.I_capture_start(cap_start),
            .I_capture_we(cap_we),.I_capture_data(cap_data),
            .I_ddr_clk(I_ddr_clk),.I_calibrated(I_ddr_calibrated),
            .O_available(ddr_available),.O_stored(ddr_stored),.O_fault(ddr_fault),
            .I_window_active(first_active),.I_window_base(first_base),.I_read_addr(first_addr),
            .O_window_ready(first_ready),.O_read_data(first_data),
            .O_req(O_ddr_req),.O_write(O_ddr_write),.O_addr(O_ddr_addr),.O_wdata(O_ddr_wdata),
            .I_accept(I_ddr_accept),.I_valid(I_ddr_valid),.I_rdata(I_ddr_rdata));
    end else begin:g_local_input
        assign ddr_fault=0;assign ddr_available=1;assign ddr_stored=1;
        assign first_ready=1;assign first_data=0;
        assign O_ddr_req=0;assign O_ddr_write=0;assign O_ddr_addr=0;assign O_ddr_wdata=0;
    end endgenerate
    //-------------------------------------------------------------------------
    // 4. 后处理
    //-------------------------------------------------------------------------
    reg         post_start;
    wire        post_done;
    wire [14:0] post_addr;
    wire [383:0] post_box_all;
    wire post_busy = (st == S_POST) || (st == S_POSTW);
    assign mem_rd_addr = post_busy ? post_addr : I_dbg_addr;
    assign O_dbg_data  = mem_rd_data;
    // A frame retains the detection-enable generation in which it was captured.
    // Off/on during inference cannot turn an old frame into a fresh voice event.
    reg frame_mirror;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)frame_mirror<=0;
        else if(cap_start)frame_mirror<=I_pix_mirror;
    reg enable_d,tracking_d;
    wire tracking=TRACKING_ENABLE?I_tracking:1'b0;
    wire policy_change=(I_en!=enable_d)||(tracking!=tracking_d);
    reg frame_tracking;
    assign O_result_tracking=frame_tracking;
    reg [31:0] observation_generation,frame_generation;
    always @(posedge I_clk or negedge I_rst_n)
        if(!I_rst_n)begin enable_d<=0;tracking_d<=0;frame_tracking<=0;observation_generation<=0;frame_generation<=0;end
        else begin
            enable_d<=I_en;tracking_d<=tracking;
            if(cap_start)frame_tracking<=tracking;
            if(policy_change)observation_generation<=observation_generation+1'b1;
            if(cap_start)
                frame_generation<=observation_generation+(policy_change?32'd1:32'd0);
        end
    generate if(POST_USE_MCU)begin: g_mcu_post
        cnn_mcu_post #(.TRACKING_ENABLE(TRACKING_ENABLE)) u_post(
            .I_frame_tracking(frame_tracking),
            .I_observation_enabled(I_en&&!capture_error&&!ddr_fault),
            .I_frame_mirror(frame_mirror),.I_observation_generation(observation_generation),.I_frame_generation(frame_generation),
            .I_clk(I_clk),.I_rst_n(I_rst_n),.I_start(post_start),.O_done(post_done),
            .O_mem_addr(post_addr),.I_mem_data(mem_rd_data),
            .I_rd_idx(I_rd_idx),.O_rd_data(O_rd_data),.O_nbox(O_nbox),.O_box_all(post_box_all),
            .O_label_bcd(O_label_bcd),.O_display(O_display),.O_spot_fresh(O_spot_fresh),
            .O_fault(post_fault),.I_paddr(I_paddr),.I_psel(I_psel),.I_penable(I_penable),
            .I_pwrite(I_pwrite),.I_pwdata(I_pwdata),.O_prdata(O_prdata),
            .O_pready(O_pready),.O_pslverr(O_pslverr));
    end else begin: g_rtl_post
        // The deployed design uses MCU post-processing; the legacy RTL-only
        // fallback keeps its original result layout and has no BCD metadata.
        assign O_label_bcd=40'd0;
        assign O_display=160'd0;
        assign O_spot_fresh=1'b0;
        assign post_fault=1'b0;
        assign O_prdata=32'd0;
        assign O_pready=1'b1;
        assign O_pslverr=I_psel&&I_penable;
    cnn_post u_post (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_start(post_start), .O_done(post_done),
        .O_mem_addr(post_addr), .I_mem_data(mem_rd_data),
        .I_rd_idx(I_rd_idx), .O_rd_data(O_rd_data), .O_nbox(O_nbox),
        .O_box_all(post_box_all)
    );

    end endgenerate

    // 发布脉冲：S_PUB 只停 1 拍，此拍 cnn_post 的 res/O_nbox/O_done 全部稳定
    //   （O_done 拉高后要等 I_start 撤除才清，而 S_POST 只给了 1 拍 post_start）
    assign O_pub     = (st == S_PUB);
    assign O_box_all = post_box_all;
    //-------------------------------------------------------------------------
    // 5. 帧调度
    //-------------------------------------------------------------------------
    reg        box_valid;
    reg [15:0] frame_cnt;
    assign O_state = st;
    assign O_box_valid = box_valid;
    assign O_frame_cnt = frame_cnt;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            st <= S_LOAD; cap_en <= 1'b0; mem_start <= 1'b0; post_start <= 1'b0;
            box_valid <= 1'b0; frame_cnt <= 16'd0;
        end else begin
            mem_start  <= 1'b0;
            post_start <= 1'b0;
            case (st)
            S_LOAD:  st <= S_WAIT;
            S_WAIT:  begin
                cap_en <= I_en && ddr_available;
                if (I_en && cap_done) begin
                    cap_en <= 1'b0;              // CNN 期间输入帧必须保持不变
                    st     <= S_CNN;
                end
            end
            S_CNN: if(ddr_fault)st<=S_POST;
                     else if(ddr_stored)begin mem_start <= 1'b1; st <= S_CNNW; end
            S_CNNW:  if (mem_done || ddr_fault) st <= S_POST;
            S_POST:  begin post_start <= 1'b1; st <= S_POSTW; end
            S_POSTW: if (post_done) st <= S_PUB;
            S_PUB:   begin
                box_valid <= 1'b1;
                frame_cnt <= frame_cnt + 16'd1;
                st        <= S_WAIT;
            end
            default: st <= S_WAIT;
            endcase
        end
    end
endmodule
