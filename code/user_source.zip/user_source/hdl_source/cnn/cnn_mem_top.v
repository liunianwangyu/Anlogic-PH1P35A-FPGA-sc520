//=============================================================================
// cnn_mem_top.v  --  CNN 子系统的顶层（层序列 + 引擎 + 存储）
//
// 结构（依据 README_cnn.md §7.1 的最终分配）：
//   cnn_top（层序列器/层表） -> cnn_layer_engine（PE 阵列 + 窗口地址 + 重量化）
//   特征图/输入帧：单一 ERAM，整幅分配，基址由层表给出（无条带、无端口 mux）
//   权重：4 个 32 位实例共用地址，一拍读出 4 个 OC x 4 个 IC = 16 字节
//
// 预装端口用于初始化权重与输入帧（测试与实际上电初始化都可复用）。
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"

module cnn_mem_top #(parameter integer DDR_INPUT=0) (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input wire I_first_ready,
    input wire [31:0] I_first_data,
    output wire [14:0] O_first_addr,O_first_base,
    output wire O_first_active,
    input  wire        I_start,
    output wire        O_done,

    // ---- 预装端口 ----
    input  wire        I_ld_en,
    input  wire [2:0]  I_ld_sel,     // 0=特征图, 1..4=权重实例 0..3
    input  wire [14:0] I_ld_addr,
    input  wire [31:0] I_ld_data,

    // ---- 结果读取（head 输出所在区域）----
    input  wire [14:0] I_rd_addr,
    output reg  [31:0] O_rd_data
);
    // Logical ABI stays fixed. With DDR input, A only holds F2/head (1840
    // words), followed by B holding F1/F3 (3600 words).
    localparam integer FMW = DDR_INPUT ? 5440 : `CNN_FM_WORDS;

    reg busy;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)      busy <= 1'b0;
        else if (I_start)  busy <= 1'b1;
        else if (O_done)   busy <= 1'b0;
    end

    // ---------------- 层序列器 ----------------
    wire        eng_start, eng_done;
    wire [3:0]  layer;
    wire [10:0] in_w, in_h, out_w, out_h;
    wire [7:0]  in_ch, out_ch;
    wire [1:0]  ksel, stride;
    wire [15:0] w_base, in_base, out_base, row_step;
    wire [4:0]  q_base;
    wire        relu6;
    wire        border;   // 1 = 3x3（行/列坐标有 -1 边界），0 = 1x1

    cnn_top u_top (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_start(I_start), .O_done(O_done),
        .O_engine_start(eng_start), .I_engine_done(eng_done), .O_layer(layer),
        .O_in_w(in_w), .O_in_h(in_h), .O_in_ch(in_ch),
        .O_out_w(out_w), .O_out_h(out_h), .O_out_ch(out_ch),
        .O_ksel(ksel), .O_stride(stride),
        .O_row_step(row_step), .O_w_base(w_base), .O_in_base(in_base), .O_out_base(out_base),
        .O_q_base(q_base), .O_relu6_en(relu6), .O_border(border)
    );

    // ---------------- 引擎 ----------------
    wire [15:0]     eng_w_addr;
    wire [`CNN_AWB-1:0] eng_in_addr, eng_out_addr;
    wire            eng_out_we;
    wire [31:0]     eng_out_data;
    wire [4*32-1:0] w_data;
    reg  [31:0]     fm_rd;

    wire eng_input_ready;
    wire [14:0] eng_window_base;
    wire eng_window_active;
    assign O_first_addr=eng_in_addr;
    assign O_first_base=eng_window_base;
    assign O_first_active=DDR_INPUT && busy && layer==0 && eng_window_active;
    assign eng_input_ready=!DDR_INPUT || layer!=0 || I_first_ready;
    cnn_layer_engine #(.EXTERNAL_INPUT(DDR_INPUT),.IC(4), .OC(4), .AW(9), .AWB(`CNN_AWB)) u_eng (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_in_w(in_w), .I_in_h(in_h), .I_in_ch(in_ch),
        .I_out_w(out_w), .I_out_h(out_h), .I_out_ch(out_ch),
        .I_ksel(ksel), .I_stride(stride), .I_row_step(row_step),
        .I_w_base(w_base), .I_in_base(in_base), .I_out_base(out_base),
        .I_q_base(q_base), .I_relu6_en(relu6), .I_row_init(border ? -13'sd1 : 13'sd0),
        .I_col_init(border ? -13'sd1 : 13'sd0),
        .I_input_ready(eng_input_ready),.O_window_base(eng_window_base),
        .O_window_active(eng_window_active),
        .I_start(eng_start), .O_done(eng_done),
        .O_w_addr(eng_w_addr), .I_w_data(w_data),
        .O_in_addr(eng_in_addr), .I_in_data((DDR_INPUT && layer==0)?I_first_data:fm_rd),
        .O_out_we(eng_out_we), .O_out_addr(eng_out_addr), .O_out_data(eng_out_data)
    );

    // ---------------- 存储 ----------------
    (* ram_style = "bram" *) reg [31:0] fm [0:FMW-1];

    wire [14:0] logical_read=busy ? eng_in_addr : I_rd_addr;
    wire [12:0] physical_read=(logical_read>=14400) ? logical_read-14400+1840 : logical_read;
    wire [12:0] physical_write=(eng_out_addr>=14400) ? eng_out_addr-14400+1840 : eng_out_addr;
    wire [14:0] read_address=DDR_INPUT ? {2'd0,physical_read} : logical_read;
    wire [14:0] write_address=DDR_INPUT ? {2'd0,physical_write} : eng_out_addr;
    always @(posedge I_clk) begin
        // 特征图：预装优先，否则引擎写
        if (!DDR_INPUT && I_ld_en && (I_ld_sel == 3'd0))
            fm[I_ld_addr] <= I_ld_data;
        else if (busy && eng_out_we)
            fm[write_address] <= eng_out_data;
        // 读端口（1 拍延迟）
        fm_rd <= fm[read_address];
        O_rd_data <= fm[read_address];
    end

    // Four independent native 512x32 PDPW ERAMs. The active model occupies
    // CNN_WEIGHT_LANE_WORDS words/lane, including padding. NOREG gives one clock
    // read latency, exactly as before. The test preload port remains writable.
    genvar lane;
    generate for(lane=0;lane<4;lane=lane+1)begin:g_weight
        cnn_weight_eram #(.INIT_FILE(lane==0?`CNN_WEIGHT_INIT_0:
            lane==1?`CNN_WEIGHT_INIT_1:lane==2?`CNN_WEIGHT_INIT_2:`CNN_WEIGHT_INIT_3)) u_weight (
            .I_clk(I_clk),.I_we(I_ld_en && I_ld_sel==(lane+1)),
            .I_waddr(I_ld_addr[`CNN_WEIGHT_ADDR_BITS-1:0]),.I_wdata(I_ld_data),
            .I_raddr(eng_w_addr[`CNN_WEIGHT_ADDR_BITS-1:0]),.O_data(w_data[lane*32+:32]));
    end endgenerate
endmodule

module cnn_weight_eram #(parameter INIT_FILE="NONE")(
    input wire I_clk,I_we,
    input wire[`CNN_WEIGHT_ADDR_BITS-1:0]I_waddr,I_raddr,
    input wire[31:0]I_wdata,
    output wire[31:0]O_data
);
    PH1P_LOGIC_ERAM #(
        .DATA_WIDTH_A(32),.DATA_WIDTH_B(32),.ADDR_WIDTH_A(9),.ADDR_WIDTH_B(9),
        .DATA_DEPTH_A(512),.DATA_DEPTH_B(512),.MODE("PDPW"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .IMPLEMENT("20K(FAST)"),.ECC_ENCODE("DISABLE"),.ECC_DECODE("DISABLE"),
        .CLKMODE("SYNC"),.SSROVERCE("DISABLE"),
        .OREGSET_A("RESET"),.OREGSET_B("RESET"),
        .RESETMODE_A("ASYNC"),.RESETMODE_B("ASYNC"),
        .ASYNC_RESET_RELEASE_A("ASYNC"),.ASYNC_RESET_RELEASE_B("ASYNC"),
        .INIT_FILE(INIT_FILE),.FILL_ALL("NONE")
    ) u_eram (
        .dia(I_wdata),.dib(32'd0),
        .addra({{(9-`CNN_WEIGHT_ADDR_BITS){1'b0}},I_waddr}),
        .addrb({{(9-`CNN_WEIGHT_ADDR_BITS){1'b0}},I_raddr}),
        .cea(I_we),.ceb(1'b1),.ocea(1'b0),.oceb(1'b0),
        .clka(I_clk),.clkb(I_clk),.wea(I_we),.web(1'b0),
        .bea(1'b0),.beb(1'b0),.rsta(1'b0),.rstb(1'b0),
        .doa(),.dob(O_data),.ecc_sbiterr(),.ecc_dbiterr(),
        .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0));
endmodule
