//=============================================================================
// cnn_window_addr.v  --  3x3 窗口地址生成 + 边界补零判定（纯组合，零乘法零 DSP）
//
// rev3 改动依据：rev2 用固定的 (ir << AW) 计算行地址，AW=9 意味着行跨度固定
//   512 字；但各层实际只需 W*n_g 字/行（128 或 32），512 会浪费 3~4 倍内存
//   （输入帧会从 14,400 字涨到 46,080 字 = 90 块，不可行）。
//   改为由控制器"递增维护"行的字基址 I_roww0，并把每行跨度 I_row_step 作为
//   输入；本模块只做 加/比较/选择，仍然零乘法：
//       addr = I_roww0 + dy*I_row_step + I_colw0 + dx*CSTRIDE + g
//   dy/dx ∈ {0,1,2}，所以 dy*step、dx*cstride 都退化成移位/(0,1,2) 三选一。
//
// 坐标口径：I_row0/I_col0 是 dy=0/dx=0 对应的输入行/列索引（可为 -1），
//          只用于边界判定；地址用 I_roww0（行字基址）。
//=============================================================================
`timescale 1ns / 1ps
module cnn_window_addr #(
    parameter integer AWB = 15
)(
    input  wire signed [12:0] I_row0,
    input  wire signed [12:0] I_col0,
    input  wire [AWB-1:0]     I_roww0,
    input  wire [15:0]        I_row_step,
    input  wire signed [12:0] I_colw0,
    input  wire [3:0]         I_tap,
    input  wire [5:0]         I_g,
    input  wire [5:0]         I_cstride,
    input  wire [11:0]        I_in_w,
    input  wire [11:0]        I_in_h,
    output wire [AWB-1:0]     O_addr,
    output wire               O_valid
);
    reg [1:0] dy, dx;
    always @(*) begin
        case (I_tap)
            4'd0: begin dy = 2'd0; dx = 2'd0; end
            4'd1: begin dy = 2'd0; dx = 2'd1; end
            4'd2: begin dy = 2'd0; dx = 2'd2; end
            4'd3: begin dy = 2'd1; dx = 2'd0; end
            4'd4: begin dy = 2'd1; dx = 2'd1; end
            4'd5: begin dy = 2'd1; dx = 2'd2; end
            4'd6: begin dy = 2'd2; dx = 2'd0; end
            4'd7: begin dy = 2'd2; dx = 2'd1; end
            4'd8: begin dy = 2'd2; dx = 2'd2; end
            default: begin dy = 2'd0; dx = 2'd0; end
        endcase
    end

    // 索引（用于边界判定）：dy/dx 是 0..2 的无符号计数，必须零扩展再 $signed()
    wire signed [13:0] ir = $signed(I_row0) + $signed({12'b0, dy});
    wire signed [13:0] ic = $signed(I_col0) + $signed({12'b0, dx});
    wire r_ok = (ir[13] == 1'b0) && ($unsigned(ir[11:0]) < I_in_h);
    wire c_ok = (ic[13] == 1'b0) && ($unsigned(ic[11:0]) < I_in_w);

    // 行/列偏移：只有三种取值，用移位/选择，不用乘法
    wire [16:0] dyw = (dy == 2'd0) ? 17'd0 :
                      ((dy == 2'd1) ? {1'b0, I_row_step} : ({1'b0, I_row_step} << 1));
    wire [6:0]  dxw = (dx == 2'd0) ? 7'd0 :
                      ((dx == 2'd1) ? {1'b0, I_cstride} : ({1'b0, I_cstride} << 1));

    assign O_valid = r_ok & c_ok;
    // 地址显式用有符号求和：colw0 在 col0=-1 时是 -1，若混入无符号会把整个表达式变无符号
    // (实测表现：ox=0 整列输出全 0，因为地址算到别处去了)
    // 注意：不要用 $signed({...}) 去"拼接再加符号"——拼接是零扩展的，
    // 会把 colw0=-1 变成 +8191（实测地址整体偏大约 8192）。
    wire signed [19:0] saddr = $signed(I_roww0) + $signed({3'b0, dyw})
                             + $signed(I_colw0) + $signed({11'b0, dxw})
                             + $signed({12'b0, I_g});
    assign O_addr  = O_valid ? saddr[AWB-1:0] : {AWB{1'b0}};
endmodule
