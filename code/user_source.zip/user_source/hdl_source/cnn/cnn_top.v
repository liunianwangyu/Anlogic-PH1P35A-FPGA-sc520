//=============================================================================
// cnn_top.v  --  CNN 顶层控制器：逐层走层表，与引擎握手，锁存该层参数
//
// 职责边界（有意收窄）：
//   本模块只做"层序列"与"参数分发"，不实例化引擎、不接任何特征图存储。
//   引擎(cnn_layer_engine)与各项存储由 design_top 与本模块并列实例化，
//   这样本模块可独立验证，且不被"特征图缓冲如何组织"这一未定问题阻塞。
//
// 序列：S_IDLE -(I_start)-> 逐层 { 脉冲 I_load 让 cnn_layer_rom 锁存参数 ->
//       拉高 O_engine_start -> 等 I_engine_done -> 撤 start -> 下一层 }
//       最后一层完成后 O_done 拉高。
//
// 依据：层参数来自 cnn_layer_rom（5 层，见 README_cnn.md §3）；层数为
//       `CNN_NUM_LAYERS`；引擎的 start/done 语义见 cnn_layer_engine.v
//       (S_IDLE 等 I_start，S_DONE 等 I_start 撤低)。
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"

module cnn_top (
    input  wire         I_clk,
    input  wire         I_rst_n,
    input  wire         I_start,
    output reg          O_done,

    // 与引擎的握手
    output reg          O_engine_start,
    input  wire         I_engine_done,

    // 锁存后的该层参数（送引擎）
    output reg  [3:0]   O_layer,
    output wire [10:0]  O_in_w,
    output wire [10:0]  O_in_h,
    output wire [7:0]   O_in_ch,
    output wire [10:0]  O_out_w,
    output wire [10:0]  O_out_h,
    output wire [7:0]   O_out_ch,
    output wire [1:0]   O_ksel,
    output wire [1:0]   O_stride,
    output wire [15:0]  O_w_base,
    output wire [15:0]  O_row_step,
    output wire [15:0]  O_in_base,
    output wire [15:0]  O_out_base,
    output wire [4:0]   O_q_base,
    output wire         O_relu6_en,
output wire         O_border
);
    localparam [3:0] S_IDLE = 4'd0, S_LOAD = 4'd1, S_LOAD2 = 4'd2,
                     S_RUN  = 4'd3, S_NEXT = 4'd4, S_DONE  = 4'd5;
    reg [3:0] st;
    reg       load_pulse;

    // ---- 层参数表（寄存器输出，load 时锁存该层）----
    cnn_layer_rom u_rom (
        .I_layer(O_layer), .I_clk(I_clk), .I_rst_n(I_rst_n), .I_load(load_pulse),
        .O_row_step(O_row_step), .O_w_base(O_w_base), .O_out_base(O_out_base), .O_in_base(O_in_base),
        .O_out_ch(O_out_ch), .O_in_ch(O_in_ch),
        .O_out_w(O_out_w), .O_out_h(O_out_h), .O_in_w(O_in_w), .O_in_h(O_in_h),
        .O_stride(O_stride), .O_ksel(O_ksel),
        .O_q_base(O_q_base), .O_relu6_en(O_relu6_en), .O_border(O_border),
        .O_valid()
    );

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            st <= S_IDLE; O_done <= 1'b0; O_engine_start <= 1'b0;
            O_layer <= 4'd0; load_pulse <= 1'b0;
        end else begin
            load_pulse <= 1'b0;
            case (st)
            S_IDLE: begin
                O_done <= 1'b0;
                if (I_start) begin
                    O_layer <= 4'd0;
                    st      <= S_LOAD;
                end
            end
            S_LOAD: begin
                load_pulse <= 1'b1;         // 锁存该层参数
                st <= S_LOAD2;
            end
            S_LOAD2: begin
                st <= S_RUN;                // 参数已有效
            end
            S_RUN: begin
                O_engine_start <= 1'b1;
                if (I_engine_done) begin
                    O_engine_start <= 1'b0; // 让引擎回到 S_IDLE
                    st <= S_NEXT;
                end
            end
            S_NEXT: begin
                if (O_layer + 4'd1 < `CNN_NUM_LAYERS) begin
                    O_layer <= O_layer + 4'd1;
                    st      <= S_LOAD;
                end else begin
                    O_done <= 1'b1;
                    st     <= S_DONE;
                end
            end
            S_DONE: begin
                if (!I_start) begin
                    O_done <= 1'b0;
                    st     <= S_IDLE;
                end
            end
            default: st <= S_IDLE;
            endcase
        end
    end
endmodule
