//=============================================================================
// cnn_layer_engine.v  --  单层卷积执行引擎（FSM + PE阵列 + 窗口地址 + 重量化）
//
// 循环顺序：位置(y,x) -> OC组 -> (tap t, IC组 g)
//    PE 在 (t,g) 内对同一 OC 组累加，per-OC组 结算后重量化并写出。
//
// 存储接口：
//    权重：4 个 32 位实例共用一个地址，一拍读出 4 个 OC x 4 个 IC 共 16 字节
//    输入/输出：32 位字 = IC 个通道；输出布局"位置优先"：
//              地址 = out_base + (cy*out_w + cx)*n_ocg + cog
//
// 【零乘法，零额外 DSP】所有地址用增量累加维护，避免乘法被综合成 DSP：
//    row0/col0/colw0  行/列/列字基址，按 stride 递增
//    w_ctr            (ct*n_g + cg)，每步 +1，每个 OC 组复位
//    w_cog_base       cog*taps*n_g，每个 OC 组 += w_step_n
//    w_step_n         taps*n_g，每层算一次（n_g*9 用移位相加）
//    out_col_base     cx*n_ocg，每列 += n_ocg
//    out_row_base     cy*out_w*n_ocg，每行 += out_col_base + n_ocg
//    v1 直接用乘法时引擎额外占 5 个 DSP（16 是 PE 阵列，合计 21 > 可用 20）；本版为 16。
//
// 周期：每 (t,g) 2 拍；全 5 层约 2.6M 拍 @100MHz = 26ms -> 约 38 fps。
// 延迟：PE 输入 -> 累加器更新 = 2 拍，故每个 OC 组结束要排空 3 拍。
//
// 踩过的坑（均由逐拍/逐字节对拍定位）：
//    1) 输出地址漏行号 cy -> 所有行写同一批地址
//    2) 排空少 1 拍 -> 丢掉最后一个 tap 的贡献
//    3) colw0 初值写成 -swn（应为 -n_g）-> stride=2 时 swn=2*n_g 暴露
//    4) 换行未复位 col0/colw0，且 out_row_base 少加最后一列 -> 行间串位
//=============================================================================
`timescale 1ns / 1ps
module cnn_layer_engine #(
    parameter integer EXTERNAL_INPUT = 0,
    parameter integer IC   = 4,
    parameter integer OC   = 4,
    parameter integer AW   = 9,
    parameter integer AWB  = 12
)(
    input  wire             I_clk,
    input  wire             I_rst_n,
    input  wire [10:0]      I_in_w,
    input  wire [10:0]      I_in_h,
    input  wire [7:0]       I_in_ch,
    input  wire [10:0]      I_out_w,
    input  wire [10:0]      I_out_h,
    input  wire [7:0]       I_out_ch,
    input  wire [1:0]       I_ksel,
    input  wire [1:0]       I_stride,
    input  wire [15:0]      I_row_step,   // 本层每行的字跨度（由层表提供，避免固定 512 造成内存浪费）
    input  wire [15:0]      I_w_base,
    input  wire [15:0]      I_in_base,
    input  wire [15:0]      I_out_base,
    input  wire [4:0]       I_q_base,        // 本层在 qparam ROM 的基址（层表 [15:11]）
    input  wire             I_relu6_en,
    input  wire signed [12:0] I_row_init,   // 起始行坐标：3x3 用 -1（边界补零），1x1 用 0
    input  wire signed [12:0] I_col_init,   // 起始列坐标：同上（由层表的 border 位决定）
    input wire I_input_ready,
    output wire [AWB-1:0] O_window_base,
    output wire O_window_active,
    input  wire             I_start,
    output reg              O_done,
    output reg  [15:0]      O_w_addr,
    input  wire [4*32-1:0]  I_w_data,
    output wire [AWB-1:0]   O_in_addr,
    input  wire [IC*8-1:0]  I_in_data,
    output reg              O_out_we,
    output reg  [AWB-1:0]   O_out_addr,
    output reg  [IC*8-1:0]  O_out_data
);
    reg [10:0] cy, cx;
    reg [7:0]  cog;
    reg [4:0]  ct, cg;
    reg [4:0]  n_g, n_ocg, taps;
    reg [1:0]  drn;

    reg signed [12:0] row0, col0, colw0;
    reg [15:0] w_cog_base, w_ctr, w_step_n;
    reg [15:0] w_ba;          // = I_w_base + w_cog_base（预算，少一层加法）
    reg [15:0] out_row_base, out_col_base;
    reg [AWB-1:0] roww0;      // row0 对应的行字基址（按 row_delta 递增维护）
    reg [16:0]    row_delta;  // = row_step * stride

    // stride*n_g：只可能是 n_g 或 2*n_g
    wire [5:0] swn = (I_stride == 2'd2) ? {n_g, 1'b0} : {1'b0, n_g};

    localparam [3:0] S_IDLE=4'd0, S_INIT=4'd1, S_CLEAR=4'd2, S_ADDR=4'd3,
                     S_MAC=4'd4, S_DRAIN=4'd5, S_NEXT=4'd6, S_NEXTP=4'd7,
                     S_DONE=4'd8;
    reg [3:0] st;

    wire [AWB-1:0] wa_addr;
    wire           wa_valid;
    cnn_window_addr #(.AWB(AWB)) u_wa (
        .I_row0(row0), .I_col0(col0), .I_colw0(colw0),
        .I_roww0(roww0), .I_row_step(I_row_step),
        .I_tap(ct[3:0]),
        .I_g({1'b0, cg}),
        .I_cstride({1'b0, n_g}),
        .I_in_w({1'b0, I_in_w}), .I_in_h({1'b0, I_in_h}),
        .O_addr(wa_addr), .O_valid(wa_valid)
    );
    wire [IC*8-1:0] x_word = wa_valid ? I_in_data : {(IC*8){1'b0}};

    reg              pe_valid, pe_clear;
    reg [IC*8-1:0]   pe_x;
    // Current contract: at most 72 signed INT8 products plus INT16 bias.
    // |acc| <= 72*128*128+32768 = 1212416; signed 24 bits is conservative.
    localparam integer ACC_W = 24;
    wire [OC*ACC_W-1:0] pe_acc;
    // ---- P1：逐输出通道量化参数（每 OC: shift[4:0] + bias[15:0]）----
    wire [4:0]         qsh0, qsh1, qsh2, qsh3;
    wire signed [15:0] qb0,  qb1,  qb2,  qb3;
    cnn_qparam_rom u_qrom (
        .I_idx(I_q_base + {cog[3:0], 2'b0}),   // q_base + cog*4
        .O_sh0(qsh0), .O_sh1(qsh1), .O_sh2(qsh2), .O_sh3(qsh3),
        .O_bi0(qb0),  .O_bi1(qb1),  .O_bi2(qb2),  .O_bi3(qb3)
    );
    // OC 车道 i 对应 PE 实例 i：{lane3, lane2, lane1, lane0}，16 位有符号扩展
    wire signed [OC*ACC_W-1:0] qbias = { {{8{qb3[15]}}, qb3}, {{8{qb2[15]}}, qb2},
                                       {{8{qb1[15]}}, qb1}, {{8{qb0[15]}}, qb0} };

    cnn_pe #(.OC(OC), .IC(IC), .ACC_W(ACC_W)) u_pe (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_w(I_w_data), .I_x(pe_x), .I_bias(qbias),
        .I_valid(pe_valid), .I_clear(pe_clear),
        .O_acc(pe_acc)
    );

    function signed [ACC_W-1:0] sh;
        input signed [ACC_W-1:0] v;
        input [4:0]         s;
        begin sh = v >>> s; end
    endfunction

    function [7:0] sat8;
        input signed [ACC_W-1:0] v;
        input               r6;
        begin
            if (r6) sat8 = (v < 0) ? 8'd0 : ((v > 127) ? 8'd127 : v[7:0]);   // P2：中间层激活钳到 [0,127]（对称 int8 的 ReLU），保证下一层按有符号读时语义一致
            else    sat8 = (v > 127) ? 8'h7F : ((v < -128) ? 8'h80 : v[7:0]);
        end
    endfunction

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            st <= S_IDLE; O_done <= 1'b0;
            cy <= 0; cx <= 0; cog <= 0; ct <= 0; cg <= 0;
            n_g <= 0; n_ocg <= 0; taps <= 0; drn <= 0;
            row0 <= 0; col0 <= 0; colw0 <= 0; roww0 <= 0; row_delta <= 0;
            w_cog_base <= 0; w_ctr <= 0; w_step_n <= 0;
            out_row_base <= 0; out_col_base <= 0;
            pe_valid <= 0; pe_clear <= 0; pe_x <= 0;
            O_w_addr <= 0; O_out_we <= 0; O_out_addr <= 0; O_out_data <= 0;
        end else begin
            pe_valid <= 1'b0;
            pe_clear <= 1'b0;
            O_out_we <= 1'b0;

            case (st)
            S_IDLE: begin
                O_done <= 1'b0;
                if (I_start) begin
                    n_g   <= I_in_ch[7:2];
                    n_ocg <= I_out_ch[7:2];
                    taps  <= (I_ksel == 2'd0) ? 5'd1 : 5'd9;
                    cy <= 11'd0; cx <= 11'd0; cog <= 8'd0;
                    row0 <= I_row_init;
                    // roww0 必须 = row0*row_step：整层模式 row0=-1 -> 0-row_step（模 2^AWB 回绕）
                    roww0 <= (I_row_init < 13'sd0) ? ({AWB{1'b0}} - I_row_step[AWB-1:0])
                                                        : {AWB{1'b0}};
                    col0 <= I_col_init;
                    w_cog_base <= 16'd0;
                w_ba <= I_w_base;      // 切回第 0 个 OC 组
                    out_row_base <= 16'd0; out_col_base <= 16'd0;
                    st <= S_INIT;
                end
            end

            S_INIT: begin
                colw0 <= (I_col_init < 13'sd0) ? -$signed({11'b0, n_g}) : 13'sd0;  // col_init*n_g（3x3 -> -n_g，1x1 -> 0）
                row_delta <= (I_stride == 2'd2) ? ({1'b0, I_row_step} << 1) : {1'b0, I_row_step};
                w_step_n <= (taps == 5'd9) ? (({3'b0, n_g} << 3) + {3'b0, n_g})
                                           : {3'b0, n_g};
                st <= S_CLEAR;
            end

            S_CLEAR: if (!EXTERNAL_INPUT || I_input_ready) begin
                pe_clear <= 1'b1;
                ct <= 5'd0; cg <= 5'd0; w_ctr <= 16'd0;
                st <= S_ADDR;
            end

            S_ADDR: begin
                O_w_addr <= w_ba + w_ctr;
                st <= S_MAC;
            end

            S_MAC: begin
                pe_valid <= 1'b1;
                pe_x     <= x_word;
                w_ctr    <= w_ctr + 16'd1;
                if (cg + 5'd1 < n_g) begin
                    cg <= cg + 5'd1;
                    st <= S_ADDR;
                end else if (ct + 5'd1 < taps) begin
                    ct <= ct + 5'd1;
                    cg <= 5'd0;
                    st <= S_ADDR;
                end else begin
                    drn <= 2'd0;
                    st  <= S_DRAIN;
                end
            end

            S_DRAIN: begin
                drn <= drn + 2'd1;
                if (drn == 2'd2) begin
                    O_out_we   <= 1'b1;
                    O_out_addr <= I_out_base[AWB-1:0] + out_row_base + out_col_base
                                  + {{4{1'b0}}, cog};
                    O_out_data <= { sat8(sh($signed(pe_acc[3*ACC_W +: ACC_W]), qsh3), I_relu6_en),
                                    sat8(sh($signed(pe_acc[2*ACC_W +: ACC_W]), qsh2), I_relu6_en),
                                    sat8(sh($signed(pe_acc[1*ACC_W +: ACC_W]), qsh1), I_relu6_en),
                                    sat8(sh($signed(pe_acc[0*ACC_W +: ACC_W]), qsh0), I_relu6_en) };
                    st <= S_NEXT;
                end
            end

            S_NEXT: begin
                if (cog + 8'd1 < n_ocg) begin
                    cog        <= cog + 8'd1;
                    w_cog_base <= w_cog_base + w_step_n;
                    w_ba       <= w_ba + w_step_n;
                    st         <= S_CLEAR;
                end else begin
                    st <= S_NEXTP;
                end
            end

            S_NEXTP: begin
                cog <= 8'd0;
                w_cog_base <= 16'd0;
                w_ba <= I_w_base;      // 切回第 0 个 OC 组
                if (cx + 11'd1 < I_out_w) begin
                    cx           <= cx + 11'd1;
                    col0         <= col0 + $signed({11'b0, I_stride});
                    colw0        <= colw0 + $signed({11'b0, swn});
                    out_col_base <= out_col_base + {10'b0, n_ocg};
                    st           <= S_CLEAR;
                end else if (cy + 11'd1 < I_out_h) begin
                    cx    <= 11'd0;
                    cy    <= cy + 11'd1;
                    col0  <= I_col_init;                     // 换行必须复位列基址
                    colw0 <= (I_col_init < 13'sd0) ? -$signed({11'b0, n_g}) : 13'sd0;  // 同上
                row_delta <= (I_stride == 2'd2) ? ({1'b0, I_row_step} << 1) : {1'b0, I_row_step};
                    row0  <= row0 + $signed({11'b0, I_stride});
                    roww0 <= roww0 + row_delta[AWB-1:0];
                    out_row_base <= out_row_base + out_col_base + {10'b0, n_ocg};
                    out_col_base <= 16'd0;
                    st <= S_INIT;
                end else begin
                    O_done <= 1'b1;
                    st     <= S_DONE;
                end
            end

            S_DONE: begin
                if (!I_start) begin
                    O_done <= 1'b0;
                    st     <= S_IDLE;
                end
            end

            default: st <= S_IDLE;
            endcase
        end
    end

    assign O_window_base = roww0;
    assign O_window_active = st != S_IDLE && st != S_DONE;
    assign O_in_addr = I_in_base[AWB-1:0] + wa_addr;
endmodule
