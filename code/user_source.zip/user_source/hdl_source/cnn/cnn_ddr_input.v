`timescale 1ns/1ps
// Private DDR address units are 16-bit words; each accepted beat advances 8.
// [5999680,6028800) is disjoint from PCM [1600000,5794304) and video
// slots 0/7000000/14000000/21000000. The first 160 words are guard data:
// the convolution masks this top padding, so its contents are never consumed.
// Reuses the existing vendor asynchronous FIFO. Video is never backpressured.
module cnn_ddr_input #(parameter integer STALL_LIMIT_CYCLES=16777216) (
 input I_clk,I_rst_n,I_capture_start,I_capture_we,
 input [31:0] I_capture_data,
 input I_ddr_clk,I_calibrated,
 output O_available,O_stored,O_fault,
 input I_window_active,input [14:0] I_window_base,I_read_addr,
 output O_window_ready,output [31:0] O_read_data,
 output O_req,O_write,output [24:0] O_addr,output [127:0] O_wdata,
 input I_accept,I_valid,input [127:0] I_rdata
);
 localparam [24:0] DDR_BASE=25'd6000000;
 wire full,empty,fifo_valid;wire [31:0] fifo_data;
 reg pop_pending;reg [2:0] pack_count;reg [127:0] pack_data;
 reg [11:0] write_index;reg stored_toggle;
 reg capture_fault;
 wire fifo_pop=!empty&&!pop_pending&&pack_count<4;
 soft_fifo_al_4057d6b76aa6 #(.DATA_WIDTH_W(32),.DATA_WIDTH_R(32),
  .ADDR_WIDTH_W(9),.ADDR_WIDTH_R(9),.AL_FULL_NUM(480),.AL_EMPTY_NUM(2),
  .SHOW_AHEAD_EN(0),.OUTREG_EN("NOREG")) u_capture_fifo (
  .rst(!I_rst_n),.clkw(I_clk),.clkr(I_ddr_clk),
  .we(I_capture_we),.di(I_capture_data),.re(fifo_pop),.dout(fifo_data),
  .valid(fifo_valid),.full_flag(full),.empty_flag(empty),
  .afull(),.aempty(),.wrusedw(),.rdusedw());
 always @(posedge I_clk or negedge I_rst_n)
  if(!I_rst_n)capture_fault<=0;
  else if(I_capture_we&&full)capture_fault<=1;

 // The request bundle is immutable from request toggle to acknowledged fill.
 reg request_toggle;reg [14:0] request_base;
 reg window_pending,request_bank;
 reg [1:0] cache_valid;reg [14:0] cache_tag0,cache_tag1;
 wire hit0=cache_valid[0]&&cache_tag0==I_window_base;
 wire hit1=cache_valid[1]&&cache_tag1==I_window_base;
 wire cache_bank=hit1;
 wire [14:0] next_base=I_window_base+15'd320;
 wire next_hit=(cache_valid[0]&&cache_tag0==next_base)||(cache_valid[1]&&cache_tag1==next_base);
 reg ack_toggle;
 (* async_reg="true" *) reg req_meta,req_sync,ack_meta,ack_sync;
 (* async_reg="true" *) reg stored_meta,stored_sync,cal_meta,cal_sync;
 (* async_reg="true" *) reg fault_meta,fault_sync;
 reg stored_seen;
 reg [$clog2(STALL_LIMIT_CYCLES)-1:0] watchdog;reg transfer_fault;
 assign O_available=cal_sync&&!O_fault;
 assign O_stored=stored_sync!=stored_seen;
 assign O_fault=capture_fault|fault_sync;
 assign O_window_ready=(hit0||hit1)&&!O_fault;
 always @(posedge I_clk or negedge I_rst_n)begin
  if(!I_rst_n)begin
   ack_meta<=0;ack_sync<=0;stored_meta<=0;stored_sync<=0;
   cal_meta<=0;cal_sync<=0;fault_meta<=0;fault_sync<=0;
   request_toggle<=0;request_base<=0;window_pending<=0;
   cache_valid<=0;cache_tag0<=0;cache_tag1<=0;request_bank<=0;stored_seen<=0;
  end else begin
   ack_meta<=ack_toggle;ack_sync<=ack_meta;
   stored_meta<=stored_toggle;stored_sync<=stored_meta;
   cal_meta<=I_calibrated;cal_sync<=cal_meta;
   fault_meta<=transfer_fault;fault_sync<=fault_meta;
   if(I_capture_start)begin stored_seen<=stored_sync;cache_valid<=0;end
   if(I_window_active&&!O_fault&&!window_pending)begin
    if(!hit0&&!hit1)begin
     request_base<=I_window_base;request_bank<=0;
     request_toggle<=!request_toggle;window_pending<=1;cache_valid[0]<=0;
    end else if(I_window_base!=15'd13920&&!next_hit)begin
     // Reuse the unused depth of the same four native ERAMs. Prefetch into
     // the other bank while the current row computes, without a new pipeline.
     request_base<=next_base;request_bank<=!cache_bank;
     request_toggle<=!request_toggle;window_pending<=1;cache_valid[!cache_bank]<=0;
    end
   end
   if(window_pending&&ack_sync==request_toggle)begin
    cache_valid[request_bank]<=1;
    if(request_bank)cache_tag1<=request_base;else cache_tag0<=request_base;
    window_pending<=0;
   end
  end
 end

 // Three 160-word rows, returned as 120 128-bit beats. One synchronous CSI
 // read preserves the engine's original one-cycle RAM latency.
 (* ram_style="block" *) reg [127:0] cache[0:255];
 reg [127:0] cache_q;reg [1:0] cache_lane;
 wire [14:0] relative_addr=I_read_addr-I_window_base;
 always @(posedge I_clk)begin
  cache_q<=cache[{cache_bank,relative_addr[8:2]}];cache_lane<=relative_addr[1:0];
 end
 assign O_read_data=cache_q[cache_lane*32+:32];
 reg reading,ddr_bank;reg [6:0] sent,received;reg [14:0] ddr_base;
 wire signed [24:0] signed_offset={{9{ddr_base[14]}},ddr_base,1'b0};
 assign O_req=!transfer_fault&&((pack_count==4)||(reading&&sent<120));
 assign O_write=pack_count==4;
 assign O_addr=O_write ? DDR_BASE+{10'd0,write_index,3'b000} :
                       DDR_BASE+signed_offset+{15'd0,sent,3'b000};
 assign O_wdata=pack_data;
 always @(posedge I_ddr_clk or negedge I_rst_n)begin
  if(!I_rst_n)begin
   pop_pending<=0;pack_count<=0;pack_data<=0;write_index<=0;stored_toggle<=0;
   req_meta<=0;req_sync<=0;ack_toggle<=0;reading<=0;ddr_bank<=0;sent<=0;received<=0;ddr_base<=0;
   watchdog<=0;transfer_fault<=0;
  end else begin
   req_meta<=request_toggle;req_sync<=req_meta;
   if(fifo_pop)pop_pending<=1;
   if(fifo_valid)begin
    pack_data[pack_count[1:0]*32+:32]<=fifo_data;
    pack_count<=pack_count+1'b1;pop_pending<=0;
   end
   if(O_req&&I_accept)begin
    if(O_write)begin
     pack_count<=0;
     if(write_index==3599)begin write_index<=0;stored_toggle<=!stored_toggle;end
     else write_index<=write_index+1'b1;
    end else sent<=sent+1'b1;
   end
   if(!reading&&req_sync!=ack_toggle)begin
    reading<=1;ddr_base<=request_base;ddr_bank<=request_bank;sent<=0;received<=0;
   end
   if(reading&&I_valid)begin
    cache[{ddr_bank,received}]<=I_rdata;received<=received+1'b1;
    if(received==119)begin reading<=0;ack_toggle<=req_sync;end
   end
   // Fail closed on a stopped/blocked DDR channel; never stall video or audio.
   if(O_req||reading)begin
    if(I_accept||I_valid)watchdog<=0;
    else if(watchdog==STALL_LIMIT_CYCLES-1)transfer_fault<=1;
    else watchdog<=watchdog+1'b1;
   end else watchdog<=0;
  end
 end
endmodule
