//=============================================================================
// cnn_post.v -- v1.7 检测后处理：阈值 + top-K(8) + 类内 NMS(IoU>0.5) + 坐标映射
//
// 依据（README_cnn.md 5.13）：
//   * head 是层表第 4 条：out 20x12x8、out_base 由 CNN_FH_BASE_W 给出、
//     row_step=40、relu6_en=0（输出是**有符号 int8**）。
//   * 引擎输出布局"位置优先"（cnn_layer_engine.v L9-10）：
//        addr = head_base + (cy*20 + cx)*n_ocg + cog，n_ocg = out_ch>>2 = 2
//     => 一个格子占 2 个字：字 g=0 装 ch0..3，字 g=1 装 ch4..7。
//   * 通道约定（与训练/量化侧对齐，必须一致）：
//        字 g=0: byte0=obj, byte1=dx, byte2=dy, byte3=w
//        字 g=1: byte0=h,   byte1=cls0, byte2=cls1, byte3=cls2
//        obj/cls 是**有符号 int8**，最终分数 = int8 + 128（零点 128，与采集侧一致）；
//        dx/dy 是有符号 int8 偏移；w/h 是无符号 8 位，**单位 8 个原图像素**。
//   * 坐标映射（全程无乘法）：
//        格宽 x: 1280/20 = 64 px -> cell_x = gx << 6
//        格高 y:  720/12 = 60 px -> cell_y = (gy<<6) - (gy<<2)
//        中心   = cell + {32, 30} + (d >>> 1)    // 有符号算术右移
//        半宽/半高 = w*4 (= (w<<3)/2)
//        四边饱和到 0..1279 / 0..719
//
// 算法：扫描 240 格 -> 合格候选按分数降序插入 8 条有序表 -> 类内两两 IoU 抑制 ->
//       输出保留的框（分数降序）。NMS 判据 2*inter > union 等价 IoU > 0.5，
//       正好对应 CNN_IOU_THRESH = 128（免除法）。
//
// 存储时序（关键）：cnn_mem_top 的读端口是"地址在拍 N 呈现、数据在拍 N+1 可用"。
//       所以每个字都要"呈现一拍 -> 下一拍用"，一个字 2 拍、一个格子 2 个字 = 3 拍
//       （两个字之间有 1 拍不可避免的空档）。240 格 x 3 拍 = 720 拍。
//       该读端口只在 busy=0 时有效（cnn_mem_top.v L105），必须在 CNN 跑完后启动。
//
// 资源：1 个 12x12 乘数（area/inter），其余全是移位/比较/加减。
// 时序：720(扫描) + 8(面积) + 2x28(NMS) + 8(输出) = 约 800 拍 @100 MHz = 8 us。
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"

module cnn_post (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_start,        // 1 拍脉冲：开始一次后处理
    output reg         O_done,         // 完成后拉高，直到 I_start 撤除
    // 存储读端口（接 cnn_mem_top 的 I_rd_addr / O_rd_data）
    output reg  [14:0] O_mem_addr,
    input  wire [31:0] I_mem_data,
    // 结果读端口
    input  wire [2:0]  I_rd_idx,
    output wire [63:0] O_rd_data,
    output reg  [3:0]  O_nbox,
    // 跨域搬运用的紧凑结果包：8 框 x 48 位（见下方 5b）
    output wire [383:0] O_box_all
);
    localparam [14:0] HEAD_BASE = `CNN_FH_BASE_W;   // A region, consumed before next capture
    localparam [14:0] HEAD_RS   = 15'd40;
    localparam [4:0]  GW        = 5'd20;
    localparam [3:0]  GH        = 4'd12;
    localparam [7:0]  OBJ_TH    = `CNN_OBJ_THRESH;  // 128

    localparam [3:0] S_IDLE=4'd0, S_S0=4'd1, S_S1=4'd2, S_S2=4'd3, S_S3=4'd4,
                     S_INS=4'd10, S_AREAW=4'd11, S_PAIR3=4'd12,
                     S_AREA=4'd5, S_PAIR=4'd6, S_PAIR2=4'd7, S_OUT=4'd8, S_DONE=4'd9;
    reg [3:0] st;

    //-------------------------------------------------------------------------
    // 1. 扫描指针（增量维护，无乘法）
    //-------------------------------------------------------------------------
    reg [4:0]  gx;
    reg [3:0]  gy;
    reg [14:0] row_base;    // HEAD_BASE + gy*40
    reg [14:0] col_off;     // gx*2

    reg [31:0] w0;                                  // 本格字 g=0
    wire [31:0] w1c = I_mem_data;                   // 本格字 g=1（只在 S_S2 有效）

    //-------------------------------------------------------------------------
    // 2. 候选解码（组合）
    //-------------------------------------------------------------------------
    wire [7:0] obj_b = w0[7:0];
    wire [7:0] dx_b  = w0[15:8];
    wire [7:0] dy_b  = w0[23:16];
    wire [7:0] w_u   = w0[31:24];
    wire [7:0] h_u   = w1c[7:0];
    wire [7:0] c0b   = w1c[15:8];
    wire [7:0] c1b   = w1c[23:16];
    wire [7:0] c2b   = w1c[31:24];

    wire signed [7:0] c0s = c0b, c1s = c1b, c2s = c2b;

    wire [7:0] obj_u8  = obj_b + 8'h80;
    wire       obj_ok  = (obj_u8 >= OBJ_TH);
    wire       size_ok = (w_u != 8'd0) && !w_u[7] && (h_u != 8'd0) && !h_u[7];

    // Match MCU: two active classes, class-0 wins ties; channel 7 reserved.
    wire [1:0] cls = (c0s >= c1s) ? 2'd0 : 2'd1;
    wire [7:0] cand_score = obj_u8;
    wire       cand_ok    = obj_ok && size_ok;

    wire signed [12:0] dxe = {{5{dx_b[7]}}, dx_b};
    wire signed [12:0] dye = {{5{dy_b[7]}}, dy_b};

    wire [11:0] gx64 = {1'b0, gx, 6'b0};            // gx*64
    wire [11:0] gy64 = {2'b0, gy, 6'b0};            // gy*64
    wire [11:0] gy4  = {4'b0, gy, 2'b0};            // gy*4
    wire [11:0] gy60 = gy64 - gy4;                  // gy*60

    wire signed [13:0] cx_s = $signed({2'b0, gx64}) + 14'sd32 + (dxe >>> 1);
    wire signed [13:0] cy_s = $signed({2'b0, gy60}) + 14'sd30 + (dye >>> 1);

    wire [10:0] hwx = {1'b0, w_u, 2'b0};            // 半宽 = w*4
    wire [10:0] hwy = {1'b0, h_u, 2'b0};

    wire signed [13:0] x1s = cx_s - $signed({3'b0, hwx});
    wire signed [13:0] x2s = cx_s + $signed({3'b0, hwx});
    wire signed [13:0] y1s = cy_s - $signed({3'b0, hwy});
    wire signed [13:0] y2s = cy_s + $signed({3'b0, hwy});

    function [10:0] satx; input signed [13:0] v;
        begin satx = v[13] ? 11'd0 : ((v > 14'sd1279) ? 11'd1279 : v[10:0]); end
    endfunction
    function [10:0] saty; input signed [13:0] v;
        begin saty = v[13] ? 11'd0 : ((v > 14'sd719) ? 11'd719 : v[10:0]); end
    endfunction

    wire [10:0] cx1 = satx(x1s), cx2 = satx(x2s);
    wire [10:0] cy1 = saty(y1s), cy2 = saty(y2s);

    //-------------------------------------------------------------------------
    // 3. top-8 有序表
    //-------------------------------------------------------------------------
    // 候选先寄存一拍：打断 I_mem_data -> 插入优先级链 的长组合路
    reg        c_ok;
    reg [7:0]  c_score;
    reg [1:0]  c_cls;
    reg [10:0] c_x1, c_y1, c_x2, c_y2;
    reg        ins_last;
    reg  [7:0]  ev;
    reg  [63:0] esc;
    reg  [15:0] ecl;
    reg  [87:0] ex1, ey1, ex2, ey2;

    wire [8:0] knew = {1'b1, c_score};
    wire [8:0] k0 = {ev[0], esc[ 0 +: 8]};
    wire [8:0] k1 = {ev[1], esc[ 8 +: 8]};
    wire [8:0] k2 = {ev[2], esc[16 +: 8]};
    wire [8:0] k3 = {ev[3], esc[24 +: 8]};
    wire [8:0] k4 = {ev[4], esc[32 +: 8]};
    wire [8:0] k5 = {ev[5], esc[40 +: 8]};
    wire [8:0] k6 = {ev[6], esc[48 +: 8]};
    wire [8:0] k7 = {ev[7], esc[56 +: 8]};

    wire gt0 = (knew > k0), gt1 = (knew > k1), gt2 = (knew > k2), gt3 = (knew > k3);
    wire gt4 = (knew > k4), gt5 = (knew > k5), gt6 = (knew > k6), gt7 = (knew > k7);

    wire [3:0] ins_pos = gt0 ? 4'd0 : gt1 ? 4'd1 : gt2 ? 4'd2 : gt3 ? 4'd3 :
                         gt4 ? 4'd4 : gt5 ? 4'd5 : gt6 ? 4'd6 : gt7 ? 4'd7 : 4'd8;
    wire ins_any = gt0|gt1|gt2|gt3|gt4|gt5|gt6|gt7;
    wire do_ins  = (st == S_INS) && c_ok && ins_any;

    //-------------------------------------------------------------------------
    // 4. NMS
    //-------------------------------------------------------------------------
    reg [175:0] area;        // 8 x 22
    reg [3:0]   aidx;
    wire [11:0] aw = ({1'b0, ex2[aidx*11 +: 11]} - {1'b0, ex1[aidx*11 +: 11]} + 12'd1);
    wire [11:0] ah = ({1'b0, ey2[aidx*11 +: 11]} - {1'b0, ey1[aidx*11 +: 11]} + 12'd1);


    reg [2:0]  pi, pj, qi, qj;
    reg [21:0] inter_q;
    reg        pair_ok;
    reg [7:0]  sup;

    wire [10:0] xi1 = ex1[pi*11 +: 11], xi2 = ex2[pi*11 +: 11];
    wire [10:0] yi1 = ey1[pi*11 +: 11], yi2 = ey2[pi*11 +: 11];
    wire [10:0] xj1 = ex1[pj*11 +: 11], xj2 = ex2[pj*11 +: 11];
    wire [10:0] yj1 = ey1[pj*11 +: 11], yj2 = ey2[pj*11 +: 11];
    wire [1:0]  ci  = ecl[pi*2 +: 2], cj = ecl[pj*2 +: 2];

    wire [10:0] ix_hi = (xi2 < xj2) ? xi2 : xj2;
    wire [10:0] ix_lo = (xi1 > xj1) ? xi1 : xj1;
    wire [10:0] iy_hi = (yi2 < yj2) ? yi2 : yj2;
    wire [10:0] iy_lo = (yi1 > yj1) ? yi1 : yj1;

    wire signed [12:0] iw_s = $signed({2'b0, ix_hi}) - $signed({2'b0, ix_lo}) + 13'sd1;
    wire signed [12:0] ih_s = $signed({2'b0, iy_hi}) - $signed({2'b0, iy_lo}) + 13'sd1;
    wire [11:0] iw = iw_s[12] ? 12'd0 : iw_s[11:0];
    wire [11:0] ih = ih_s[12] ? 12'd0 : ih_s[11:0];
    // 面积与交叠面积错峰使用，共用 1 个 12x12 乘数 -> 只占 1 个 DSP
    // （依据：DSP 余量 20 - PE 16 = 4；若占 2 个就只剩 2 个给 Otsu 等）
    reg  [11:0] mul_a, mul_b;   // 乘法操作数先寄存，打断 ex1 -> 乘法 的长路

    wire [23:0] mul_p = mul_a * mul_b;
    wire [22:0] aprod   = mul_p[22:0];
    wire [22:0] inter_n = mul_p[22:0];

    wire pair_valid = ev[pi] && ev[pj] && !sup[pi] && !sup[pj] && (ci == cj);

    wire [21:0] ar_i = area[qi*22 +: 22];
    wire [21:0] ar_j = area[qj*22 +: 22];
    wire [23:0] d2inter = {2'b0, inter_q} << 1;
    wire [23:0] dunion  = {2'b0, ar_i} + {2'b0, ar_j} - {2'b0, inter_q};
    wire        suppress = pair_ok && (d2inter > dunion);

    //-------------------------------------------------------------------------
    // 5. 结果表
    //-------------------------------------------------------------------------
    reg [511:0] res;
    reg [3:0]   oi;
    wire [63:0] ow = {esc[oi*8 +: 8], ecl[oi*2 +: 2],
                      ex1[oi*11 +: 11], ey1[oi*11 +: 11],
                      ex2[oi*11 +: 11], ey2[oi*11 +: 11], 10'b0};

    assign O_rd_data = res[I_rd_idx*64 +: 64];

    //-------------------------------------------------------------------------
    // 5b. 跨域搬运用的紧凑打包（每框 48 位，比 res 的 64 位/框少搬 128 位）
    //     [47:46]=0  [45:44]=cls  [43:33]=x1  [32:22]=y1  [21:11]=x2  [10:0]=y2
    //     只新增打包输出，不改 O_rd_data 的既有语义（调试与旧 TB 仍用 64 位/框）
    //-------------------------------------------------------------------------
    genvar gpk;
    generate
        for (gpk = 0; gpk < 8; gpk = gpk + 1) begin : g_boxpack
            assign O_box_all[gpk*48 +: 48] = {
                2'b00,
                res[gpk*64 + 54 +: 2],
                res[gpk*64 + 43 +: 11],
                res[gpk*64 + 32 +: 11],
                res[gpk*64 + 21 +: 11],
                res[gpk*64 + 10 +: 11]
            };
        end
    endgenerate

    //-------------------------------------------------------------------------
    // 6. 主状态机
    //-------------------------------------------------------------------------
    integer jj, kk;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            st <= S_IDLE; O_done <= 1'b0; O_nbox <= 4'd0; O_mem_addr <= 15'd0;
            gx <= 5'd0; gy <= 4'd0; row_base <= HEAD_BASE; col_off <= 15'd0;
            w0 <= 32'd0;
            ev <= 8'd0; esc <= 64'd0; ecl <= 16'd0;
            ex1 <= 88'd0; ey1 <= 88'd0; ex2 <= 88'd0; ey2 <= 88'd0;
            area <= 176'd0; aidx <= 4'd0; sup <= 8'd0;
            pi <= 3'd0; pj <= 3'd0; qi <= 3'd0; qj <= 3'd0;
            inter_q <= 22'd0; pair_ok <= 1'b0;
            c_ok <= 1'b0; c_score <= 8'd0; c_cls <= 2'd0;
            c_x1 <= 11'd0; c_y1 <= 11'd0; c_x2 <= 11'd0; c_y2 <= 11'd0;
            ins_last <= 1'b0;
            res <= 512'd0; oi <= 4'd0;
            mul_a <= 12'd0; mul_b <= 12'd0;
        end else begin
            // ---- top-8 插入（S_S2 且候选合格）----
            if (do_ins && (ins_pos == 4'd0)) begin
                ev[0] <= 1'b1; esc[0 +: 8] <= c_score; ecl[0 +: 2] <= c_cls;
                ex1[0 +: 11] <= c_x1; ey1[0 +: 11] <= c_y1;
                ex2[0 +: 11] <= c_x2; ey2[0 +: 11] <= c_y2;
            end
            for (jj = 1; jj < 8; jj = jj + 1) begin
                if (do_ins && (jj == ins_pos)) begin
                    ev[jj] <= 1'b1; esc[jj*8 +: 8] <= c_score; ecl[jj*2 +: 2] <= c_cls;
                    ex1[jj*11 +: 11] <= c_x1; ey1[jj*11 +: 11] <= c_y1;
                    ex2[jj*11 +: 11] <= c_x2; ey2[jj*11 +: 11] <= c_y2;
                end else if (do_ins && (jj > ins_pos)) begin
                    ev[jj] <= ev[jj-1];
                    esc[jj*8 +: 8] <= esc[(jj-1)*8 +: 8];
                    ecl[jj*2 +: 2] <= ecl[(jj-1)*2 +: 2];
                    ex1[jj*11 +: 11] <= ex1[(jj-1)*11 +: 11];
                    ey1[jj*11 +: 11] <= ey1[(jj-1)*11 +: 11];
                    ex2[jj*11 +: 11] <= ex2[(jj-1)*11 +: 11];
                    ey2[jj*11 +: 11] <= ey2[(jj-1)*11 +: 11];
                end
            end

            // ---- 面积登记 ----
            if (st == S_AREAW) area[aidx*22 +: 22] <= mul_p[21:0];

            // ---- NMS 抑制 ----
            if ((st == S_PAIR3) && suppress) sup[qj] <= 1'b1;

            // ---- 结果表写入 ----
            if (st == S_OUT) begin
                if (ev[oi] && !sup[oi]) begin
                    for (kk = 0; kk < 8; kk = kk + 1)
                        if (kk == O_nbox) res[kk*64 +: 64] <= ow;
                    O_nbox <= O_nbox + 4'd1;
                end
            end

            case (st)
            S_IDLE: begin
                O_done <= 1'b0;
                if (I_start) begin
                    gx <= 5'd0; gy <= 4'd0;
                    row_base <= HEAD_BASE; col_off <= 15'd0;
                    ev <= 8'd0; esc <= 64'd0; ecl <= 16'd0;
                    ex1 <= 88'd0; ey1 <= 88'd0; ex2 <= 88'd0; ey2 <= 88'd0;
                    sup <= 8'd0; O_nbox <= 4'd0; res <= 512'd0;
                    O_mem_addr <= HEAD_BASE;      // 呈现格 0 的字 0
                    st <= S_S0;
                end
            end
            S_S0: begin                          // 等字 0 数据，同时把地址推进到本格字 1
                O_mem_addr <= row_base + col_off + 15'd1;
                st <= S_S1;
            end
            S_S1: begin
                w0 <= I_mem_data;                 // 格 (gx,gy) 的字 0
                O_mem_addr <= row_base + col_off + 15'd1;
                st <= S_S2;
            end
            S_S2: begin                                  // 本拍 I_mem_data = 本格字 1
                c_ok    <= cand_ok;
                c_score <= cand_score;
                c_cls   <= cls;
                c_x1 <= cx1; c_y1 <= cy1; c_x2 <= cx2; c_y2 <= cy2;
                if (gx + 5'd1 < GW) begin
                    gx <= gx + 5'd1;
                    col_off <= col_off + 15'd2;
                    O_mem_addr <= row_base + col_off + 15'd2;
                    ins_last <= 1'b0;
                end else begin
                    gx <= 5'd0; col_off <= 15'd0;
                    if (gy + 4'd1 < GH) begin
                        gy <= gy + 4'd1;
                        row_base <= row_base + HEAD_RS;
                        O_mem_addr <= row_base + HEAD_RS;
                        ins_last <= 1'b0;
                    end else begin
                        ins_last <= 1'b1;
                    end
                end
                st <= S_INS;
            end
            S_INS: begin                                 // 候选已寄存，这一拍做插入
                if (ins_last) begin aidx <= 4'd0; st <= S_AREA; end
                else                st <= S_S3;
            end
            S_S3: begin
                O_mem_addr <= row_base + col_off + 15'd1;
                st <= S_S1;
            end

            S_AREA: begin                                // 只算操作数（短）
                mul_a <= aw; mul_b <= ah;
                st <= S_AREAW;
            end
            S_AREAW: begin                               // 乘法结果登记
                if (aidx == 4'd7) begin
                    pi <= 3'd0; pj <= 3'd1; st <= S_PAIR;
                end else begin aidx <= aidx + 4'd1; st <= S_AREA; end
            end

            S_PAIR: begin                                // 只算操作数（短）
                qi <= pi; qj <= pj;
                pair_ok <= pair_valid;
                mul_a <= iw; mul_b <= ih;
                st <= S_PAIR2;
            end
            S_PAIR2: begin                               // 乘法结果登记
                inter_q <= pair_ok ? mul_p[21:0] : 22'd0;
                st <= S_PAIR3;
            end
            S_PAIR3: begin                               // 比较 + 抑制 + 推进
                if (pj == 3'd7) begin
                    if (pi == 3'd6) begin
                        oi <= 4'd0; st <= S_OUT;
                    end else begin
                        pi <= pi + 3'd1; pj <= pi + 3'd2; st <= S_PAIR;
                    end
                end else begin
                    pj <= pj + 3'd1; st <= S_PAIR;
                end
            end

            S_OUT: begin
                if (oi == 4'd7) begin
                    O_done <= 1'b1; st <= S_DONE;
                end else oi <= oi + 4'd1;
            end

            S_DONE: begin
                if (!I_start) begin O_done <= 1'b0; st <= S_IDLE; end
            end
            default: st <= S_IDLE;
            endcase
        end
    end
endmodule
