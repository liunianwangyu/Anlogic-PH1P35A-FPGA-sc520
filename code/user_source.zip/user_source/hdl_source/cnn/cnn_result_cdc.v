//=============================================================================
// cnn_result_cdc.v -- CNN 结果包跨时钟域搬运（csi 域 -> HDMI 像素域）
//
// 为什么需要：cnn_subsystem 整条链在 S_csi_rx_clk（约 103.52 MHz）单域里跑，
//   而画框/上屏必须在 S_hdmi_pixel_clk（约 74.25 MHz）域。SDC 里
//   MIPI_RX_BYTE_CLK 与 HDMI_PIXEL_CLK 已在同一组 set_clock_groups -asynchronous
//   里，所以这里只需保证**结构正确**，不需要改约束。
//
// 结构与项目里已验证的 ae_stats_cdc / effect_config_cdc 同构：
//   * 源域持有数据（src_hold），只有握手空闲时才接受新的发布脉冲；
//     传输途中来的新发布会被**丢弃**（不会破坏在途数据）。
//   * 只同步 req/ack 两个握手位，各两级同步器。
//   * 目的域在 req_sync != ack_toggle 时整体采样 src_hold -> O_dst_data，
//     并给出 O_dst_valid 一拍脉冲。
//   数据完整性由"src_hold 从 req 翻转前一直保持到 ack 返回"保证：
//   目的域看到 req 变化至少晚 2 个目的时钟，此时数据早已稳定。
//
// 发布频率是每帧一次（约 30 Hz），而握手在几十个时钟内完成，
// 所以"丢弃"这一路径在正常使用下不会触发。
//=============================================================================
`timescale 1ns / 1ps

module cnn_result_cdc #(
    parameter integer WIDTH = 420
) (
    input  wire             I_src_clk,
    input  wire             I_dst_clk,
    input  wire             I_rst_n,
    input  wire [WIDTH-1:0] I_src_data,
    input  wire             I_src_valid,   // 源域 1 拍脉冲：发布一包新结果
    output reg  [WIDTH-1:0] O_dst_data,    // 目的域：已采样到的整包
    output reg              O_dst_valid    // 目的域 1 拍脉冲：O_dst_data 刚刚更新
);
    reg [WIDTH-1:0] src_hold;
    reg             req_toggle;
    reg             ack_toggle;
    reg             ack_meta, ack_sync;
    reg             req_meta, req_sync;

    // ---- 源域：抓包 + 发请求 ----
    always @(posedge I_src_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            src_hold   <= {WIDTH{1'b0}};
            req_toggle <= 1'b0;
            ack_meta   <= 1'b0;
            ack_sync   <= 1'b0;
        end else begin
            ack_meta <= ack_toggle;
            ack_sync <= ack_meta;
            if (I_src_valid && (req_toggle == ack_sync)) begin
                src_hold   <= I_src_data;
                req_toggle <= ~req_toggle;
            end
        end
    end

    // ---- 目的域：收包 + 回确认 ----
    always @(posedge I_dst_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            req_meta    <= 1'b0;
            req_sync    <= 1'b0;
            ack_toggle  <= 1'b0;
            O_dst_data  <= {WIDTH{1'b0}};
            O_dst_valid <= 1'b0;
        end else begin
            req_meta    <= req_toggle;
            req_sync    <= req_meta;
            O_dst_valid <= 1'b0;
            if (req_sync != ack_toggle) begin
                O_dst_data  <= src_hold;
                O_dst_valid <= 1'b1;
                ack_toggle  <= req_sync;
            end
        end
    end
endmodule