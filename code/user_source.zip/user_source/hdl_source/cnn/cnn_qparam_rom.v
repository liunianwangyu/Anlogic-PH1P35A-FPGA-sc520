//=============================================================================
// cnn_qparam_rom.v -- 逐输出通道的量化参数（每 OC 一条：{shift[4:0], bias[15:0]}）
//
// 目的（P1）：
//   * **偏置**：PE 累加器用"初值装载"实现偏置 —— 清零改成装 bias，
//     不改累加路径（acc + S），所以**零时序代价**。
//   * **逐 OC 重量化**：把原来"每层一个移位"改成"每个输出通道一个移位"，
//     这是量化精度最大的单一杠杆（per-tensor -> per-OC）。
//
// 语义（与 cnn_contract.json 的 quant_params 一致）：
//      out = sat8( (acc + bias) >>> shift )
//   * bias 是 int16（累加器尺度），训练侧必须保证 |bias| <= 32767
//   * shift 是 5 位（0..31）
//   * 表内容由 scripts/cnn_contract.ps1 -GenQrom 从 cnn_contract.json 生成，
//     **不要手改** cnn_qparam_table.vh
//
// 索引：I_idx = 层表的 q_base + cog*4（必须是 4 的倍数），一次读 4 条（一个 OC 组）
//=============================================================================
`timescale 1ns / 1ps
module cnn_qparam_rom (
    input  wire [5:0]         I_idx,
    output wire [4:0]         O_sh0, O_sh1, O_sh2, O_sh3,
    output wire signed [15:0] O_bi0, O_bi1, O_bi2, O_bi3
);
`include "cnn_qparam_table.vh"

    wire [20:0] r0 = qrec(I_idx);
    wire [20:0] r1 = qrec(I_idx + 6'd1);
    wire [20:0] r2 = qrec(I_idx + 6'd2);
    wire [20:0] r3 = qrec(I_idx + 6'd3);

    assign O_sh0 = r0[20:16];
    assign O_sh1 = r1[20:16];
    assign O_sh2 = r2[20:16];
    assign O_sh3 = r3[20:16];

    assign O_bi0 = r0[15:0];
    assign O_bi1 = r1[15:0];
    assign O_bi2 = r2[15:0];
    assign O_bi3 = r3[15:0];
endmodule
