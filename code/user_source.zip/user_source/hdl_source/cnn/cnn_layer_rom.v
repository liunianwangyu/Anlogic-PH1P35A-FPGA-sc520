//=============================================================================
// cnn_layer_rom.v  --  卷积层参数表（144 位层记录，含每层行跨度 row_step）
//
// 记录字段：[143:128] row_step  每行字跨度 = W_in * (C_in/IC)  （由层表提供，
//                                替代固定 512，避免小层浪费 3~4 倍内存）
//          [127:112] w_base   权重字基址
//          [111: 96] out_base 输出特征图字基址
//          [ 95: 80] in_base  输入特征图字基址
//          [ 79: 72] out_ch  [71:64] in_ch
//          [ 63: 53] out_w   [52:42] out_h  [41:31] in_w  [30:20] in_h
//          [ 19: 18] stride  [17:16] ksel  [15:11] requant_shift
//          [ 10]     relu6_en   [9:0] 保留
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"

module cnn_layer_rom (
    input  wire [3:0]  I_layer,
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_load,
    output reg  [15:0] O_row_step,
    output reg  [15:0] O_w_base,
    output reg  [15:0] O_out_base,
    output reg  [15:0] O_in_base,
    output reg  [7:0]  O_out_ch,
    output reg  [7:0]  O_in_ch,
    output reg  [10:0] O_out_w,
    output reg  [10:0] O_out_h,
    output reg  [10:0] O_in_w,
    output reg  [10:0] O_in_h,
    output reg  [1:0]  O_stride,
    output reg  [1:0]  O_ksel,
    output reg  [4:0]  O_q_base,        // P1：本层 qparam ROM 基址（原 requant_shift）
    output reg         O_relu6_en,
    output reg         O_border,
    output             O_valid
);
    function [143:0] layer_rec;
        input [3:0] idx;
        begin
            case (idx)
                4'd0: layer_rec = {16'd160, 16'd0, 16'd14400, 16'd0, 8'd4, 8'd4, 11'd80, 11'd45, 11'd160, 11'd90, 2'd2, 2'd1, 5'd0, 1'd1, 1'd1, 9'd0};
                4'd1: layer_rec = {16'd80, 16'd9, 16'd0, 16'd14400, 8'd8, 8'd4, 11'd40, 11'd23, 11'd80, 11'd45, 2'd2, 2'd1, 5'd4, 1'd1, 1'd1, 9'd0};
                4'd2: layer_rec = {16'd80, 16'd27, 16'd14400, 16'd0, 8'd16, 8'd8, 11'd20, 11'd12, 11'd40, 11'd23, 2'd2, 2'd1, 5'd12, 1'd1, 1'd1, 9'd0};
                4'd3: layer_rec = {16'd80, 16'd99, 16'd0, 16'd14400, 8'd8, 8'd16, 11'd20, 11'd12, 11'd20, 11'd12, 2'd1, 2'd1, 5'd28, 1'd0, 1'd1, 9'd0};
                default: layer_rec = 144'd0;
            endcase
        end
    endfunction

    wire [143:0] S_rec = layer_rec(I_layer);
    assign O_valid = (I_layer < `CNN_NUM_LAYERS);

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_row_step <= 16'd0; O_w_base <= 16'd0; O_out_base <= 16'd0; O_in_base <= 16'd0;
            O_out_ch <= 8'd0; O_in_ch <= 8'd0;
            O_out_w <= 11'd0; O_out_h <= 11'd0; O_in_w <= 11'd0; O_in_h <= 11'd0;
            O_stride <= 2'd1; O_ksel <= 2'd1; O_q_base <= 5'd0; O_relu6_en <= 1'b0; O_border <= 1'b0;
        end else if (I_load) begin
            O_row_step      <= S_rec[143:128];
            O_w_base        <= S_rec[127:112];
            O_out_base      <= S_rec[111:96];
            O_in_base       <= S_rec[95:80];
            O_out_ch        <= S_rec[79:72];
            O_in_ch         <= S_rec[71:64];
            O_out_w         <= S_rec[63:53];
            O_out_h         <= S_rec[52:42];
            O_in_w          <= S_rec[41:31];
            O_in_h          <= S_rec[30:20];
            O_stride        <= S_rec[19:18];
            O_ksel          <= S_rec[17:16];
            O_q_base        <= S_rec[15:11];
            O_relu6_en      <= S_rec[10];
            O_border        <= S_rec[9];
        end
    end
endmodule
