//=============================================================================
// cnn_capture.v -- v1.7：把 ISP 的像素对齐 96bit 流降采样成 CNN 输入帧
//
// 依据（README_cnn.md 5.11）：
//   S5  isp_top.v 里 segment_x/segment_y 的计数逻辑（板上已跑通的分割功能就是
//       用它定位的）证明：ISP 输出 1 拍 = 4 像素（96 bit；p0=[95:72] ...
//       p3=[23:0]，每像素 R=[23:16] G=[15:8] B=[7:0]），一行 320 拍、一帧 720 行。
//       isp_top 里 video_mirror 的注释说基线 awb 的 tlast 是 "valid 下降" 脉冲、没和
//       有效拍对齐；v1.6 真实使用的 hdl_source/awb.v 实测是对齐的（见 README 5.12）。
//       本模块一律按 "有效拍计数" 定行边界，与 video_mirror 的 BEATS_LAST 口径一致，
//       不依赖 tlast 的相位。
//   S1  1280/8 = 160、720/8 = 90。
//
// 算法（8x8 箱式平均，两级可分离实现，避免 14 位累加器）：
//   水平：一拍内 4 像素先各自求和；两拍凑满 8 像素 -> 四舍五入到 8 位
//   垂直：同一列组的 8 行累加在 acc[]（11 位 x 3 通道，8*255 = 2040）
//         第 8 行时同时把 (acc + 本行) >> 3 写进 CNN 输入帧区，并把 acc 覆盖成
//         下一带的初值。写的是输入帧、读的是 acc —— 两个不同存储器同拍各一次
//         读写：没有端口冲突，也不需要额外的 flush 周期。
//
// 时序（每 2 拍一个列组，偶拍/奇拍两拍流水，无状态机）：
//   偶拍（bx_now[0]==0）：发 acc 读地址 = bx_now[8:1]，同时寄存前 4 像素和
//   奇拍（bx_now[0]==1）：acc_rd 已到 -> 加本组 8 像素和 -> 登记写 acc 和写输入帧
//
// 与训练/量化侧的接口约定（必须一致，否则权重对不上）：
//   输入帧字 = {EDGE_DENSITY, B, G, R}；字节序 ch0=R ch1=G ch2=B ch3=min(8x8 edge hits * 4,127)
//   每通道是 int8 有符号，值 = clamp(8x8 均值,0,255) + 128（零点 128）。
//   cnn_pe 用 $signed(W)*$signed(X)，图像必须先居中；否则 >=128 的像素会被当成
//   负数（本项目第 4 次遇到的有符号/无符号问题，在采集侧一次性处理）。
//
// 踩过的坑（本轮实测定位，两条都靠逐拍探针抓到）：
//   1) 帧首拍不能用 "把 bx 清 0" 处理 —— 那一拍自己就占用了 bx=0，于是首行变成
//      321 拍，之后整帧的行/带边界永久错位（frame_done 永不出现、全部 14400 个
//      字都对不上）。正确做法是用组合的 bx_now/by_now（帧首拍强制取 0）。
//   2) ERAM/BRAM 读出延迟 1 拍，而列组间隔恰好只有 2 拍：如果在 "组完成" 之后
//      才发读地址、下一拍就用 acc_rd，拿到的其实是上一组的累加值（表现为每个
//      通道的垂直累加被串了一组）。必须把读地址提前到偶拍。
//=============================================================================
`timescale 1ns / 1ps
`include "cnn_config.vh"
module cnn_capture (
    input  wire        I_clk,
    input  wire        I_rst_n,
    // ISP 侧：像素对齐 96 bit 流（1 拍 = 4 像素）。被动监听、不产生 tready，
    // 对视频通路零影响。
    input  wire        I_pix_valid,
    input  wire        I_pix_tuser,
    input  wire [95:0] I_pix_data,
    input wire [1:0] I_edge_hits, // bit1: pixels 0/1, bit0: pixels 2/3
    // 采集使能：帧首锁存。1 = 采集本帧；0 = 丢弃本帧（CNN 运行期间用）
    input  wire        I_en,
    // CNN 输入帧写端口（地址已含输入帧区基址）
    output reg         O_wr_en,
    output reg  [14:0] O_wr_addr,
    output reg  [31:0] O_wr_data,
    // O_frame_done 只对 "被采集的帧" 产生脉冲，控制器据此启动 CNN
    output wire        O_frame_start,  // effective first valid beat, including pending tuser
    output reg         O_frame_done,
    output reg  [14:0] O_dbg_wr_cnt,   // 上一帧写进输入帧区的字数（应恒为 14400）
    output reg         O_dbg_err       // 粘滞：写次数异常
);
    localparam [14:0] FB_BASE = `CNN_FIN_BASE_W;
    localparam [7:0]  ZP      = `CNN_CAP_ZP;
    localparam integer FB_WORD = 14400;     // 160 x 90
    //-------------------------------------------------------------------------
    // 1. 帧 / 行 / 列 定位
    //    tuser 可能比第一个有效拍早 1~2 拍（awb 的输出就是这样），先挂起；
    //    "帧首拍" 用组合方式强制取 bx_now/by_now = 0，寄存器按 bx_now 推进。
    //-------------------------------------------------------------------------
    reg  [8:0]  bx;         // 行内拍号 0..319
    reg  [9:0]  by;         // 行号 0..719
    reg         usr_pend;
    reg         cap_on;
    wire beat_first = I_pix_valid && (I_pix_tuser || usr_pend);
    assign O_frame_start = beat_first && I_en;
    wire [8:0]  bx_now = beat_first ? 9'd0  : bx;
    wire [9:0]  by_now = beat_first ? 10'd0 : by;
    wire line_last  = (bx_now == 9'd319);
    wire frame_last = line_last && (by_now == 10'd719);
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            bx <= 9'd0; by <= 10'd0; usr_pend <= 1'b0; cap_on <= 1'b0;
        end else begin
            // 使能在帧首锁存：本帧中途改变不了本帧的行为
            if (I_pix_tuser || beat_first)
                cap_on <= I_en;
            if (I_pix_tuser && !I_pix_valid)
                usr_pend <= 1'b1;
            else if (I_pix_valid)
                usr_pend <= 1'b0;
            if (I_pix_valid) begin
                if (line_last) begin
                    bx <= 9'd0;
                    by <= frame_last ? 10'd0 : (by_now + 10'd1);
                end else begin
                    bx <= bx_now + 9'd1;
                end
            end
        end
    end
    //-------------------------------------------------------------------------
    // 2. 水平：偶拍寄存前 4 像素和，奇拍加后 4 像素 -> 8 位水平均值；
    //    偶拍同时发 acc 读地址（bx_now[8:1] 在偶拍就已经是本组号）
    //-------------------------------------------------------------------------
    wire [7:0] r0 = I_pix_data[95:88];
    wire [7:0] g0 = I_pix_data[87:80];
    wire [7:0] b0 = I_pix_data[79:72];
    wire [7:0] r1 = I_pix_data[71:64];
    wire [7:0] g1 = I_pix_data[63:56];
    wire [7:0] b1 = I_pix_data[55:48];
    wire [7:0] r2 = I_pix_data[47:40];
    wire [7:0] g2 = I_pix_data[39:32];
    wire [7:0] b2 = I_pix_data[31:24];
    wire [7:0] r3 = I_pix_data[23:16];
    wire [7:0] g3 = I_pix_data[15:8];
    wire [7:0] b3 = I_pix_data[7:0];
    wire [9:0]  s4r = {2'b0,r0} + {2'b0,r1} + {2'b0,r2} + {2'b0,r3};
    wire [9:0]  s4g = {2'b0,g0} + {2'b0,g1} + {2'b0,g2} + {2'b0,g3};
    wire [9:0]  s4b = {2'b0,b0} + {2'b0,b1} + {2'b0,b2} + {2'b0,b3};
    wire [1:0] hit_count = {1'b0,I_edge_hits[1]} + {1'b0,I_edge_hits[0]};
    reg [1:0] hs_edge;
    reg [2:0] g_edge;
    reg  [10:0] hs_r, hs_g, hs_b;      // 组内前 4 像素的和
    wire [10:0] hs8r = hs_r + {1'b0, s4r};   // 8 像素通道和（<= 2040）
    wire [10:0] hs8g = hs_g + {1'b0, s4g};
    wire [10:0] hs8b = hs_b + {1'b0, s4b};
    wire [7:0]  h_r = (hs8r + 11'd4) >> 3;   // 本组 8 位水平均值
    wire [7:0]  h_g = (hs8g + 11'd4) >> 3;
    wire [7:0]  h_b = (hs8b + 11'd4) >> 3;
    wire [7:0]  c_gx   = bx_now[8:1];
    wire [6:0]  c_band = by_now[9:3];
    wire        c_first = (by_now[2:0] == 3'd0);
    wire        c_last  = (by_now[2:0] == 3'd7);
    // 组结果寄存一拍（打断 像素 -> 5 层加法 -> 写寄存器 的长路，见 README 5.14）
    reg  [7:0]  g_hr, g_hg, g_hb, g_gx;
    reg  [6:0]  g_band;
    reg         g_first, g_last, g_vld;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            hs_edge <= 0; g_edge <= 0;
            hs_r <= 11'd0; hs_g <= 11'd0; hs_b <= 11'd0;
            g_hr <= 8'd0; g_hg <= 8'd0; g_hb <= 8'd0; g_gx <= 8'd0;
            g_band <= 7'd0; g_first <= 1'b0; g_last <= 1'b0; g_vld <= 1'b0;
        end else if (I_pix_valid && !bx_now[0]) begin
            hs_edge <= hit_count;
            hs_r  <= {1'b0, s4r};
            hs_g  <= {1'b0, s4g};
            hs_b  <= {1'b0, s4b};
            g_vld <= 1'b0;
        end else if (I_pix_valid && bx_now[0]) begin
            g_edge <= {1'b0,hs_edge} + {1'b0,hit_count};
            g_hr <= h_r; g_hg <= h_g; g_hb <= h_b;
            g_gx <= c_gx; g_band <= c_band; g_first <= c_first; g_last <= c_last;
            g_vld <= 1'b1;
        end else begin
            g_vld <= 1'b0;
        end
    end
    //-------------------------------------------------------------------------
    // 3. 垂直：acc[] 累加；每带第 8 行把 8 行均值写进 CNN 输入帧区
    //-------------------------------------------------------------------------
    (* ram_style = "bram" *) reg [38:0] acc [0:159];
    reg  [38:0] acc_rd;
    reg         acc_we;
    reg  [7:0]  acc_waddr;
    reg  [38:0] acc_wdata;
    always @(posedge I_clk) begin
        if (acc_we) acc[acc_waddr] <= acc_wdata;
        if (I_pix_valid && !bx_now[0]) acc_rd <= acc[bx_now[8:1]];
    end
    // 通道切片：R = [10:0]，G = [21:11]，B = [32:22]
    wire [11:0] sum_r = {1'b0, acc_rd[10:0]}  + {1'b0, g_hr};
    wire [11:0] sum_g = {1'b0, acc_rd[21:11]} + {1'b0, g_hg};
    wire [11:0] sum_b = {1'b0, acc_rd[32:22]} + {1'b0, g_hb};
    wire [7:0]  mn_r = (sum_r + 12'd4) >> 3;   // 8 行均值（<= 255，不需饱和）
    wire [7:0]  mn_g = (sum_g + 12'd4) >> 3;
    wire [7:0]  mn_b = (sum_b + 12'd4) >> 3;
    wire [10:0] nx_r = g_first ? {3'b0, g_hr} : sum_r[10:0];
    wire [10:0] nx_g = g_first ? {3'b0, g_hg} : sum_g[10:0];
    wire [10:0] nx_b = g_first ? {3'b0, g_hb} : sum_b[10:0];
    // 33 RGB bits + 6 count bits fit the same pair of 20-bit RAM lanes.
    wire [5:0] edge_sum = acc_rd[38:33] + {3'b0,g_edge};
    wire [5:0] nx_edge = g_first ? {3'b0,g_edge} : edge_sum;
    wire [7:0] edge_density = edge_sum[5] ? 8'd127 : {1'b0,edge_sum[4:0],2'b00};
    reg  [7:0]  fd_sr;
    reg  [14:0] wr_cnt;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            acc_we <= 1'b0; acc_waddr <= 8'd0; acc_wdata <= 39'd0;
            O_wr_en <= 1'b0; O_wr_addr <= 15'd0; O_wr_data <= 32'd0;
            O_frame_done <= 1'b0; fd_sr <= 8'd0;
        end else begin
            acc_we  <= 1'b0;
            O_wr_en <= 1'b0;
            if (g_vld && cap_on) begin
                acc_we    <= 1'b1;
                acc_waddr <= g_gx;
                acc_wdata <= {nx_edge,nx_b, nx_g, nx_r};
                if (g_last) begin
                    O_wr_en   <= 1'b1;
                    O_wr_addr <= FB_BASE + ({g_band, 7'b0} + {g_band, 5'b0})
                                        + {7'b0, g_gx};
                    O_wr_data <= {edge_density, (mn_b + ZP), (mn_g + ZP), (mn_r + ZP)};
                end
            end
            // 帧完成脉冲：只对采集过的帧产生，且等输入帧最后一批写完之后
            fd_sr <= {fd_sr[6:0], (I_pix_valid && frame_last && cap_on)};
            O_frame_done <= fd_sr[7];
        end
    end
    //-------------------------------------------------------------------------
    // 4. 诊断：本帧写入输入帧区的字数（正确值恒为 14400）
    //-------------------------------------------------------------------------
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) wr_cnt <= 15'd0;
        else if (beat_first) wr_cnt <= 15'd0;
        else if (O_wr_en) wr_cnt <= wr_cnt + 15'd1;
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_dbg_wr_cnt <= 15'd0; O_dbg_err <= 1'b0;
        end else if (O_frame_done) begin
            O_dbg_wr_cnt <= wr_cnt;
            if (wr_cnt != FB_WORD) O_dbg_err <= 1'b1;
        end
    end
endmodule
