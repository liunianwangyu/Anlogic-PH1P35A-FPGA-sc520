//---------------------------------------------------------------------------
// NOTE: 本文件的设计依据、参数推导与验证证据见同目录 README_cnn.md。
//       (早期中文行内注释因写入编码问题丢失, 现统一收敛到该文档。)
//---------------------------------------------------------------------------
//=============================================================================







//




//=============================================================================
`timescale 1ns / 1ps

module cnn_pe #(
    parameter integer OC = 4,
    parameter integer IC = 4,
    parameter integer ACC_W = 32
)(
    input  wire                        I_clk,
    input  wire                        I_rst_n,
    input  wire signed [OC*IC*8-1:0]   I_w,
    input  wire signed [IC*8-1:0]      I_x,
    input  wire signed [OC*ACC_W-1:0]  I_bias,
    input  wire                        I_valid,
    input  wire                        I_clear,
    output reg  signed [OC*ACC_W-1:0]  O_acc
);

    reg signed [7:0] W1 [0:OC*IC-1];
    reg signed [7:0] X1 [0:IC-1];
    reg              V1, C1;
    integer i, k;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            V1 <= 1'b0;
            C1 <= 1'b0;
        end else begin
            V1 <= I_valid;
            C1 <= I_clear;
            for (i = 0; i < OC*IC; i = i + 1) W1[i] <= I_w[i*8 +: 8];
            for (k = 0; k < IC;    k = k + 1) X1[k] <= I_x[k*8 +: 8];
        end
    end


    reg signed [ACC_W-1:0] S [0:OC-1];
    always @(*) begin
        for (i = 0; i < OC; i = i + 1) begin
            S[i] = 0;
            for (k = 0; k < IC; k = k + 1)
                S[i] = S[i] + (W1[i*IC+k] * X1[k]);
        end
    end


    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            for (i = 0; i < OC; i = i + 1) O_acc[i*ACC_W +: ACC_W] <= 0;
        end else if (C1) begin
            // P1：偏置用"初值装载"实现，累加路径 (acc + S) 不变 -> 零时序代价
            for (i = 0; i < OC; i = i + 1) O_acc[i*ACC_W +: ACC_W] <= $signed(I_bias[i*ACC_W +: ACC_W]);
        end else if (V1) begin
            for (i = 0; i < OC; i = i + 1)
                O_acc[i*ACC_W +: ACC_W] <= $signed(O_acc[i*ACC_W +: ACC_W]) + S[i];
        end
    end
endmodule
