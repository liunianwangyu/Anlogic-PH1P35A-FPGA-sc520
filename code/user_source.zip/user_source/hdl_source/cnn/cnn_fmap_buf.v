//---------------------------------------------------------------------------
// NOTE: 本文件的设计依据、参数推导与验证证据见同目录 README_cnn.md。
//       (早期中文行内注释因写入编码问题丢失, 现统一收敛到该文档。)
//---------------------------------------------------------------------------
//=============================================================================

//


//



//

//=============================================================================
`timescale 1ns / 1ps

module cnn_fmap_buf #(
    parameter integer DW   = 32,
    parameter integer MAXW = 2560,
    parameter integer AWB  = 12
)(
    input  wire             I_clk,
    input  wire             I_rst_n,
    input  wire             I_wr_en,
    input  wire [AWB-1:0]   I_wr_addr,
    input  wire [DW-1:0]    I_wr_data,
    input  wire [AWB-1:0]   I_rd_addr,
    output reg  [DW-1:0]    O_rd_data
);
    (* ram_style = "block" *) reg [DW-1:0] mem [0:MAXW-1];

    always @(posedge I_clk) begin
        if (I_wr_en) mem[I_wr_addr] <= I_wr_data;
        O_rd_data <= mem[I_rd_addr];
    end
endmodule
