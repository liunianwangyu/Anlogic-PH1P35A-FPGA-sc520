`timescale 1ns/1ps
// No statistics copy: AWB holds I_stats frozen until this job finishes.
// GLOBAL_ONLY reduces the staging bank to one 32-bit pair. Config bit 9
// tells firmware to submit only group 9; awb.v owns temporal smoothing and
// frame-boundary commit. Legacy ten-group jobs retain their original ABI.
module awb_mcu_solver #(
    parameter[15:0] GAIN_MIN=16'h0800,GAIN_MAX=16'h2000,
    parameter integer MIN_LOCAL=128,MIN_GLOBAL=1024,SMOOTH_SHIFT=0,REQUIRE_ALL_LOCAL=1,
    parameter integer TIMEOUT_CYCLES=750000,GLOBAL_ONLY=0,SPATIAL_AUTO=0,DEADBAND=8
)(
    input I_clk,I_rst_n,I_start,
    input[879:0] I_stats,
    input[319:0] I_previous,
    input[319:0] I_base,
    input I_auto_job,
    output[319:0] O_profile,
    output reg O_done,O_good,
    input[8:0] I_paddr,
    input I_psel,I_penable,I_pwrite,
    input[31:0] I_pwdata,
    output reg[31:0] O_prdata,
    output O_pready,O_pslverr
);
    localparam[15:0] MIN_LOCAL_U=MIN_LOCAL,MIN_GLOBAL_U=MIN_GLOBAL;
    localparam[7:0] SHIFT_U=SMOOTH_SHIFT;
    localparam REQUIRE_U=(REQUIRE_ALL_LOCAL!=0);
    localparam GLOBAL_U=(GLOBAL_ONLY!=0);
    localparam integer GROUPS=GLOBAL_ONLY?1:10;
    reg[GROUPS*32-1:0] staged_profile;
    assign O_profile=GLOBAL_ONLY?{10{staged_profile[31:0]}}:staged_profile;
    reg pending,rejected,fault,staged_good;
    reg[31:0] token;
    reg[GROUPS-1:0] written;
    reg[$clog2(TIMEOUT_CYCLES)-1:0] elapsed;
    wire access=I_psel&&I_penable;
    wire gains=(I_paddr>=9'h020)&&(I_paddr<=9'h044)&&(I_paddr[1:0]==0);
    wire stats=(I_paddr>=9'h080)&&(I_paddr<=9'h11c)&&(I_paddr[1:0]==0);
    wire[3:0] gain_index=I_paddr[5:2]-4'd8;
    wire[3:0] stat_index=(I_paddr-9'h080)>>4;
    wire base_gains=SPATIAL_AUTO&&(I_paddr>=9'h140)&&(I_paddr<=9'h164)&&(I_paddr[1:0]==0);
    wire[3:0] base_index=(I_paddr-9'h140)>>2;
    wire read_ok=I_paddr==0||I_paddr==4||I_paddr==8||I_paddr==12||I_paddr==16||I_paddr==20||gains||stats||base_gains||(SPATIAL_AUTO&&I_paddr==9'h048);
    wire write_ok=I_paddr==24||I_paddr==28||(gains&&(!GLOBAL_ONLY||(gain_index==9)));
    assign O_pready=1'b1;
    assign O_pslverr=access&&(I_pwrite?!write_ok:!read_ok);
    always @*begin
        O_prdata=0;
        if(base_gains)O_prdata=I_base[base_index*32+:32];
        else if(gains)O_prdata=I_previous[(GLOBAL_ONLY?9:gain_index)*32+:32];
        else if(stats&&(!GLOBAL_ONLY||(stat_index==9)))case(I_paddr[3:2])
            0:O_prdata={8'd0,I_stats[(GLOBAL_ONLY?9:stat_index)*88+:24]};
            1:O_prdata={8'd0,I_stats[(GLOBAL_ONLY?9:stat_index)*88+24+:24]};
            2:O_prdata={8'd0,I_stats[(GLOBAL_ONLY?9:stat_index)*88+48+:24]};
            3:O_prdata={16'd0,I_stats[(GLOBAL_ONLY?9:stat_index)*88+72+:16]};
        endcase
        else case(I_paddr)
            0:O_prdata=32'h57420101;
            4:O_prdata={28'd0,rejected,fault,1'b0,pending};
            8:O_prdata=token;
            12:O_prdata={GAIN_MAX,GAIN_MIN};
            16:O_prdata={MIN_GLOBAL_U,MIN_LOCAL_U};
            20:O_prdata={21'd0,(SPATIAL_AUTO&&I_auto_job),GLOBAL_U,REQUIRE_U,
                        ((SPATIAL_AUTO&&!I_auto_job)?8'd0:SHIFT_U)};
            9'h048:O_prdata=SPATIAL_AUTO?DEADBAND:0;
            default:begin end
        endcase
    end
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            pending<=0;rejected<=0;fault<=0;staged_good<=0;token<=0;written<=0;elapsed<=0;
            staged_profile<={GROUPS{32'h10001000}};O_done<=0;O_good<=0;
        end else begin
            O_done<=0;
            if(I_start)begin token<=token+1'b1;pending<=1;written<=0;staged_good<=0;elapsed<=0;O_good<=0;end
            else if(pending&&(elapsed==TIMEOUT_CYCLES-1))begin pending<=0;fault<=1;O_done<=1;O_good<=0;end
            else begin
                if(pending)elapsed<=elapsed+1'b1;
                // Local write acceptance avoids feeding the read/error mux
                // back into every gain-register clock enable.
                if(access&&I_pwrite&&write_ok)begin
                    if(!pending)rejected<=1;
                    else if(gains)begin
                        staged_profile[(GLOBAL_ONLY?0:gain_index)*32+:32]<=I_pwdata;
                        written[GLOBAL_ONLY?0:gain_index]<=I_pwdata[15:0]>=GAIN_MIN&&I_pwdata[15:0]<=GAIN_MAX&&
                                              I_pwdata[31:16]>=GAIN_MIN&&I_pwdata[31:16]<=GAIN_MAX;
                    end else if(I_paddr==28)staged_good<=I_pwdata==1;
                    else if(I_paddr==24)begin
                        if(I_pwdata==token&&(!staged_good||(&written)))begin
                            pending<=0;O_done<=1;O_good<=staged_good;
                        end else rejected<=1;
                    end
                end
            end
        end
    end
endmodule
