`timescale 1ns/1ps
`include "../cnn/cnn_config.vh"
// Frozen head reader and single result bank. MCU owns threshold/top-8/NMS;
// FPGA retains the original 64-bit debug and compact 48-bit result layouts.
// The existing result CDC samples only O_done/publication, so a second result
// staging bank would waste registers without improving coherence.
module cnn_mcu_post #(
    parameter integer TRACKING_ENABLE=0,
    parameter integer TIMEOUT_CYCLES=750000
)(
    input I_clk,I_rst_n,I_start,
    input I_observation_enabled,
    input I_frame_mirror,
    input I_frame_tracking,
    input [31:0] I_observation_generation,I_frame_generation,
    output reg O_done,
    output [14:0] O_mem_addr,
    input [31:0] I_mem_data,
    input [2:0] I_rd_idx,
    output [63:0] O_rd_data,
    output reg[3:0] O_nbox,
    output [383:0] O_box_all,
    output [39:0] O_label_bcd,
    output reg [159:0] O_display,
    output reg O_spot_fresh,
    output reg O_fault,
    input[7:0] I_paddr,
    input I_psel,I_penable,I_pwrite,
    input[31:0] I_pwdata,
    output reg[31:0] O_prdata,
    output O_pready,O_pslverr
);
    reg pending,rejected,observation_fault;
    reg accepted_mirror;
    reg [31:0] accepted_token,accepted_seq;reg accepted_valid;
    reg [31:0] accepted_generation;
    reg[31:0] token;
    reg[8:0] head_index;
    reg[511:0] result_words;
    reg[15:0] written;
    reg[5:0] display_written;
    reg[3:0] staged_count;
    reg count_valid,staged_spot_fresh;
    reg[$clog2(TIMEOUT_CYCLES)-1:0] elapsed;
    wire access=I_psel&&I_penable;
    wire result_address=(I_paddr>=8'h20)&&(I_paddr<=8'h5c)&&(I_paddr[1:0]==0);
    wire[3:0] result_index=I_paddr[5:2]-4'd8;
    wire display_address=(I_paddr>=8'hc0)&&(I_paddr<=8'hd4)&&(I_paddr[1:0]==0);
    wire[2:0] display_index=(I_paddr-8'hc0)>>2;
    wire read_ok=I_paddr==8'hd8||I_paddr==0||I_paddr==4||I_paddr==8||I_paddr==12||I_paddr==16||I_paddr==20||I_paddr==24||result_address||I_paddr==8'h60||I_paddr==8'h64||I_paddr==8'h68||I_paddr==8'h6c||I_paddr==8'h70||I_paddr==8'h74||I_paddr==8'h78||I_paddr==8'h7c||display_address;
    wire write_ok=I_paddr==16||I_paddr==24||I_paddr==28||result_address||I_paddr==8'h60||I_paddr==8'h64||I_paddr==8'h68||I_paddr==8'h6c||I_paddr==8'h70||display_address;
    assign O_pready=1'b1;
    assign O_pslverr=access&&(I_pwrite?!write_ok:!read_ok);
    assign O_mem_addr=`CNN_FH_BASE_W+{6'd0,head_index};
    assign O_rd_data=result_words[I_rd_idx*64+:64];
    // Reuse the previously reserved low ten bits in result slots 0..3.
    // MCU stores X BCD[15:0], normal Y BCD[27:16], flipped Y BCD[39:28].
    // Defined score/class/box fields and the compact 48-bit layout are intact.
    assign O_label_bcd={result_words[192+:10],result_words[128+:10],
                        result_words[64+:10],result_words[0+:10]};
    genvar k;
    generate for(k=0;k<8;k=k+1)begin: packed_boxes
        assign O_box_all[k*48+:48]={2'b0,result_words[k*64+54+:2],
            result_words[k*64+43+:11],result_words[k*64+32+:11],
            result_words[k*64+21+:11],result_words[k*64+10+:11]};
    end endgenerate
    always @*begin
        O_prdata=0;
        if(result_address)O_prdata=result_words[result_index*32+:32];
        else if(display_address)begin
            case(display_index)
                0:O_prdata=O_display[31:0];1:O_prdata=O_display[63:32];2:O_prdata={15'd0,staged_spot_fresh,O_display[79:64]};
                3:O_prdata=O_display[111:80];4:O_prdata=O_display[143:112];5:O_prdata={16'd0,O_display[159:144]};
                default:O_prdata=0;
            endcase
        end else case(I_paddr)
            0:O_prdata=32'h43500101;
            4:O_prdata=TRACKING_ENABLE?{1'b1,24'd0,I_frame_tracking,I_frame_mirror,
                (I_frame_generation==I_observation_generation),rejected,O_fault,1'b0,pending}:
                {28'd0,rejected,O_fault,1'b0,pending};
            8:O_prdata=token;
            12:O_prdata={16'd480,8'd0,`CNN_OBJ_THRESH};
            16:O_prdata={23'd0,head_index};
            20:O_prdata=pending?I_mem_data:32'd0;
            24:O_prdata={28'd0,O_nbox};
            8'hd8:O_prdata={1'b1,I_observation_enabled,accepted_valid,
                (accepted_generation==I_observation_generation),27'd0,accepted_mirror};
            8'h60:O_prdata=accepted_token;
            8'h64:O_prdata=accepted_seq;
            8'h68:O_prdata={31'd0,accepted_valid};
            8'h6c:O_prdata={30'd0,observation_fault,I_observation_enabled};
            8'h70:O_prdata=1; // fixed model generation, no runtime model loading
            8'h74:O_prdata=I_observation_generation;
            8'h78:O_prdata=accepted_generation;
            // One acknowledged read contains identity, enable and capture
            // attribution. A stopped-clock CDC reply is zero, never valid.
            // Tokens are only matched against the latest software COMMIT;
            // the low sequence byte is used for deduplication within 1 s.
            8'h7c:O_prdata={1'b1,I_observation_enabled,accepted_valid,
                (accepted_generation==I_observation_generation),
                I_observation_generation[7:0],accepted_token[11:0],accepted_seq[7:0]};
            default:begin end
        endcase
    end
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            accepted_mirror<=0;
            accepted_token<=0;accepted_seq<=0;accepted_valid<=0;observation_fault<=0;accepted_generation<=0;
            pending<=0;rejected<=0;token<=0;head_index<=0;result_words<=0;
            written<=0;display_written<=0;O_display<=0;staged_count<=0;count_valid<=0;elapsed<=0;
            O_done<=0;O_nbox<=0;O_fault<=0;O_spot_fresh<=0;staged_spot_fresh<=0;
        end else begin
            O_done<=0;
            if(I_start)begin
                token<=token+1'b1;pending<=1;head_index<=0;written<=0;O_spot_fresh<=0;staged_spot_fresh<=0;
                result_words<=0;O_display<=0;display_written<=0;O_nbox<=0;count_valid<=0;elapsed<=0;
            end else if(pending&&(elapsed==TIMEOUT_CYCLES-1))begin
                pending<=0;O_done<=1;O_nbox<=0;O_spot_fresh<=0;staged_spot_fresh<=0;result_words<=0;O_display<=0;O_fault<=1;observation_fault<=1;
            end else begin
                if(pending)elapsed<=elapsed+1'b1;
                if(access)begin
                    if(!I_pwrite&&(I_paddr==20)&&pending&&(head_index<479))head_index<=head_index+1'b1;
                    if(I_pwrite&&write_ok)begin
                        if(!pending)rejected<=1;
                        else if(result_address)begin
                            result_words[result_index*32+:32]<=I_pwdata;written[result_index]<=1;
                        end else if(display_address)begin
                            display_written[display_index]<=1;
                            case(display_index)
                                0:O_display[31:0]<=I_pwdata;1:O_display[63:32]<=I_pwdata;
                                2:begin O_display[79:64]<=I_pwdata[15:0];staged_spot_fresh<=I_pwdata[16];end 3:O_display[111:80]<=I_pwdata;
                                4:O_display[143:112]<=I_pwdata;5:O_display[159:144]<=I_pwdata[15:0];
                                default:begin end
                            endcase
                        end else case(I_paddr)
                            16:if(I_pwdata<480)head_index<=I_pwdata[8:0];else rejected<=1;
                            24:begin staged_count<=I_pwdata[3:0];count_valid<=(I_pwdata<=8);end
                            // A legacy numerical-only submission displays no boxes. Once any
                            // display word is written, all six are required for atomic commit.
                            28:if(I_pwdata==token&&(&written)&&count_valid&&
                                  ((display_written==0)||(&display_written)))begin
                                pending<=0;O_nbox<=staged_count;O_done<=1;
                                O_spot_fresh<=staged_spot_fresh&&(&display_written)&&O_display[79]&&
                                    I_observation_enabled&&I_frame_tracking&&
                                    (I_frame_generation==I_observation_generation);
                                accepted_token<=token;accepted_seq<=accepted_seq+1'b1;accepted_valid<=1;observation_fault<=0;
                                accepted_generation<=I_frame_generation;accepted_mirror<=I_frame_mirror;
                            end else rejected<=1;
                            default:begin end
                        endcase
                    end
                end
            end
        end
    end
endmodule

