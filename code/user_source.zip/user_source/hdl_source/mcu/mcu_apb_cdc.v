`timescale 1ns/1ps
// One shared transaction bridge for the CNN/AWB CSI-clock peripherals.
// Bundles are held until the two-flop handshake acknowledges them. There is
// no second head/statistics RAM. A stopped CSI clock cannot monopolize AE's
// AHB port: timed-out transactions return zero and drain before reuse.
module mcu_apb_cdc #(
    parameter integer ADDR_W=10,
    parameter integer TIMEOUT_CYCLES=4096,
    // Optional local readback registers capture each slave's actual APB
    // transfer. Retire on the following clock; never repeat a slave write.
    parameter integer REGISTER_RESPONSE=0
)(
    input I_bus_clk,I_dst_clk,I_rst_n,
    input [ADDR_W-1:0] I_paddr,
    input I_psel,I_penable,I_pwrite,
    input [31:0] I_pwdata,
    output [31:0] O_prdata,
    output O_pready,O_pslverr,
    output [ADDR_W-1:0] O_paddr,
    output O_psel,O_penable,O_pwrite,
    output [31:0] O_pwdata,
    input [31:0] I_prdata,
    input I_pready,I_pslverr
);
    localparam IDLE=3'd0,WAIT_ACK=3'd1,REPLY=3'd2,FAILED=3'd3,DRAIN=3'd4;
    reg[2:0] state;
    reg request,abort_request;
    reg[ADDR_W+32:0] request_data;
    reg[31:0] reply_data;
    reg reply_error;
    reg[$clog2(TIMEOUT_CYCLES)-1:0] timeout_count;
    reg acknowledge;
    reg[31:0] response_data;
    reg response_error;
    (* async_reg="true" *) reg ack_meta,ack_sync;
    assign O_prdata=(state==REPLY)?reply_data:32'd0;
    assign O_pready=(state==REPLY)||(state==FAILED)||(state==DRAIN);
    assign O_pslverr=(state==REPLY)&&reply_error;
    always @(posedge I_bus_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin
            state<=IDLE;request<=0;request_data<=0;abort_request<=0;
            reply_data<=0;reply_error<=0;timeout_count<=0;ack_meta<=0;ack_sync<=0;
        end else begin
            ack_meta<=acknowledge;ack_sync<=ack_meta;
            case(state)
                IDLE:if(I_psel&&I_penable)begin
                    request_data<={I_pwrite,I_paddr,I_pwdata};
                    request<=~request;abort_request<=0;timeout_count<=0;state<=WAIT_ACK;
                end
                WAIT_ACK:if(ack_sync==request)begin
                    reply_data<=response_data;reply_error<=response_error;state<=REPLY;
                end else if(timeout_count==TIMEOUT_CYCLES-1)begin
                    abort_request<=1;state<=FAILED;
                end else timeout_count<=timeout_count+1'b1;
                REPLY:if(!I_psel||!I_penable)state<=IDLE;
                FAILED:if(!I_psel||!I_penable)state<=DRAIN;
                DRAIN:if((ack_sync==request)&&(!I_psel||!I_penable))state<=IDLE;
                default:state<=IDLE;
            endcase
        end
    end
    (* async_reg="true" *) reg req_meta,req_sync,abort_meta,abort_sync;
    reg[1:0] dst_state;
    reg[ADDR_W+32:0] dst_data;
    assign O_pwrite=dst_data[ADDR_W+32];
    assign O_paddr=dst_data[32+:ADDR_W];
    assign O_pwdata=dst_data[31:0];
    assign O_psel=(dst_state!=0)&&(!REGISTER_RESPONSE||(dst_state!=3))&&!abort_sync;
    assign O_penable=(dst_state==2)&&!abort_sync;
    // I_rst_n is released by the MCU bus clock domain. Releasing destination
    // state directly from it creates recovery/removal paths into every
    // response register. Assert immediately, release only after two local
    // clock edges; a stopped peripheral clock therefore stays in reset.
    (* async_reg="true" *) reg [1:0] dst_reset_release;
    wire S_dst_rst_n = dst_reset_release[1];
    always @(posedge I_dst_clk or negedge I_rst_n)begin
        if(!I_rst_n) dst_reset_release <= 2'b00;
        else dst_reset_release <= {dst_reset_release[0], 1'b1};
    end
    always @(posedge I_dst_clk or negedge S_dst_rst_n)begin
        if(!S_dst_rst_n)begin
            req_meta<=0;req_sync<=0;abort_meta<=0;abort_sync<=0;
            dst_state<=0;dst_data<=0;acknowledge<=0;response_data<=0;response_error<=0;
        end else begin
            req_meta<=request;req_sync<=req_meta;
            abort_meta<=abort_request;abort_sync<=abort_meta;
            case(dst_state)
                0:if(req_sync!=acknowledge)begin dst_data<=request_data;dst_state<=1;end
                1:dst_state<=2;
                2:if(abort_sync||I_pready)begin
                    if(REGISTER_RESPONSE&&!abort_sync)dst_state<=3;
                    else begin
                        response_data<=abort_sync?32'd0:I_prdata;
                        response_error<=!abort_sync&&I_pslverr;
                        acknowledge<=req_sync;dst_state<=0;
                    end
                end
                3:begin
                    response_data<=abort_sync?32'd0:I_prdata;
                    response_error<=!abort_sync&&I_pslverr;
                    acknowledge<=req_sync;dst_state<=0;
                end
                default:dst_state<=0;
            endcase
        end
    end
endmodule
