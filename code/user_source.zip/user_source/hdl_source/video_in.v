module video_in (
    input wire         I_rst_n,

    input wire         I_camera_clk,
    input wire         I_camera_frame_start,
    input wire         I_camera_valid,
    input wire[127:0]  I_camera_data,
    input wire         I_mipi_rx_error,
    input wire         I_flip_y,          // v0.8 P4: vertical flip (top <-> bottom)

    input wire         I_ddr_clk,

    input wire         I_display_pause,
    input wire         I_video_out_rd_busy,
    output wire        O_video_in_wr_busy,
    output reg[1:0]    O_video_out_rp,     ///读指针

    output reg         O_ddr_user_wr_en,
    output reg[24:0]   O_ddr_user_addr,
    output wire[127:0] O_ddr_user_wr_data,
    input wire         I_ddr_user_ready,
    // Passive observation of the exact pre-increment write-address branch.
    output wire        O_latency_start,
    output wire [1:0]  O_latency_slot,
    output wire        O_latency_flip
);

    wire        S_fifo_rst;
    reg         S_camera_frame_start_extend; ///脉冲展宽，同步到ddr_clk时钟域
    reg[3:0]    S_extend_cnt;
    reg         S_camera_frame_start_extend_1d;
    reg         S_camera_frame_start_extend_2d;
    reg         S_camera_frame_start_extend_3d;
    wire        S_frame_start;
    reg[1:0]    S_video_in_wp;       ///写指针
    wire[8:0]   S_fifo_rd_num;
    wire        S_fifo_rd_en;
    wire        S_fifo_rd_valid;
    wire[127:0] S_fifo_rd_data;
    reg         S_ddr_wr_valid;
    reg[9:0]    S_ddr_wr_cnt;

    localparam IMAGE_BASE_ADDR_0 = 25'd0;
    localparam IMAGE_BASE_ADDR_1 = 25'd7000000;
    localparam IMAGE_BASE_ADDR_2 = 25'd14000000;
    localparam IMAGE_BASE_ADDR_3 = 25'd21000000;

    // ==================================================================
    // v0.8 P4: vertical flip.
    //
    // One write burst is exactly one row - 1280 pixels * 24 bit / 128 bit =
    // 240 words, and the burst controller stops at S_ddr_wr_cnt == 239 - so
    // the vertical order can be reversed purely in the write address:
    //
    //   * start the frame at the last row (base + 719 * ROW_STRIDE)
    //   * at every row boundary replace the natural +8 step of the last word
    //     by a jump that lands on the previous row (delta = -ROW_STRIDE-1912
    //     = -3832 relative to the last word address)
    //
    // No frame store and no extra ERAM.  The state is synchronised from the
    // 24 MHz control domain and latched once per frame, so toggling the flip
    // can never tear a frame that is already being written.
    // ==================================================================
    localparam [24:0] ROW_STRIDE   = 25'd1920;      // 240 words * 8
    localparam [24:0] ROW_JUMP_BK  = 25'd3832;      // 2 * ROW_STRIDE - 8
    localparam [24:0] LAST_ROW_OFF = 25'd1380480;   // 719 * ROW_STRIDE

    reg [1:0] S_flip_y_sync;
    reg       S_flip_y_frame;

    // Column counter inside the row, clocked by the *write* enable so it is
    // aligned with the address register.  S_ddr_wr_cnt counts FIFO reads and
    // is therefore one word ahead of O_ddr_user_wr_en, which would shift the
    // row jump by one word.
    reg [7:0] S_col_word;

    // At the frame start the freshly synchronised value takes effect for the
    // frame that is beginning; for the rest of the frame the latched value is
    // used, so a change can never tear a frame in progress.
    wire S_flip_y_cur = S_frame_start ? S_flip_y_sync[1] : S_flip_y_frame;
    assign O_latency_start = S_frame_start;
    assign O_latency_slot = I_mipi_rx_error ? S_video_in_wp-2'd1 : S_video_in_wp;
    assign O_latency_flip = S_flip_y_cur;

    assign S_fifo_rst = S_camera_frame_start_extend_3d;

    // 以完整DDR写突发的占用标志仲裁，避免连续视频写入长期阻塞读通道。
    assign O_video_in_wr_busy = S_ddr_wr_valid;

    w128_d512_fifo U_w128_d512_fifo(
        .rst        ( S_fifo_rst         ),   

        .clkw       ( I_camera_clk       ),     
        .we         ( I_camera_valid     ),
        .di         ( I_camera_data      ),
        .afull      (),
        .full_flag  (),
        .wrusedw    (),
 
        .clkr       ( I_ddr_clk          ),
        .re         ( S_fifo_rd_en       ), 
        .dout       ( O_ddr_user_wr_data ),  
        .rdusedw    ( S_fifo_rd_num      ),
        .valid      (),
        .empty_flag (),
        .aempty     ()
    );


    always @(posedge I_camera_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_camera_frame_start_extend <= 1'b0;
        else
            if(I_camera_frame_start)
                S_camera_frame_start_extend <= 1'b1;
            else if(S_extend_cnt == 'd7)
                S_camera_frame_start_extend <= 1'b0;
            else
                S_camera_frame_start_extend <= S_camera_frame_start_extend;
    end

	
    always @ (posedge I_camera_clk) begin
    	if(S_camera_frame_start_extend)
        	S_extend_cnt <= S_extend_cnt + 'd1;
      	else
          	S_extend_cnt <= 'd0;
    end


    always @(posedge I_ddr_clk) begin
        S_camera_frame_start_extend_1d <= S_camera_frame_start_extend;
        S_camera_frame_start_extend_2d <= S_camera_frame_start_extend_1d;
        S_camera_frame_start_extend_3d <= S_camera_frame_start_extend_2d;
    end

    assign S_frame_start = ~S_camera_frame_start_extend_3d & S_camera_frame_start_extend_2d;

	/*
		如果前一帧图像有误少行了，那么地址回退为之前的，覆盖有问题的那帧图像
	*/
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_video_in_wp <= 'd0;
        else
            if(I_display_pause)
                S_video_in_wp <= S_video_in_wp;
            else if(S_frame_start)
                begin
                    if(I_mipi_rx_error)
                        S_video_in_wp <= S_video_in_wp;
                    else
                        S_video_in_wp <= S_video_in_wp + 'd1;
                end
            else
                S_video_in_wp <= S_video_in_wp;
    end


    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            O_video_out_rp <= 'd0;
        else
            if(I_display_pause)
                O_video_out_rp <= O_video_out_rp;
            else if(S_frame_start)
                begin
                    case(S_video_in_wp)
                        'd0: O_video_out_rp <= 'd2;
                        'd1: O_video_out_rp <= 'd3;
                        'd2: O_video_out_rp <= 'd0;
                        'd3: O_video_out_rp <= 'd1;
                    endcase
                end
            else
                O_video_out_rp <= O_video_out_rp;
    end

    /*
        fifo的深度是512，实际的深度是510，因此需要注意每次读出的长度避免为256，否则连续两次读写会引起fifo读空，丢失数据
    */
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_ddr_wr_valid <= 1'b0;
        else
            if(S_ddr_wr_valid && I_ddr_user_ready && S_ddr_wr_cnt == 'd239)
                S_ddr_wr_valid <= 1'b0;
            else if(S_fifo_rd_num >= 'd240 && (!I_video_out_rd_busy) && (!S_fifo_rst))
                S_ddr_wr_valid <= 1'b1;
            else
                S_ddr_wr_valid <= S_ddr_wr_valid;
    end

    always @(posedge I_ddr_clk) begin
        if(S_ddr_wr_valid)
            begin
                if(I_ddr_user_ready)
                    S_ddr_wr_cnt <= S_ddr_wr_cnt + 'd1;
                else
                    S_ddr_wr_cnt <= S_ddr_wr_cnt;
            end
        else
            S_ddr_wr_cnt <= 'd0;
    end

    assign S_fifo_rd_en = S_ddr_wr_valid & I_ddr_user_ready;

    always @(posedge I_ddr_clk) begin
        O_ddr_user_wr_en <= S_fifo_rd_en;
    end

    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_col_word <= 8'd0;
        else if(S_frame_start)
            S_col_word <= 8'd0;
        else if(O_ddr_user_wr_en)
            S_col_word <= (S_col_word == 8'd239) ? 8'd0 : (S_col_word + 8'd1);
    end

    // vertical flip state: synchronise, then latch once per frame
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_flip_y_sync <= 2'b00;
        else
            S_flip_y_sync <= {S_flip_y_sync[0], I_flip_y};
    end

    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            S_flip_y_frame <= 1'b0;
        else if(S_frame_start)
            S_flip_y_frame <= S_flip_y_sync[1];
    end

	/*
		如果前一帧图像有误少行了，那么地址回退为之前的，覆盖有问题的那帧图像
	*/
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            O_ddr_user_addr <= 25'd0;
        end
        else
            if(S_frame_start && (!I_mipi_rx_error))
                begin
                    case(S_video_in_wp)
                        'd0: O_ddr_user_addr <= IMAGE_BASE_ADDR_0 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd1: O_ddr_user_addr <= IMAGE_BASE_ADDR_1 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd2: O_ddr_user_addr <= IMAGE_BASE_ADDR_2 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd3: O_ddr_user_addr <= IMAGE_BASE_ADDR_3 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                    endcase
                end
			else if(S_frame_start && I_mipi_rx_error)
				begin
                	case(S_video_in_wp)
                        'd0: O_ddr_user_addr <= IMAGE_BASE_ADDR_3 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd1: O_ddr_user_addr <= IMAGE_BASE_ADDR_0 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd2: O_ddr_user_addr <= IMAGE_BASE_ADDR_1 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                        'd3: O_ddr_user_addr <= IMAGE_BASE_ADDR_2 + (S_flip_y_cur ? LAST_ROW_OFF : 25'd0);
                    endcase
				end
            else if(O_ddr_user_wr_en)
                O_ddr_user_addr <= (S_flip_y_cur && (S_col_word == 8'd239))
                                  ? (O_ddr_user_addr - ROW_JUMP_BK)
                                  : (O_ddr_user_addr + 25'd8);
            else    
                O_ddr_user_addr <= O_ddr_user_addr;
    end

endmodule
