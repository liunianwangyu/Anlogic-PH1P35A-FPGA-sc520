/************************************************************\
**	Copyright (c) 2012-2024 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Mar 06 2025 10:18:38
**	TD version	:	6.1.126561
************************************************************/
`timescale 1ns/1ps
module blk_mem_gen_awb_delay_signal #(parameter ADDR_WIDTH = 10, parameter DATA_DEPTH = 1024, parameter DATA_WIDTH = 96)
(
  output  [DATA_WIDTH-1:0]                doa,
  input   [DATA_WIDTH-1:0]                dia,
  input   [ADDR_WIDTH-1:0]                addra,
  input                         wea,
  input                         clka,
  output  [DATA_WIDTH-1:0]                dob,
  input   [ADDR_WIDTH-1:0]                addrb,
  input                         clkb,
  input   [DATA_WIDTH-1:0]                dib,
  input                         web
);

  ram_f84573da5ab5
  #(
      .DATA_WIDTH_A(DATA_WIDTH),
      .ADDR_WIDTH_A(ADDR_WIDTH),
      .DATA_DEPTH_A(DATA_DEPTH),
      .DATA_WIDTH_B(DATA_WIDTH),
      .ADDR_WIDTH_B(ADDR_WIDTH),
      .DATA_DEPTH_B(DATA_DEPTH),
      .REGMODE_A("NOREG"),
      .WRITEMODE_A("NORMAL"),
      .RESETMODE_A("ASYNC"),
      .INIT_FILE("NONE"),
      .REGMODE_B("NOREG"),
      .FILL_ALL("NONE"),
      .WRITEMODE_B("READBEFOREWRITE"),
      .RESETMODE_B("ASYNC")
  )ram_f84573da5ab5_Inst
  (
      .doa(doa),
      .dia(dia),
      .addra(addra),
      .wea(wea),
      .clka(clka),
      .dob(dob),
      .addrb(addrb),
      .clkb(clkb),
      .dib(dib),
      .web(web)
  );
endmodule
