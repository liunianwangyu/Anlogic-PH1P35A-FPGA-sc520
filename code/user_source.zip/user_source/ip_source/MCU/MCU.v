/************************************************************\
**	Copyright (c) 2012-2024 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Jul 24 2024 17:43:05
**	TD template version: 6.2.168116; configured for SC520 v1.5
************************************************************/
`timescale 1ps/1ps 
module MCU
(
  input                         jtag_tck,
  input                         jtag_tms,
  input                         jtag_tdi,
  output                        jtag_tdo,
  input                         gpio0_in,
  output                        gpio0_out,
  output                        gpio0_dir,
  input                         gpio1_in,
  output                        gpio1_out,
  output                        gpio1_dir,
  input                         gpio2_in,
  output                        gpio2_out,
  output                        gpio2_dir,
  input                         gpio3_in,
  output                        gpio3_out,
  output                        gpio3_dir,
  input                         gpio4_in,
  output                        gpio4_out,
  output                        gpio4_dir,
  input                         gpio5_in,
  output                        gpio5_out,
  output                        gpio5_dir,
  input                         gpio6_in,
  output                        gpio6_out,
  output                        gpio6_dir,
  input                         gpio7_in,
  output                        gpio7_out,
  output                        gpio7_dir,
  output                        uart0_tx,
  input                         uart0_rx,
  output                        uart1_tx,
  input                         uart1_rx,
  output                        qspi1_clk,
  output                        qspi1_ss,
  input                         qspi1_d0_in,
  input                         qspi1_d1_in,
  input                         qspi1_d2_in,
  input                         qspi1_d3_in,
  output                        qspi1_d0_out,
  output                        qspi1_d1_out,
  output                        qspi1_d2_out,
  output                        qspi1_d3_out,
  output  [3:0]                 qspi1_dir,
  output                        ahb_clk,
  output  [1:0]                 htrans,
  output                        hwrite,
  output  [30:0]                haddr,
  output  [2:0]                 hsize,
  output  [2:0]                 hburst,
  output  [3:0]                 hprot,
  output                        hmastlock,
  output  [31:0]                hwdata,
  input   [31:0]                hrdata,
  input   [1:0]                 hresp,
  input                         hready,
  input                         apb_clk,
  input                         apb_rst,
  output  [19:0]                paddr,
  output                        psel,
  output                        penable,
  output                        pwrite,
  output  [31:0]                pwdata,
  output  [3:0]                 pstrobe,
  output  [2:0]                 pprot,
  input   [31:0]                prdata,
  input                         pready,
  input                         pslverr,
  input                         core_clk,
  input                         timer_clk,
  input                         core_reset,
  input                         por_reset,
  input                         nmi,
  input   [22:0]                clic_irq
);

  MCU_f9f874759a41
  #(
      .MCU_JTAG_SEL("0"),
      .MCU_RESET_VECTOR('h20E00000),
      .AHB_FREQ("100.0"),
      .QSPI_FREQ("50.0"),
      .MCU_DPLL_POST_DIV(4)
  )MCU_f9f874759a41_Inst
  (











































      .ahb_clk(ahb_clk),
      .htrans(htrans),
      .hwrite(hwrite),
      .haddr(haddr),
      .hsize(hsize),
      .hburst(hburst),
      .hprot(hprot),
      .hmastlock(hmastlock),
      .hwdata(hwdata),
      .hrdata(hrdata),
      .hresp(hresp),
      .hready(hready),












      .core_clk(core_clk),
      .timer_clk(timer_clk),
      .core_reset(core_reset),
      .por_reset(por_reset),
      .nmi(nmi),
      .clic_irq(clic_irq)
  );
endmodule
