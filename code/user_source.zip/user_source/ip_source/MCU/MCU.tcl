set_ip_property AHB_DIV 1 [get_cells {*u_MCU/MCU_f9f874759a41_Inst/PH1P_PHY_MCU_Inst}]
