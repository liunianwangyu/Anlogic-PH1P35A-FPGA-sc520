Anlogic proc_sys_reset 1.0, copied without RTL modifications from the installed
TD 6.2.168116 catalog:
G:/FPGAcontest/Application/TD/ip/depot/proc_sys_reset_1.0/proc_sys_reset/RTL/proc_sys_reset.v

The IP runs on the always-on 50 MHz board reference. Only soc_reset is consumed;
unused bus/peripheral sequencing and constant auxiliary input are optimized by
TD. EXTERNAL_RESET_PULSE_WIDTH=1 because the MCU already debounces KEY4 for
20 ms and ui_osd holds the request until the whole system resets. The vendor's
four-stage request synchronizer and reset release sequence remain intact.
The UI CSR accepts its exact reset command only while all switches are OFF
and KEY4 alone is pressed (I_button=4'b0111); KEY1..3 and chords cannot reset.

The sequencer drives the main PLL's reset input from the independent board
reference clock. Its pll_locked input is tied HIGH to avoid waiting for a PLL
held in reset. PLL lock still gates the original shared power-on reset tree;
no new timed cross-domain global reset fanout is added. MCU core/POR and AHB reset retain their
existing local two-stage release synchronizers. Camera power-up timing restarts
on the shared reset, with the existing >=1 ms low and >=5 ms startup wait.
